# FolkChat: Deep Sovereign Redesign, QR Contact Discovery & Instagram-Style Message Requests

FolkChat is receiving a comprehensive architectural upgrade to resolve QR contact discovery, eliminate one-way messaging bottlenecks via an Instagram-style Message Requests system, replace childish welcome boxes with an ultra-clean minimalist breathing emblem, and streamline offline mesh operation.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following key decisions have been aligned directly from user feedback:
> - **QR Code Discovery**: Scanning a peer QR code now immediately displays an interactive **Contact Profile Card** showing their avatar, display name, public key fingerprint, and security verification level, with explicit **Add Contact & Chat** confirmation.
> - **Incoming Messages from Unknown Peers**: Instead of silently dropping messages from peers who have not been added mutually, FolkChat now routes them into a dedicated, privacy-preserving **Message Requests** box (styled with a deep, mature Instagram-style aesthetic). Users can preview incoming messages and decide whether to **Accept** (promoting them to direct chats), **Decline/Delete**, or **Block**.
> - **Start Screen Redesign**: The three feature boxes on the Welcome screen have been completely removed. In their place is an **Ultra-Clean Typographic Layout with a Calm Breathing Emblem**—a serene pulsing sage/emerald crest with subtle depth, refined typography, and zero childish clutter.
> - **Offline Mesh Usability**: Enhanced offline routing with automatic local subnet socket discovery, instant offline test simulation, and clear visual indicators for store-and-forward outbox delivery.

---

## 1. Overview & Core Concept

- **What It Does**: FolkChat is an air-gapped, zero-knowledge, peer-to-peer and relayed encrypted messaging system. It allows two individuals to establish cryptographic communication over both cloud relays and completely offline local networks (Wi-Fi sockets and BLE GATT) without centralized accounts or phone numbers.
- **Target Audience / Persona**: Privacy-conscious individuals, journalists, and security practitioners who demand absolute sovereignty over their communications, crystal-clear control over incoming contacts, and a mature, calm aesthetic.
- **Key Value**: Eliminates the frustration of broken QR scans and missed messages while maintaining uncompromising zero-trust privacy through an Instagram-inspired message request intake model.

---

## 2. User Experience & Visual Design

### Key User Flows

#### Flow 1: Sovereign Onboarding (Clean Typographic & Breathing Emblem)
1. **Welcome Screen**:
   - The user opens FolkChat and is greeted by a deep, calm, cream-and-forest atmosphere.
   - At the focal point: A **Minimalist Breathing Emblem**—two softly overlapping organic shields with a gentle, breathing alpha glow animation (3-second cycle).
   - Below the emblem: Crisp typography (`"Welcome to FolkChat"` in deep forest green `#103D31`, followed by the minimalist manifesto: `"Private. Simple. Yours."`).
   - The three childish feature boxes are entirely gone, replaced by spacious margins and a single prominent forest-green pill button: **`Let's Start →`**.
2. **Name Setup**:
   - Smooth slide transition into the personalized name entry screen (`"What should we call you?"`).
   - Clean outlined input field, auto-focus, character counter, whitespace trimming, and validation.
   - Tapping **`Continue →`** seeds the local cryptographic identity and transitions directly into Chats.

#### Flow 2: QR Code Scan & Contact Confirmation Card
1. User taps the QR scanner button from either the Top Bar or the People tab.
2. In-app camera viewfinder displays with high-contrast corner brackets and an optional flashlight toggle.
3. Enhanced multi-format parsing handles `sc1:hex:name`, `folkchat://...`, and raw public keys, with landscape/portrait camera rotation auto-correction and an inline "Paste Code / Test QR" utility.
4. When a QR code is detected:
   - A modal **Contact Profile Card** slides up from the bottom.
   - Shows contact avatar with initials, display name, 12-digit security fingerprint (`#### #### ####`), and truncated public key.
   - User reviews the identity and taps **`Add Contact & Chat`** (or **`Dismiss`**).
   - The contact is saved in the local vault and the direct conversation opens immediately.

#### Flow 3: Incoming Messages & Instagram-Style Message Requests Box
1. Peer Alice sends an encrypted message to Bob. Bob has not added Alice yet.
2. Previously, Bob's device silently dropped the message.
3. **New Flow**:
   - Bob's routing layer decrypts the payload with his private key.
   - Recognizing an unknown sender, Bob's vault creates a **Message Request**.
   - On Bob's Chats tab, a sleek, deep pill card appears above conversations:
     `✉ Message Requests • 1 new request`
   - Bob taps the pill to enter the **Requests Box**:
     - Lists all incoming requests from peers not yet in his contacts.
     - Displays sender snippet, timestamp, and message preview.
   - Bob taps a request to inspect the thread in a safe preview mode with a bottom action bar:
     - **Accept**: Adds Alice to Bob's contacts, unlocks full two-way chat, and moves the thread to the main Inbox.
     - **Delete**: Wipes the message and removes the request.
     - **Block**: Prevents future messages from this public key.

#### Flow 4: Effortless Dual-Mode (Online & Offline Mesh)
1. User can switch connection policies in the Profile Hub (`AUTO_FALLBACK`, `FORCE_ONLINE`, `FORCE_OFFLINE`).
2. When offline or air-gapped:
   - The header displays a calming status: `"Offline Mode • Local Mesh Active"`.
   - Messages sent to nearby peers transmit directly over Wi-Fi sockets or BLE GATT.
   - If the recipient is not yet in wireless proximity, messages queue safely in the encrypted outbox with status badge `"Queued for Mesh"`.
   - Outbox automatically flushes the moment the peer is discovered or internet is restored.

### Visual Identity & Theme Tokens

- **Dominant Palette**:
  - Primary Forest Green: `#174A3A` (primary buttons, active tabs, outgoing message bubbles)
  - Deep Forest Green: `#103D31` (emblem strokes, high-contrast headings, card borders)
  - Secondary Sage Green: `#92AD96` (accents, breathing glow, secondary badges)
  - Light Sage Background: `#E4EBDD` (soft secondary surfaces)
  - Warm Ivory: `#F7F5EA` (primary screen background, chat canvas)
  - Card Surface: `#F0F0E4` (elevated cards, request items, search bars)
  - Primary Text: `#18372E`
  - Secondary Text: `#728277`
- **Atmosphere**: Deep, organic, trustworthy, matte finish without harsh neon or shiny gold.

---

## 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Approach | Rationale & Trade-Offs |
| :--- | :--- | :--- |
| **Unknown Sender Handling** | Instagram-Style Message Requests Box | Balances spam protection with frictionless discovery. Dropping messages caused broken communication when both users hadn't mutually added each other beforehand. Storing in Requests keeps user inbox clean while ensuring no messages are lost. |
| **QR Code Result Action** | Contact Profile Card Confirmation | Users requested explicit confirmation before adding. Displaying the profile card with security fingerprint builds cryptographic trust and lets the user review the peer's identity before saving. |
| **Welcome Screen Aesthetic** | Typographic Minimalism + Breathing Emblem | Replaces cluttered 3 feature cards with an elegant breathing emblem. Produces a mature, high-end first impression matching modern privacy-focused software (Signal, Proton). |
| **Offline Peer Discovery** | Multi-Interface UDP Broadcast + Loopback / Test Simulation | Ensures offline mode works reliably on local Wi-Fi networks, while providing built-in test utilities for single-device verification in emulators. |

---

## 4. Technical Architecture & Data Strategy

### System Component Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                          FolkChat Mobile UI                            │
├─────────────────┬───────────────────┬──────────────────────────────────┤
│  WelcomeScreen  │ ConversationsTab  │        ChatScreen & Radar        │
│ (Breathing Logo │ (Inbox, Requests  │ (E2EE Chat, Transport Badges,    │
│  & Name Setup)  │  Box, Profile)    │  Live Connection Header)         │
└────────┬────────┴─────────┬─────────┴─────────────────┬────────────────┘
         │                  │                           │
         ▼                  ▼                           ▼
┌────────────────────────────────────────────────────────────────────────┐
│                              ChatViewModel                             │
│  - addContactFromQrCode / confirmContactAdd                            │
│  - messageRequests: StateFlow<List<MessageRequest>>                    │
│  - acceptRequest / declineRequest / blockPeer                          │
│  - toggleSimulatedOffline / setRoutingPolicy                           │
└────────┬──────────────────────────────────────────────┬────────────────┘
         │                                              │
         ▼                                              ▼
┌──────────────────────────────────┐   ┌─────────────────────────────────┐
│          EncryptedVault          │   │       TransportCoordinator      │
│ - Identity KeyPair (X25519)      │   │ - Outbox Worker & Flush Loop    │
│ - Contacts & Blocked Keys        │   │ - Dual-Mode Dispatcher          │
│ - Messages (Delivered / Queued)  │   │ - Incoming Payload Classifier   │
│ - MessageRequests (Pending store)│   │   (Accepted Contact vs Request) │
└──────────────────────────────────┘   └────────┬───────┬───────┬────────┘
                                                │       │       │
                     ┌──────────────────────────┘       │       └──────────────────────────┐
                     ▼                                  ▼                                  ▼
      ┌─────────────────────────────┐    ┌─────────────────────────────┐    ┌─────────────────────────────┐
      │     OnlineRelayManager      │    │        SocketManager        │    │         BleManager          │
      │  (Cloud E2EE Zero-Knowledge │    │  (Offline LAN / Wi-Fi UDP   │    │  (Offline Bluetooth Low     │
      │   Relay Dispatch & Sub)     │    │   Discovery & TCP Sockets)  │    │   Energy GATT Mesh Link)    │
      └─────────────────────────────┘    └─────────────────────────────┘    └─────────────────────────────┘
```

### Data Model & State Additions

1. **`MessageRequest` Model**:
   - `peerPubKeyHex: String`
   - `peerDisplayName: String`
   - `lastMessageText: String`
   - `timestampMs: Long`
   - `messageCount: Int`
   - `status: RequestStatus (PENDING, ACCEPTED, REJECTED, BLOCKED)`
2. **`EncryptedVault` Extensions**:
   - `getMessageRequests(): List<MessageRequest>`
   - `saveMessageRequest(request: MessageRequest)`
   - `acceptMessageRequest(peerPubKeyHex: String, customName: String?)`
   - `declineMessageRequest(peerPubKeyHex: String)`
   - `blockPublicKey(peerPubKeyHex: String)`
   - `isBlocked(peerPubKeyHex: String): Boolean`
3. **`QrScannerView` & Parsing Enhancements**:
   - Camera image proxy rotation handling.
   - Robust regex and URI schema parsing for FolkChat QR codes.
   - Immediate emission of scanned data to the `ContactConfirmationDialog`.
