package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.EncryptedVault
import com.example.data.MessageStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FolkChat", appName)
    }

    @Test
    fun `test vault persistence and outbox`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vault = EncryptedVault(context)

        val identity = vault.getIdentityKeyPair()
        assertNotNull(identity.publicKeyHex)
        assertEquals(64, identity.publicKeyHex.length)

        val contact = Contact(
            id = "test-peer",
            displayName = "Bob Test",
            x25519PublicKeyHex = "aabbccddeeff00112233445566778899aabbccddeeff00112233445566778899"
        )
        vault.addOrUpdateContact(contact)

        val contacts = vault.getContacts()
        assertTrue(contacts.any { it.displayName == "Bob Test" })

        val message = ChatMessage(
            id = "msg-1",
            conversationPeerPubKeyHex = contact.x25519PublicKeyHex,
            senderPubKeyHex = identity.publicKeyHex,
            recipientPubKeyHex = contact.x25519PublicKeyHex,
            content = "Testing vault outbox queue",
            status = MessageStatus.QUEUED
        )
        vault.saveMessage(message)

        val outbox = vault.getQueuedOutbox()
        assertEquals(1, outbox.size)
        assertEquals("msg-1", outbox[0].id)

        vault.updateMessageStatus("msg-1", MessageStatus.DELIVERED)
        val updatedOutbox = vault.getQueuedOutbox()
        assertEquals(0, updatedOutbox.size)
    }
}
