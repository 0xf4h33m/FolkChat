package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.crypto.CryptoEngine
import com.example.data.Contact
import com.example.service.SecureChatForegroundService
import com.example.ui.ChatViewModel
import com.example.ui.components.AddContactDialog
import com.example.ui.components.ContactConfirmationDialog
import com.example.ui.components.ContactProfileDialog
import com.example.ui.components.LinkDiagnosticsDialog
import com.example.ui.components.MyCodeDialog
import com.example.ui.components.QrScannerDialog
import com.example.ui.screens.ActiveCallScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.LockScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : FragmentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Deep link: open a conversation straight from a notification.
        val openPeerKey = intent?.getStringExtra(SecureChatForegroundService.EXTRA_OPEN_PEER)
        if (!openPeerKey.isNullOrBlank()) {
            viewModel.openConversationByPubKey(openPeerKey)
        }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val settings by viewModel.settings.collectAsState()

            // Screenshot protection (FLAG_SECURE): hides content in the app
            // switcher and blocks screen capture when enabled.
            LaunchedEffect(settings.screenshotProtection) {
                if (settings.screenshotProtection) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            MyApplicationTheme(themeMode = themeMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FolkChatAppContent(viewModel, this@MainActivity)
                }
            }
        }
    }
}

@Composable
fun FolkChatAppContent(viewModel: ChatViewModel, activity: FragmentActivity) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val contacts by viewModel.contacts.collectAsState()
    val allMessages by viewModel.allMessages.collectAsState()
    val activeContact by viewModel.activeContact.collectAsState()
    val activeMessages by viewModel.activeConversationMessages.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()
    val isServiceRunning by viewModel.isServiceRunning.collectAsState()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val typingPeers by viewModel.typingPeers.collectAsState()
    val callSession by viewModel.callManager.session.collectAsState()
    val isLocked by viewModel.appLock.locked.collectAsState()

    var showMyCodeDialog by remember { mutableStateOf(false) }
    var showAddContactDialog by remember { mutableStateOf(false) }
    var showContactProfileContact by remember { mutableStateOf<Contact?>(null) }
    var showDiagnosticsDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var contactConfirmationCandidate by remember { mutableStateOf<Pair<String, String>?>(null) }

    // App-lock lifecycle wiring (auto-lock after backgrounding).
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> viewModel.appLock.onAppStopped(activity)
                Lifecycle.Event.ON_START -> viewModel.appLock.onAppResumed()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Permissions: Bluetooth, notifications, camera, microphone.
    val requiredPermissions = remember {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        list.add(Manifest.permission.CAMERA)
        list.add(Manifest.permission.RECORD_AUDIO)
        list
    }

    var hasRequestedPermissions by remember { mutableStateOf(false) }
    var permissionsGranted by remember {
        mutableStateOf(
            requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        permissionsGranted = results.values.all { it }
        if (permissionsGranted) viewModel.startBackgroundService()
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showQrScannerDialog = true
        else Toast.makeText(context, "Camera permission needed to scan QR codes", Toast.LENGTH_SHORT).show()
    }

    fun openQrScannerWithPermissionCheck() {
        val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (hasCamera) showQrScannerDialog = true else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    LaunchedEffect(Unit) {
        if (!permissionsGranted && !hasRequestedPermissions) {
            hasRequestedPermissions = true
            permissionLauncher.launch(requiredPermissions.toTypedArray())
        }
    }

    // App Lock overlay takes absolute priority — gates everything.
    if (settings.appLockEnabled && isLocked) {
        LockScreen(appLock = viewModel.appLock, activity = activity, onUnlocked = { viewModel.appLock.unlock() })
        return
    }

    if (!isOnboardingCompleted) {
        WelcomeScreen(
            initialName = viewModel.displayName.collectAsState().value,
            onStartWithName = { name -> viewModel.completeOnboardingWithName(name) }
        )
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            if (!permissionsGranted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Links, calls & media need permissions",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Bluetooth builds links; camera & microphone enable calls and voice notes.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { permissionLauncher.launch(requiredPermissions.toTypedArray()) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(start = 6.dp)
                        ) {
                            Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            if (activeContact != null) {
                ChatScreen(
                    contact = activeContact!!,
                    messages = activeMessages,
                    peers = discoveredPeers,
                    isInternetAvailable = isInternetAvailable,
                    onSendMessage = { text -> viewModel.sendMessage(text) },
                    onSendMessageWithMeta = { text, replyId, replyPreview, replySender ->
                        viewModel.sendMessage(text, replyId, replyPreview, replySender)
                    },
                    onDeleteMessage = { msgId -> viewModel.deleteMessageLocally(msgId) },
                    onEditMessage = { msgId, text -> viewModel.editMessage(msgId, text) },
                    onDeleteForEveryone = { msgId -> viewModel.deleteMessageForEveryone(msgId) },
                    onTogglePin = { msgId -> viewModel.togglePin(msgId) },
                    onToggleReaction = { msgId, emoji -> viewModel.toggleReaction(msgId, emoji) },
                    onSendAttachment = { attachment, caption -> viewModel.sendMediaAttachment(attachment, caption) },
                    onCancelTransfer = { msgId -> viewModel.cancelMediaTransfer(msgId) },
                    onRetryTransfer = { msgId -> viewModel.retryMediaTransfer(msgId) },
                    resolveLocalFile = { attachment -> viewModel.resolveMediaFile(attachment) },
                    onOpenContactProfile = { showContactProfileContact = activeContact },
                    onBack = { viewModel.selectContact(null) },
                    onStartCall = { contact, isVideo -> viewModel.startCall(contact, isVideo) },
                    // v2
                    contactsForForward = contacts,
                    onToggleStar = { msgId -> viewModel.toggleStar(msgId) },
                    onForward = { msgId, toKey -> viewModel.forwardMessage(msgId, toKey) },
                    onConsumeView = { msgId -> viewModel.consumeViewLimitedMedia(msgId) },
                    onSetDisappearTimer = { timer -> activeContact?.let { viewModel.setDisappearTimer(it, timer) } },
                    onTypingSignal = { viewModel.sendTypingSignal() },
                    isPeerTyping = viewModel.isPeerTyping(activeContact),
                    peerLastReadMs = activeContact?.peerLastReadMs ?: 0L,
                    readReceiptsEnabled = settings.readReceipts,
                    compactChat = settings.compactChat
                )
            } else {
                ConversationsScreen(
                    viewModel = viewModel,
                    onOpenMyCode = { showMyCodeDialog = true },
                    onOpenAddContact = { showAddContactDialog = true },
                    onOpenDiagnostics = { showDiagnosticsDialog = true },
                    onOpenContactProfile = { contact -> showContactProfileContact = contact }
                )
            }
        }
    }

    // Live call overlay — driven entirely by the real CallManager.
    if (callSession != null) {
        ActiveCallScreen(
            callManager = viewModel.callManager,
            onClose = { /* session clears itself */ }
        )
    }

    if (showQrScannerDialog) {
        QrScannerDialog(
            onQrCodeDetected = { qrContent ->
                val parsed = CryptoEngine.parseContactCode(qrContent)
                showQrScannerDialog = false
                if (parsed != null) contactConfirmationCandidate = parsed
                else Toast.makeText(context, "Unrecognized FolkChat QR code format", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showQrScannerDialog = false }
        )
    }

    if (contactConfirmationCandidate != null) {
        val candidate = contactConfirmationCandidate!!
        ContactConfirmationDialog(
            scannedPubKeyHex = candidate.first,
            initialDisplayName = candidate.second,
            onConfirmAdd = { name, key ->
                val contact = viewModel.confirmAddContact(key, name)
                contactConfirmationCandidate = null
                Toast.makeText(context, "Connected with ${contact.displayName}", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { contactConfirmationCandidate = null }
        )
    }

    if (showContactProfileContact != null) {
        ContactProfileDialog(
            contact = showContactProfileContact!!,
            myPubKey = viewModel.identity.collectAsState().value.publicKey,
            onDeleteContact = {
                viewModel.deleteContact(showContactProfileContact!!.x25519PublicKeyHex)
                showContactProfileContact = null
            },
            onClearChat = {
                viewModel.clearChatHistory(showContactProfileContact!!.x25519PublicKeyHex)
                showContactProfileContact = null
                Toast.makeText(context, "Chat history deleted", Toast.LENGTH_SHORT).show()
            },
            onBlockContact = {
                viewModel.blockPeer(
                    showContactProfileContact!!.x25519PublicKeyHex,
                    showContactProfileContact!!.displayName
                )
                showContactProfileContact = null
                Toast.makeText(context, "Peer blocked", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showContactProfileContact = null }
        )
    }

    if (showMyCodeDialog) {
        MyCodeDialog(
            identity = viewModel.identity.collectAsState().value,
            displayName = viewModel.displayName.collectAsState().value,
            onUpdateName = { newName -> viewModel.updateDisplayName(newName) },
            onDismiss = { showMyCodeDialog = false }
        )
    }

    if (showAddContactDialog) {
        AddContactDialog(
            onAddContact = { code, name -> viewModel.addContact(code, name) },
            onOpenQrScanner = { openQrScannerWithPermissionCheck() },
            onDismiss = { showAddContactDialog = false }
        )
    }

    if (showDiagnosticsDialog) {
        LinkDiagnosticsDialog(
            peers = discoveredPeers,
            isServiceRunning = isServiceRunning,
            onToggleService = { enable ->
                if (enable) viewModel.startBackgroundService() else viewModel.stopBackgroundService()
            },
            onFlushOutbox = { viewModel.triggerOutboxFlush() },
            onAddManualIp = { ip ->
                viewModel.registerManualPeer(ip)
                Toast.makeText(context, "Direct link registered to $ip", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showDiagnosticsDialog = false }
        )
    }
}
