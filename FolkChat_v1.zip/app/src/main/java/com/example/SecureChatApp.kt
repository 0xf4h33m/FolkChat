package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import com.example.data.EncryptedVault
import com.example.net.transport.TransportCoordinator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SecureChatApp : Application(), ImageLoaderFactory {
    companion object {
        const val CHANNEL_SERVICE_ID = "securechat_link_service"
        const val CHANNEL_MESSAGES_ID = "securechat_messages"
        const val CHANNEL_CALLS_ID = "securechat_calls"

        lateinit var instance: SecureChatApp
            private set
    }

    lateinit var vault: EncryptedVault
        private set

    lateinit var transportCoordinator: TransportCoordinator
        private set

    lateinit var callManager: com.example.net.call.CallManager
        private set

    lateinit var appLockManager: com.example.ui.security.AppLockManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        vault = EncryptedVault(this)
        transportCoordinator = TransportCoordinator(this, vault)
        callManager = com.example.net.call.CallManager(
            context = this,
            vault = vault,
            signalSender = { peer, json -> transportCoordinator.dispatchEncryptedJson(peer, json) }
        )
        appLockManager = com.example.ui.security.AppLockManager(vault, this)

        // Cold-start enforcement: if App Lock is enabled, the app must be gated
        // from the very first frame after process death.
        appLockManager.onAppCreated()

        // Restore persisted routing policy.
        try {
            val persisted = com.example.data.RoutingPolicy.valueOf(vault.getRoutingPolicyName())
            transportCoordinator.routingEngine.setRoutingPolicy(persisted)
        } catch (e: Exception) {
            // keep default AUTO_FALLBACK
        }

        CoroutineScope(Dispatchers.IO).launch {
            transportCoordinator.onCallSignal.collect { signal -> callManager.onSignal(signal) }
        }

        createNotificationChannels()
    }

    /** Global image loader with animated GIF support (view-once/GIF sending). */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components {
                if (Build.VERSION.SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .crossfade(true)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE_ID,
                "FolkChat Mesh Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps BLE and local link listening in background"
                setShowBadge(false)
            }

            val messagesChannel = NotificationChannel(
                CHANNEL_MESSAGES_ID,
                "FolkChat Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for incoming peer messages"
                enableVibration(true)
                setShowBadge(true)
            }

            val callsChannel = NotificationChannel(
                CHANNEL_CALLS_ID,
                "FolkChat Calls",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming call alerts"
                enableVibration(true)
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(serviceChannel)
            notificationManager.createNotificationChannel(messagesChannel)
            notificationManager.createNotificationChannel(callsChannel)
        }
    }
}
