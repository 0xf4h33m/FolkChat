package com.example.net.routing

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import com.example.data.ActiveRouteType
import com.example.data.DiscoveredPeer
import com.example.data.RoutingPolicy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * FolkChat Secure Routing Engine
 *
 * Implements dual-mode hybrid routing:
 * - Online Mode: Dispatches end-to-end encrypted packets over internet cloud relays
 * - Offline Mode: Automatically falls back to direct P2P (Wi-Fi Direct / local LAN sockets and BLE GATT mesh)
 * - Offline Queue: Zero-knowledge store-and-forward in encrypted vault when peer is out of range
 */
class RoutingEngine(private val context: Context) {
    companion object {
        private const val TAG = "RoutingEngine"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isInternetAvailable = MutableStateFlow(checkInitialConnectivity())
    val isInternetAvailable: StateFlow<Boolean> = _isInternetAvailable.asStateFlow()

    private val _networkTypeName = MutableStateFlow(getInitialNetworkTypeName())
    val networkTypeName: StateFlow<String> = _networkTypeName.asStateFlow()

    private val _routingPolicy = MutableStateFlow(RoutingPolicy.AUTO_FALLBACK)
    val routingPolicy: StateFlow<RoutingPolicy> = _routingPolicy.asStateFlow()

    // Simulated network override (for testing in airgap/offline or emulator)
    private var simulatedOffline: Boolean = false

    init {
        registerNetworkCallback()
    }

    private fun checkInitialConnectivity(): Boolean {
        if (connectivityManager == null) return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun getInitialNetworkTypeName(): String {
        if (connectivityManager == null) return "Offline"
        val activeNetwork = connectivityManager.activeNetwork ?: return "Offline"
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi (Online)"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular (Online)"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet (Online)"
            else -> "Connected"
        }
    }

    private fun registerNetworkCallback() {
        if (connectivityManager == null) return
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            connectivityManager.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val caps = connectivityManager.getNetworkCapabilities(network)
                    val typeName = when {
                        caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi (Online)"
                        caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Cellular (Online)"
                        else -> "Internet (Online)"
                    }
                    scope.launch {
                        _isInternetAvailable.value = !simulatedOffline
                        _networkTypeName.value = if (simulatedOffline) "Simulated Offline" else typeName
                    }
                }

                override fun onLost(network: Network) {
                    scope.launch {
                        _isInternetAvailable.value = false
                        _networkTypeName.value = "Offline (Airgap)"
                    }
                }
            })
        } catch (e: Exception) {
            Log.w(TAG, "Failed registering network callback: ${e.message}")
        }
    }

    fun setRoutingPolicy(policy: RoutingPolicy) {
        _routingPolicy.value = policy
    }

    fun toggleSimulatedOffline() {
        simulatedOffline = !simulatedOffline
        if (simulatedOffline) {
            _isInternetAvailable.value = false
            _networkTypeName.value = "Simulated Offline (Airgap Mode)"
        } else {
            _isInternetAvailable.value = checkInitialConnectivity()
            _networkTypeName.value = getInitialNetworkTypeName()
        }
    }

    fun isSimulatedOffline(): Boolean = simulatedOffline

    /**
     * Determine best secure route for recipient based on:
     * 1. Active Routing Policy
     * 2. Live Internet Reachability
     * 3. Discovered Peer Proximity (Wi-Fi Socket or BLE GATT)
     */
    fun resolveRoute(
        recipientPubKeyHex: String,
        discoveredPeers: List<DiscoveredPeer>,
        expectedRotatingTagHex: String
    ): ActiveRouteType {
        val policy = _routingPolicy.value
        val hasInternet = _isInternetAvailable.value && !simulatedOffline

        // 1. If forced offline: strictly use direct peer proximity or store-and-forward
        if (policy == RoutingPolicy.FORCE_OFFLINE) {
            return resolveOfflineLocalRoute(discoveredPeers, expectedRotatingTagHex)
        }

        // 2. If online relay is forced:
        if (policy == RoutingPolicy.FORCE_ONLINE) {
            return if (hasInternet) ActiveRouteType.ONLINE_RELAY else ActiveRouteType.OFFLINE_STORE_AND_FORWARD
        }

        // 3. AUTO_FALLBACK:
        // If internet is available, prefer Online Relay for global reach
        if (hasInternet) {
            return ActiveRouteType.ONLINE_RELAY
        }

        // Internet is NOT available: automatically fallback to Offline local links!
        return resolveOfflineLocalRoute(discoveredPeers, expectedRotatingTagHex)
    }

    private fun resolveOfflineLocalRoute(
        discoveredPeers: List<DiscoveredPeer>,
        expectedRotatingTagHex: String
    ): ActiveRouteType {
        val matchingPeer = discoveredPeers.firstOrNull { p ->
            p.tagHex.equals(expectedRotatingTagHex, ignoreCase = true) ||
            (p.tagHex.length >= 16 && expectedRotatingTagHex.startsWith(p.tagHex, ignoreCase = true)) ||
            (expectedRotatingTagHex.length >= 16 && p.tagHex.startsWith(expectedRotatingTagHex.take(16), ignoreCase = true)) ||
            (p.linkType == "WIFI_SOCKET" && p.tagHex == "manual")
        }

        return when {
            matchingPeer == null -> ActiveRouteType.OFFLINE_STORE_AND_FORWARD
            matchingPeer.linkType == "WIFI_SOCKET" -> ActiveRouteType.OFFLINE_DIRECT_WIFI
            matchingPeer.linkType == "BLE_GATT" -> ActiveRouteType.OFFLINE_BLE_MESH
            else -> ActiveRouteType.OFFLINE_STORE_AND_FORWARD
        }
    }
}
