package com.example.net.call

import com.example.data.CallType

/** Call signaling types exchanged over the encrypted P2P transport. */
enum class CallSignalType {
    OFFER,
    RINGING,
    ACCEPT,
    REJECT,
    BUSY,
    END,
    ICE
}

/**
 * A call signaling message received from a remote peer.
 * [payload] carries type-specific data such as the responder's LAN address.
 */
data class IncomingCallSignal(
    val callId: String,
    val type: CallSignalType,
    val callType: CallType,
    val senderPubKeyHex: String,
    val senderDisplayName: String,
    val payload: Map<String, String> = emptyMap()
)
