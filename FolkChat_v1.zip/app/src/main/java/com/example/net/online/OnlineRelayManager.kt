package com.example.net.online

import android.content.Context
import android.util.Base64
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.EncryptedVault
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Online Secure Cloud Relay Transport — REAL WebSocket client.
 *
 * Connects to a zero-knowledge relay over a WebSocket. The relay only ever sees
 * opaque, end-to-end encrypted X25519 + ChaCha20-Poly1305 envelopes; it can
 * neither decrypt nor forge message content.
 *
 * Wire protocol (JSON text frames):
 *   client -> server: {"type":"subscribe","key":"<my pubKey hex>"}
 *   client -> server: {"type":"envelope","to":"<pubKey hex>","payload":"<base64 envelope>"}
 *   server -> client: {"type":"envelope","from":"<pubKey hex>","payload":"<base64 envelope>"}
 *
 * Optional Tor routing: when enabled (OFF by default), every relay connection is
 * tunneled through the local Tor SOCKS proxy exposed by Orbot (127.0.0.1:9050).
 */
class OnlineRelayManager(
    private val context: Context,
    private val vault: EncryptedVault? = null
) {
    companion object {
        private const val TAG = "OnlineRelayManager"
        const val TOR_SOCKS_HOST = "127.0.0.1"
        const val TOR_SOCKS_PORT = 9050
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _incomingPayloads = MutableSharedFlow<ByteArray>(extraBufferCapacity = 128)
    val incomingPayloads: SharedFlow<ByteArray> = _incomingPayloads.asSharedFlow()

    private var myPubKeyHex: String? = null
    private val webSocketRef = AtomicReference<WebSocket?>(null)
    private var client: OkHttpClient? = null
    private var clientBuiltForTor: Boolean = false
    private var reconnectJob: kotlinx.coroutines.Job? = null
    @Volatile private var shouldRun = false

    /** Reads the relay URL from settings when a vault is attached. */
    private fun relayUrl(): String = vault?.getSettings()?.relayUrl?.trim().orEmpty()

    private fun torEnabled(): Boolean = vault?.getSettings()?.torRoutingEnabled ?: false

    /** True when the Tor SOCKS proxy (Orbot) is reachable on this device. */
    fun isTorProxyReachable(): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(TOR_SOCKS_HOST, TOR_SOCKS_PORT), 1200)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun start(publicKey: ByteArray) {
        val pubHex = CryptoEngine.bytesToHex(publicKey).lowercase()
        myPubKeyHex = pubHex
        shouldRun = true
        connect()
    }

    private fun buildClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS) // WebSocket stays open
            .writeTimeout(15, TimeUnit.SECONDS)
            .pingInterval(25, TimeUnit.SECONDS)
        if (torEnabled()) {
            // Route the entire relay connection through the Tor network via Orbot's
            // local SOCKS proxy. The relay only ever sees a Tor exit address.
            builder.proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress(TOR_SOCKS_HOST, TOR_SOCKS_PORT)))
        } else {
            builder.proxy(Proxy.NO_PROXY)
        }
        return builder.build()
    }

    private fun connect() {
        val url = relayUrl()
        if (url.isBlank()) {
            _isConnected.value = false
            _lastError.value = null // not an error: relay intentionally unconfigured
            return
        }
        if (!url.startsWith("ws://") && !url.startsWith("wss://")) {
            _isConnected.value = false
            _lastError.value = "Relay URL must start with ws:// or wss://"
            return
        }

        try {
            // Rebuild the client when the Tor setting flipped since it was created.
            val wantTor = torEnabled()
            if (client == null || clientBuiltForTor != wantTor) {
                client = buildClient()
                clientBuiltForTor = wantTor
            }
            val c = client ?: buildClient().also { client = it; clientBuiltForTor = wantTor }

            val request = Request.Builder().url(url).build()
            val ws = c.newWebSocket(request, RelayListener())
            webSocketRef.set(ws)
            Log.i(TAG, "Connecting to online relay${if (wantTor) " via Tor" else ""}: $url")
        } catch (e: Exception) {
            _isConnected.value = false
            _lastError.value = "Relay connection failed: ${e.message}"
            scheduleReconnect()
        }
    }

    private inner class RelayListener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            _isConnected.value = true
            _lastError.value = null
            myPubKeyHex?.let { key ->
                val sub = JSONObject()
                    .put("type", "subscribe")
                    .put("key", key)
                webSocket.send(sub.toString())
            }
            Log.i(TAG, "Online relay connected${if (torEnabled()) " (via Tor)" else ""}.")
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val json = JSONObject(text)
                if (json.optString("type") == "envelope") {
                    val payloadB64 = json.getString("payload")
                    val raw = Base64.decode(payloadB64, Base64.NO_WRAP)
                    _incomingPayloads.tryEmit(raw)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Bad relay frame: ${e.message}")
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            _isConnected.value = false
            _lastError.value = "Relay lost: ${t.message}"
            scheduleReconnect()
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            _isConnected.value = false
            if (shouldRun) scheduleReconnect()
        }
    }

    private fun scheduleReconnect() {
        if (!shouldRun) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(5000)
            if (shouldRun && !_isConnected.value) connect()
        }
    }

    fun stop() {
        shouldRun = false
        reconnectJob?.cancel()
        webSocketRef.getAndSet(null)?.close(1000, "client stop")
        _isConnected.value = false
    }

    /** Reconnect after settings changed (relay URL / Tor toggle). */
    fun restart() {
        stop()
        shouldRun = true
        client = null // force rebuild so Tor proxy config is re-evaluated
        if (myPubKeyHex != null) connect()
    }

    /**
     * Send an end-to-end encrypted envelope to a recipient over the online relay.
     * Honest semantics: returns true ONLY when a live relay accepted the frame.
     */
    fun sendEnvelope(recipientPubKeyHex: String, envelopeBytes: ByteArray): Boolean {
        val ws = webSocketRef.get()
        if (ws == null || !_isConnected.value) return false
        return try {
            val frame = JSONObject()
                .put("type", "envelope")
                .put("to", recipientPubKeyHex.lowercase().trim())
                .put("payload", Base64.encodeToString(envelopeBytes, Base64.NO_WRAP))
            ws.send(frame.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Failed sending envelope over relay: ${e.message}")
            false
        }
    }
}
