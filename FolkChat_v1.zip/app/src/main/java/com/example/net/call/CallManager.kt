package com.example.net.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.crypto.CryptoEngine
import com.example.data.CallLogEntry
import com.example.data.CallOutcome
import com.example.data.CallType
import com.example.data.Contact
import com.example.data.EncryptedVault
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

enum class CallState {
    IDLE,
    OUTGOING_RINGING,
    INCOMING_RINGING,
    CONNECTING,
    ACTIVE,
    ENDED
}

data class CallSession(
    val callId: String,
    val peerPubKeyHex: String,
    val peerName: String,
    val type: CallType,
    val isOutgoing: Boolean,
    val state: CallState,
    val startedAtMs: Long = System.currentTimeMillis(),
    val connectedAtMs: Long = 0L,
    val error: String? = null,
    val muted: Boolean = false,
    val speakerOn: Boolean = true,
    val videoEnabled: Boolean = false
)

/**
 * Peer-to-peer voice & video call engine.
 *
 * Signaling travels as end-to-end encrypted CALL_SIGNAL envelopes over the existing
 * FolkChat transport (Bluetooth / local Wi-Fi socket / relay). Once both parties agree,
 * a dedicated, full-duplex TCP media socket is established directly between the two
 * devices and carries live AudioRecord/AudioTrack PCM plus optional camera JPEG frames.
 *
 * Because media flows device-to-device (no TURN/relay media server is configured),
 * a call can only complete when both peers can reach each other on the same local
 * network. Otherwise the call fails gracefully and is recorded in call history.
 */
class CallManager(
    private val context: Context,
    private val vault: EncryptedVault,
    private val signalSender: suspend (String, JSONObject) -> String?
) {
    companion object {
        private const val TAG = "CallManager"
        const val CALL_PORT = 42426
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SAMPLES = 320 // 20 ms @ 16 kHz
        private const val FRAME_BYTES = FRAME_SAMPLES * 2
        private const val AUDIO_FRAME = 0x01
        private const val VIDEO_FRAME = 0x02
        private const val RING_TIMEOUT_MS = 45_000L
        private const val CONNECT_TIMEOUT_MS = 15_000
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _session = MutableStateFlow<CallSession?>(null)
    val session: StateFlow<CallSession?> = _session.asStateFlow()

    private val _durationSeconds = MutableStateFlow(0L)
    val durationSeconds: StateFlow<Long> = _durationSeconds.asStateFlow()

    private val _remoteFrame = MutableStateFlow<Bitmap?>(null)
    val remoteFrame: StateFlow<Bitmap?> = _remoteFrame.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var mediaSocket: Socket? = null
    private var mediaOut: DataOutputStream? = null
    private var mediaIn: DataInputStream? = null
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var audioManager: AudioManager? = null

    private var captureJob: Job? = null
    private var playbackJob: Job? = null
    private var tickerJob: Job? = null
    private var ringTimeoutJob: Job? = null

    private val running = AtomicBoolean(false)
    private val writeLock = Any()

    init {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        startServer()
    }

    private fun startServer() {
        scope.launch {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(CALL_PORT))
                serverSocket = ss
                while (isActive && !ss.isClosed) {
                    val client = ss.accept()
                    onIncomingMediaConnection(client)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Call server stopped: ${e.message}")
            }
        }
    }

    private fun onIncomingMediaConnection(socket: Socket) {
        val current = _session.value
        if (current == null || (current.state != CallState.CONNECTING && current.state != CallState.ACTIVE)) {
            try { socket.close() } catch (_: Exception) {}
            return
        }
        if (mediaSocket != null) {
            try { socket.close() } catch (_: Exception) {}
            return
        }
        adoptMediaSocket(socket, asInitiator = false)
    }

    // ------------------------------------------------------------------
    // Outgoing / incoming control
    // ------------------------------------------------------------------

    fun startOutgoing(contact: Contact, type: CallType) {
        if (_session.value != null && _session.value?.state != CallState.ENDED) return
        val callId = UUID.randomUUID().toString()
        val session = CallSession(
            callId = callId,
            peerPubKeyHex = contact.x25519PublicKeyHex,
            peerName = contact.displayName,
            type = type,
            isOutgoing = true,
            state = CallState.OUTGOING_RINGING,
            videoEnabled = type == CallType.VIDEO
        )
        _session.value = session
        _statusMessage.value = "Ringing…"
        sendSignal(contact.x25519PublicKeyHex, callId, CallSignalType.OFFER, type)
        scheduleRingTimeout()
    }

    fun onSignal(signal: IncomingCallSignal) {
        when (signal.type) {
            CallSignalType.OFFER -> handleOffer(signal)
            CallSignalType.RINGING -> { /* remote acknowledges ring */ }
            CallSignalType.ACCEPT -> handleAccept(signal)
            CallSignalType.REJECT -> {
                finishCall(CallOutcome.DECLINED, signal.senderPubKeyHex, signal.senderDisplayName, signal.callType, outgoing = true)
            }
            CallSignalType.BUSY -> {
                _statusMessage.value = "Peer is busy"
                finishCall(CallOutcome.DECLINED, signal.senderPubKeyHex, signal.senderDisplayName, signal.callType, outgoing = true)
            }
            CallSignalType.END -> {
                val current = _session.value
                if (current != null && current.callId == signal.callId) {
                    val outcome = if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.CANCELED
                    finishActive(outcome)
                }
            }
            CallSignalType.ICE -> { /* reserved for future negotiated transports */ }
        }
    }

    private fun handleOffer(signal: IncomingCallSignal) {
        val existing = _session.value
        if (existing != null && existing.state != CallState.ENDED) {
            if (existing.callId != signal.callId) {
                sendSignal(signal.senderPubKeyHex, signal.callId, CallSignalType.BUSY, signal.callType)
            }
            return
        }
        // Blocked peers can never ring us.
        if (vault.isBlocked(signal.senderPubKeyHex)) {
            sendSignal(signal.senderPubKeyHex, signal.callId, CallSignalType.REJECT, signal.callType)
            return
        }
        _session.value = CallSession(
            callId = signal.callId,
            peerPubKeyHex = signal.senderPubKeyHex,
            peerName = signal.senderDisplayName,
            type = signal.callType,
            isOutgoing = false,
            state = CallState.INCOMING_RINGING,
            videoEnabled = signal.callType == CallType.VIDEO
        )
        _statusMessage.value = "Incoming ${if (signal.callType == CallType.VIDEO) "video" else "voice"} call"
        sendSignal(signal.senderPubKeyHex, signal.callId, CallSignalType.RINGING, signal.callType)

        // Heads-up call notification so a backgrounded user never misses a call.
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.notify(12000, buildIncomingCallNotification(signal))
        } catch (_: Exception) {}
    }

    private fun buildIncomingCallNotification(signal: IncomingCallSignal): android.app.Notification {
        val pendingIntent = android.app.PendingIntent.getActivity(
            context,
            12000,
            android.content.Intent(context, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val label = if (signal.callType == CallType.VIDEO) "video" else "voice"
        return androidx.core.app.NotificationCompat.Builder(context, com.example.SecureChatApp.CHANNEL_CALLS_ID)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setContentTitle("Incoming $label call")
            .setContentText(signal.senderDisplayName)
            .setContentIntent(pendingIntent)
            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setOngoing(true)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setDefaults(0)
            .build()
    }

    private fun dismissIncomingCallNotification() {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(12000)
        } catch (_: Exception) {}
    }

    fun acceptIncoming() {
        val current = _session.value ?: return
        if (current.state != CallState.INCOMING_RINGING) return
        dismissIncomingCallNotification()
        val host = localIpAddress() ?: "0.0.0.0"
        _session.value = current.copy(state = CallState.CONNECTING)
        _statusMessage.value = "Connecting…"
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.ACCEPT, current.type, host = host)
        scheduleConnectTimeout()
    }

    fun rejectIncoming() {
        val current = _session.value ?: return
        dismissIncomingCallNotification()
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.REJECT, current.type)
        logCall(current, if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.DECLINED)
        teardown()
        _session.value = null
    }

    private fun handleAccept(signal: IncomingCallSignal) {
        val current = _session.value ?: return
        if (current.callId != signal.callId) return
        val host = signal.payload["host"]
        _session.value = current.copy(state = CallState.CONNECTING)
        _statusMessage.value = "Connecting…"
        scheduleConnectTimeout()
        if (host.isNullOrBlank() || host == "0.0.0.0") {
            _statusMessage.value = "Peer not reachable on local network"
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "Peer not reachable on local network")
            return
        }
        scope.launch {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(host, CALL_PORT), CONNECT_TIMEOUT_MS)
                adoptMediaSocket(socket, asInitiator = true)
            } catch (e: Exception) {
                Log.e(TAG, "Media connect failed: ${e.message}")
                _statusMessage.value = "Could not establish media link"
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "Media connection failed — peers must be on the same local network")
            }
        }
    }

    private fun adoptMediaSocket(socket: Socket, asInitiator: Boolean) {
        try {
            socket.tcpNoDelay = true
            mediaSocket = socket
            mediaOut = DataOutputStream(socket.getOutputStream())
            mediaIn = DataInputStream(socket.getInputStream())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to adopt media socket: ${e.message}")
            return
        }
        ringTimeoutJob?.cancel()
        startMedia()
    }

    private fun startMedia() {
        val current = _session.value ?: return
        if (running.getAndSet(true)) return
        _session.value = current.copy(state = CallState.ACTIVE, connectedAtMs = System.currentTimeMillis())
        _statusMessage.value = null
        configureAudioRoute(current.speakerOn)
        startAudioPipeline()
        startTicker()
        // Send END eventually by caller; auto end handled by UI.

        val audioPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!audioPerm) {
            _statusMessage.value = "Microphone permission missing — you are muted"
        }
    }

    private fun startAudioPipeline() {
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val record = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, FRAME_BYTES * 4)
                )
                if (record.state == AudioRecord.STATE_INITIALIZED) {
                    audioRecord = record
                    record.startRecording()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord init failed: ${e.message}")
        }

        try {
            val minTrack = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minTrack, FRAME_BYTES * 8))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            audioTrack = track
            track.play()
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack init failed: ${e.message}")
        }

        captureJob = scope.launch {
            val buffer = ByteArray(FRAME_BYTES)
            while (isActive && running.get()) {
                val record = audioRecord ?: break
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0 && _session.value?.muted != true) {
                    sendFrame(AUDIO_FRAME, buffer, read)
                }
            }
        }

        playbackJob = scope.launch {
            while (isActive && running.get()) {
                try {
                    val type = mediaIn?.readByte()?.toInt() ?: break
                    val length = mediaIn?.readInt() ?: break
                    if (length <= 0 || length > 2_000_000) break
                    val payload = ByteArray(length)
                    mediaIn?.readFully(payload)
                    when (type) {
                        AUDIO_FRAME -> audioTrack?.write(payload, 0, payload.size)
                        VIDEO_FRAME -> decodeRemoteFrame(payload)
                    }
                } catch (e: Exception) {
                    if (running.get()) Log.d(TAG, "Media read ended: ${e.message}")
                    break
                }
            }
            if (running.get()) {
                // Remote hung up
                scope.launch { finishActive(CallOutcome.COMPLETED) }
            }
        }
    }

    private fun sendFrame(type: Int, payload: ByteArray, length: Int) {
        val out = mediaOut ?: return
        try {
            synchronized(writeLock) {
                out.writeByte(type)
                out.writeInt(length)
                out.write(payload, 0, length)
                out.flush()
            }
        } catch (e: Exception) {
            Log.d(TAG, "sendFrame failed: ${e.message}")
        }
    }

    /** Called from the video-call UI with a JPEG-encoded camera frame. */
    fun sendLocalVideoFrame(jpeg: ByteArray) {
        if (!running.get()) return
        if (_session.value?.videoEnabled != true) return
        sendFrame(VIDEO_FRAME, jpeg, jpeg.size)
    }

    private fun decodeRemoteFrame(bytes: ByteArray) {
        try {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
            _remoteFrame.value = bmp
        } catch (_: Exception) {}
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive && running.get()) {
                val s = _session.value ?: break
                if (s.connectedAtMs > 0) {
                    _durationSeconds.value = (System.currentTimeMillis() - s.connectedAtMs) / 1000
                }
                delay(1000)
            }
        }
    }

    // ------------------------------------------------------------------
    // Controls
    // ------------------------------------------------------------------

    fun toggleMute() {
        val s = _session.value ?: return
        _session.value = s.copy(muted = !s.muted)
    }

    fun toggleSpeaker() {
        val s = _session.value ?: return
        val now = !s.speakerOn
        _session.value = s.copy(speakerOn = now)
        configureAudioRoute(now)
    }

    fun setVideoEnabled(enabled: Boolean) {
        val s = _session.value ?: return
        _session.value = s.copy(videoEnabled = enabled)
        if (!enabled) _remoteFrame.value = null
    }

    private fun configureAudioRoute(speakerOn: Boolean) {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = am.availableCommunicationDevices
                val target = devices.firstOrNull {
                    if (speakerOn) it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    else it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                }
                if (target != null) am.setCommunicationDevice(target)
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = speakerOn
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audio route change failed: ${e.message}")
        }
    }

    fun endCall() {
        val current = _session.value ?: return
        if (current.state == CallState.INCOMING_RINGING) {
            rejectIncoming()
            return
        }
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.END, current.type)
        finishActive(if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.CANCELED)
    }

    private fun finishActive(outcome: CallOutcome) {
        val current = _session.value ?: return
        dismissIncomingCallNotification()
        logCall(current, outcome)
        teardown()
        _session.value = current.copy(state = CallState.ENDED, error = _statusMessage.value)
        scope.launch {
            delay(1200)
            if (_session.value?.state == CallState.ENDED) {
                _session.value = null
                _durationSeconds.value = 0
                _statusMessage.value = null
            }
        }
    }

    private fun finishCall(
        outcome: CallOutcome,
        peerHex: String,
        peerName: String,
        type: CallType,
        outgoing: Boolean,
        reason: String? = null
    ) {
        val current = _session.value
        val entry = current ?: CallSession(
            callId = UUID.randomUUID().toString(),
            peerPubKeyHex = peerHex,
            peerName = peerName,
            type = type,
            isOutgoing = outgoing,
            state = CallState.ENDED
        )
        logCall(entry, outcome)
        if (reason != null) _statusMessage.value = reason
        teardown()
        _session.value = entry.copy(state = CallState.ENDED, error = reason ?: _statusMessage.value)
        scope.launch {
            delay(1400)
            if (_session.value?.state == CallState.ENDED) {
                _session.value = null
                _statusMessage.value = null
                _durationSeconds.value = 0
            }
        }
    }

    private fun logCall(session: CallSession, outcome: CallOutcome) {
        vault.addCallLog(
            CallLogEntry(
                id = UUID.randomUUID().toString(),
                peerPubKeyHex = session.peerPubKeyHex,
                peerName = session.peerName,
                type = session.type,
                outcome = outcome,
                timestampMs = System.currentTimeMillis(),
                durationSeconds = if (session.connectedAtMs > 0) (System.currentTimeMillis() - session.connectedAtMs) / 1000 else 0,
                isOutgoing = session.isOutgoing
            )
        )
    }

    private fun scheduleRingTimeout() {
        ringTimeoutJob?.cancel()
        ringTimeoutJob = scope.launch {
            delay(RING_TIMEOUT_MS)
            val current = _session.value
            if (current != null && current.state == CallState.OUTGOING_RINGING) {
                _statusMessage.value = "No answer"
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "No answer")
            }
        }
    }

    private fun scheduleConnectTimeout() {
        scope.launch {
            delay(20_000)
            val current = _session.value
            if (current != null && current.state == CallState.CONNECTING) {
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = current.isOutgoing, reason = "Connection timed out")
            }
        }
    }

    private fun sendSignal(
        peerHex: String,
        callId: String,
        signal: CallSignalType,
        type: CallType,
        host: String? = null
    ) {
        scope.launch {
            val json = JSONObject().apply {
                put("type", "CALL_SIGNAL")
                put("callId", callId)
                put("signal", signal.name)
                put("callType", type.name)
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("senderDisplayName", vault.getDisplayName())
                if (host != null) {
                    put("host", host)
                    put("port", CALL_PORT.toString())
                }
            }
            signalSender(peerHex, json)
        }
    }

    private fun localIpAddress(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    private fun teardown() {
        running.set(false)
        ringTimeoutJob?.cancel()
        captureJob?.cancel()
        playbackJob?.cancel()
        tickerJob?.cancel()
        captureJob = null; playbackJob = null; tickerJob = null; ringTimeoutJob = null
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        try { mediaIn?.close() } catch (_: Exception) {}
        try { mediaOut?.close() } catch (_: Exception) {}
        try { mediaSocket?.close() } catch (_: Exception) {}
        mediaIn = null; mediaOut = null; mediaSocket = null
        try {
            val am = audioManager
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.clearCommunicationDevice()
                else { @Suppress("DEPRECATION") am.isSpeakerphoneOn = false }
            }
        } catch (_: Exception) {}
    }

    fun currentPeerHex(): String? = _session.value?.peerPubKeyHex
}
