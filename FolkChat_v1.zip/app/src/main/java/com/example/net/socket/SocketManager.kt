package com.example.net.socket

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.DiscoveredPeer
import com.example.net.framing.L1Framer
import com.example.net.link.Link
import com.example.net.link.LinkState
import com.example.net.link.LinkType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

class SocketLink(
    override val id: String,
    override val peerId: String,
    private val socketManager: SocketManager,
    private val hostAddress: String,
    private val port: Int
) : Link {
    override val type: LinkType = LinkType.WIFI_SOCKET
    override val mtu: Int = 4096

    private val _state = MutableStateFlow(LinkState.CONNECTED)
    override val state: StateFlow<LinkState> = _state.asStateFlow()

    private val _onFrame = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    override val onFrame: SharedFlow<ByteArray> = _onFrame.asSharedFlow()

    fun emitFrame(frame: ByteArray) {
        _onFrame.tryEmit(frame)
    }

    override suspend fun send(frame: ByteArray): Boolean {
        if (_state.value != LinkState.CONNECTED) return false
        return socketManager.sendPayload(hostAddress, port, frame)
    }

    override fun disconnect() {
        _state.value = LinkState.DISCONNECTED
    }
}

class SocketManager(private val context: Context) {
    companion object {
        private const val TAG = "SecureChatSocket"
        const val UDP_PORT = 42424
        const val TCP_PORT = 42425
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var udpSocket: DatagramSocket? = null
    private var tcpServerSocket: ServerSocket? = null
    private var broadcastJob: Job? = null
    private var udpListenJob: Job? = null
    private var tcpListenJob: Job? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<Map<String, DiscoveredPeer>>(emptyMap())
    val discoveredPeers: StateFlow<Map<String, DiscoveredPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPayloads = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    val incomingPayloads: SharedFlow<ByteArray> = _incomingPayloads.asSharedFlow()

    var myIdentityPubKey: ByteArray? = null

    fun start(identityPubKey: ByteArray) {
        myIdentityPubKey = identityPubKey
        if (_isRunning.value) return

        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifi?.createMulticastLock("SecureChatMulticastLock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire multicast lock: ${e.message}")
        }

        _isRunning.value = true
        startTcpServer()
        startUdpListener()
        startUdpBroadcaster()
    }

    fun stop() {
        _isRunning.value = false
        broadcastJob?.cancel()
        udpListenJob?.cancel()
        tcpListenJob?.cancel()

        try {
            udpSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }
        try {
            tcpServerSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }

        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun startUdpBroadcaster() {
        broadcastJob = scope.launch {
            while (isActive && _isRunning.value) {
                val pubKey = myIdentityPubKey
                if (pubKey != null) {
                    try {
                        val tagHex = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(pubKey))
                        val message = "SC_BEACON:$tagHex:$TCP_PORT"
                        val data = message.toByteArray()

                        val broadcastAddresses = mutableSetOf<InetAddress>()
                        broadcastAddresses.add(InetAddress.getByName("255.255.255.255"))

                        try {
                            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
                            while (interfaces.hasMoreElements()) {
                                val netIf = interfaces.nextElement()
                                if (!netIf.isLoopback && netIf.isUp) {
                                    for (ifAddr in netIf.interfaceAddresses) {
                                        val bcast = ifAddr.broadcast
                                        if (bcast != null) {
                                            broadcastAddresses.add(bcast)
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            // Fallback to 255.255.255.255
                        }

                        DatagramSocket().use { sock ->
                            sock.broadcast = true
                            for (addr in broadcastAddresses) {
                                try {
                                    val packet = DatagramPacket(data, data.size, addr, UDP_PORT)
                                    sock.send(packet)
                                } catch (e: Exception) {
                                    // Individual broadcast failure ignore
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "UDP Broadcast failed: ${e.message}")
                    }
                }
                delay(3000)
            }
        }
    }

    fun registerPeerManually(host: String, port: Int = TCP_PORT) {
        val peer = DiscoveredPeer(
            id = "$host:$port",
            displayName = "Direct Link [$host]",
            tagHex = "manual",
            linkType = "WIFI_SOCKET",
            hostAddress = host,
            port = port,
            lastSeenEpochMs = System.currentTimeMillis()
        )
        val current = _discoveredPeers.value.toMutableMap()
        current[peer.id] = peer
        _discoveredPeers.value = current
    }

    private fun startUdpListener() {
        udpListenJob = scope.launch {
            try {
                udpSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(UDP_PORT))
                }
                val buffer = ByteArray(256)
                while (isActive && _isRunning.value) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(packet)
                    val text = String(packet.data, 0, packet.length)
                    if (text.startsWith("SC_BEACON:")) {
                        val parts = text.split(":")
                        if (parts.size >= 3) {
                            val tagHex = parts[1]
                            val tcpPort = parts[2].toIntOrNull() ?: TCP_PORT
                            val senderIp = packet.address.hostAddress ?: ""

                            // Don't discover ourselves
                            val myTag = myIdentityPubKey?.let { CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(it)) }
                            if (tagHex != myTag && senderIp.isNotEmpty()) {
                                val peer = DiscoveredPeer(
                                    id = "$senderIp:$tcpPort",
                                    displayName = "LAN Peer [${tagHex.take(6)}]",
                                    tagHex = tagHex,
                                    linkType = "WIFI_SOCKET",
                                    hostAddress = senderIp,
                                    port = tcpPort,
                                    lastSeenEpochMs = System.currentTimeMillis()
                                )
                                val current = _discoveredPeers.value.toMutableMap()
                                current[peer.id] = peer
                                _discoveredPeers.value = current
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                if (_isRunning.value) {
                    Log.e(TAG, "UDP listener failed: ${e.message}")
                }
            }
        }
    }

    private fun startTcpServer() {
        tcpListenJob = scope.launch {
            try {
                tcpServerSocket = ServerSocket(TCP_PORT)
                while (isActive && _isRunning.value) {
                    val client = tcpServerSocket?.accept() ?: break
                    scope.launch {
                        handleIncomingTcpClient(client)
                    }
                }
            } catch (e: Exception) {
                if (_isRunning.value) {
                    Log.e(TAG, "TCP Server error: ${e.message}")
                }
            }
        }
    }

    private suspend fun handleIncomingTcpClient(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            socket.use { s ->
                val input = DataInputStream(s.getInputStream())
                val output = DataOutputStream(s.getOutputStream())

                // Read length prefix
                val length = input.readInt()
                if (length in 1..1048576) { // 1 MB limit
                    val payload = ByteArray(length)
                    input.readFully(payload)

                    // Write 1-byte ACK
                    output.writeByte(0x06) // ASCII ACK
                    output.flush()

                    // Check if framed
                    val chunk = L1Framer.parseFrame(payload)
                    if (chunk != null) {
                        val fullPayload = L1Framer.ingestChunk(chunk)
                        if (fullPayload != null) {
                            _incomingPayloads.tryEmit(fullPayload)
                        }
                    } else {
                        _incomingPayloads.tryEmit(payload)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling TCP client: ${e.message}")
        }
    }

    suspend fun sendPayload(hostAddress: String, port: Int, payload: ByteArray): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(hostAddress, port), 5000)
                socket.soTimeout = 10000
                val output = DataOutputStream(socket.getOutputStream())
                val input = DataInputStream(socket.getInputStream())

                val frames = L1Framer.slicePayload(payload, maxChunkPayloadSize = 4096)
                for (frame in frames) {
                    output.writeInt(frame.size)
                    output.write(frame)
                    output.flush()

                    val ack = input.readByte()
                    if (ack != 0x06.toByte()) {
                        return@withContext false
                    }
                }
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send payload to $hostAddress:$port: ${e.message}")
            false
        }
    }
}
