package com.example.net.transport

import android.content.Context
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptedEnvelope
import com.example.data.ActiveRouteType
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DiscoveredPeer
import com.example.data.EncryptedVault
import com.example.data.MediaAutoDownload
import com.example.data.MediaKind
import com.example.data.MediaAttachment
import com.example.data.MessageRequest
import com.example.data.MessageStatus
import com.example.data.RoutingPolicy
import com.example.data.TransferState
import com.example.net.ble.BleManager
import com.example.net.call.CallSignalType
import com.example.net.call.IncomingCallSignal
import com.example.net.media.MediaTransferManager
import com.example.net.online.OnlineRelayManager
import com.example.net.routing.RoutingEngine
import com.example.net.socket.SocketManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.util.UUID

class TransportCoordinator(
    private val context: Context,
    val vault: EncryptedVault
) {
    companion object {
        private const val TAG = "TransportCoordinator"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val routingEngine = RoutingEngine(context)
    val onlineRelayManager = OnlineRelayManager(context, vault)
    val bleManager = BleManager(context)
    val socketManager = SocketManager(context)

    val mediaTransferManager = MediaTransferManager(
        vault = vault,
        mediaDir = File(context.filesDir, "media"),
        dispatcher = { recipient, json -> dispatchEncryptedJson(recipient, json) },
        onUpdated = { _onConversationUpdated.tryEmit(Unit) }
    )

    private val _allDiscoveredPeers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val allDiscoveredPeers: StateFlow<List<DiscoveredPeer>> = _allDiscoveredPeers.asStateFlow()

    private val _onNewMessageReceived = MutableSharedFlow<ChatMessage>(extraBufferCapacity = 64)
    val onNewMessageReceived: SharedFlow<ChatMessage> = _onNewMessageReceived.asSharedFlow()

    private val _onConversationUpdated = MutableSharedFlow<Unit>(extraBufferCapacity = 64)
    val onConversationUpdated: SharedFlow<Unit> = _onConversationUpdated.asSharedFlow()

    private val _onCallSignal = MutableSharedFlow<IncomingCallSignal>(extraBufferCapacity = 32)
    val onCallSignal: SharedFlow<IncomingCallSignal> = _onCallSignal.asSharedFlow()

    /** peerPubKeyHex -> isTyping events for live "typing…" indicators. */
    private val _onTypingUpdate = MutableSharedFlow<Pair<String, Boolean>>(extraBufferCapacity = 32)
    val onTypingUpdate: SharedFlow<Pair<String, Boolean>> = _onTypingUpdate.asSharedFlow()

    /** peerPubKeyHex of any peer that just produced traffic (presence refresh). */
    private val _onPresenceSeen = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val onPresenceSeen: SharedFlow<String> = _onPresenceSeen.asSharedFlow()

    private var outboxWorkerJob: Job? = null

    init {
        // Observe peers from BLE and Socket
        scope.launch {
            bleManager.discoveredPeers.collectLatest { blePeers ->
                val socketPeers = socketManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }
        scope.launch {
            socketManager.discoveredPeers.collectLatest { socketPeers ->
                val blePeers = bleManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }

        // Listen for incoming payloads from Online Relay
        scope.launch {
            onlineRelayManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "ONLINE_RELAY")
            }
        }

        // Listen for incoming payloads from BLE
        scope.launch {
            bleManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "BLE")
            }
        }

        // Listen for incoming payloads from Wi-Fi Socket
        scope.launch {
            socketManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "WIFI_SOCKET")
            }
        }

        startOutboxWorker()
    }

    private fun mergePeers(blePeers: Collection<DiscoveredPeer>, socketPeers: Collection<DiscoveredPeer>) {
        val list = mutableListOf<DiscoveredPeer>()
        list.addAll(blePeers)
        list.addAll(socketPeers)
        _allDiscoveredPeers.value = list.sortedByDescending { it.lastSeenEpochMs }
    }

    fun startTransports() {
        val identity = vault.getIdentityKeyPair()
        onlineRelayManager.start(identity.publicKey)
        bleManager.startAdvertising(identity.publicKey)
        bleManager.startScanning()
        socketManager.start(identity.publicKey)
    }

    fun stopTransports() {
        onlineRelayManager.stop()
        bleManager.cleanUp()
        socketManager.stop()
    }

    private fun startOutboxWorker() {
        outboxWorkerJob = scope.launch {
            while (isActive) {
                flushOutbox()
                delay(2000)
            }
        }
    }

    suspend fun flushOutbox() {
        val queued = vault.getQueuedOutbox()
        if (queued.isEmpty()) return

        for (msg in queued) {
            // Media messages are dispatched by the MediaTransferManager, not the text outbox.
            if (msg.attachment != null) continue

            val recipientHex = msg.recipientPubKeyHex.lowercase()

            // 1. Self-loopback delivery (e.g. Saved Notes or testing)
            if (recipientHex == vault.getIdentityKeyPair().publicKeyHex.lowercase()) {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.DELIVERED, "LOOPBACK")
                val incomingCopy = msg.copy(
                    id = UUID.randomUUID().toString(),
                    isOutgoing = false,
                    status = MessageStatus.DELIVERED,
                    routeUsed = "LOOPBACK"
                )
                vault.saveMessage(incomingCopy)
                _onNewMessageReceived.tryEmit(incomingCopy)
                continue
            }

            val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
            val json = buildChatJson(msg)
            val route = dispatchToPeer(recipientHex, recipientPubKeyBytes, json)
            if (route != null) {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.DELIVERED, route)
                _onConversationUpdated.tryEmit(Unit)
            } else {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.QUEUED, "OFFLINE_QUEUED")
            }
        }
    }

    private fun buildChatJson(msg: ChatMessage): JSONObject {
        return JSONObject().apply {
            put("type", "CHAT_MSG")
            put("msgId", msg.id)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("recipientPubKey", msg.recipientPubKeyHex)
            put("text", msg.content)
            put("timestamp", msg.timestampMs)
            msg.replyToId?.let { put("replyToId", it) }
            msg.replyToPreview?.let { put("replyToPreview", it) }
            msg.replyToSender?.let { put("replyToSender", it) }
        }
    }

    private fun seal(recipientPubKeyBytes: ByteArray, json: JSONObject): ByteArray? {
        return try {
            CryptoEngine.encryptToPeer(
                recipientPublicKey = recipientPubKeyBytes,
                plaintext = json.toString().toByteArray(Charsets.UTF_8)
            ).toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Failed encrypting payload: ${e.message}")
            null
        }
    }

    private fun findWifiPeer(expectedTag: String): DiscoveredPeer? {
        val peers = _allDiscoveredPeers.value
        return peers.firstOrNull { p ->
            p.linkType == "WIFI_SOCKET" && (
                p.tagHex.equals(expectedTag, ignoreCase = true) ||
                (p.tagHex.length >= 16 && expectedTag.startsWith(p.tagHex, ignoreCase = true)) ||
                (expectedTag.length >= 16 && p.tagHex.startsWith(expectedTag.take(16), ignoreCase = true)) ||
                p.tagHex == "manual"
            )
        }
    }

    /**
     * Encrypts and dispatches [json] to [recipientPubKeyHex] using the best available
     * route. Returns the route used, or null if the peer was unreachable.
     */
    suspend fun dispatchEncryptedJson(recipientPubKeyHex: String, json: JSONObject): String? {
        val recipientHex = recipientPubKeyHex.lowercase()
        val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
        return dispatchToPeer(recipientHex, recipientPubKeyBytes, json)
    }

    private suspend fun dispatchToPeer(recipientHex: String, recipientPubKeyBytes: ByteArray, json: JSONObject): String? {
        val myHex = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val wireBytes = seal(recipientPubKeyBytes, json) ?: return null

        // Self loopback
        if (recipientHex == myHex) {
            handleIncomingRawPayload(wireBytes, "LOOPBACK")
            return "LOOPBACK"
        }

        val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(recipientPubKeyBytes))
        val peers = _allDiscoveredPeers.value
        val policy = routingEngine.routingPolicy.value
        val preferred = routingEngine.resolveRoute(recipientHex, peers, expectedTag)

        // Attempt the preferred route first, then gracefully fall back to any other
        // usable link. Previously a single failed attempt (e.g. an unconfigured online
        // relay, or "internet up" hiding a reachable LAN peer) left the message stuck
        // in the outbox even though the peer was reachable on another transport.
        val order = LinkedHashSet<ActiveRouteType>()
        order.add(preferred)
        if (policy != RoutingPolicy.FORCE_ONLINE) {
            order.add(ActiveRouteType.OFFLINE_DIRECT_WIFI)
            order.add(ActiveRouteType.OFFLINE_BLE_MESH)
        }
        if (policy != RoutingPolicy.FORCE_OFFLINE) {
            order.add(ActiveRouteType.ONLINE_RELAY)
        }

        for (route in order) {
            val used = when (route) {
                ActiveRouteType.ONLINE_RELAY ->
                    if (onlineRelayManager.sendEnvelope(recipientHex, wireBytes)) "ONLINE_RELAY" else null
                ActiveRouteType.OFFLINE_DIRECT_WIFI -> {
                    val peer = findWifiPeer(expectedTag)
                    if (peer?.hostAddress != null && peer.port > 0 &&
                        socketManager.sendPayload(peer.hostAddress, peer.port, wireBytes)
                    ) "OFFLINE_DIRECT_WIFI" else null
                }
                ActiveRouteType.OFFLINE_BLE_MESH -> {
                    val peer = peers.firstOrNull { it.linkType == "BLE_GATT" }
                    if (peer != null && bleManager.sendPayloadToDevice(peer.id, wireBytes)) "OFFLINE_BLE_MESH" else null
                }
                ActiveRouteType.OFFLINE_STORE_AND_FORWARD -> null
            }
            if (used != null) return used
        }
        return null
    }

    fun queueMessage(recipientPubKeyHex: String, text: String): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = text,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.QUEUED,
            isOutgoing = true,
            routeUsed = "AUTO"
        )
        vault.saveMessage(msg)
        scope.launch { flushOutbox() }
        return msg
    }

    fun queueMediaMessage(
        recipientPubKeyHex: String,
        attachment: MediaAttachment,
        caption: String = ""
    ): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = caption,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.SENDING,
            isOutgoing = true,
            routeUsed = "AUTO",
            attachment = attachment
        )
        vault.saveMessage(msg)
        mediaTransferManager.startTransfer(msg)
        _onConversationUpdated.tryEmit(Unit)
        return msg
    }

    private fun handleIncomingRawPayload(rawPayload: ByteArray, linkName: String) {
        try {
            val myIdentity = vault.getIdentityKeyPair()
            val envelope = EncryptedEnvelope.fromByteArray(rawPayload)
            val decryptedBytes = CryptoEngine.decryptFromPeer(myIdentity.privateKey, envelope)
            val json = JSONObject(String(decryptedBytes, Charsets.UTF_8))

            // Privacy-first block list: silently drop everything from blocked peers.
            val senderKey = json.optString("senderPubKey").lowercase().trim()
            if (senderKey.isNotEmpty() && vault.isBlocked(senderKey)) {
                Log.i(TAG, "Dropped payload from blocked peer ${senderKey.take(8)}")
                return
            }

            // Presence: any incoming traffic marks the sender as recently seen.
            if (senderKey.isNotEmpty() && senderKey != myIdentity.publicKeyHex.lowercase()) {
                touchContactPresence(senderKey)
            }

            when (json.optString("type", "CHAT_MSG")) {
                "CHAT_MSG" -> handleIncomingChat(json, linkName)
                "CHAT_EDIT" -> handleIncomingEdit(json)
                "CHAT_DELETE" -> handleIncomingDelete(json)
                "CHAT_REACTION" -> handleIncomingReaction(json)
                "CHAT_PIN" -> handleIncomingPin(json)
                "CHAT_TYPING" -> {
                    _onTypingUpdate.tryEmit(Pair(senderKey, json.optBoolean("typing", true)))
                }
                "CHAT_READ" -> handleIncomingRead(senderKey, json)
                "CHAT_PRESENCE" -> _onPresenceSeen.tryEmit(senderKey)
                "PROFILE_UPDATE" -> handleIncomingProfileUpdate(senderKey, json)
                "ATTACHMENT_VIEWED" -> handleIncomingAttachmentViewed(json)
                "DISAPPEAR_SYNC" -> handleIncomingDisappearSync(senderKey, json)
                "MEDIA_CHUNK" -> {
                    mediaTransferManager.handleIncomingChunk(json)
                }
                "CALL_SIGNAL" -> handleIncomingCallSignal(json)
                else -> Log.w(TAG, "Unknown payload type: ${json.optString("type")}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt incoming payload from $linkName: ${e.message}")
        }
    }

    private fun touchContactPresence(senderPubKeyHex: String) {
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        if (System.currentTimeMillis() - contact.lastSeenEpochMs > 5_000L) {
            vault.addOrUpdateContact(contact.copy(lastSeenEpochMs = System.currentTimeMillis()))
        }
        _onPresenceSeen.tryEmit(senderPubKeyHex)
    }

    private fun handleIncomingChat(json: JSONObject, linkName: String) {
        val senderPubKey = json.getString("senderPubKey")
        val senderDisplayName = json.optString("senderDisplayName", "").ifBlank {
            "Peer " + senderPubKey.take(6)
        }
        val text = json.optString("text", "")
        val msgId = json.getString("msgId")
        val timestamp = json.optLong("timestamp", System.currentTimeMillis())

        val attachment = if (json.has("attachment")) parseAttachment(json.getJSONObject("attachment")) else null

        val incomingMessage = ChatMessage(
            id = msgId,
            conversationPeerPubKeyHex = senderPubKey,
            senderPubKeyHex = senderPubKey,
            recipientPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            content = text,
            timestampMs = timestamp,
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = linkName,
            replyToId = if (json.has("replyToId")) json.getString("replyToId") else null,
            replyToPreview = if (json.has("replyToPreview")) json.getString("replyToPreview") else null,
            replyToSender = if (json.has("replyToSender")) json.getString("replyToSender") else null,
            attachment = attachment
        )

        vault.saveMessage(incomingMessage)

        if (attachment != null) {
            val mode = vault.getSettings().mediaAutoDownload
            if (mode == MediaAutoDownload.NEVER) {
                vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = "Auto-download disabled in Settings"
                    ))
                }
            } else {
                mediaTransferManager.prepareIncoming(incomingMessage)
            }
        }

        val contacts = vault.getContacts()
        val isKnown = contacts.any { it.x25519PublicKeyHex.equals(senderPubKey, ignoreCase = true) }

        if (!isKnown) {
            val existingRequests = vault.getMessageRequests()
            val currentReq = existingRequests.firstOrNull { it.senderPubKeyHex.equals(senderPubKey, ignoreCase = true) }
            val newCount = (currentReq?.messageCount ?: 0) + 1
            val request = MessageRequest(
                senderPubKeyHex = senderPubKey,
                senderDisplayName = senderDisplayName,
                latestMessageText = incomingMessage.previewText,
                timestampMs = timestamp,
                messageCount = newCount
            )
            vault.addOrUpdateMessageRequest(request)
            Log.i(TAG, "Message request received from unknown peer: $senderDisplayName ($senderPubKey)")
        }

        _onNewMessageReceived.tryEmit(incomingMessage)
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun parseAttachment(obj: JSONObject): MediaAttachment {
        return MediaAttachment(
            id = obj.getString("id"),
            kind = try { MediaKind.valueOf(obj.getString("kind")) } catch (e: Exception) { MediaKind.DOCUMENT },
            fileName = obj.optString("fileName", "file"),
            mimeType = obj.optString("mimeType", "application/octet-stream"),
            sizeBytes = obj.optLong("sizeBytes", 0L),
            durationMs = obj.optLong("durationMs", 0L),
            width = obj.optInt("width", 0),
            height = obj.optInt("height", 0),
            viewLimit = obj.optInt("viewLimit", 0),
            transferState = TransferState.PENDING
        )
    }

    private fun handleIncomingEdit(json: JSONObject) {
        val msgId = json.optString("msgId")
        val newText = json.optString("text")
        vault.updateMessage(msgId) {
            it.copy(content = newText, isEdited = true, editedAtMs = System.currentTimeMillis())
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingDelete(json: JSONObject) {
        val msgId = json.optString("msgId")
        vault.updateMessage(msgId) {
            it.copy(deletedAtMs = System.currentTimeMillis(), content = "")
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingReaction(json: JSONObject) {
        val msgId = json.optString("msgId")
        val emoji = json.optString("emoji")
        val sender = json.optString("senderPubKey").lowercase()
        val add = json.optBoolean("add", true)
        if (emoji.isBlank()) return
        vault.updateMessage(msgId) { msg ->
            val map = msg.reactions.toMutableMap()
            val current = (map[emoji] ?: emptyList()).toMutableList()
            if (add) {
                if (!current.contains(sender)) current.add(sender)
            } else {
                current.remove(sender)
            }
            if (current.isEmpty()) map.remove(emoji) else map[emoji] = current
            msg.copy(reactions = map)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingPin(json: JSONObject) {
        val msgId = json.optString("msgId")
        val pinned = json.optBoolean("pinned", true)
        vault.updateMessage(msgId) { it.copy(isPinned = pinned) }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingCallSignal(json: JSONObject) {
        val signal = IncomingCallSignal(
            callId = json.optString("callId"),
            type = try { CallSignalType.valueOf(json.optString("signal")) } catch (e: Exception) { CallSignalType.OFFER },
            callType = try { com.example.data.CallType.valueOf(json.optString("callType", "VOICE")) } catch (e: Exception) { com.example.data.CallType.VOICE },
            senderPubKeyHex = json.optString("senderPubKey"),
            senderDisplayName = json.optString("senderDisplayName", "Peer"),
            payload = buildMap {
                json.optString("host").takeIf { it.isNotBlank() }?.let { put("host", it) }
                json.optString("port").takeIf { it.isNotBlank() }?.let { put("port", it) }
            }
        )
        _onCallSignal.tryEmit(signal)
    }

    // ------------------------------------------------------------------
    // v2 protocol: read receipts / presence / profile / view-once / disappearing
    // ------------------------------------------------------------------

    /** Peer reports they have read everything up to lastReadMs in our conversation. */
    private fun handleIncomingRead(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val lastReadMs = json.optLong("lastReadMs", 0L)
        if (lastReadMs <= 0L) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        if (lastReadMs > contact.peerLastReadMs) {
            vault.addOrUpdateContact(contact.copy(peerLastReadMs = lastReadMs))
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Peer updated their profile (display name and/or avatar). */
    private fun handleIncomingProfileUpdate(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        val newName = json.optString("displayName").trim()
        val updated = if (newName.isNotEmpty() && newName != contact.displayName) {
            contact.copy(displayName = newName)
        } else contact
        vault.addOrUpdateContact(updated)

        val avatarB64 = json.optString("avatarBase64", "")
        if (avatarB64.isNotEmpty()) {
            try {
                val bytes = android.util.Base64.decode(avatarB64, android.util.Base64.NO_WRAP)
                if (bytes.isNotEmpty() && bytes.size < 512 * 1024) {
                    val dir = File(context.filesDir, "avatars")
                    if (!dir.exists()) dir.mkdirs()
                    val f = File(dir, "peer_${senderPubKeyHex.take(12)}.jpg")
                    f.writeBytes(bytes)
                    vault.setContactAvatar(senderPubKeyHex, f.absolutePath)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to store peer avatar: ${e.message}")
            }
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Recipient opened a view-limited attachment; increment and expire when spent. */
    private fun handleIncomingAttachmentViewed(json: JSONObject) {
        val msgId = json.optString("msgId")
        if (msgId.isEmpty()) return
        vault.updateMessage(msgId) { m ->
            val att = m.attachment ?: return@updateMessage m
            if (att.viewLimit <= 0) return@updateMessage m
            val views = (json.optInt("viewsUsed", att.viewsUsed + 1)).coerceAtLeast(att.viewsUsed)
            m.copy(attachment = att.copy(viewsUsed = views))
        }
        // If the limit is now spent, wipe the local copy of the media.
        vault.getMessageById(msgId)?.attachment?.let { att ->
            if (att.viewLimit > 0 && att.viewsUsed >= att.viewLimit) {
                att.localPath?.let { path ->
                    try { File(path).delete() } catch (_: Exception) {}
                }
                vault.updateMessage(msgId) { m ->
                    m.copy(attachment = m.attachment?.copy(localPath = null))
                }
            }
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Peer changed the disappearing-message timer for our conversation. */
    private fun handleIncomingDisappearSync(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        val seconds = json.optInt("seconds", 0)
        vault.addOrUpdateContact(contact.copy(disappearAfterSec = seconds))

        val label = com.example.data.DisappearTimer.fromSeconds(seconds).label
        val event = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = senderPubKeyHex,
            senderPubKeyHex = senderPubKeyHex,
            recipientPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            content = "",
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = "SYNC",
            systemEvent = "${contact.displayName} set disappearing messages to $label"
        )
        vault.saveMessage(event)
        vault.purgeExpiredDisappearingMessages()
        _onConversationUpdated.tryEmit(Unit)
    }
}
