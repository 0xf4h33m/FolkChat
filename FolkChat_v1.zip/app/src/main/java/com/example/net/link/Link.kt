package com.example.net.link

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

enum class LinkType {
    BLE_GATT,
    BLE_L2CAP,
    WIFI_SOCKET,
    LOOPBACK
}

enum class LinkState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

interface Link {
    val id: String
    val peerId: String
    val type: LinkType
    val mtu: Int
    val state: StateFlow<LinkState>
    val onFrame: SharedFlow<ByteArray>

    suspend fun send(frame: ByteArray): Boolean
    fun disconnect()
}
