package com.example.net.media

import android.util.Base64
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.ChatMessage
import com.example.data.EncryptedVault
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import com.example.data.MessageStatus
import com.example.data.TransferState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/**
 * Transfers media attachments (images, videos, documents, voice notes) as
 * chunked, end-to-end encrypted envelopes over the existing P2P transport.
 *
 * Outgoing transfers report progress, can be cancelled and retried.
 * Incoming transfers are reassembled into the app's private media directory.
 */
class MediaTransferManager(
    private val vault: EncryptedVault,
    private val mediaDir: File,
    private val dispatcher: suspend (String, JSONObject) -> String?,
    private val onUpdated: () -> Unit
) {
    companion object {
        private const val TAG = "MediaTransfer"
        private const val CHUNK_SIZE_SOCKET = 48 * 1024
        private const val CHUNK_SIZE_BLE = 280
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cancelled = mutableSetOf<String>()
    private val activeTransfers = mutableSetOf<String>()
    private val incomingStreams = mutableMapOf<String, IncomingTransfer>()
    private val mutex = Mutex()

    private class IncomingTransfer(
        val file: File,
        val randomAccess: RandomAccessFile,
        val totalChunks: Int,
        val receivedChunks: MutableSet<Int> = mutableSetOf()
    )

    init {
        mediaDir.mkdirs()
    }

    fun resolveLocalFile(attachment: MediaAttachment?): File? {
        val path = attachment?.localPath ?: return null
        val f = File(path)
        return if (f.exists()) f else null
    }

    /** Kick off (or resume) an outgoing media transfer for [message]. */
    fun startTransfer(message: ChatMessage, restart: Boolean = false) {
        val attachment = message.attachment ?: return
        message.recipientPubKeyHex.let { recipient ->
            if (activeTransfers.contains(attachment.id)) return
            if (restart) {
                synchronized(cancelled) { cancelled.remove(attachment.id) }
            }
            scope.launch { runOutgoing(message, recipient) }
        }
    }

    /** Re-attempts a failed or cancelled transfer. */
    fun retry(messageId: String) {
        val message = vault.getMessageById(messageId) ?: return
        if (message.attachment == null) return
        val attachmentId = message.attachment.id
        synchronized(cancelled) { cancelled.remove(attachmentId) }
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.SENDING,
                attachment = it.attachment?.copy(
                    transferState = TransferState.IN_PROGRESS,
                    progress = 0f,
                    error = null
                )
            )
        }
        onUpdated()
        startTransfer(vault.getMessageById(messageId) ?: message, restart = true)
    }

    fun cancel(messageId: String) {
        val message = vault.getMessageById(messageId) ?: return
        val attachment = message.attachment ?: return
        synchronized(cancelled) { cancelled.add(attachment.id) }
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.CANCELLED, error = "Cancelled")
            )
        }
        onUpdated()
    }

    private suspend fun runOutgoing(message: ChatMessage, recipientHex: String) {
        val attachment = message.attachment ?: return
        val sourceFile = resolveLocalFile(attachment)
        if (sourceFile == null || !sourceFile.exists()) {
            markFailed(message.id, attachment.id, "Local file missing")
            return
        }
        activeTransfers.add(attachment.id)
        try {
            val totalBytes = sourceFile.length()
            val totalChunks = maxOf(1, ((totalBytes + CHUNK_SIZE_SOCKET - 1) / CHUNK_SIZE_SOCKET).toInt())
            var chunkSize = CHUNK_SIZE_SOCKET

            // 1. Send the message envelope (metadata) first so the peer can create the bubble.
            val route = dispatcher(recipientHex, buildChatEnvelope(message))
            if (route == null) {
                markFailed(message.id, attachment.id, "Peer unreachable — will retry")
                return
            }
            if (route == "OFFLINE_BLE_MESH") chunkSize = CHUNK_SIZE_BLE

            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS))
            }
            onUpdated()

            RandomAccessFile(sourceFile, "r").use { raf ->
                val adjustedTotal = maxOf(1, ((totalBytes + chunkSize - 1) / chunkSize).toInt())
                val buffer = ByteArray(chunkSize)
                var index = 0
                var offset = 0L
                while (offset < totalBytes) {
                    if (isCancelled(attachment.id)) {
                        markCancelled(message.id)
                        return
                    }
                    raf.seek(offset)
                    val read = raf.read(buffer, 0, minOf(chunkSize.toLong(), totalBytes - offset).toInt())
                    if (read <= 0) break
                    val dataB64 = Base64.encodeToString(buffer.copyOf(read), Base64.NO_WRAP)
                    val chunkJson = JSONObject().apply {
                        put("type", "MEDIA_CHUNK")
                        put("transferId", attachment.id)
                        put("msgId", message.id)
                        put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                        put("senderDisplayName", vault.getDisplayName())
                        put("recipientPubKey", recipientHex)
                        put("index", index)
                        put("total", adjustedTotal)
                        put("chunkSize", chunkSize)
                        put("data", dataB64)
                        put("timestamp", System.currentTimeMillis())
                    }
                    val chunkRoute = dispatcher(recipientHex, chunkJson)
                    if (chunkRoute == null) {
                        markFailed(message.id, attachment.id, "Transfer interrupted — tap retry")
                        return
                    }
                    offset += read
                    index++
                    val progress = if (totalBytes <= 0) 1f else (offset.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                    vault.updateMessage(message.id) {
                        it.copy(attachment = it.attachment?.copy(progress = progress, transferState = TransferState.IN_PROGRESS))
                    }
                    if (index % 4 == 0 || offset >= totalBytes) onUpdated()
                }
            }

            vault.updateMessage(message.id) {
                it.copy(
                    status = MessageStatus.DELIVERED,
                    routeUsed = route,
                    attachment = it.attachment?.copy(transferState = TransferState.COMPLETED, progress = 1f)
                )
            }
            onUpdated()
        } catch (e: Exception) {
            Log.e(TAG, "Outgoing media transfer failed: ${e.message}")
            markFailed(message.id, attachment.id, e.message ?: "Transfer failed")
        } finally {
            activeTransfers.remove(attachment.id)
        }
    }

    private fun buildChatEnvelope(message: ChatMessage): JSONObject {
        val attachment = message.attachment
        return JSONObject().apply {
            put("type", "CHAT_MSG")
            put("msgId", message.id)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("recipientPubKey", message.recipientPubKeyHex)
            put("text", message.content)
            put("timestamp", message.timestampMs)
            message.replyToId?.let { put("replyToId", it) }
            message.replyToPreview?.let { put("replyToPreview", it) }
            message.replyToSender?.let { put("replyToSender", it) }
            if (attachment != null) {
                put("attachment", JSONObject().apply {
                    put("id", attachment.id)
                    put("kind", attachment.kind.name)
                    put("fileName", attachment.fileName)
                    put("mimeType", attachment.mimeType)
                    put("sizeBytes", attachment.sizeBytes)
                    put("durationMs", attachment.durationMs)
                    put("width", attachment.width)
                    put("height", attachment.height)
                    put("viewLimit", attachment.viewLimit)
                })
            }
        }
    }

    // ------------------------------------------------------------------
    // Incoming
    // ------------------------------------------------------------------

    /** Called when a CHAT_MSG carrying an attachment arrives. Returns true if accepted. */
    fun prepareIncoming(message: ChatMessage, totalChunks: Int = -1): Boolean {
        val attachment = message.attachment ?: return false
        if (attachment.sizeBytes > 0 && attachment.sizeBytes > MAX_INCOMING_BYTES) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = "File too large"))
            }
            onUpdated()
            return false
        }
        scope.launch {
            mutex.withLock {
                if (!incomingStreams.containsKey(attachment.id)) {
                    val safeName = sanitize(attachment.fileName)
                    val out = File(mediaDir, "${attachment.id}_$safeName")
                    try {
                        incomingStreams[attachment.id] = IncomingTransfer(
                            file = out,
                            randomAccess = RandomAccessFile(out, "rw"),
                            totalChunks = totalChunks
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Cannot open incoming file: ${e.message}")
                    }
                }
            }
        }
        return true
    }

    fun handleIncomingChunk(json: JSONObject) {
        val transferId = json.optString("transferId")
        val msgId = json.optString("msgId")
        val index = json.optInt("index", -1)
        val total = json.optInt("total", -1)
        val chunkSize = json.optInt("chunkSize", CHUNK_SIZE_SOCKET)
        val dataB64 = json.optString("data")
        if (transferId.isEmpty() || index < 0) return

        val bytes = try { Base64.decode(dataB64, Base64.NO_WRAP) } catch (e: Exception) { return }

        scope.launch {
            mutex.withLock {
                var entry = incomingStreams[transferId]
                if (entry == null) {
                    val message = vault.getMessageById(msgId) ?: return@withLock
                    val attachment = message.attachment ?: return@withLock
                    val safeName = sanitize(attachment.fileName)
                    val out = File(mediaDir, "${transferId}_$safeName")
                    entry = try {
                        IncomingTransfer(out, RandomAccessFile(out, "rw"), total)
                    } catch (e: Exception) { return@withLock }
                    incomingStreams[transferId] = entry
                }
                val idx = entry!!
                try {
                    idx.randomAccess.seek(index.toLong() * chunkSize.toLong())
                    idx.randomAccess.write(bytes)
                    idx.receivedChunks.add(index)
                    val progress = if (total > 0) (idx.receivedChunks.size.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                    vault.updateMessage(msgId) {
                        it.copy(attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = progress))
                    }
                    val complete = total > 0 && idx.receivedChunks.size >= total
                    // For BLE-sized chunks the offsets differ; completeness is driven by chunk count.
                    if (complete) {
                        finalize(transferId, msgId, idx)
                    } else if (idx.receivedChunks.size % 4 == 0) {
                        onUpdated()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Chunk write failed: ${e.message}")
                }
            }
        }
    }

    private fun finalize(transferId: String, msgId: String, entry: IncomingTransfer) {
        try {
            entry.randomAccess.close()
        } catch (_: Exception) {}
        incomingStreams.remove(transferId)
        vault.updateMessage(msgId) {
            it.copy(
                status = MessageStatus.DELIVERED,
                attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED,
                    progress = 1f,
                    localPath = entry.file.absolutePath
                )
            )
        }
        onUpdated()
    }

    private fun markFailed(messageId: String, transferId: String, reason: String) {
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = reason)
            )
        }
        onUpdated()
    }

    private fun markCancelled(messageId: String) {
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.CANCELLED, error = "Cancelled")
            )
        }
        onUpdated()
    }

    private fun isCancelled(transferId: String): Boolean = synchronized(cancelled) { cancelled.contains(transferId) }

    private fun sanitize(name: String): String {
        val base = name.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (cleaned.isBlank()) "file" else cleaned.take(64)
    }

    fun registerLocalCopy(attachment: MediaAttachment): MediaAttachment {
        return attachment.copy(transferState = TransferState.COMPLETED, progress = 1f)
    }

    private val MAX_INCOMING_BYTES = 2L * 1024 * 1024 * 1024 // 2 GB — chunked transfer supports very large files
}
