package com.example.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.crypto.KeyPairBytes
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

class EncryptedVault(private val context: Context) {
    companion object {
        private const val TAG = "EncryptedVault"
        private const val KEYSTORE_ALIAS = "SecureChatMasterKey"
        private const val VAULT_FILENAME = "vault_v1.enc"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    }

    private var cachedIdentity: KeyPairBytes? = null
    private var myDisplayName: String = "Alice"
    private var appThemeMode: String = "CLASSIC_LIGHT"
    private var onboardingCompleted: Boolean = false
    private var settings: AppSettings = AppSettings()
    private val contactsMap = mutableMapOf<String, Contact>()
    private val messagesList = mutableListOf<ChatMessage>()
    private val outboxList = mutableListOf<ChatMessage>()
    private val messageRequestsMap = mutableMapOf<String, MessageRequest>()
    private val callLogs = mutableListOf<CallLogEntry>()
    private val blockedPeers = mutableMapOf<String, String>()   // pubKeyHex -> displayName
    private val readCursors = mutableMapOf<String, Long>()      // conversation pubKeyHex -> last read timestamp
    private var myAvatarPath: String? = null
    private var routingPolicyName: String = "AUTO_FALLBACK"

    private val masterKey: ByteArray by lazy {
        getOrCreateMasterKey()
    }

    init {
        loadVault()
        purgeExpiredDisappearingMessages()
        ensureDefaultSelfContact()
    }

    private fun ensureDefaultSelfContact() {
        val identity = getIdentityKeyPair()
        if (contactsMap.isEmpty()) {
            val selfContact = Contact(
                id = "self_notes",
                displayName = "Saved Notes (Self-Test)",
                x25519PublicKeyHex = identity.publicKeyHex.lowercase(),
                isVerified = true
            )
            contactsMap[selfContact.x25519PublicKeyHex] = selfContact
            saveVault()
        }
    }

    fun isOnboardingCompleted(): Boolean = onboardingCompleted

    fun setOnboardingCompleted(completed: Boolean) {
        onboardingCompleted = completed
        saveVault()
    }

    fun getThemeMode(): String = appThemeMode

    fun setThemeMode(mode: String) {
        appThemeMode = mode
        saveVault()
    }

    // ---------------------------------------------------------------------
    // App settings
    // ---------------------------------------------------------------------
    fun getSettings(): AppSettings = settings

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settings = transform(settings)
        saveVault()
    }

    /**
     * Sets a numeric PIN. The PIN is never stored in plaintext: a random salt is
     * generated and a PBKDF-style derivation (iterated SHA-256 via HKDF) is stored.
     */
    fun setPin(pin: String) {
        val salt = ByteArray(16).apply { SecureRandom().nextBytes(this) }
        val hash = hashPin(pin, CryptoEngine.bytesToHex(salt))
        settings = settings.copy(pinHash = hash, pinSalt = CryptoEngine.bytesToHex(salt))
        saveVault()
    }

    fun verifyPin(pin: String): Boolean {
        if (settings.pinHash.isEmpty() || settings.pinSalt.isEmpty()) return false
        return hashPin(pin, settings.pinSalt).equals(settings.pinHash, ignoreCase = true)
    }

    fun clearPin() {
        settings = settings.copy(pinHash = "", pinSalt = "")
        saveVault()
    }

    private fun hashPin(pin: String, saltHex: String): String {
        var material = (saltHex + ":" + pin).toByteArray()
        repeat(20_000) {
            material = CryptoEngine.hkdfSha256(
                material,
                salt = saltHex.toByteArray(),
                info = "folkchat-pin".toByteArray(),
                length = 32
            )
        }
        return CryptoEngine.bytesToHex(material)
    }

    // ---------------------------------------------------------------------
    // Call history
    // ---------------------------------------------------------------------
    fun getCallLogs(): List<CallLogEntry> = synchronized(callLogs) {
        callLogs.sortedByDescending { it.timestampMs }
    }

    fun addCallLog(entry: CallLogEntry) {
        synchronized(callLogs) {
            if (callLogs.none { it.id == entry.id }) callLogs.add(entry)
        }
        saveVault()
    }

    fun clearCallLogs() {
        synchronized(callLogs) { callLogs.clear() }
        saveVault()
    }

    // ---------------------------------------------------------------------
    // Identity / contacts
    // ---------------------------------------------------------------------
    fun getIdentityKeyPair(): KeyPairBytes {
        cachedIdentity?.let { return it }
        val newPair = CryptoEngine.generateX25519KeyPair()
        cachedIdentity = newPair
        saveVault()
        return newPair
    }

    fun getDisplayName(): String = myDisplayName

    fun setDisplayName(name: String) {
        myDisplayName = name.trim()
        saveVault()
    }

    fun getContacts(): List<Contact> = synchronized(contactsMap) { contactsMap.values.toList() }

    fun addOrUpdateContact(contact: Contact) {
        synchronized(contactsMap) {
            contactsMap[contact.x25519PublicKeyHex.lowercase()] = contact.copy(
                x25519PublicKeyHex = contact.x25519PublicKeyHex.lowercase()
            )
        }
        saveVault()
    }

    fun deleteContact(pubKeyHex: String) {
        synchronized(contactsMap) {
            contactsMap.remove(pubKeyHex)
        }
        saveVault()
    }

    fun getContactByPubKey(pubKeyHex: String): Contact? = synchronized(contactsMap) {
        contactsMap[pubKeyHex.lowercase().trim()]
    }

    fun getMessageRequests(): List<MessageRequest> = synchronized(messageRequestsMap) {
        messageRequestsMap.values.sortedByDescending { it.timestampMs }
    }

    fun addOrUpdateMessageRequest(req: MessageRequest) {
        synchronized(messageRequestsMap) {
            messageRequestsMap[req.senderPubKeyHex.lowercase()] = req.copy(
                senderPubKeyHex = req.senderPubKeyHex.lowercase()
            )
        }
        saveVault()
    }

    fun acceptMessageRequest(senderPubKeyHex: String, displayName: String): Contact {
        val cleanPubKey = senderPubKeyHex.lowercase().trim()
        val contact = Contact(
            id = java.util.UUID.randomUUID().toString(),
            displayName = displayName.ifBlank { "Peer " + cleanPubKey.take(6) },
            x25519PublicKeyHex = cleanPubKey,
            isVerified = true
        )
        synchronized(contactsMap) {
            contactsMap[cleanPubKey] = contact
        }
        synchronized(messageRequestsMap) {
            messageRequestsMap.remove(cleanPubKey)
        }
        saveVault()
        return contact
    }

    fun declineMessageRequest(senderPubKeyHex: String) {
        val cleanPubKey = senderPubKeyHex.lowercase().trim()
        synchronized(messageRequestsMap) {
            messageRequestsMap.remove(cleanPubKey)
        }
        clearAllMessagesForContact(cleanPubKey)
        saveVault()
    }

    // ---------------------------------------------------------------------
    // Blocked peers (privacy-first persistent block list)
    // ---------------------------------------------------------------------
    fun blockPeer(pubKeyHex: String, displayName: String) {
        val key = pubKeyHex.lowercase().trim()
        if (key.isEmpty()) return
        synchronized(blockedPeers) { blockedPeers[key] = displayName.ifBlank { "Peer ${key.take(6)}" } }
        // Blocking also removes any pending message request from that peer.
        synchronized(messageRequestsMap) { messageRequestsMap.remove(key) }
        saveVault()
    }

    fun unblockPeer(pubKeyHex: String) {
        synchronized(blockedPeers) { blockedPeers.remove(pubKeyHex.lowercase().trim()) }
        saveVault()
    }

    fun isBlocked(pubKeyHex: String): Boolean =
        synchronized(blockedPeers) { blockedPeers.containsKey(pubKeyHex.lowercase().trim()) }

    fun getBlockedPeers(): List<Pair<String, String>> =
        synchronized(blockedPeers) { blockedPeers.map { Pair(it.key, it.value) } }

    // ---------------------------------------------------------------------
    // Read cursors & unread counts
    // ---------------------------------------------------------------------
    fun markConversationRead(peerPubKeyHex: String) {
        readCursors[peerPubKeyHex.lowercase().trim()] = System.currentTimeMillis()
        saveVault()
    }

    fun getReadCursor(peerPubKeyHex: String): Long =
        readCursors[peerPubKeyHex.lowercase().trim()] ?: 0L

    fun getUnreadCount(peerPubKeyHex: String): Int {
        val key = peerPubKeyHex.lowercase().trim()
        val cursor = readCursors[key] ?: 0L
        return synchronized(messagesList) {
            messagesList.count {
                !it.isOutgoing && !it.isDeleted && it.systemEvent == null &&
                    it.timestampMs > cursor &&
                    it.conversationPeerPubKeyHex.equals(key, ignoreCase = true)
            }
        }
    }

    // ---------------------------------------------------------------------
    // Starred messages
    // ---------------------------------------------------------------------
    fun getStarredMessages(): List<ChatMessage> = synchronized(messagesList) {
        messagesList.filter { it.isStarred && !it.isDeleted }.sortedByDescending { it.timestampMs }
    }

    fun setStarred(messageId: String, starred: Boolean) {
        updateMessage(messageId) { it.copy(isStarred = starred) }
    }

    // ---------------------------------------------------------------------
    // Disappearing messages (enforced locally per conversation timer)
    // ---------------------------------------------------------------------
    fun purgeExpiredDisappearingMessages() {
        val now = System.currentTimeMillis()
        val timers = synchronized(contactsMap) {
            contactsMap.values.associate { it.x25519PublicKeyHex.lowercase() to it.disappearAfterSec }
        }
        var changed = false
        synchronized(messagesList) {
            val expired = messagesList.filter { m ->
                val t = timers[m.conversationPeerPubKeyHex.lowercase()] ?: 0
                t > 0 && !m.isDeleted && now - m.timestampMs > (t * 1000L)
            }
            if (expired.isNotEmpty()) {
                messagesList.removeAll(expired.toSet())
                changed = true
            }
        }
        if (changed) {
            synchronized(outboxList) {
                outboxList.removeAll { queued ->
                    val t = timers[queued.conversationPeerPubKeyHex.lowercase()] ?: 0
                    t > 0 && now - queued.timestampMs > (t * 1000L)
                }
            }
            saveVault()
        }
    }

    // ---------------------------------------------------------------------
    // Avatars (profile image flow)
    // ---------------------------------------------------------------------
    fun saveAvatarImage(bytes: ByteArray): String {
        val dir = File(context.filesDir, "avatars")
        if (!dir.exists()) dir.mkdirs()
        val f = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
        f.writeBytes(bytes)
        myAvatarPath = f.absolutePath
        saveVault()
        return f.absolutePath
    }

    fun getMyAvatarPath(): String? = myAvatarPath

    fun setContactAvatar(pubKeyHex: String, path: String) {
        val key = pubKeyHex.lowercase().trim()
        synchronized(contactsMap) {
            contactsMap[key]?.let { contactsMap[key] = it.copy(avatarPath = path) }
        }
        saveVault()
    }

    fun copyAvatarForContact(pubKeyHex: String, sourcePath: String): String? {
        return try {
            val src = File(sourcePath)
            if (!src.exists()) return null
            val dir = File(context.filesDir, "avatars")
            if (!dir.exists()) dir.mkdirs()
            val dst = File(dir, "peer_${pubKeyHex.take(12)}_${System.currentTimeMillis()}.jpg")
            src.copyTo(dst, overwrite = true)
            setContactAvatar(pubKeyHex, dst.absolutePath)
            dst.absolutePath
        } catch (e: Exception) {
            Log.w(TAG, "Failed to copy avatar: ${e.message}")
            null
        }
    }

    // ---------------------------------------------------------------------
    // Routing policy persistence
    // ---------------------------------------------------------------------
    fun getRoutingPolicyName(): String = routingPolicyName

    fun setRoutingPolicyName(name: String) {
        routingPolicyName = name
        saveVault()
    }

    // ---------------------------------------------------------------------
    // Messages
    // ---------------------------------------------------------------------
    fun getMessagesForConversation(peerPubKeyHex: String): List<ChatMessage> {
        return synchronized(messagesList) {
            messagesList.filter { it.conversationPeerPubKeyHex.equals(peerPubKeyHex, ignoreCase = true) }
        }
    }

    fun getAllMessages(): List<ChatMessage> = synchronized(messagesList) { messagesList.toList() }

    fun getMessageById(messageId: String): ChatMessage? = synchronized(messagesList) {
        messagesList.firstOrNull { it.id == messageId }
    }

    fun saveMessage(message: ChatMessage) {
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == message.id }
            if (idx >= 0) {
                messagesList[idx] = message
            } else {
                messagesList.add(message)
            }
        }
        if (message.status == MessageStatus.QUEUED) {
            synchronized(outboxList) {
                if (outboxList.none { it.id == message.id }) {
                    outboxList.add(message)
                }
            }
        }
        saveVault()
    }

    /** Applies an arbitrary mutation to a stored message and persists it. */
    fun updateMessage(messageId: String, transform: (ChatMessage) -> ChatMessage): ChatMessage? {
        var updated: ChatMessage? = null
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == messageId }
            if (idx >= 0) {
                updated = transform(messagesList[idx])
                messagesList[idx] = updated!!
            }
        }
        saveVault()
        return updated
    }

    fun updateMessageStatus(messageId: String, newStatus: MessageStatus) {
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == messageId }
            if (idx >= 0) {
                val current = messagesList[idx]
                messagesList[idx] = current.copy(status = newStatus)
            }
        }
        if (newStatus == MessageStatus.DELIVERED || newStatus == MessageStatus.FAILED) {
            synchronized(outboxList) {
                outboxList.removeAll { it.id == messageId }
            }
        }
        saveVault()
    }

    fun updateMessageStatusAndRoute(messageId: String, newStatus: MessageStatus, routeUsed: String) {
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == messageId }
            if (idx >= 0) {
                val current = messagesList[idx]
                messagesList[idx] = current.copy(status = newStatus, routeUsed = routeUsed)
            }
        }
        if (newStatus == MessageStatus.DELIVERED || newStatus == MessageStatus.FAILED) {
            synchronized(outboxList) {
                outboxList.removeAll { it.id == messageId }
            }
        }
        saveVault()
    }

    fun deleteMessage(messageId: String) {
        synchronized(messagesList) {
            messagesList.removeAll { it.id == messageId }
        }
        synchronized(outboxList) {
            outboxList.removeAll { it.id == messageId }
        }
        saveVault()
    }

    fun clearAllMessagesForContact(peerPubKeyHex: String) {
        synchronized(messagesList) {
            messagesList.removeAll { it.conversationPeerPubKeyHex.equals(peerPubKeyHex, ignoreCase = true) }
        }
        synchronized(outboxList) {
            outboxList.removeAll { it.conversationPeerPubKeyHex.equals(peerPubKeyHex, ignoreCase = true) }
        }
        saveVault()
    }

    fun getQueuedOutbox(): List<ChatMessage> = synchronized(outboxList) { outboxList.toList() }

    private fun getOrCreateMasterKey(): ByteArray {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
            keyStore.load(null)
            if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                val spec = KeyGenParameterSpec.Builder(
                    KEYSTORE_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGenerator.init(spec)
                keyGenerator.generateKey()
            }
            // Derive a 32-byte key for ChaCha20Poly1305 from keystore alias
            CryptoEngine.hkdfSha256(KEYSTORE_ALIAS.toByteArray(), salt = "SC_VAULT_SALT".toByteArray(), length = 32)
        } catch (e: Exception) {
            Log.w(TAG, "AndroidKeyStore unavailable (testing environment). Falling back to persistent seed.")
            // Secure fallback for Robolectric / JVM testing
            CryptoEngine.hkdfSha256("SECURE_FALLBACK_SEED".toByteArray(), salt = "TEST_SALT".toByteArray(), length = 32)
        }
    }

    @Synchronized
    private fun saveVault() {
        try {
            val root = JSONObject()
            cachedIdentity?.let {
                root.put("x25519_priv", it.privateKeyHex)
                root.put("x25519_pub", it.publicKeyHex)
            }
            root.put("display_name", myDisplayName)
            root.put("theme_mode", appThemeMode)
            root.put("onboarding_completed", onboardingCompleted)
            root.put("routing_policy", routingPolicyName)
            myAvatarPath?.let { root.put("my_avatar_path", it) }
            root.put("settings", settingsToJson(settings))

            val blockedObj = JSONObject()
            synchronized(blockedPeers) {
                for ((k, v) in blockedPeers) blockedObj.put(k, v)
            }
            root.put("blocked_peers", blockedObj)

            val cursorsObj = JSONObject()
            synchronized(readCursors) {
                for ((k, v) in readCursors) cursorsObj.put(k, v)
            }
            root.put("read_cursors", cursorsObj)

            val contactsArray = JSONArray()
            synchronized(contactsMap) {
                for (c in contactsMap.values) {
                    val obj = JSONObject()
                    obj.put("id", c.id)
                    obj.put("name", c.displayName)
                    obj.put("pubKey", c.x25519PublicKeyHex)
                    obj.put("verified", c.isVerified)
                    obj.put("lastSeen", c.lastSeenEpochMs)
                    obj.put("statusText", c.statusText)
                    c.avatarPath?.let { obj.put("avatarPath", it) }
                    obj.put("archived", c.isArchived)
                    obj.put("muted", c.isMuted)
                    obj.put("disappearAfterSec", c.disappearAfterSec)
                    obj.put("peerLastReadMs", c.peerLastReadMs)
                    contactsArray.put(obj)
                }
            }
            root.put("contacts", contactsArray)

            val messagesArray = JSONArray()
            synchronized(messagesList) {
                for (m in messagesList) {
                    messagesArray.put(messageToJson(m))
                }
            }
            root.put("messages", messagesArray)

            val requestsArray = JSONArray()
            synchronized(messageRequestsMap) {
                for (r in messageRequestsMap.values) {
                    val obj = JSONObject()
                    obj.put("senderPubKey", r.senderPubKeyHex)
                    obj.put("senderName", r.senderDisplayName)
                    obj.put("latestMsg", r.latestMessageText)
                    obj.put("timestamp", r.timestampMs)
                    obj.put("count", r.messageCount)
                    requestsArray.put(obj)
                }
            }
            root.put("message_requests", requestsArray)

            val callsArray = JSONArray()
            synchronized(callLogs) {
                for (c in callLogs) {
                    val obj = JSONObject()
                    obj.put("id", c.id)
                    obj.put("peerKey", c.peerPubKeyHex)
                    obj.put("peerName", c.peerName)
                    obj.put("type", c.type.name)
                    obj.put("outcome", c.outcome.name)
                    obj.put("timestamp", c.timestampMs)
                    obj.put("duration", c.durationSeconds)
                    obj.put("isOutgoing", c.isOutgoing)
                    callsArray.put(obj)
                }
            }
            root.put("call_logs", callsArray)

            val jsonBytes = root.toString().toByteArray(Charsets.UTF_8)
            val nonce = ByteArray(12).apply { SecureRandom().nextBytes(this) }
            val encrypted = CryptoEngine.encryptChaCha20Poly1305(masterKey, nonce, jsonBytes)

            val file = File(context.filesDir, VAULT_FILENAME)
            file.outputStream().use { os ->
                os.write(nonce)
                os.write(encrypted)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save encrypted vault: ${e.message}")
        }
    }

    private fun messageToJson(m: ChatMessage): JSONObject {
        val obj = JSONObject()
        obj.put("id", m.id)
        obj.put("convPeer", m.conversationPeerPubKeyHex)
        obj.put("sender", m.senderPubKeyHex)
        obj.put("recipient", m.recipientPubKeyHex)
        obj.put("content", m.content)
        obj.put("timestamp", m.timestampMs)
        obj.put("status", m.status.name)
        obj.put("isOutgoing", m.isOutgoing)
        obj.put("routeUsed", m.routeUsed)
        m.replyToId?.let { obj.put("replyToId", it) }
        m.replyToPreview?.let { obj.put("replyToPreview", it) }
        m.replyToSender?.let { obj.put("replyToSender", it) }
        if (m.reactions.isNotEmpty()) {
            val reactionsObj = JSONObject()
            for ((emoji, senders) in m.reactions) {
                reactionsObj.put(emoji, JSONArray(senders))
            }
            obj.put("reactions", reactionsObj)
        }
        obj.put("isEdited", m.isEdited)
        obj.put("editedAtMs", m.editedAtMs)
        obj.put("deletedAtMs", m.deletedAtMs)
        obj.put("isPinned", m.isPinned)
        obj.put("isStarred", m.isStarred)
        m.systemEvent?.let { obj.put("systemEvent", it) }
        m.attachment?.let { obj.put("attachment", attachmentToJson(it)) }
        return obj
    }

    private fun attachmentToJson(a: MediaAttachment): JSONObject {
        val obj = JSONObject()
        obj.put("id", a.id)
        obj.put("kind", a.kind.name)
        obj.put("fileName", a.fileName)
        obj.put("mimeType", a.mimeType)
        obj.put("sizeBytes", a.sizeBytes)
        obj.put("durationMs", a.durationMs)
        obj.put("width", a.width)
        obj.put("height", a.height)
        a.localPath?.let { obj.put("localPath", it) }
        obj.put("transferState", a.transferState.name)
        obj.put("progress", a.progress.toDouble())
        obj.put("viewLimit", a.viewLimit)
        obj.put("viewsUsed", a.viewsUsed)
        a.error?.let { obj.put("error", it) }
        return obj
    }

    private fun attachmentFromJson(obj: JSONObject): MediaAttachment {
        return MediaAttachment(
            id = obj.getString("id"),
            kind = try { MediaKind.valueOf(obj.getString("kind")) } catch (e: Exception) { MediaKind.DOCUMENT },
            fileName = obj.optString("fileName", "file"),
            mimeType = obj.optString("mimeType", "application/octet-stream"),
            sizeBytes = obj.optLong("sizeBytes", 0L),
            durationMs = obj.optLong("durationMs", 0L),
            width = obj.optInt("width", 0),
            height = obj.optInt("height", 0),
            localPath = if (obj.has("localPath")) obj.getString("localPath") else null,
            transferState = try { TransferState.valueOf(obj.optString("transferState", "PENDING")) } catch (e: Exception) { TransferState.PENDING },
            progress = obj.optDouble("progress", 0.0).toFloat(),
            viewLimit = obj.optInt("viewLimit", 0),
            viewsUsed = obj.optInt("viewsUsed", 0),
            error = if (obj.has("error")) obj.optString("error") else null
        )
    }

    private fun settingsToJson(s: AppSettings): JSONObject {
        return JSONObject().apply {
            put("appLockEnabled", s.appLockEnabled)
            put("biometricEnabled", s.biometricEnabled)
            put("pinHash", s.pinHash)
            put("pinSalt", s.pinSalt)
            put("autoLockMillis", s.autoLockMillis)
            put("notificationPreviewMode", s.notificationPreviewMode.name)
            put("mediaAutoDownload", s.mediaAutoDownload.name)
            put("readReceipts", s.readReceipts)
            put("typingIndicators", s.typingIndicators)
            put("screenshotProtection", s.screenshotProtection)
            put("compactChat", s.compactChat)
            put("outgoingBubbleEmphasis", s.outgoingBubbleEmphasis)
            put("notificationSound", s.notificationSound)
            put("notificationVibrate", s.notificationVibrate)
            put("torRoutingEnabled", s.torRoutingEnabled)
            put("relayUrl", s.relayUrl)
        }
    }

    private fun settingsFromJson(obj: JSONObject): AppSettings {
        return AppSettings(
            appLockEnabled = obj.optBoolean("appLockEnabled", false),
            biometricEnabled = obj.optBoolean("biometricEnabled", true),
            pinHash = obj.optString("pinHash", ""),
            pinSalt = obj.optString("pinSalt", ""),
            autoLockMillis = obj.optLong("autoLockMillis", 60_000L),
            notificationPreviewMode = try { NotificationPreviewMode.valueOf(obj.optString("notificationPreviewMode", "FULL")) } catch (e: Exception) { NotificationPreviewMode.FULL },
            mediaAutoDownload = try { MediaAutoDownload.valueOf(obj.optString("mediaAutoDownload", "WIFI_OR_LAN")) } catch (e: Exception) { MediaAutoDownload.WIFI_OR_LAN },
            readReceipts = obj.optBoolean("readReceipts", true),
            typingIndicators = obj.optBoolean("typingIndicators", true),
            screenshotProtection = obj.optBoolean("screenshotProtection", false),
            compactChat = obj.optBoolean("compactChat", false),
            outgoingBubbleEmphasis = obj.optBoolean("outgoingBubbleEmphasis", true),
            notificationSound = obj.optBoolean("notificationSound", true),
            notificationVibrate = obj.optBoolean("notificationVibrate", true),
            torRoutingEnabled = obj.optBoolean("torRoutingEnabled", false),
            relayUrl = obj.optString("relayUrl", "")
        )
    }

    @Synchronized
    private fun loadVault() {
        val file = File(context.filesDir, VAULT_FILENAME)
        if (!file.exists()) return

        try {
            val bytes = file.readBytes()
            if (bytes.size < 12 + 16) return

            val nonce = bytes.copyOfRange(0, 12)
            val ciphertext = bytes.copyOfRange(12, bytes.size)
            val decrypted = CryptoEngine.decryptChaCha20Poly1305(masterKey, nonce, ciphertext)
            val root = JSONObject(String(decrypted, Charsets.UTF_8))

            if (root.has("x25519_priv") && root.has("x25519_pub")) {
                val priv = CryptoEngine.hexToBytes(root.getString("x25519_priv"))
                val pub = CryptoEngine.hexToBytes(root.getString("x25519_pub"))
                cachedIdentity = KeyPairBytes(priv, pub)
            }
            if (root.has("display_name")) {
                myDisplayName = root.getString("display_name")
            }
            if (root.has("theme_mode")) {
                appThemeMode = root.getString("theme_mode")
            }
            if (root.has("routing_policy")) {
                routingPolicyName = root.optString("routing_policy", "AUTO_FALLBACK")
            }
            if (root.has("my_avatar_path")) {
                myAvatarPath = root.getString("my_avatar_path")
            }
            if (root.has("onboarding_completed")) {
                onboardingCompleted = root.getBoolean("onboarding_completed")
            }
            if (root.has("settings")) {
                settings = settingsFromJson(root.getJSONObject("settings"))
            }

            if (root.has("blocked_peers")) {
                val bObj = root.getJSONObject("blocked_peers")
                for (k in bObj.keys()) {
                    blockedPeers[k.lowercase()] = bObj.optString(k, "Peer")
                }
            }

            if (root.has("read_cursors")) {
                val cObj = root.getJSONObject("read_cursors")
                for (k in cObj.keys()) {
                    readCursors[k.lowercase()] = cObj.optLong(k, 0L)
                }
            }

            if (root.has("contacts")) {
                val arr = root.getJSONArray("contacts")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val c = Contact(
                        id = obj.getString("id"),
                        displayName = obj.getString("name"),
                        x25519PublicKeyHex = obj.getString("pubKey"),
                        isVerified = obj.optBoolean("verified", false),
                        lastSeenEpochMs = obj.optLong("lastSeen", 0L),
                        statusText = obj.optString("statusText", ""),
                        avatarPath = if (obj.has("avatarPath")) obj.getString("avatarPath") else null,
                        isArchived = obj.optBoolean("archived", false),
                        isMuted = obj.optBoolean("muted", false),
                        disappearAfterSec = obj.optInt("disappearAfterSec", 0),
                        peerLastReadMs = obj.optLong("peerLastReadMs", 0L)
                    )
                    contactsMap[c.x25519PublicKeyHex] = c
                }
            }

            if (root.has("messages")) {
                val arr = root.getJSONArray("messages")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val status = try {
                        MessageStatus.valueOf(obj.getString("status"))
                    } catch (e: Exception) {
                        MessageStatus.DELIVERED
                    }
                    val routeUsed = if (obj.has("routeUsed")) obj.getString("routeUsed") else "AUTO"

                    val reactions = mutableMapOf<String, List<String>>()
                    if (obj.has("reactions")) {
                        val rObj = obj.getJSONObject("reactions")
                        for (emoji in rObj.keys()) {
                            val sendersArr = rObj.getJSONArray(emoji)
                            val senders = mutableListOf<String>()
                            for (j in 0 until sendersArr.length()) senders.add(sendersArr.getString(j))
                            reactions[emoji] = senders
                        }
                    }

                    val attachment = if (obj.has("attachment")) attachmentFromJson(obj.getJSONObject("attachment")) else null

                    val m = ChatMessage(
                        id = obj.getString("id"),
                        conversationPeerPubKeyHex = obj.getString("convPeer"),
                        senderPubKeyHex = obj.getString("sender"),
                        recipientPubKeyHex = obj.getString("recipient"),
                        content = obj.getString("content"),
                        timestampMs = obj.getLong("timestamp"),
                        status = status,
                        isOutgoing = obj.getBoolean("isOutgoing"),
                        routeUsed = routeUsed,
                        replyToId = if (obj.has("replyToId")) obj.getString("replyToId") else null,
                        replyToPreview = if (obj.has("replyToPreview")) obj.getString("replyToPreview") else null,
                        replyToSender = if (obj.has("replyToSender")) obj.getString("replyToSender") else null,
                        reactions = reactions,
                        isEdited = obj.optBoolean("isEdited", false),
                        editedAtMs = obj.optLong("editedAtMs", 0L),
                        deletedAtMs = obj.optLong("deletedAtMs", 0L),
                        isPinned = obj.optBoolean("isPinned", false),
                        isStarred = obj.optBoolean("isStarred", false),
                        systemEvent = if (obj.has("systemEvent")) obj.getString("systemEvent") else null,
                        attachment = attachment
                    )
                    messagesList.add(m)
                    if (status == MessageStatus.QUEUED) {
                        outboxList.add(m)
                    }
                }
            }

            if (root.has("message_requests")) {
                val arr = root.getJSONArray("message_requests")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val r = MessageRequest(
                        senderPubKeyHex = obj.getString("senderPubKey"),
                        senderDisplayName = obj.optString("senderName", "Unknown Peer"),
                        latestMessageText = obj.optString("latestMsg", ""),
                        timestampMs = obj.optLong("timestamp", System.currentTimeMillis()),
                        messageCount = obj.optInt("count", 1)
                    )
                    messageRequestsMap[r.senderPubKeyHex.lowercase()] = r
                }
            }

            if (root.has("call_logs")) {
                val arr = root.getJSONArray("call_logs")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val c = CallLogEntry(
                        id = obj.getString("id"),
                        peerPubKeyHex = obj.getString("peerKey"),
                        peerName = obj.optString("peerName", "Unknown"),
                        type = try { CallType.valueOf(obj.getString("type")) } catch (e: Exception) { CallType.VOICE },
                        outcome = try { CallOutcome.valueOf(obj.getString("outcome")) } catch (e: Exception) { CallOutcome.FAILED },
                        timestampMs = obj.getLong("timestamp"),
                        durationSeconds = obj.optLong("duration", 0L),
                        isOutgoing = obj.optBoolean("isOutgoing", true)
                    )
                    callLogs.add(c)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load encrypted vault: ${e.message}")
        }
    }
}
