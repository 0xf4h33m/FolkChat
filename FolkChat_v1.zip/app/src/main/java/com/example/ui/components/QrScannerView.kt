package com.example.ui.components

import android.util.Log
import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.FolkDeepForest
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkWarmIvory
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.EnumMap
import java.util.concurrent.Executors

@Composable
fun QrScannerDialog(
    onQrCodeDetected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasDetected by remember { mutableStateOf(false) }
    var torchEnabled by remember { mutableStateOf(false) }
    var cameraControl by remember { mutableStateOf<androidx.camera.core.CameraControl?>(null) }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()

                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    val reader = MultiFormatReader().apply {
                        val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
                            put(DecodeHintType.POSSIBLE_FORMATS, listOf(BarcodeFormat.QR_CODE))
                            put(DecodeHintType.CHARACTER_SET, "UTF-8")
                            put(DecodeHintType.TRY_HARDER, java.lang.Boolean.TRUE)
                        }
                        setHints(hints)
                    }

                    imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        if (hasDetected) {
                            imageProxy.close()
                            return@setAnalyzer
                        }

                        try {
                            val plane = imageProxy.planes[0]
                            val buffer = plane.buffer
                            val width = imageProxy.width
                            val height = imageProxy.height
                            val rowStride = plane.rowStride

                            // Extract contiguous Y luminance respecting rowStride
                            val yData = ByteArray(width * height)
                            for (row in 0 until height) {
                                buffer.position(row * rowStride)
                                buffer.get(yData, row * width, width)
                            }

                            // Handle camera rotation degrees (portrait mode on phones is typically 90 or 270)
                            val rotation = imageProxy.imageInfo.rotationDegrees
                            val (rotatedData, finalWidth, finalHeight) = when (rotation) {
                                90 -> {
                                    val rotated = ByteArray(width * height)
                                    for (y in 0 until height) {
                                        for (x in 0 until width) {
                                            rotated[x * height + (height - y - 1)] = yData[y * width + x]
                                        }
                                    }
                                    Triple(rotated, height, width)
                                }
                                270 -> {
                                    val rotated = ByteArray(width * height)
                                    for (y in 0 until height) {
                                        for (x in 0 until width) {
                                            rotated[(width - x - 1) * height + y] = yData[y * width + x]
                                        }
                                    }
                                    Triple(rotated, height, width)
                                }
                                180 -> {
                                    val rotated = ByteArray(width * height)
                                    for (i in 0 until width * height) {
                                        rotated[width * height - 1 - i] = yData[i]
                                    }
                                    Triple(rotated, width, height)
                                }
                                else -> Triple(yData, width, height)
                            }

                            val source = PlanarYUVLuminanceSource(
                                rotatedData, finalWidth, finalHeight,
                                0, 0, finalWidth, finalHeight, false
                            )

                            // Try standard binarizer first, then inverted if not detected
                            var decodedText: String? = null
                            try {
                                val bitmap = BinaryBitmap(HybridBinarizer(source))
                                val result = reader.decodeWithState(bitmap)
                                decodedText = result.text
                            } catch (e: Exception) {
                                // Try inverted luminance source
                                try {
                                    val invertedBitmap = BinaryBitmap(HybridBinarizer(source.invert()))
                                    val result = reader.decodeWithState(invertedBitmap)
                                    decodedText = result.text
                                } catch (e2: Exception) {
                                    // Not found in this frame
                                }
                            }

                            if (!decodedText.isNullOrBlank() && !hasDetected) {
                                hasDetected = true
                                previewView.post {
                                    onQrCodeDetected(decodedText)
                                }
                            }
                        } catch (e: Exception) {
                            Log.w("QrScanner", "Frame analysis error: ${e.message}")
                        } finally {
                            reader.reset()
                            imageProxy.close()
                        }
                    }

                    try {
                        cameraProvider.unbindAll()
                        val camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            imageAnalysis
                        )
                        cameraControl = camera.cameraControl
                    } catch (e: Exception) {
                        Log.e("QrScanner", "Camera bind failed: ${e.message}")
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Dim overlay with center transparent cutout
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val frameSize = canvasWidth.coerceAtMost(canvasHeight) * 0.7f
            val left = (canvasWidth - frameSize) / 2f
            val top = (canvasHeight - frameSize) / 2f

            // Dark semi-transparent scrim
            drawRect(
                color = Color.Black.copy(alpha = 0.65f),
                size = size
            )

            // Transparent viewfinder window
            drawRoundRect(
                color = Color.Transparent,
                topLeft = Offset(left, top),
                size = Size(frameSize, frameSize),
                cornerRadius = CornerRadius(24f, 24f),
                blendMode = BlendMode.Clear
            )

            // Subtle border
            drawRoundRect(
                color = FolkSage,
                topLeft = Offset(left, top),
                size = Size(frameSize, frameSize),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 3f)
            )
        }

        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
                    .testTag("close_qr_scanner_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = FolkWarmIvory
                )
            }

            Text(
                "Scan Peer QR Code",
                color = FolkWarmIvory,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            IconButton(
                onClick = {
                    torchEnabled = !torchEnabled
                    cameraControl?.enableTorch(torchEnabled)
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
            ) {
                Icon(
                    imageVector = if (torchEnabled) Icons.Default.FlashlightOff else Icons.Default.FlashlightOn,
                    contentDescription = "Toggle Torch",
                    tint = if (torchEnabled) FolkSage else FolkWarmIvory
                )
            }
        }

        var showPasteDialog by remember { mutableStateOf(false) }
        var pasteInput by remember { mutableStateOf("") }

        // Bottom instruction card and manual paste button
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 40.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(FolkDeepForest.copy(alpha = 0.95f))
                    .border(1.dp, FolkSage.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Align FolkChat QR Code in frame",
                        color = FolkWarmIvory,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "Point camera at peer's QR code to scan instantly",
                        color = FolkSage,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { showPasteDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Black.copy(alpha = 0.65f),
                    contentColor = FolkWarmIvory
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("paste_qr_code_button")
            ) {
                Text("Paste Key or Code Manually ›", fontSize = 12.sp, color = FolkSage)
            }
        }

        if (showPasteDialog) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showPasteDialog = false },
                title = { Text("Enter Contact Code", color = FolkDeepForest, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            "Paste an sc1:... contact code or a 64-character sovereign public key:",
                            fontSize = 13.sp,
                            color = FolkDeepForest.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        androidx.compose.material3.OutlinedTextField(
                            value = pasteInput,
                            onValueChange = { pasteInput = it },
                            placeholder = { Text("sc1:public_key:name", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth().testTag("paste_code_input_field"),
                            maxLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val trimmed = pasteInput.trim()
                            if (trimmed.isNotEmpty()) {
                                showPasteDialog = false
                                onQrCodeDetected(trimmed)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FolkDeepForest)
                    ) {
                        Text("Add Contact", color = FolkWarmIvory)
                    }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = { showPasteDialog = false }) {
                        Text("Cancel", color = FolkDeepForest)
                    }
                },
                containerColor = FolkWarmIvory
            )
        }
    }
}
