package com.example.ui.security

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.data.AppSettings
import com.example.data.EncryptedVault
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * App Lock: a real 6-digit PIN (salted + iterated hash in the encrypted vault) plus
 * optional system biometric (fingerprint / face) unlock, cold-start enforcement and
 * an idle auto-lock timer. Everything is driven by persisted settings in the vault —
 * nothing here is cosmetic.
 */
class AppLockManager(private val vault: EncryptedVault, private val context: Context) {

    private val _locked = MutableStateFlow(false)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()

    private val _unlockFailure = MutableStateFlow<String?>(null)
    val unlockFailure: StateFlow<String?> = _unlockFailure.asStateFlow()

    private val handler = Handler(Looper.getMainLooper())
    private var lastUnlockAt = System.currentTimeMillis()
    private var pendingLock: Runnable? = null

    private var prompt: BiometricPrompt? = null

    fun settings(): AppSettings = vault.getSettings()

    val isAppLockEnabled: Boolean get() = vault.getSettings().appLockEnabled

    /** True when the user has configured a 6-digit PIN. */
    fun hasPin(): Boolean = vault.getSettings().pinHash.isNotBlank()

    /** True only when real biometrics are enrolled and usable (not merely hardware present). */
    fun canUseBiometric(): Boolean {
        val can = BiometricManager.from(context).canAuthenticate(BIOMETRIC_WEAK)
        return can == BiometricManager.BIOMETRIC_SUCCESS
    }

    /** True when any unlock method (usable biometric or device credential) exists. */
    fun canAuthenticate(): Boolean {
        val can = BiometricManager.from(context).canAuthenticate(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)
        return can == BiometricManager.BIOMETRIC_SUCCESS
    }

    /** True when any device credential (PIN/pattern/password) is enrolled on the device. */
    fun hasDeviceCredential(): Boolean {
        val can = BiometricManager.from(context).canAuthenticate(DEVICE_CREDENTIAL)
        return can == BiometricManager.BIOMETRIC_SUCCESS
    }

    /**
     * Cold-start enforcement: app lock must gate the app from the very first frame
     * after process death, not only after a background/foreground transition.
     */
    fun onAppCreated() {
        if (isAppLockEnabled) {
            _locked.value = true
        }
    }

    fun lockNow() {
        if (!isAppLockEnabled) return
        _locked.value = true
        cancelAutoLock()
    }

    fun unlock() {
        lastUnlockAt = System.currentTimeMillis()
        _locked.value = false
        _unlockFailure.value = null
        scheduleAutoLock()
    }

    fun cancelAutoLock() {
        pendingLock?.let { handler.removeCallbacks(it) }
        pendingLock = null
    }

    private fun scheduleAutoLock() {
        cancelAutoLock()
        if (!isAppLockEnabled) return
        val delay = vault.getSettings().autoLockMillis
        if (delay <= 0L) return
        val r = Runnable {
            if (isAppLockEnabled && System.currentTimeMillis() - lastUnlockAt >= delay) {
                _locked.value = true
            }
            pendingLock = null
        }
        pendingLock = r
        handler.postDelayed(r, delay)
    }

    fun onAppStopped(activity: Activity?) {
        if (!isAppLockEnabled) return
        val delay = vault.getSettings().autoLockMillis
        // "Immediately" (0) or standard timer: lock as soon as the app leaves the
        // foreground when the timer has elapsed; a 0-delay policy always locks now.
        if (delay <= 0L || System.currentTimeMillis() - lastUnlockAt >= delay) {
            _locked.value = true
            cancelAutoLock()
        } else {
            scheduleAutoLock()
        }
    }

    fun onAppResumed() {
        if (!isAppLockEnabled) {
            _locked.value = false
            return
        }
        // If still within the idle window, treat as unlocked.
        val idle = System.currentTimeMillis() - lastUnlockAt
        if (idle < vault.getSettings().autoLockMillis) {
            _locked.value = false
            scheduleAutoLock()
        }
    }

    // ------------------------------------------------------------------
    // PIN lifecycle: set / change / disable / verify
    // ------------------------------------------------------------------

    fun setPin(pin: String): Boolean {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return false
        vault.setPin(pin)
        return true
    }

    fun clearPin() {
        vault.clearPin()
    }

    fun verifyPin(pin: String): Boolean {
        val ok = vault.verifyPin(pin)
        if (ok) {
            unlock()
        } else {
            _unlockFailure.value = "Incorrect PIN. Try again."
        }
        return ok
    }

    /** Launches the system biometric prompt when biometrics are actually enrolled. */
    fun authenticateWithBiometric(
        activity: FragmentActivity,
        title: String = "FolkChat is locked",
        subtitle: String = "Confirm it is you",
        onSuccess: () -> Unit
    ): Boolean {
        if (!canUseBiometric()) return false
        val executor = ContextCompat.getMainExecutor(activity)
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                _unlockFailure.value = null
                unlock()
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // User can still fall back to PIN; do not spam.
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON
                ) {
                    _unlockFailure.value = errString.toString()
                }
            }
        }
        val p = BiometricPrompt(activity, executor, cb)
        prompt = p
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BIOMETRIC_WEAK)
            .build()
        p.authenticate(info)
        return true
    }

    // ------------------------------------------------------------------
    // Settings mutations
    // ------------------------------------------------------------------

    /**
     * Enable / disable the whole app lock. Enabling requires that at least one
     * unlock method exists (a configured FolkChat PIN, or usable biometrics).
     * Returns false (and does not enable) when no unlock method would be available.
     */
    fun setEnabled(enabled: Boolean): Boolean {
        if (enabled && !hasPin() && !canUseBiometric()) {
            return false // refuse to lock the user out
        }
        vault.updateSettings { it.copy(appLockEnabled = enabled) }
        if (enabled) {
            lastUnlockAt = System.currentTimeMillis()
            _locked.value = true // engage immediately: the user just armed it
            scheduleAutoLock()
        } else {
            _locked.value = false
            cancelAutoLock()
        }
        return true
    }

    fun setAutoLockMillis(millis: Long) {
        vault.updateSettings { it.copy(autoLockMillis = millis) }
        scheduleAutoLock()
    }

    fun setBiometricEnabled(enabled: Boolean) {
        vault.updateSettings { it.copy(biometricEnabled = enabled) }
    }

    /** Full disable: lock off + PIN cleared. */
    fun disableEverything() {
        vault.clearPin()
        vault.updateSettings { it.copy(appLockEnabled = false) }
        _locked.value = false
        cancelAutoLock()
    }

    fun invalidatePrompt() {
        prompt = null
    }
}
