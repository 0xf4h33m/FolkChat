package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =====================================================================
// FolkChat Design System — "Folk Forest" unified palette
// One palette across every screen: chats, calls, QR, lock, settings.
// =====================================================================

// ---- Brand anchors ---------------------------------------------------
val FolkForestGreen = Color(0xFF174A3A)      // Primary actions, active states, outgoing bubbles (light)
val FolkDeepForest = Color(0xFF103D31)       // Emphasis headings, emblem strokes, dark accents
val FolkSage = Color(0xFF92AD96)             // Sage accent, secondary highlights
val FolkLightSage = Color(0xFFE4EBDD)        // Soft sage tint surface
val FolkWarmIvory = Color(0xFFF7F5EA)        // Primary background, chat canvas
val FolkCardSurface = Color(0xFFF0F0E4)      // Elevated cards, incoming bubbles (light)
val FolkMutedGreen = Color(0xFF71877A)       // Muted icons, tertiary controls
val FolkTextPrimary = Color(0xFF18372E)      // Deep green-black body text (light)
val FolkTextSecondary = Color(0xFF728277)    // Secondary text (light)
val FolkBorderSubtle = Color(0xFFD8E0D2)     // Hairline dividers (light)
val FolkSuccess = Color(0xFF378653)          // Verified, online, delivered
val FolkError = Color(0xFFB94D48)            // Danger, delete, failed
val FolkWarning = Color(0xFFC97A2E)          // Queued, warnings
val FolkOnboarding = Color(0xFF2E7D5B)       // Fresh emerald for gradients / onboarding

// ---- Light theme tokens ----------------------------------------------
val LightBg = FolkWarmIvory
val LightSurface = FolkCardSurface
val LightSurfaceElevated = Color(0xFFFAF8F2)
val LightSurfaceSearch = Color(0xFFEDEDE0)
val LightOutline = FolkBorderSubtle
val LightOutlineSubtle = Color(0xFFEAEFE6)
val LightTopBar = Color(0xFFF3F1E4)

val LightTextPrimary = FolkTextPrimary
val LightTextSecondary = FolkTextSecondary
val LightTextMuted = FolkMutedGreen

val LightOutgoingBubble = FolkForestGreen
val LightOutgoingBubbleBorder = FolkDeepForest
val LightOutgoingText = FolkWarmIvory
val LightOutgoingMeta = Color(0xFFBCCFC2)

val LightIncomingBubble = Color(0xFFF3F2E6)
val LightIncomingBubbleBorder = FolkBorderSubtle
val LightIncomingText = FolkTextPrimary
val LightIncomingMeta = FolkTextSecondary

// ---- Dark theme tokens ("Deep Forest Dark") --------------------------
val DarkBg = Color(0xFF0F1E19)               // Rich dark forest background (not pure black)
val DarkSurfaceClean = Color(0xFF152922)     // Deep forest card surface
val DarkSurfaceElevatedClean = Color(0xFF1E3830)
val DarkSurfaceSearch = Color(0xFF132520)
val DarkOutlineClean = Color(0xFF28483D)
val DarkTopBar = Color(0xFF12241D)

val DarkTextPrimaryClean = Color(0xFFE8F2EC)
val DarkTextSecondaryClean = Color(0xFFA5BDB0)
val DarkTextMutedClean = Color(0xFF7A9788)

val DarkOutgoingBubbleClean = Color(0xFF1B4E3E)
val DarkOutgoingBubbleBorderClean = Color(0xFF246350)
val DarkOutgoingTextClean = Color(0xFFF5FAF7)
val DarkOutgoingMetaClean = Color(0xFF9DC0AC)

val DarkIncomingBubbleClean = Color(0xFF19322A)
val DarkIncomingBubbleBorderClean = Color(0xFF244439)
val DarkIncomingTextClean = Color(0xFFE8F2EC)
val DarkIncomingMetaClean = Color(0xFF8FAD9E)

// ---- Status colors: identical family in both modes (brighter for dark) ----
val FolkSuccessDark = Color(0xFF66C285)
val FolkWarningDark = Color(0xFFE0A458)
val FolkErrorDark = Color(0xFFE07B75)

// ---- Call surface (WhatsApp-style deep stage, same in both modes) ----
val CallStageBg = Color(0xFF0B1A15)
val CallStageBgDeep = Color(0xFF071310)
val CallControlSurface = Color(0xFF1C3A2F)
val CallControlSurfaceActive = Color(0xFF2E7D5B)
val CallAccent = Color(0xFF9FCBAD)

// ---- QR scanner chrome ------------------------------------------------
val QrScrim = Color(0x99000000)
val QrFrame = FolkSage
