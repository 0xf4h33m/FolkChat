package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.PinDots
import com.example.ui.security.AppLockManager
import com.example.ui.theme.FolkError
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkTextPrimary

/**
 * Two-step PIN creation flow: choose a 6-digit PIN, then confirm it.
 * Calls [onDone] with the verified PIN so the caller persists it and
 * (optionally) arms the app lock.
 */
@Composable
fun PinSetupDialog(
    appLock: AppLockManager,
    onDone: (pin: String) -> Unit,
    onDismiss: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) } // 1 = choose, 2 = confirm
    var firstPin by remember { mutableStateOf("") }
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val haptics = LocalHapticFeedback.current

    val title = when (step) {
        1 -> "Create your PIN"
        else -> "Confirm your PIN"
    }
    val subtitle = when (step) {
        1 -> "Choose a 6-digit PIN used to unlock FolkChat"
        else -> "Re-enter the same 6 digits to confirm"
    }

    fun onFullPin(pin: String) {
        if (step == 1) {
            firstPin = pin
            step = 2
            entry = ""
        } else {
            if (pin == firstPin) {
                appLock.setPin(pin)
                onDone(pin)
            } else {
                error = "PINs don't match. Start over."
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                step = 1
                firstPin = ""
                entry = ""
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(18.dp))
                PinDots(count = 6, filled = entry.length, isError = error != null)
                error?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = FolkError, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(22.dp))
                DialogKeypad(
                    onDigit = {
                        if (entry.length < 6) {
                            entry += it
                            error = null
                            if (entry.length == 6) onFullPin(entry)
                        }
                    },
                    onBackspace = { if (entry.isNotEmpty()) entry = entry.dropLast(1) }
                )
            }
        }
    )
}

/**
 * Change-PIN flow: verify the current PIN first, then create a new one.
 */
@Composable
fun ChangePinDialog(
    appLock: AppLockManager,
    onDone: () -> Unit,
    onDismiss: () -> Unit
) {
    var stage by remember { mutableIntStateOf(0) } // 0 = verify old, 1..2 = new/confirm
    var verifiedOld by remember { mutableStateOf(false) }
    var firstPin by remember { mutableStateOf("") }
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val haptics = LocalHapticFeedback.current

    val (title, subtitle) = when (stage) {
        0 -> "Enter current PIN" to "Verify it is you before changing the PIN"
        1 -> "Create new PIN" to "Choose a new 6-digit PIN"
        else -> "Confirm new PIN" to "Re-enter the same 6 digits"
    }

    fun onFullPin(pin: String) {
        when (stage) {
            0 -> {
                if (appLock.settings().pinHash.isNotBlank()) {
                    if (appLock.verifyPin(pin)) {
                        verifiedOld = true
                        stage = 1
                        entry = ""
                    } else {
                        error = "Incorrect current PIN"
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        entry = ""
                    }
                } else {
                    verifiedOld = true
                    stage = 1
                    entry = ""
                }
            }
            1 -> {
                firstPin = pin
                stage = 2
                entry = ""
            }
            else -> {
                if (pin == firstPin) {
                    appLock.setPin(pin)
                    onDone()
                } else {
                    error = "PINs don't match. Start over."
                    stage = 1
                    firstPin = ""
                    entry = ""
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(18.dp))
                PinDots(count = 6, filled = entry.length, isError = error != null)
                error?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = FolkError, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(22.dp))
                DialogKeypad(
                    onDigit = {
                        if (entry.length < 6) {
                            entry += it
                            error = null
                            if (entry.length == 6) onFullPin(entry)
                        }
                    },
                    onBackspace = { if (entry.isNotEmpty()) entry = entry.dropLast(1) }
                )
            }
        }
    )
}

/** Compact themed keypad used inside PIN dialogs. */
@Composable
private fun DialogKeypad(
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9")
        ).forEach { rowKeys ->
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                rowKeys.forEach { key ->
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onDigit(key)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(key, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = FolkTextPrimary)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(58.dp))
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDigit("0")
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("0", fontSize = 20.sp, fontWeight = FontWeight.Medium, color = FolkTextPrimary)
            }
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onBackspace()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = FolkSage,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
