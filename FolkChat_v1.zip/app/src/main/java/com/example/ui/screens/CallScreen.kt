package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.CallType
import com.example.net.call.CallManager
import com.example.net.call.CallState
import com.example.ui.components.PeerAvatar
import com.example.ui.theme.CallControlSurface
import com.example.ui.theme.CallControlSurfaceActive
import com.example.ui.theme.CallStageBg
import com.example.ui.theme.CallStageBgDeep
import com.example.ui.theme.FolkError
import com.example.ui.theme.FolkErrorDark
import com.example.ui.theme.FolkOnboarding
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkSuccessDark
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Full-screen WhatsApp-style call overlay for the entire call lifecycle,
 * driven directly by the real [CallManager] state.
 */
@Composable
fun ActiveCallScreen(
    callManager: CallManager,
    onClose: () -> Unit
) {
    val session by callManager.session.collectAsState()
    val duration by callManager.durationSeconds.collectAsState()
    val remoteFrame by callManager.remoteFrame.collectAsState()
    val statusMessage by callManager.statusMessage.collectAsState()

    val current = session ?: return

    val isIncoming = current.state == CallState.INCOMING_RINGING
    val isActive = current.state == CallState.ACTIVE
    val isEnded = current.state == CallState.ENDED
    val isVideoLive = current.type == CallType.VIDEO && isActive && current.videoEnabled

    // Resolve the peer's saved avatar (profile image flow) if we have one.
    val context = LocalContext.current
    val peerAvatarPath = remember(current.peerPubKeyHex) {
        try {
            (context.applicationContext as? com.example.SecureChatApp)
                ?.vault?.getContactByPubKey(current.peerPubKeyHex)?.avatarPath
        } catch (_: Exception) {
            null
        }
    }

    // Auto-dismiss overlay shortly after the engine clears the session.
    LaunchedEffect(session) {
        if (session == null) onClose()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(CallStageBg, CallStageBgDeep)))
    ) {
        if (isVideoLive) {
            // Remote camera feed fills the stage.
            val frame = remoteFrame
            if (frame != null) {
                Image(
                    bitmap = frame.asImageBitmap(),
                    contentDescription = "Remote video",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Waiting for peer video…", color = FolkSage, fontSize = 13.sp)
                }
            }

            // Local self-view (picture-in-picture).
            CameraCaptureView(
                callManager = callManager,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .size(width = 104.dp, height = 148.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 52.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(28.dp))

            if (!isVideoLive) {
                PeerAvatar(
                    name = current.peerName,
                    avatarPath = peerAvatarPath,
                    size = 128.dp
                )
                Spacer(modifier = Modifier.height(24.dp))
            } else {
                Spacer(modifier = Modifier.height(8.dp))
            }

            Text(
                text = current.peerName,
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = when {
                    isEnded -> statusMessage ?: "Call ended"
                    isIncoming -> "Incoming ${if (current.type == CallType.VIDEO) "video" else "voice"} call"
                    current.state == CallState.OUTGOING_RINGING -> statusMessage ?: "Ringing…"
                    current.state == CallState.CONNECTING -> statusMessage ?: "Connecting…"
                    isActive -> formatActiveCallDuration(duration)
                    else -> ""
                },
                fontSize = 14.sp,
                color = FolkSage
            )

            if (isActive) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = FolkSuccessDark,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "End-to-end encrypted peer-to-peer",
                        fontSize = 11.sp,
                        color = FolkSage
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            if (isIncoming) {
                // WhatsApp-style incoming call controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CallControlButton(
                        icon = Icons.Default.CallEnd,
                        label = "Decline",
                        container = FolkErrorDark,
                        onClick = { callManager.rejectIncoming(); onClose() }
                    )
                    CallControlButton(
                        icon = Icons.Default.Call,
                        label = "Accept",
                        container = FolkOnboarding,
                        onClick = { callManager.acceptIncoming() }
                    )
                }
            } else if (isEnded) {
                CallControlButton(
                    icon = Icons.Default.CallEnd,
                    label = "Close",
                    container = CallControlSurface,
                    onClick = { onClose() }
                )
            } else {
                // Outgoing ringing / connecting / active controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CallControlButton(
                        icon = if (current.muted) Icons.Default.MicOff else Icons.Default.Mic,
                        label = if (current.muted) "Unmute" else "Mute",
                        container = if (current.muted) CallControlSurfaceActive else CallControlSurface,
                        enabled = isActive,
                        onClick = { callManager.toggleMute() }
                    )
                    CallControlButton(
                        icon = if (current.speakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        label = "Speaker",
                        container = if (current.speakerOn) CallControlSurfaceActive else CallControlSurface,
                        enabled = isActive,
                        onClick = { callManager.toggleSpeaker() }
                    )
                    if (current.type == CallType.VIDEO) {
                        CallControlButton(
                            icon = if (current.videoEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            label = "Camera",
                            container = if (current.videoEnabled) CallControlSurfaceActive else CallControlSurface,
                            enabled = isActive,
                            onClick = { callManager.setVideoEnabled(!current.videoEnabled) }
                        )
                    }
                    CallControlButton(
                        icon = Icons.Default.CallEnd,
                        label = "End",
                        container = FolkErrorDark,
                        onClick = { callManager.endCall() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun CallControlButton(
    icon: ImageVector,
    label: String,
    container: Color,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(if (enabled) container else container.copy(alpha = 0.35f)),
            contentAlignment = Alignment.Center
        ) {
            IconButton(onClick = { if (enabled) onClick() }) {
                Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(label, fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f), fontWeight = FontWeight.Medium)
    }
}

/**
 * Binds CameraX and continuously feeds JPEG frames into the live call. This makes the
 * "camera" toggle a real, functional control rather than a visual placeholder.
 */
@Composable
private fun CameraCaptureView(
    callManager: CallManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    AndroidView(
        factory = { ctx ->
            PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
        },
        modifier = modifier
    )

    DisposableEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val preview = Preview.Builder().build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()

                analysis.setAnalyzer(executor) { imageProxy ->
                    try {
                        if (callManager.session.value?.videoEnabled == true) {
                            val jpeg = imageProxyToJpeg(imageProxy)
                            if (jpeg != null) callManager.sendLocalVideoFrame(jpeg)
                        }
                    } catch (_: Exception) {
                    } finally {
                        imageProxy.close()
                    }
                }

                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview,
                    analysis
                )
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            try { cameraProvider?.unbindAll() } catch (_: Exception) {}
            executor.shutdown()
        }
    }
}

private fun imageProxyToJpeg(imageProxy: ImageProxy): ByteArray? {
    val plane = imageProxy.planes.firstOrNull() ?: return null
    val buffer = plane.buffer
    val rowStride = plane.rowStride
    val pixelStride = plane.pixelStride
    val width = imageProxy.width
    val height = imageProxy.height

    val bitmap = Bitmap.createBitmap(
        width + (if (pixelStride > 0) (rowStride / pixelStride - width).coerceAtLeast(0) else 0),
        height,
        Bitmap.Config.ARGB_8888
    )
    buffer.rewind()
    bitmap.copyPixelsFromBuffer(buffer)

    val cropped = if (bitmap.width != width) Bitmap.createBitmap(bitmap, 0, 0, width, height) else bitmap

    // Rotate to match sensor orientation.
    val rotation = imageProxy.imageInfo.rotationDegrees
    val rotated = if (rotation != 0) {
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        Bitmap.createBitmap(cropped, 0, 0, cropped.width, cropped.height, matrix, true)
    } else cropped

    val out = ByteArrayOutputStream()
    rotated.compress(Bitmap.CompressFormat.JPEG, 60, out)
    return out.toByteArray()
}

private fun formatActiveCallDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}
