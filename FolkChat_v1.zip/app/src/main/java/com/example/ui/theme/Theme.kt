package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppThemeMode {
    CLASSIC_LIGHT,
    DEEP_DARK,
    SYSTEM
}

/**
 * Extended chat + app surface palette. Every screen (bubbles, calls, QR,
 * lock, dialogs) consumes these tokens so the palette is identical everywhere.
 */
data class CustomChatColors(
    val outgoingBubbleBg: Color,
    val outgoingBubbleBorder: Color,
    val outgoingText: Color,
    val outgoingMeta: Color,
    val incomingBubbleBg: Color,
    val incomingBubbleBorder: Color,
    val incomingText: Color,
    val incomingMeta: Color,
    val statusSuccess: Color,
    val statusWarning: Color,
    val statusError: Color,
    val presenceOnline: Color,
    val presenceAway: Color,
    val cardElevated: Color,
    val searchField: Color,
    val topBar: Color,
    val textMuted: Color,
    val primaryBrand: Color,
    val sageAccent: Color,
    val borderSubtle: Color,
    val scrim: Color
)

val LocalChatColors = staticCompositionLocalOf {
    CustomChatColors(
        outgoingBubbleBg = LightOutgoingBubble,
        outgoingBubbleBorder = LightOutgoingBubbleBorder,
        outgoingText = LightOutgoingText,
        outgoingMeta = LightOutgoingMeta,
        incomingBubbleBg = LightIncomingBubble,
        incomingBubbleBorder = LightIncomingBubbleBorder,
        incomingText = LightIncomingText,
        incomingMeta = LightIncomingMeta,
        statusSuccess = FolkSuccess,
        statusWarning = FolkWarning,
        statusError = FolkError,
        presenceOnline = FolkSuccess,
        presenceAway = FolkWarning,
        cardElevated = LightSurfaceElevated,
        searchField = LightSurfaceSearch,
        topBar = LightTopBar,
        textMuted = LightTextMuted,
        primaryBrand = FolkForestGreen,
        sageAccent = FolkSage,
        borderSubtle = LightOutline,
        scrim = Color(0x66000000)
    )
}

private val FolkLightColorScheme = lightColorScheme(
    primary = FolkForestGreen,
    onPrimary = FolkWarmIvory,
    primaryContainer = FolkLightSage,
    onPrimaryContainer = FolkDeepForest,
    secondary = FolkSage,
    onSecondary = FolkDeepForest,
    secondaryContainer = FolkLightSage,
    onSecondaryContainer = FolkDeepForest,
    tertiary = FolkSuccess,
    onTertiary = Color.White,
    error = FolkError,
    onError = Color.White,
    background = FolkWarmIvory,
    onBackground = FolkTextPrimary,
    surface = FolkWarmIvory,
    onSurface = FolkTextPrimary,
    surfaceVariant = FolkLightSage,
    onSurfaceVariant = FolkTextSecondary,
    surfaceTint = FolkForestGreen,
    inverseSurface = FolkDeepForest,
    inverseOnSurface = FolkWarmIvory,
    outline = FolkBorderSubtle,
    outlineVariant = LightOutlineSubtle,
    scrim = Color(0x66000000)
)

private val FolkDarkColorScheme = darkColorScheme(
    primary = FolkSage,
    onPrimary = FolkDeepForest,
    primaryContainer = DarkOutgoingBubbleClean,
    onPrimaryContainer = Color(0xFFD4E8DC),
    secondary = FolkSage,
    onSecondary = FolkDeepForest,
    secondaryContainer = DarkSurfaceElevatedClean,
    onSecondaryContainer = Color(0xFFD4E8DC),
    tertiary = FolkSuccessDark,
    onTertiary = Color(0xFF0F1E19),
    error = FolkErrorDark,
    onError = Color(0xFF0F1E19),
    background = DarkBg,
    onBackground = DarkTextPrimaryClean,
    surface = DarkSurfaceClean,
    onSurface = DarkTextPrimaryClean,
    surfaceVariant = DarkSurfaceElevatedClean,
    onSurfaceVariant = DarkTextSecondaryClean,
    surfaceTint = FolkSage,
    inverseSurface = Color(0xFFE8F2EC),
    inverseOnSurface = FolkDeepForest,
    outline = DarkOutlineClean,
    outlineVariant = Color(0xFF223E34),
    scrim = Color(0x99000000)
)

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode = AppThemeMode.CLASSIC_LIGHT,
    content: @Composable () -> Unit,
) {
    val isDark = when (themeMode) {
        AppThemeMode.CLASSIC_LIGHT -> false
        AppThemeMode.DEEP_DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) FolkDarkColorScheme else FolkLightColorScheme

    val chatColors = if (isDark) {
        CustomChatColors(
            outgoingBubbleBg = DarkOutgoingBubbleClean,
            outgoingBubbleBorder = DarkOutgoingBubbleBorderClean,
            outgoingText = DarkOutgoingTextClean,
            outgoingMeta = DarkOutgoingMetaClean,
            incomingBubbleBg = DarkIncomingBubbleClean,
            incomingBubbleBorder = DarkIncomingBubbleBorderClean,
            incomingText = DarkIncomingTextClean,
            incomingMeta = DarkIncomingMetaClean,
            statusSuccess = FolkSuccessDark,
            statusWarning = FolkWarningDark,
            statusError = FolkErrorDark,
            presenceOnline = FolkSuccessDark,
            presenceAway = FolkWarningDark,
            cardElevated = DarkSurfaceElevatedClean,
            searchField = DarkSurfaceSearch,
            topBar = DarkTopBar,
            textMuted = DarkTextMutedClean,
            primaryBrand = FolkSage,
            sageAccent = FolkSage,
            borderSubtle = DarkOutlineClean,
            scrim = Color(0xB3000000)
        )
    } else {
        CustomChatColors(
            outgoingBubbleBg = LightOutgoingBubble,
            outgoingBubbleBorder = LightOutgoingBubbleBorder,
            outgoingText = LightOutgoingText,
            outgoingMeta = LightOutgoingMeta,
            incomingBubbleBg = LightIncomingBubble,
            incomingBubbleBorder = LightIncomingBubbleBorder,
            incomingText = LightIncomingText,
            incomingMeta = LightIncomingMeta,
            statusSuccess = FolkSuccess,
            statusWarning = FolkWarning,
            statusError = FolkError,
            presenceOnline = FolkSuccess,
            presenceAway = FolkWarning,
            cardElevated = LightSurfaceElevated,
            searchField = LightSurfaceSearch,
            topBar = LightTopBar,
            textMuted = LightTextMuted,
            primaryBrand = FolkForestGreen,
            sageAccent = FolkSage,
            borderSubtle = LightOutline,
            scrim = Color(0x66000000)
        )
    }

    CompositionLocalProvider(LocalChatColors provides chatColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
