package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.LocalChatColors
import java.io.File

/**
 * Reusable peer / self avatar: profile image when available, initials
 * fallback, optional live presence dot. Consumes the unified palette.
 */
@Composable
fun PeerAvatar(
    name: String,
    avatarPath: String?,
    size: Dp = 52.dp,
    isOnline: Boolean = false,
    showPresence: Boolean = false
) {
    val chatColors = LocalChatColors.current
    val context = LocalContext.current

    Box(modifier = Modifier.size(size)) {
        val avatarFile = avatarPath?.let { File(it) }?.takeIf { it.exists() }
        if (avatarFile != null) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(avatarFile)
                    .crossfade(true)
                    .build(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initialsOf(name),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontSize = (size.value * 0.36f).sp
                )
            }
        }

        if (showPresence) {
            val ring = size * 0.055f
            Box(
                modifier = Modifier
                    .size(size * 0.26f)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(if (isOnline) chatColors.presenceOnline else MaterialTheme.colorScheme.surfaceVariant)
                    .border(ring, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

fun initialsOf(name: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return when {
        parts.isEmpty() -> "?"
        parts.size == 1 -> parts[0].take(1).uppercase()
        else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
    }
}

// ---------------------------------------------------------------------
// Time formatting helpers (shared across screens)
// ---------------------------------------------------------------------

private val timeFormat by lazy { java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault()) }
private val dayMonthFormat by lazy { java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault()) }
private val fullDateFormat by lazy { java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.getDefault()) }
private val dayOfWeekFormat by lazy { java.text.SimpleDateFormat("EEEE", java.util.Locale.getDefault()) }

private fun startOfDay(ms: Long): Long {
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = ms
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

/** Compact list timestamp: time today, "Yesterday", weekday this week, else date. */
fun formatListTimestamp(ms: Long): String {
    val today = startOfDay(System.currentTimeMillis())
    val day = startOfDay(ms)
    return when {
        day == today -> timeFormat.format(java.util.Date(ms))
        day == today - 86_400_000L -> "Yesterday"
        day > today - 6 * 86_400_000L -> dayOfWeekFormat.format(java.util.Date(ms)).take(3)
        else -> dayMonthFormat.format(java.util.Date(ms))
    }
}

/** In-chat date divider label. */
fun formatChatDivider(ms: Long): String {
    val today = startOfDay(System.currentTimeMillis())
    val day = startOfDay(ms)
    return when {
        day == today -> "Today"
        day == today - 86_400_000L -> "Yesterday"
        day > today - 7 * 86_400_000L -> dayOfWeekFormat.format(java.util.Date(ms))
        else -> fullDateFormat.format(java.util.Date(ms))
    }
}

/** Presence subtitle: "Online", "Last seen today at 3:42 PM", "Offline". */
fun formatPresence(isOnline: Boolean, lastSeenMs: Long): String {
    if (isOnline) return "Online"
    if (lastSeenMs <= 0L) return "Offline"
    val today = startOfDay(System.currentTimeMillis())
    val day = startOfDay(lastSeenMs)
    return when {
        day == today -> "Last seen today at ${timeFormat.format(java.util.Date(lastSeenMs))}"
        day == today - 86_400_000L -> "Last seen yesterday at ${timeFormat.format(java.util.Date(lastSeenMs))}"
        else -> "Last seen ${fullDateFormat.format(java.util.Date(lastSeenMs))}"
    }
}
