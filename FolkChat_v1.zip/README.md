# FolkChat v2 — Private. Simple. Yours.

FolkChat is an air-gapped, zero-knowledge, **peer-to-peer end-to-end encrypted messenger** for Android. No accounts. No phone numbers. No tracking. Identity is a local X25519 keypair; messages are sealed with ChaCha20-Poly1305 and travel device-to-device over local Wi-Fi, BLE, or an optional self-hosted zero-knowledge relay (optionally routed through Tor).

## Run Locally

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Open Android Studio → **Open** → choose this project directory.
2. Allow Android Studio to fix any import incompatibilities.
3. If you use the AI Studio signing path: create a file named `.env` with your `GEMINI_API_KEY` (see `.env.example`) and keep the `signingConfig` lines in `app/build.gradle.kts`. Otherwise remove the `signingConfig = signingConfigs.getByName("debugConfig")` line from the debug build type.
4. Run the app on an emulator or physical device.

## Feature Overview (v2)

### Messaging
- E2E text messaging with reply, reactions (6 quick emoji), edit, delete for me/everyone, pin, copy
- **Typing indicators** and **read receipts (✓✓)** — both privacy-toggleable
- **Disappearing messages** per chat (30 s / 5 m / 1 h / 24 h / 7 d), synced to the peer and enforced locally on both devices
- **Forward** any message to another contact, **star** messages (browse from Profile)
- **Archive** and **mute** conversations, unread badges per chat and on the bottom bar
- Message requests from unknown peers (Instagram-style intake: Accept / Decline / Block)
- Per-conversation search with live highlighting, day dividers, system event pills

### Media
- Photos, videos, documents — **any file type up to 2 GB**, chunked E2E transfer with live progress, cancel and retry
- **Animated GIF sending** (picked and rendered with Coil + GifDecoder)
- **View once / view twice** media (WhatsApp-style): sealed bubble, view counter, media destroyed after the budget is spent, sender sees "Opened"
- Voice notes with inline player (auto-play bug fixed)

### Calls
- Real P2P voice and video calls over LAN (16 kHz PCM + CameraX JPEG frames)
- WhatsApp-style call UI: deep forest stage, avatar, round controls, E2EE badge
- Incoming-call heads-up notification, call history with outcome colors and redial
- Blocked peers are auto-rejected

### Privacy & Security (first-class)
- **App Lock**: 6-digit PIN (salted, 20 000-iteration hash) + biometric unlock, cold-start enforcement, auto-lock (Immediately / 30 s / 1 m / 5 m)
- Full PIN setup / change dialogs in **Settings → Security center**
- **Block list** enforced at the transport layer (messages and calls silently dropped)
- Notification privacy: full / sender-only / hidden previews + sound & vibration toggles + per-chat mute
- **Screenshot protection** (FLAG_SECURE)
- Read receipts and typing indicators can be disabled
- **Profile image flow**: set your avatar, synced E2E to contacts; avatars shown in lists, chats and calls
- **Online / last-seen presence** in chats and calls

### Networking
- Routing policy: Auto / Force online relay / Force offline mesh — **persisted across restarts**
- Offline mesh over Wi-Fi LAN sockets (UDP beacon discovery) and BLE GATT
- **Real WebSocket relay client** (configure your own relay URL in Settings → Network)
- **Tor routing** (OFF by default): tunnels the relay connection through Orbot's SOCKS proxy (127.0.0.1:9050) with live Orbot detection
- Link diagnostics: peers, manual IP links, outbox flush, airgap simulation

### Design
- Unified **Folk Forest** palette (#174A3A forest green / #F7F5EA warm ivory / sage accents) across every screen, light and dark
- Professional Material 3 type scale, flat messenger layout, custom PIN keypad with haptics

## Tech

Kotlin · Jetpack Compose (Material 3) · BouncyCastle (X25519, ChaCha20-Poly1305, HKDF, BLAKE2b) · ZXing (QR) · CameraX · Coil (+GIF) · OkHttp (WebSocket relay, Tor SOCKS) · androidx.biometric · minSdk 24 / targetSdk 36
