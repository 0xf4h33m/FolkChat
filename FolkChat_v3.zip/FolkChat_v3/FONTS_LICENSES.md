# Font licenses & attribution

FolkChat bundles two open-licensed typeface families, subset to Latin-1 + common
punctuation with fontTools (`pyftsubset`) to keep the APK lean. Subsetting does not
change the license terms.

## Carlito (Friendly)

- Files: `app/src/main/res/font/carlito_regular.ttf`, `carlito_bold.ttf`
- Origin: https://github.com/googlefonts/carlito — metric-compatible with Calibri
- License: SIL Open Font License 1.1
- Copyright 2013 The Carlito Project Authors, licensed under the SIL OFL 1.1 with
  this Reserved Font Name "Carlito".

## Liberation Serif (Classic)

- Files: `app/src/main/res/font/serif_regular.ttf`, `serif_bold.ttf`
- Origin: https://github.com/liberationfonts/liberation-sans — metric-compatible with Times New Roman
- License: SIL Open Font License 1.1
- Copyright Red Hat, Inc., licensed under the SIL OFL 1.1 with Reserved Font Names
  "Liberation" and "Liberation Serif".

## SIL Open Font License 1.1 — summary

The full license text is available at https://openfontlicense.org/ (and is reproduced
below in brief). The fonts may be used, studied, modified, embedded and redistributed
(freely or as part of a larger work), provided the Reserved Font Names are not used to
name derivative fonts and that the license accompanies any redistribution of the font
files themselves. Bundling inside an APK is standard permitted use.

Full text: https://scripts.sil.org/OFL

## All other families

Default (Roboto), Modern serif (Noto Serif), Mono and Script resolve to typefaces that
already exist on the device; no additional font data ships for them.
