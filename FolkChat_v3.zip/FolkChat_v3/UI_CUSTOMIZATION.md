# FolkChat v3 — Appearance & Customization Guide

FolkChat is fully themeable from **Settings → Appearance**. Every choice is stored inside
the encrypted vault (like the rest of your data), survives restarts, and applies instantly
across the entire app — chats, lists, dialogs, calls, lock screens and the QR scanner.

## Theme modes

| Mode | Description |
|------|-------------|
| **Light** | Warm ivory canvas with sage accents (the classic Folk look). |
| **Dark** | Deep forest dark — rich near-black greens. |
| **AMOLED** | Pure-black canvas and near-black surfaces for OLED power saving. |
| **System** | Follows the Android system light/dark setting. |

AMOLED is a true `#000000` background with dimmed surfaces and stronger scrims, so dark
rooms and battery life both benefit.

## Accent colors

Eight palettes re-tint the *brand slots* only — outgoing bubbles, primary buttons, active
controls, the send/mic button, transfer cards and the voice player:

**Forest** (default) · **Emerald** · **Ocean** · **Dusk** · **Sunset** · **Rose** ·
**Amethyst** · **Graphite**

Neutrals (backgrounds, incoming bubbles, status colors) stay theme-owned so readability
never depends on which accent is active. Palettes automatically brighten for dark/AMOLED
mode.

## Text size

Five steps — **XS · S · M · L · XL** (0.85× – 1.25×). The step scales the complete
Material type scale (every screen, every dialog) and chat message bodies additionally clamp
to a readable 11–20 sp window. The scale is persisted as a multiplier and coerced to a safe
0.8–1.4 range on load.

## Bubble styles

- **Classic tails** — the traditional messenger silhouette with a tight tail corner.
- **Modern rounded** — even 16 dp corners with a small tail hint.
- **Soft squircle** — large 24 dp uniform corners, calm and minimal.

## Chat wallpapers

- **Solid** — flat theme canvas.
- **Gentle wash** — a soft vertical tint wash.
- **Folk dots** — the quiet dotted texture over the wash.

## Density and emphasis

- **Compact chat density** — tighter bubble padding fits more of the conversation on screen.
- **Outgoing bubble emphasis** — keeps your bubbles visually stronger than incoming ones.
- **Reduce motion** — disables pulses and animated movement (also swaps the animated typing
  dots for static dots).

## Live preview

The top of Settings → Appearance shows a miniature conversation (one incoming and one
outgoing bubble on the current wallpaper). Because every choice re-resolves the root theme,
the preview — and the whole app behind it — repaints the moment you tap.

## Technical notes

- Theme resolution lives in `ui/theme/Theme.kt` (`MyApplicationTheme`), palettes in
  `ui/theme/Color.kt`, the type scale and scaling in `ui/theme/Type.kt`.
- Chat-level choices are delivered via `LocalChatCustomization`
  (bubble style, wallpaper, font scale) next to the existing `LocalChatColors`.
- Persistence: `AppSettings.accentPalette / chatFontScale / bubbleStyle / chatWallpaper`
  inside the encrypted vault, with defensive parsing (unknown names fall back, the scale is
  clamped, strings are capped) so a corrupted vault can never crash the UI.
- `MainActivity` re-resolves the theme from the settings flow, which is what makes
  customization live rather than require a restart.

## Font families (new)

Six typefaces are selectable, two of them bundled inside the APK (subset to Latin-1, ~30–45 KB
each — see `FONTS_LICENSES.md`):

| Font | Family | Feel |
|------|--------|------|
| **Default** | Roboto (system) | The calm native Android voice |
| **Friendly** | Carlito (bundled) | Warm humanist sans, round and relaxed |
| **Classic** | Times-style serif (bundled) | Editorial weight |
| **Modern serif** | Noto Serif (system) | Crisp and contemporary |
| **Mono** | System monospace | Terminal clarity |
| **Script** | System cursive | Handwriting flavor (device-dependent) |

The family applies to the *entire* type scale (titles, body, labels) while preserving sizes,
weights and rhythm, so layouts do not shift. Settings → Appearance → **Font** renders a live
"Aa" sample in each family.

## Chat wallpapers (expanded)

Seven backdrops: **Solid** · **Wash** · **Dots** · **Aurora** (two brand-tinted blobs that
drift slowly — automatically static when *Reduce motion* is on) · **Grid** (fine engineering
grid) · **Paper** (warm diagonal hatch) · **Bloom** (two radial corner blooms). All are
drawn procedurally with the active palette, so they re-tint with your accent and theme.

## App emblem (new)

Five brand-mark styles rendered in the conversations header and the welcome screen:
**Folk** (forest badge + sage leaf), **Leaf**, **Bubbles**, **Shield**, **Signal**.
Settings → Appearance → **App emblem**.

## Home-screen app icon (new)

Four launcher icon variants, switchable at runtime: **Folk Forest** (classic sage/forest),
**Deep Ocean**, **Warm Sunset**, **Graphite**. Implementation: the manifest exposes four
`activity-alias` launcher entries, exactly one enabled at a time; the app enables the new
alias *before* disabling the old one (never a zero-entry-point window) and repairs the
state at startup if it ever becomes inconsistent. Adaptive icons ship for Android 8+
(including Android 13+ monochrome/themed icons); plain vector tiles cover API 24–25.
Your launcher app may take a moment (or a launcher restart) to redraw the icon — that is
an Android platform behavior, not an app delay.

## Motion & feel (new)

- Staggered entrance animations on the Welcome screen and both lock gates.
- Fresh messages rise and fade into place; history stays static.
- Chat and conversation lists animate item placement/reordering (`animateItem`).
- PIN failures shake the dots row (skipped under *Reduce motion*).
- A calm cross-fade bridges first-run onboarding and the main app.
- Unsent messages are preserved per conversation as drafts while you switch chats.

*Reduce motion* (Settings → Appearance) disables every animation above, and **Haptic
feedback** (new toggle) controls the tactile taps on keys, sends and toggles.
