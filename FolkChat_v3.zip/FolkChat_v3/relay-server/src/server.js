'use strict';

const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocket, WebSocketServer } = require('ws');
const { createX25519KeyPair, verifyRelayProof } = require('./auth');

function boundedIntegerFromEnv(name, fallback, min, max) {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === '') return fallback;
  if (!/^-?\d+$/.test(raw.trim())) {
    console.warn(`Ignoring invalid ${name}; using ${fallback}.`);
    return fallback;
  }
  const parsed = Number(raw.trim());
  if (!Number.isSafeInteger(parsed) || parsed < min || parsed > max) {
    console.warn(`Ignoring out-of-range ${name}; using ${fallback}.`);
    return fallback;
  }
  return parsed;
}

const PORT = boundedIntegerFromEnv('PORT', 8080, 1, 65535);
const WS_PATH = process.env.WS_PATH || '/ws';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const QUEUE_FILE = process.env.QUEUE_FILE || path.join(DATA_DIR, 'mailboxes.json');
const MAX_FRAME_BYTES = 256 * 1024;
const MAX_QUEUE_MESSAGES_PER_KEY = 256;
const MAX_QUEUE_BYTES_PER_KEY = 8 * 1024 * 1024;
const MAX_QUEUE_BYTES_TOTAL = 128 * 1024 * 1024;
// Offline encrypted envelopes expire after seven days by default to limit metadata retention.
// Invalid values fall back to policy defaults rather than purging queues due to NaN arithmetic.
const MAILBOX_TTL_MS = boundedIntegerFromEnv('MAILBOX_TTL_MS', 7 * 24 * 60 * 60 * 1000, 60_000, 90 * 24 * 60 * 60 * 1000);
const QUEUE_KEY_FILE = process.env.QUEUE_KEY_FILE || path.join(DATA_DIR, '.mailbox.key');
const MAX_CONNECTIONS = boundedIntegerFromEnv('MAX_CONNECTIONS', 5000, 1, 100_000);
const MAX_MESSAGES_PER_SECOND = 300;
const CHALLENGE_TTL_MS = 10_000;

const mailboxes = new Map(); // public key -> Array<{id, from, payload, createdAtMs, bytes}>
const clientsByKey = new Map(); // public key -> Set<WebSocket>
const challenges = new WeakMap();
let queuedBytesTotal = 0;
let queueEncryptionKey = null;
let persistChain = Promise.resolve();

/** Load a 256-bit key from an out-of-band secret where available. For local development,
 * create a mode-0600 key file inside DATA_DIR. Release deployments should set
 * MAILBOX_ENCRYPTION_KEY in the host's secret store and back it up separately. */
async function ensureQueueEncryptionKey() {
  if (queueEncryptionKey) return queueEncryptionKey;
  const configured = process.env.MAILBOX_ENCRYPTION_KEY?.trim();
  if (configured) {
    if (!/^[0-9a-f]{64}$/i.test(configured)) {
      throw new Error('MAILBOX_ENCRYPTION_KEY must be exactly 64 hexadecimal characters');
    }
    queueEncryptionKey = Buffer.from(configured, 'hex');
    return queueEncryptionKey;
  }
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    const existing = (await fs.readFile(QUEUE_KEY_FILE, 'utf8')).trim();
    if (!/^[0-9a-f]{64}$/i.test(existing)) throw new Error('Invalid mailbox encryption key file');
    await fs.chmod(QUEUE_KEY_FILE, 0o600).catch(() => {});
    queueEncryptionKey = Buffer.from(existing, 'hex');
    return queueEncryptionKey;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  const generated = crypto.randomBytes(32);
  try {
    await fs.writeFile(QUEUE_KEY_FILE, `${generated.toString('hex')}\n`, { flag: 'wx', mode: 0o600 });
    queueEncryptionKey = generated;
    return queueEncryptionKey;
  } catch (error) {
    // Another process may have won the create race. Never replace an existing key.
    if (error.code !== 'EEXIST') throw error;
    const existing = (await fs.readFile(QUEUE_KEY_FILE, 'utf8')).trim();
    if (!/^[0-9a-f]{64}$/i.test(existing)) throw new Error('Invalid mailbox encryption key file');
    queueEncryptionKey = Buffer.from(existing, 'hex');
    return queueEncryptionKey;
  }
}

function encryptMailboxSnapshot(plainText) {
  if (!queueEncryptionKey) throw new Error('Mailbox encryption key is not initialized');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', queueEncryptionKey, iv);
  const ciphertext = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  return JSON.stringify({
    format: 'folkchat-mailbox-v1',
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: ciphertext.toString('base64')
  });
}

function isMailboxItemShape(item) {
  return item && typeof item === 'object' && !Array.isArray(item) &&
    typeof item.id === 'string' && item.id.length > 0 && item.id.length <= 80 &&
    typeof item.from === 'string' && /^[0-9a-f]{64}$/i.test(item.from) &&
    typeof item.payload === 'string' && item.payload.length > 0 &&
    Buffer.byteLength(item.payload, 'utf8') <= MAX_FRAME_BYTES &&
    /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(item.payload) &&
    Number.isFinite(item.createdAtMs);
}

function decryptMailboxSnapshot(rawText) {
  const container = JSON.parse(rawText);
  if (!container || container.format !== 'folkchat-mailbox-v1') {
    // Only migrate a structurally valid legacy queue. Treating arbitrary/corrupt JSON as an
    // empty legacy queue would allow startup to overwrite and destroy queued messages.
    if (container && typeof container === 'object' && !Array.isArray(container)) {
      const entries = Object.entries(container);
      const legacyShapeIsValid = entries.every(([key, items]) =>
        /^[0-9a-f]{64}$/i.test(key) && Array.isArray(items) && items.every(isMailboxItemShape));
      if (legacyShapeIsValid) return { value: container, legacyPlaintext: true };
    }
    throw new Error('Unsupported or malformed mailbox store format');
  }
  const iv = Buffer.from(String(container.iv || ''), 'base64');
  const tag = Buffer.from(String(container.tag || ''), 'base64');
  const data = Buffer.from(String(container.data || ''), 'base64');
  if (iv.length !== 12 || tag.length !== 16 || data.length > MAX_QUEUE_BYTES_TOTAL * 2) {
    throw new Error('Invalid encrypted mailbox store');
  }
  const decipher = crypto.createDecipheriv('aes-256-gcm', queueEncryptionKey, iv);
  decipher.setAuthTag(tag);
  const plain = Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  return { value: JSON.parse(plain), legacyPlaintext: false };
}

function purgeExpiredMailboxesInMemory() {
  const cutoff = Date.now() - MAILBOX_TTL_MS;
  let changed = false;
  for (const [key, items] of mailboxes) {
    const retained = items.filter(item => Number.isFinite(item.createdAtMs) && item.createdAtMs >= cutoff);
    if (retained.length !== items.length) {
      changed = true;
      if (retained.length) mailboxes.set(key, retained);
      else mailboxes.delete(key);
    }
  }
  queuedBytesTotal = [...mailboxes.values()].reduce((sum, items) => sum + mailboxBytes(items), 0);
  return changed;
}

async function purgeExpiredMailboxes() {
  if (purgeExpiredMailboxesInMemory()) await persistMailboxes();
}

function sendJson(ws, payload) {
  if (ws.readyState !== WebSocket.OPEN || ws.bufferedAmount > 2 * 1024 * 1024) return false;
  try { ws.send(JSON.stringify(payload)); return true; } catch { return false; }
}

function replyError(ws, requestId, message) {
  sendJson(ws, { type: 'error', ...(requestId ? { requestId } : {}), message });
}

function mailboxBytes(items) {
  return items.reduce((n, item) => n + (item.bytes || Buffer.byteLength(item.payload || '', 'utf8')), 0);
}

async function loadMailboxes() {
  await ensureQueueEncryptionKey();
  let raw;
  try {
    raw = await fs.readFile(QUEUE_FILE, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return;
    throw new Error(`Could not read mailbox store; refusing to start without preserving queued messages (${error.message})`);
  }

  let parsed;
  let legacyPlaintext = false;
  try {
    const decoded = decryptMailboxSnapshot(raw);
    parsed = decoded.value;
    legacyPlaintext = decoded.legacyPlaintext;
  } catch (error) {
    // Fail closed: a wrong/missing key or tampered ciphertext must never be silently
    // interpreted as an empty mailbox and then overwritten.
    throw new Error(`Could not authenticate mailbox store; refusing to discard queued messages (${error.message})`);
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('Invalid mailbox store structure; refusing to overwrite it');
  }

  const now = Date.now();
  let changed = legacyPlaintext;
  const normalizedKeys = new Set();
  for (const [rawKey, items] of Object.entries(parsed)) {
    if (!/^[0-9a-f]{64}$/i.test(rawKey) || !Array.isArray(items) || !items.every(isMailboxItemShape)) {
      throw new Error('Invalid mailbox queue structure; refusing to overwrite queued data');
    }
    const key = rawKey.toLowerCase();
    if (normalizedKeys.has(key)) throw new Error('Duplicate normalized mailbox key; refusing to overwrite queued data');
    normalizedKeys.add(key);
    if (key !== rawKey) changed = true;
    const valid = items.filter(item => item.createdAtMs >= now - MAILBOX_TTL_MS)
      .slice(-MAX_QUEUE_MESSAGES_PER_KEY)
      .map(item => ({ ...item, from: item.from.toLowerCase(), bytes: Buffer.byteLength(item.payload, 'utf8') }));
    if (valid.length !== items.length) changed = true;
    if (valid.length) mailboxes.set(key, valid);
  }

  // Trim oldest queues if a restored file is larger than current policy.
  for (const [key, items] of mailboxes) {
    while (items.length > 0 && mailboxBytes(items) > MAX_QUEUE_BYTES_PER_KEY) {
      items.shift();
      changed = true;
    }
    if (!items.length) mailboxes.delete(key);
  }
  queuedBytesTotal = [...mailboxes.values()].reduce((sum, items) => sum + mailboxBytes(items), 0);
  // Trim the globally oldest entries until the process-wide cap is respected.
  while (queuedBytesTotal > MAX_QUEUE_BYTES_TOTAL) {
    let oldestKey = null;
    let oldestCreatedAt = Number.POSITIVE_INFINITY;
    for (const [key, items] of mailboxes) {
      const oldest = items[0];
      if (oldest && oldest.createdAtMs < oldestCreatedAt) {
        oldestCreatedAt = oldest.createdAtMs;
        oldestKey = key;
      }
    }
    if (!oldestKey) break;
    const items = mailboxes.get(oldestKey);
    const removed = items?.shift();
    if (removed) {
      queuedBytesTotal = Math.max(0, queuedBytesTotal - removed.bytes);
      changed = true;
    }
    if (!items?.length) mailboxes.delete(oldestKey);
  }
  if (changed) await persistMailboxes();
}

function persistMailboxes() {
  const snapshot = JSON.stringify(Object.fromEntries(mailboxes));
  const current = persistChain.then(async () => {
    await ensureQueueEncryptionKey();
    await fs.mkdir(DATA_DIR, { recursive: true });
    const temporaryPath = `${QUEUE_FILE}.tmp`;
    const encrypted = encryptMailboxSnapshot(snapshot);
    await fs.writeFile(temporaryPath, encrypted, { mode: 0o600 });
    await fs.rename(temporaryPath, QUEUE_FILE);
  });
  persistChain = current.catch(error => {
    console.error('Mailbox persistence failed; queued envelopes remain in memory:', error.message);
  });
  return current;
}

function addClient(key, ws) {
  let clients = clientsByKey.get(key);
  if (!clients) {
    clients = new Set();
    clientsByKey.set(key, clients);
  }
  clients.add(ws);
}

function removeClient(ws) {
  const key = ws.userKey;
  if (!key) return;
  const clients = clientsByKey.get(key);
  if (!clients) return;
  clients.delete(ws);
  if (!clients.size) clientsByKey.delete(key);
}

function deliverQueued(key, ws) {
  const queue = mailboxes.get(key) || [];
  for (const item of queue) {
    if (!sendJson(ws, {
      type: 'envelope',
      from: item.from,
      payload: item.payload,
      deliveryId: item.id
    })) break;
  }
}

async function handleEnvelope(ws, message) {
  const requestId = typeof message.requestId === 'string' && message.requestId.length <= 80 ? message.requestId : '';
  const recipientKey = typeof message.to === 'string' ? message.to.toLowerCase() : '';
  const payload = typeof message.payload === 'string' ? message.payload : '';
  const payloadBytes = Buffer.byteLength(payload, 'utf8');
  if (!/^[0-9a-f]{64}$/.test(recipientKey)) return replyError(ws, requestId, 'Invalid recipient key');
  if (!payload || payloadBytes > MAX_FRAME_BYTES || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(payload)) {
    return replyError(ws, requestId, 'Invalid or oversized encrypted packet');
  }

  const recipients = clientsByKey.get(recipientKey) || new Set();
  const openRecipients = [...recipients].filter(client => client.readyState === WebSocket.OPEN && client.userKey === recipientKey);
  const queueIfOffline = message.queueIfOffline !== false;

  if (!openRecipients.length && !queueIfOffline) {
    return replyError(ws, requestId, 'Recipient is offline; this packet type is not queued');
  }

  let queueItem = null;
  if (queueIfOffline) {
    const oldQueue = mailboxes.get(recipientKey) || [];
    const itemBytes = payloadBytes;
    if (oldQueue.length >= MAX_QUEUE_MESSAGES_PER_KEY || mailboxBytes(oldQueue) + itemBytes > MAX_QUEUE_BYTES_PER_KEY || queuedBytesTotal + itemBytes > MAX_QUEUE_BYTES_TOTAL) {
      return replyError(ws, requestId, 'Recipient offline mailbox is full; ask them to connect and retry');
    }
    queueItem = {
      id: crypto.randomUUID(),
      from: ws.userKey,
      payload,
      createdAtMs: Date.now(),
      bytes: itemBytes
    };
    oldQueue.push(queueItem);
    mailboxes.set(recipientKey, oldQueue);
    queuedBytesTotal += itemBytes;
    try {
      await persistMailboxes();
    } catch (error) {
      oldQueue.splice(oldQueue.findIndex(item => item.id === queueItem.id), 1);
      if (!oldQueue.length) mailboxes.delete(recipientKey);
      queuedBytesTotal = Math.max(0, queuedBytesTotal - itemBytes);
      return replyError(ws, requestId, 'Could not persist encrypted packet');
    }
  }

  if (openRecipients.length) {
    for (const recipient of openRecipients) {
      const ok = sendJson(recipient, {
        type: 'envelope',
        from: ws.userKey,
        payload,
        ...(queueItem ? { deliveryId: queueItem.id } : {})
      });
      if (!ok && queueItem) {
        // The persistent queue entry remains available for reconnect/redelivery.
      }
    }
  }
  sendJson(ws, { type: 'accepted', requestId });
}

async function handleReceived(ws, message) {
  const deliveryId = typeof message.deliveryId === 'string' ? message.deliveryId : '';
  if (!deliveryId || !ws.userKey) return;
  // Direct lookup instead of scanning every key: each acknowledgement used to
  // iterate the whole mailboxes map, costing O(total registered keys) per ACK.
  const items = mailboxes.get(ws.userKey);
  if (!items) return;
  const index = items.findIndex(item => item.id === deliveryId);
  if (index < 0) return;
  const [removed] = items.splice(index, 1);
  queuedBytesTotal = Math.max(0, queuedBytesTotal - removed.bytes);
  if (!items.length) mailboxes.delete(ws.userKey);
  try { await persistMailboxes(); }
  catch (error) { console.error('Could not persist mailbox acknowledgement:', error.message); }
}

function createRelayServer({ port = PORT, host = '0.0.0.0' } = {}) {
  const server = http.createServer((req, res) => {
    if (req.url === '/healthz') {
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify({ ok: true, service: 'folkchat-relay', protocol: 1 }));
      return;
    }
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('FolkChat relay. WebSocket endpoint: /ws\n');
  });

  const wss = new WebSocketServer({ server, path: WS_PATH, maxPayload: MAX_FRAME_BYTES });
  wss.on('connection', (ws) => {
    if (wss.clients.size > MAX_CONNECTIONS) {
      ws.close(1013, 'server at capacity');
      return;
    }
    ws.rateStartedMs = Date.now();
    ws.rateCount = 0;
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    ws.on('message', async (raw) => {
      try {
        const now = Date.now();
        if (now - ws.rateStartedMs >= 1000) {
          ws.rateStartedMs = now;
          ws.rateCount = 0;
        }
        ws.rateCount += 1;
        if (ws.rateCount > MAX_MESSAGES_PER_SECOND) {
          ws.close(1008, 'rate limit exceeded');
          return;
        }

        const message = JSON.parse(raw.toString('utf8'));
        if (!message || typeof message.type !== 'string') throw new Error('invalid message');

        if (!ws.userKey) {
          if (message.type === 'subscribe') {
            if (challenges.has(ws)) return replyError(ws, '', 'Challenge already issued');
            const key = typeof message.key === 'string' ? message.key.toLowerCase() : '';
            if (!/^[0-9a-f]{64}$/.test(key)) {
              ws.close(1008, 'invalid identity key');
              return;
            }
            const ephemeral = createX25519KeyPair();
            const nonce = crypto.randomBytes(32).toString('hex');
            challenges.set(ws, { key, nonce, privateKey: ephemeral.privateKey, expiresAt: Date.now() + CHALLENGE_TTL_MS });
            sendJson(ws, { type: 'challenge', nonce, serverPubKey: ephemeral.publicKeyHex });
            return;
          }
          if (message.type === 'authenticate') {
            const challenge = challenges.get(ws);
            if (!challenge || Date.now() > challenge.expiresAt || message.key?.toLowerCase() !== challenge.key || message.nonce !== challenge.nonce) {
              ws.close(1008, 'authentication challenge expired or mismatched');
              return;
            }
            const verified = verifyRelayProof({
              serverPrivateKey: challenge.privateKey,
              clientPublicKeyHex: challenge.key,
              nonce: challenge.nonce,
              suppliedProofHex: message.proof
            });
            challenges.delete(ws);
            if (!verified) {
              ws.close(1008, 'identity proof failed');
              return;
            }
            ws.userKey = challenge.key;
            addClient(ws.userKey, ws);
            sendJson(ws, { type: 'subscribed' });
            await purgeExpiredMailboxes();
            deliverQueued(ws.userKey, ws);
            return;
          }
          ws.close(1008, 'authenticate before sending');
          return;
        }

        if (message.type === 'envelope') await handleEnvelope(ws, message);
        else if (message.type === 'received') await handleReceived(ws, message);
        else if (message.type === 'pong') ws.isAlive = true;
        else replyError(ws, '', 'Unknown relay command');
      } catch (error) {
        replyError(ws, '', `Malformed relay frame: ${error.message}`);
      }
    });

    ws.on('close', () => removeClient(ws));
    ws.on('error', (error) => console.warn('WebSocket error:', error.message));
  });

  const mailboxJanitor = setInterval(() => {
    purgeExpiredMailboxes().catch(error => console.error('Mailbox expiry cleanup failed:', error.message));
  }, 60_000);
  mailboxJanitor.unref?.();

  const heartbeat = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) {
        ws.terminate();
        continue;
      }
      ws.isAlive = false;
      try { ws.ping(); } catch { ws.terminate(); }
    }
  }, 25_000);

  server.on('close', () => {
    clearInterval(heartbeat);
    clearInterval(mailboxJanitor);
  });
  return {
    server,
    wss,
    listen: () => new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, host, () => {
        server.off('error', reject);
        resolve(server.address());
      });
    }),
    close: () => new Promise(resolve => {
      clearInterval(heartbeat);
      for (const ws of wss.clients) ws.close(1001, 'server shutdown');
      wss.close(() => server.close(() => resolve()));
    })
  };
}

async function main() {
  await loadMailboxes();
  const relay = createRelayServer();
  const address = await relay.listen();
  console.log(`FolkChat relay listening on ${address.address}:${address.port}${WS_PATH}`);
  console.log(`Health endpoint: http://127.0.0.1:${address.port}/healthz`);
  console.log('Expose this service through TLS and configure the app with wss://your-host/ws.');
}

if (require.main === module) {
  main().catch(error => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = {
  createRelayServer, loadMailboxes, persistMailboxes, mailboxes, clientsByKey, verifyRelayProof,
  ensureQueueEncryptionKey, encryptMailboxSnapshot, decryptMailboxSnapshot, boundedIntegerFromEnv
};
