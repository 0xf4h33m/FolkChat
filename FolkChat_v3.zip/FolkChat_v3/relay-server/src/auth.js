'use strict';

const crypto = require('node:crypto');

const X25519_SPKI_PREFIX = Buffer.from('302a300506032b656e032100', 'hex');
const MAX_KEY_HEX = /^[0-9a-f]{64}$/;

function createX25519KeyPair() {
  const pair = crypto.generateKeyPairSync('x25519');
  const publicDer = pair.publicKey.export({ format: 'der', type: 'spki' });
  return {
    privateKey: pair.privateKey,
    publicKeyHex: publicDer.subarray(-32).toString('hex')
  };
}

function importRawX25519PublicKey(publicKeyHex) {
  if (typeof publicKeyHex !== 'string' || !MAX_KEY_HEX.test(publicKeyHex.toLowerCase())) {
    throw new TypeError('Invalid X25519 public key');
  }
  const raw = Buffer.from(publicKeyHex, 'hex');
  return crypto.createPublicKey({
    key: Buffer.concat([X25519_SPKI_PREFIX, raw]),
    format: 'der',
    type: 'spki'
  });
}

function relayProof(sharedSecret, nonce, publicKeyHex) {
  return crypto.createHmac('sha256', sharedSecret)
    .update(`FolkChat-Relay-Auth-v1|${nonce}|${publicKeyHex.toLowerCase()}`, 'utf8')
    .digest();
}

function verifyRelayProof({ serverPrivateKey, clientPublicKeyHex, nonce, suppliedProofHex }) {
  try {
    if (typeof nonce !== 'string' || !/^[0-9a-f]{64}$/i.test(nonce)) return false;
    if (typeof suppliedProofHex !== 'string' || !/^[0-9a-f]{64}$/i.test(suppliedProofHex)) return false;
    const clientPublicKey = importRawX25519PublicKey(clientPublicKeyHex);
    const shared = crypto.diffieHellman({ privateKey: serverPrivateKey, publicKey: clientPublicKey });
    const expected = relayProof(shared, nonce, clientPublicKeyHex);
    const supplied = Buffer.from(suppliedProofHex, 'hex');
    return supplied.length === expected.length && crypto.timingSafeEqual(expected, supplied);
  } catch {
    return false;
  }
}

module.exports = {
  createX25519KeyPair,
  importRawX25519PublicKey,
  relayProof,
  verifyRelayProof
};
