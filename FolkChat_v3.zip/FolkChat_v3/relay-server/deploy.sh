#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${1:-${FOLKCHAT_RELAY_DOMAIN:-}}"
if [[ -z "$DOMAIN" ]]; then
  echo "Usage: ./deploy.sh relay.your-domain.com" >&2
  exit 2
fi
if [[ ! "$DOMAIN" =~ ^[A-Za-z0-9.-]+$ || "$DOMAIN" != *.* || "$DOMAIN" == *..* || "$DOMAIN" == .* || "$DOMAIN" == *. ]]; then
  echo "Provide a real DNS hostname only (no scheme, port, path, or placeholder domain)." >&2
  exit 2
fi
if [[ "$DOMAIN" == *example* || "$DOMAIN" == "localhost" ]]; then
  echo "Placeholder/local hostnames cannot receive a public TLS certificate." >&2
  exit 2
fi

command -v docker >/dev/null 2>&1 || { echo "Docker is required on this server." >&2; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose plugin is required." >&2; exit 1; }
command -v openssl >/dev/null 2>&1 || { echo "OpenSSL is required to generate the relay storage key." >&2; exit 1; }

cd "$(dirname "$0")"
if [[ ! -f .env ]]; then
  umask 077
  printf 'FOLKCHAT_RELAY_DOMAIN=%s\nMAILBOX_ENCRYPTION_KEY=%s\n' \
    "$DOMAIN" "$(openssl rand -hex 32)" > .env
  chmod 600 .env
else
  # Preserve the existing mailbox encryption key across deploys and updates.
  if grep -q '^FOLKCHAT_RELAY_DOMAIN=' .env; then
    sed -i "s/^FOLKCHAT_RELAY_DOMAIN=.*/FOLKCHAT_RELAY_DOMAIN=$DOMAIN/" .env
  else
    printf '\nFOLKCHAT_RELAY_DOMAIN=%s\n' "$DOMAIN" >> .env
  fi
  if ! grep -q '^MAILBOX_ENCRYPTION_KEY=[0-9a-fA-F]\{64\}$' .env; then
    echo "MAILBOX_ENCRYPTION_KEY in .env is missing or invalid; refusing to rotate it automatically." >&2
    echo "Restore the original key or back up the encrypted mailbox before changing it." >&2
    exit 1
  fi
  chmod 600 .env
fi

printf '\nDeploying FolkChat relay for %s...\n' "$DOMAIN"
printf 'Prerequisite: DNS A/AAAA points here and inbound TCP 80/443 are reachable.\n\n'
docker compose up --build -d

if command -v curl >/dev/null 2>&1; then
  echo "Waiting briefly for HTTPS health check..."
  for _ in $(seq 1 30); do
    if curl --fail --silent --show-error --max-time 4 "https://${DOMAIN}/healthz" >/dev/null 2>&1; then
      echo "Relay is healthy: wss://${DOMAIN}/ws"
      echo "No phone-side relay configuration is needed when this endpoint is embedded in the APK."
      exit 0
    fi
    sleep 2
  done
  echo "Containers started, but HTTPS health check has not passed yet." >&2
  echo "Check DNS, firewall ports 80/443, and: docker compose logs --tail=100 caddy folkchat-relay" >&2
  exit 1
else
  echo "Relay started. Verify https://${DOMAIN}/healthz, then use wss://${DOMAIN}/ws in the release build."
fi
