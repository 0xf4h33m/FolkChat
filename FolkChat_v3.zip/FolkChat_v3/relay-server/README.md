# FolkChat Relay Server

This service is an optional self-hosted internet transport for FolkChat. The app also includes a no-configuration public WAN fallback, so this server is only needed when operators want to run their own relay. The relay forwards opaque, end-to-end-encrypted envelopes and does **not** decrypt message contents.

## Deploy for real mobile data

1. Deploy this folder to a VPS/container host with persistent storage and a public DNS name.
2. Terminate TLS in front of the container (Caddy, nginx, or a managed HTTPS/WebSocket host). Use a valid certificate; Android only accepts `wss://` for ordinary internet relays.
3. Keep the `/data` volume persistent. The encrypted offline mailbox is stored there; without a persistent volume, pending offline messages can be lost on restart.
4. In **FolkChat → Settings → Relay server**, enter `wss://YOUR_HOST/ws` on every phone, save it, and wait until the relay connects. Both phones need working internet and the same relay URL. For a preconfigured build, set `FOLKCHAT_RELAY_URL=wss://YOUR_HOST/ws` in `~/.gradle/gradle.properties` or the build environment; a per-device setting overrides it.
5. Test `/healthz` over HTTPS, then test phone A to phone B while on different networks (one on cellular and one on Wi-Fi). To test cellular-to-cellular, put both phones on mobile data and disable Wi-Fi. Switch one phone from Wi-Fi to cellular during a test; the client should re-authenticate after Android reports the default-network change.

## Run locally for development

Requires Node.js 20+ and npm.

```bash
cd relay-server
npm install
npm test
npm start
```

The local server listens on `0.0.0.0:8080`, WebSocket path `/ws`, with health endpoint `/healthz`. Local `ws://` should only be used for isolated development with a development build/configuration; release builds require `wss://` or a `.onion` relay through Tor.

Docker deployment:

```bash
docker compose up --build -d
```

The Compose file binds port 8080 to loopback for a TLS reverse proxy. Configure your reverse proxy to pass WebSocket upgrades to `127.0.0.1:8080` and forward the `/ws` path unchanged. For a Caddy installation on the host, copy `Caddyfile.example` to the Caddy config and replace `relay.example.com` with your real DNS name. Caddy can manage TLS certificates when the domain resolves to the host and ports 80/443 are reachable.

## Relay behavior and limits

- Identity subscription requires a fresh X25519 challenge proof. Knowing a public key alone is not enough to subscribe as that identity.
- Messages are routed to authenticated subscribers for the destination public key. Queueable packets are persisted in an encrypted-payload mailbox and removed after an authenticated destination client acknowledges receipt.
- Media chunks, typing events, and call-signal packets are not queued when the destination is offline. Media must be retried once the recipient is online/has accepted the download.
- Limits are intentionally bounded: WebSocket frames max 256 KiB, up to 256 queued packets and 8 MiB per recipient mailbox, 128 MiB queued globally, and 5,000 concurrent clients by default. Larger files stream as individual encrypted chunks and are not stored in the offline mailbox.
- The relay still sees public keys, timing, packet sizes, and traffic volume. Protect host access, patch the OS/runtime, monitor logs, and use TLS. Do not expose the service directly on the internet without TLS termination and persistent storage.
