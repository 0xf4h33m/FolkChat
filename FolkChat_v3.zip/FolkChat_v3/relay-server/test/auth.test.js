'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { createX25519KeyPair, importRawX25519PublicKey, relayProof, verifyRelayProof } = require('../src/auth');

function exportRawPublic(key) {
  return key.export({ format: 'der', type: 'spki' }).subarray(-32).toString('hex');
}

test('relay X25519 challenge proves possession of the matching private key', () => {
  const server = createX25519KeyPair();
  const client = crypto.generateKeyPairSync('x25519');
  const clientPublicHex = exportRawPublic(client.publicKey);
  const nonce = crypto.randomBytes(32).toString('hex');
  const clientShared = crypto.diffieHellman({
    privateKey: client.privateKey,
    publicKey: importRawX25519PublicKey(server.publicKeyHex)
  });
  const proof = relayProof(clientShared, nonce, clientPublicHex).toString('hex');
  assert.equal(verifyRelayProof({
    serverPrivateKey: server.privateKey,
    clientPublicKeyHex: clientPublicHex,
    nonce,
    suppliedProofHex: proof
  }), true);
  assert.equal(verifyRelayProof({
    serverPrivateKey: server.privateKey,
    clientPublicKeyHex: clientPublicHex,
    nonce,
    suppliedProofHex: '00'.repeat(32)
  }), false);
});
