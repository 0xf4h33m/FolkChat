'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const dataDir = path.join(os.tmpdir(), `folkchat-relay-test-${crypto.randomUUID()}`);
process.env.DATA_DIR = dataDir;
process.env.QUEUE_FILE = path.join(dataDir, 'mailboxes.json');
process.env.MAILBOX_ENCRYPTION_KEY = crypto.randomBytes(32).toString('hex');
process.env.MAILBOX_TTL_MS = '60000';

const relay = require('../src/server');

test('offline mailbox storage is encrypted, authenticated, persistent, and expires old entries', async (t) => {
  t.after(async () => fs.rm(dataDir, { recursive: true, force: true }));
  await relay.ensureQueueEncryptionKey();

  const recipient = 'a'.repeat(64);
  const sender = 'b'.repeat(64);
  const payload = Buffer.from('end-to-end-ciphertext-placeholder').toString('base64');
  relay.mailboxes.set(recipient, [{
    id: crypto.randomUUID(),
    from: sender,
    payload,
    createdAtMs: Date.now(),
    bytes: Buffer.byteLength(payload, 'utf8')
  }]);
  await relay.persistMailboxes();

  const raw = await fs.readFile(process.env.QUEUE_FILE, 'utf8');
  const encrypted = JSON.parse(raw);
  assert.equal(encrypted.format, 'folkchat-mailbox-v1');
  assert.equal(raw.includes(payload), false, 'disk snapshot must not contain the queued packet in clear text');
  assert.deepEqual(relay.decryptMailboxSnapshot(raw).value[recipient][0].payload, payload);

  const tampered = { ...encrypted, data: Buffer.from(encrypted.data, 'base64').map((value, index) => index === 0 ? value ^ 1 : value).toString('base64') };
  assert.throws(() => relay.decryptMailboxSnapshot(JSON.stringify(tampered)), /authenticate|Unsupported state|unable to authenticate/i,
    'AES-GCM authentication must reject modified snapshots');

  relay.mailboxes.clear();
  await relay.loadMailboxes();
  assert.equal(relay.mailboxes.get(recipient)?.length, 1, 'queued packets should survive a restart/reload');

  relay.mailboxes.clear();
  relay.mailboxes.set(recipient, [{
    id: crypto.randomUUID(),
    from: sender,
    payload,
    createdAtMs: Date.now() - 120_000,
    bytes: Buffer.byteLength(payload, 'utf8')
  }]);
  await relay.persistMailboxes();
  relay.mailboxes.clear();
  await relay.loadMailboxes();
  assert.equal(relay.mailboxes.size, 0, 'entries older than the configured retention period should be purged');
});

test('malformed mailbox JSON is rejected instead of migrated as an empty queue', () => {
  assert.throws(() => relay.decryptMailboxSnapshot(JSON.stringify({ notAKey: 'junk' })), /Unsupported|malformed/i);
  assert.throws(() => relay.decryptMailboxSnapshot(JSON.stringify({ ['a'.repeat(64)]: [{ payload: 'junk' }] })), /Unsupported|malformed/i);
});

test('invalid numeric environment settings fall back instead of becoming NaN', () => {
  assert.equal(relay.boundedIntegerFromEnv('FOLKCHAT_TEST_INTEGER', 420, 1, 1000), 420);
  process.env.FOLKCHAT_TEST_INTEGER = 'not-a-number';
  assert.equal(relay.boundedIntegerFromEnv('FOLKCHAT_TEST_INTEGER', 420, 1, 1000), 420);
  process.env.FOLKCHAT_TEST_INTEGER = '999999';
  assert.equal(relay.boundedIntegerFromEnv('FOLKCHAT_TEST_INTEGER', 420, 1, 1000), 420);
  process.env.FOLKCHAT_TEST_INTEGER = '600';
  assert.equal(relay.boundedIntegerFromEnv('FOLKCHAT_TEST_INTEGER', 420, 1, 1000), 600);
  delete process.env.FOLKCHAT_TEST_INTEGER;
});
