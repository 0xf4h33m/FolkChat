# FolkChat: WAN, calls, large files, privacy, and settings

## WAN message delivery

FolkChat uses the configured private WSS relay first when one is configured and available. Its public fallback sends compact packets over several ntfy-compatible public services (`ntfy.sh`, `ntfy.envs.net`, and `ntfy.adminforge.de`). The message is encrypted for the peer before routing; copies sent to community relays receive a host-specific AES-GCM wrapper. Receivers authenticate, deduplicate, and then run the existing peer-message authentication/decryption checks. These public services are community infrastructure, not a reliability guarantee. They may log the source IP, topics, timing, payload sizes, throttle, cache, delay, or drop packets. Encryption does not provide anonymity.

No manual URL or provider API key is needed for the built-in fallback. A private relay remains optional and gives you control over operation/retention if you deploy and maintain it yourself.

## Audio/video calls over WAN

Calls use native WebRTC audio and video tracks. FolkChat transports call offers/answers and trickle ICE candidates through its encrypted control-message transport, splitting SDP into size-bounded fragments when needed. WebRTC uses DTLS-SRTP for media encryption. STUN defaults help peers discover direct paths. STUN alone cannot guarantee calls on every NAT/carrier network.

To route calls through a TURN relay (and avoid disclosing the peer's IP through a direct media path), open **Settings → Calls & media transport → Call network / ICE servers**, configure one or more trusted `turn:`/`turns:` URLs, and provide credentials. Turn on **Relay-only calls** to fail closed rather than fall back to direct ICE. Do not paste credentials from untrusted sources. The app does not ship with a globally guaranteed TURN account: a provider or self-hosted TURN deployment and valid credentials are required for relay-only calling and some restrictive networks. Tor routing disables calls because standard WebRTC UDP media cannot transparently use the current Tor path.

## Files, voice notes, audio, and video attachments

Photos, voice notes, videos, and documents use the attachment transfer pipeline; GIF selection and playback have been removed from FolkChat. Small/control data uses receiver acknowledgements, bounded chunks, retry, and SHA-256 verification. Public WAN file delivery uses a separate client-side encrypted blob flow for files above 8 MiB on relay routes; files larger than 64 MiB are divided into independent 16 MiB AES-GCM ciphertext segments and described by an independently encrypted manifest. Segment uploads/downloads have bounded retries and progress reporting. The receiver authenticates each segment before appending its plaintext to a private temporary file, then checks final size and SHA-256 before atomically finalizing it. File decryption keys and original names are carried inside FolkChat's encrypted peer message, not in the public blob URL.

The source currently allows an application-level ceiling of 100 GiB for segmented transfers, but this is **not a promise that public hosting services accept that overall size**. Each segment and the manifest are separate uploads; third-party hosting can impose smaller per-upload/retention/rate limits and may delete ciphertext early. Segment retries are implemented, but completed upload state is not persisted for byte-offset resume after app/process restart. Retry restarts the transfer. Very large transfers therefore need testing and may be impractical on temporary public hosts.

Public uploads use randomized ciphertext filenames, request the host's secret-link/expiry options where supported, validate all downloaded URLs against the expected HTTPS host allowlist, and delete remote uploads on a best-effort basis after a verified receipt. None of this makes a third-party service's retention/deletion guarantees enforceable.

## Profile photos

Profile avatars use compact, low-resolution JPEG thumbnails sized to fit the public packet limit. Contact creation/acceptance triggers a profile update and profile request, so each side can exchange the current name/photo without needing to edit their profile later. **Settings → Security and privacy → Share profile photo** controls whether the app advertises the avatar; turning it off sends a clear-avatar update. If a user chooses not to share their photo, the receiver should show the initials/fallback avatar instead.

## Settings and motion

The settings hub separates Security & privacy, notifications/lock controls, media download policy, calls & media transport, network/routing, appearance, and data cleanup. Preferences persist in FolkChat's encrypted vault. Animation feedback is included for microphone recording, call ringing, selected bottom-navigation icons, and expandable settings cards. **Reduce motion** limits ongoing pulse animations for accessibility.

## Build and validation

Build in Android Studio with an installed Android SDK and Gradle. The WebRTC artifact is declared in `app/build.gradle.kts`. This workspace did not include an Android SDK, Gradle executable, or a complete Gradle wrapper, so the full app was not build-verified here. Before release, run the following on physical devices:

1. Install the same build on two phones and pair them; ensure each side receives the other's current avatar. Toggle profile-photo sharing off and verify the old photo is removed.
2. Test messages/voice notes/photos/documents with phones on separate mobile/Wi-Fi networks, then disable one public relay at a time. Verify duplicate suppression, delivery receipts, and retry behavior.
3. Call between different networks with video off and on; test background/foreground, mic mute, camera toggle, speaker/headset route, screen rotation, mobile-data changes, and call end/reconnect.
4. Test default STUN mode, then configure a trusted TURN server and enable Relay-only calls. Confirm call failure is explicit when TURN credentials are absent/invalid; verify both peers do not use a direct media path in relay-only mode.
5. Transfer files around the 8 MiB WAN-blob threshold and 64 MiB segment threshold, a multi-segment file, an interrupted upload/download, a corrupt/tampered segment, low free storage, and a host failure. Confirm failures are explicit and no partial file is presented as complete.
6. Test settings migration from an older vault, Reduce motion, automatic voice/video download, temporary cleanup, and the profile-photo privacy toggle.

## Honest limitations

- Public relays and temporary file hosts are best-effort; there is no guaranteed availability or worldwide delivery SLA.
- Direct WebRTC media can expose a peer's public IP to the other peer. Relay-only requires a real, reachable TURN service with valid credentials.
- Group chat is encrypted per-member text fan-out; group media uploads and group calls are not implemented yet.
- No installable APK or successful full Android build is included in this package; real-device verification is still required.


## QR pairing and direct-link identity pinning

The `fc2` QR format carries the public key, display name, expiry time, and a random 256-bit one-time token. The receiver keeps its challenge in memory only while the QR is shown, and subscribes to a per-relay topic derived from the token. The sender's encrypted/authenticated pairing request includes a random request ID. The QR-display side accepts one sender/request pair, adds that public key as verified, then sends an encrypted ACK; the scanner side only sets `isVerified` after the matching ACK is authenticated. Legacy `sc1` QR codes are not auto-verified.

Before a direct TCP link carries frames, both endpoints prove possession of their X25519 identity private keys in a nonce-based handshake. The client pins the expected recipient public key, and the server only permits an existing verified, non-blocked contact. Peer IPs are not persisted as trusted identities. Android's system firewall is not modified; this is an app-level authenticated peer gate. QR pairing requires an internet delivery path in this version, and is deliberately not sent over WAN when `Force Offline` is selected.
