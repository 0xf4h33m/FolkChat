package com.example.net.online

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.fail
import org.junit.Test
import java.security.SecureRandom

class RelayPacketCipherTest {
    private fun randomKey(): ByteArray = ByteArray(32).also { SecureRandom().nextBytes(it) }

    @Test
    fun roundTripsAndUsesFreshNonceForEachRelayCopy() {
        val key = randomKey()
        val packet = "already end-to-end encrypted FolkChat packet".toByteArray()
        val first = RelayPacketCipher.seal(key, "ntfy.envs.net", packet)
        val second = RelayPacketCipher.seal(key, "ntfy.envs.net", packet)

        assertArrayEquals(packet, RelayPacketCipher.open(key, "ntfy.envs.net", first))
        assertArrayEquals(packet, RelayPacketCipher.open(key, "ntfy.envs.net", second))
        assertFalse("Each relay copy must use a fresh nonce", first.contentEquals(second))
    }

    @Test
    fun wrongRelayHostIsRejected() {
        val key = randomKey()
        val wrapped = RelayPacketCipher.seal(key, "ntfy.envs.net", byteArrayOf(1, 2, 3))
        assertAuthenticationFailure { RelayPacketCipher.open(key, "ntfy.adminforge.de", wrapped) }
    }

    @Test
    fun tamperedCiphertextIsRejected() {
        val key = randomKey()
        val wrapped = RelayPacketCipher.seal(key, "ntfy.envs.net", byteArrayOf(1, 2, 3, 4))
        wrapped[wrapped.lastIndex] = (wrapped.last().toInt() xor 1).toByte()
        assertAuthenticationFailure { RelayPacketCipher.open(key, "ntfy.envs.net", wrapped) }
    }

    @Test
    fun wrongKeyIsRejected() {
        val wrapped = RelayPacketCipher.seal(randomKey(), "ntfy.envs.net", byteArrayOf(7, 8, 9))
        assertAuthenticationFailure { RelayPacketCipher.open(randomKey(), "ntfy.envs.net", wrapped) }
    }

    private fun assertAuthenticationFailure(block: () -> Unit) {
        try {
            block()
            fail("Invalid relay wrapper should not be accepted")
        } catch (_: javax.crypto.AEADBadTagException) {
            // Expected authentication failure.
        } catch (e: IllegalArgumentException) {
            // Malformed framing is also rejected.
        }
    }
}
