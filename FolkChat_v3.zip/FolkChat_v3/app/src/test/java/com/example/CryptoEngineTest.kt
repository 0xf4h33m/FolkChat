package com.example

import com.example.crypto.CryptoEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CryptoEngineTest {

    @Test
    fun testX25519KeyAgreementAndEnvelope() {
        val alice = CryptoEngine.generateX25519KeyPair()
        val bob = CryptoEngine.generateX25519KeyPair()

        assertEquals(32, alice.privateKey.size)
        assertEquals(32, alice.publicKey.size)
        assertEquals(32, bob.privateKey.size)
        assertEquals(32, bob.publicKey.size)

        // Mutual shared secret agreement
        val aliceShared = CryptoEngine.computeSharedSecret(alice.privateKey, bob.publicKey)
        val bobShared = CryptoEngine.computeSharedSecret(bob.privateKey, alice.publicKey)

        assertTrue(aliceShared.contentEquals(bobShared))

        // Encrypt envelope from Alice to Bob
        val message = "Zero cloud, pure offline P2P encryption."
        val envelope = CryptoEngine.encryptToPeer(bob.publicKey, message.toByteArray(Charsets.UTF_8))
        val decryptedBytes = CryptoEngine.decryptFromPeer(bob.privateKey, envelope)

        assertEquals(message, String(decryptedBytes, Charsets.UTF_8))
    }


    @Test
    fun testHexCodecIsStrictAndRoundTrips() {
        val raw = byteArrayOf(0x00, 0x7f, 0x80.toByte(), 0xff.toByte())
        val encoded = CryptoEngine.bytesToHex(raw)
        assertEquals("007f80ff", encoded)
        assertArrayEquals(raw, CryptoEngine.hexToBytes(" 007F80ff "))
        assertThrows(IllegalArgumentException::class.java) { CryptoEngine.hexToBytes("abc") }
        assertThrows(IllegalArgumentException::class.java) { CryptoEngine.hexToBytes("00xz") }
    }

    @Test
    fun testEnvelopeTamperingIsRejected() {
        val bob = CryptoEngine.generateX25519KeyPair()
        val envelope = CryptoEngine.encryptToPeer(bob.publicKey, "authenticated".toByteArray(Charsets.UTF_8))
        val altered = envelope.copy(ciphertext = envelope.ciphertext.copyOf().apply { this[lastIndex] = (this[lastIndex].toInt() xor 1).toByte() })
        assertThrows(Exception::class.java) { CryptoEngine.decryptFromPeer(bob.privateKey, altered) }
    }

    @Test
    fun testChaCha20Poly1305RoundTrip() {
        val key = ByteArray(32) { it.toByte() }
        val nonce = ByteArray(12) { (it * 2).toByte() }
        val plaintext = "SecureChat local vault test payload".toByteArray(Charsets.UTF_8)

        val ciphertext = CryptoEngine.encryptChaCha20Poly1305(key, nonce, plaintext)
        // Ciphertext should be plaintext size + 16-byte Poly1305 MAC tag
        assertEquals(plaintext.size + 16, ciphertext.size)

        val decrypted = CryptoEngine.decryptChaCha20Poly1305(key, nonce, ciphertext)
        assertEquals(String(plaintext, Charsets.UTF_8), String(decrypted, Charsets.UTF_8))
    }

    @Test
    fun testRotatingDiscoveryTags() {
        val key = ByteArray(32) { 42.toByte() }
        val slot1 = 1000L
        val slot2 = 1001L

        val tag1a = CryptoEngine.computeRotatingTag(key, slot1)
        val tag1b = CryptoEngine.computeRotatingTag(key, slot1)
        val tag2 = CryptoEngine.computeRotatingTag(key, slot2)

        assertEquals(16, tag1a.size)
        // Deterministic within same epoch slot
        assertTrue(tag1a.contentEquals(tag1b))
        // Rotates across different epoch slots (prevents tracking)
        assertFalse(tag1a.contentEquals(tag2))
    }

    @Test
    fun testEpochIntervalMustBePositive() {
        assertThrows(IllegalArgumentException::class.java) { CryptoEngine.currentEpochSlot(0L) }
        assertThrows(IllegalArgumentException::class.java) { CryptoEngine.currentEpochSlot(-1L) }
    }

    @Test
    fun testSafetyNumberOrderIndependence() {
        val key1 = ByteArray(32) { 1.toByte() }
        val key2 = ByteArray(32) { 2.toByte() }

        val safety1 = CryptoEngine.computeSafetyNumber(key1, key2)
        val safety2 = CryptoEngine.computeSafetyNumber(key2, key1)

        assertEquals(safety1, safety2)
        assertTrue(safety1.matches(Regex("^\\d{4}( \\d{4}){5}$")))
    }

    @Test
    fun testContactCodeParsing() {
        val pubKey = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
        val code = "sc1:$pubKey:Alice"

        val parsed = CryptoEngine.parseContactCode(code)
        assertNotNull(parsed)
        assertEquals(pubKey, parsed!!.first)
        assertEquals("Alice", parsed.second)

        // Invalid code returns null
        val invalidCode = "invalid:123"
        assertEquals(null, CryptoEngine.parseContactCode(invalidCode))

        // Malformed percent-encoding from an untrusted QR must not throw out of the parser.
        val malformedUri = "folkchat://peer?key=$pubKey&name=%ZZ"
        assertEquals("Peer ${pubKey.take(6)}", CryptoEngine.parseContactCode(malformedUri)!!.second)

        // Control characters must not be allowed to forge multi-line contact labels.
        val spoofedLabel = "sc1:$pubKey:Alice\nAdmin"
        assertEquals("AliceAdmin", CryptoEngine.parseContactCode(spoofedLabel)!!.second)
    }
}
