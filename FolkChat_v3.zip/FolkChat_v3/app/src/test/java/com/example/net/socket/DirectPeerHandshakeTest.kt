package com.example.net.socket

import com.example.crypto.CryptoEngine
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DirectPeerHandshakeTest {
    @Test
    fun mutualProofAuthenticatesPinnedIdentity() {
        val alice = CryptoEngine.generateX25519KeyPair()
        val bob = CryptoEngine.generateX25519KeyPair()
        val result = runHandshake(alice, bob, allowlisted = true)
        assertTrue(result.clientAccepted)
        assertEquals(alice.publicKeyHex, result.serverPeerHex)
    }

    @Test
    fun serverRejectsIdentityNotInContactAllowlist() {
        val alice = CryptoEngine.generateX25519KeyPair()
        val bob = CryptoEngine.generateX25519KeyPair()
        val result = runHandshake(alice, bob, allowlisted = false)
        assertFalse(result.clientAccepted)
        assertEquals(null, result.serverPeerHex)
    }

    private data class HandshakeResult(val clientAccepted: Boolean, val serverPeerHex: String?)

    private fun runHandshake(
        alice: com.example.crypto.KeyPairBytes,
        bob: com.example.crypto.KeyPairBytes,
        allowlisted: Boolean
    ): HandshakeResult {
        val aliceToBobInput = PipedInputStream(4096)
        val aliceToBobOutput = PipedOutputStream(aliceToBobInput)
        val bobToAliceInput = PipedInputStream(4096)
        val bobToAliceOutput = PipedOutputStream(bobToAliceInput)
        val accepted = AtomicBoolean(false)
        val serverPeer = AtomicReference<String?>(null)

        val server = thread(name = "folkchat-handshake-server") {
            try {
                val peer = DirectPeerHandshake.acceptClient(
                    DataInputStream(aliceToBobInput),
                    DataOutputStream(bobToAliceOutput),
                    bob
                ) { presentedKey -> allowlisted && presentedKey == alice.publicKeyHex }
                serverPeer.set(peer)
                if (peer == null) bobToAliceOutput.close()
            } catch (_: Exception) {
                serverPeer.set(null)
            }
        }
        val client = thread(name = "folkchat-handshake-client") {
            accepted.set(
                DirectPeerHandshake.clientAuthenticate(
                    DataInputStream(bobToAliceInput),
                    DataOutputStream(aliceToBobOutput),
                    alice,
                    bob.publicKeyHex
                )
            )
        }
        server.join(3_000)
        client.join(3_000)
        try { aliceToBobOutput.close() } catch (_: Exception) {}
        try { bobToAliceOutput.close() } catch (_: Exception) {}
        try { aliceToBobInput.close() } catch (_: Exception) {}
        try { bobToAliceInput.close() } catch (_: Exception) {}
        assertFalse("Handshake server should not hang", server.isAlive)
        assertFalse("Handshake client should not hang", client.isAlive)
        return HandshakeResult(accepted.get(), serverPeer.get())
    }
}
