package com.example.crypto

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Test

class PairingQrCodeTest {
    private val publicKey = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    private val token = "abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789"

    @Test
    fun roundTripsNameAndTokenBeforeExpiry() {
        val now = 1_800_000_000_000L
        val encoded = CryptoEngine.createPairingQrCode(publicKey, "Alice: Work + Personal", token, now + 120_000L)
        val parsed = CryptoEngine.parsePairingQrCode(encoded, now)
        assertNotNull(parsed)
        assertEquals(publicKey, parsed!!.pubKeyHex)
        assertEquals(token, parsed.tokenHex)
        assertEquals("Alice: Work + Personal", parsed.displayName)
        assertEquals(now + 120_000L, parsed.expiresAtMs)
    }

    @Test
    fun rejectsExpiredOrFarFutureQr() {
        val now = 1_800_000_000_000L
        assertNull(CryptoEngine.parsePairingQrCode(CryptoEngine.createPairingQrCode(publicKey, "A", token, now), now))
        assertNull(CryptoEngine.parsePairingQrCode(CryptoEngine.createPairingQrCode(publicKey, "A", token, now + 4 * 60_000L), now))
    }

    @Test
    fun rejectsMalformedPublicKeyAndToken() {
        assertNull(CryptoEngine.parsePairingQrCode("fc2:bad:$token:1800000120000:Alice", 1_800_000_000_000L))
        assertNull(CryptoEngine.parsePairingQrCode("fc2:$publicKey:bad:1800000120000:Alice", 1_800_000_000_000L))
    }
}
