package com.example.net.socket

import com.example.crypto.CryptoEngine
import com.example.crypto.KeyPairBytes
import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Mutual proof-of-possession handshake for direct TCP links.
 * The discovered IP/port is only a route hint; identity is pinned to the contact public key.
 */
internal object DirectPeerHandshake {
    private val clientMagic = byteArrayOf('F'.code.toByte(), 'C'.code.toByte(), 'H'.code.toByte(), '2'.code.toByte())
    private val serverMagic = byteArrayOf('F'.code.toByte(), 'C'.code.toByte(), 'A'.code.toByte(), '2'.code.toByte())
    private const val VERSION: Int = 1
    private const val PUBLIC_KEY_BYTES = 32
    private const val NONCE_BYTES = 32
    private const val MAC_BYTES = 32

    fun clientAuthenticate(
        input: DataInputStream,
        output: DataOutputStream,
        localIdentity: KeyPairBytes,
        expectedPeerPubKeyHex: String
    ): Boolean {
        return try {
            val peerPub = CryptoEngine.hexToBytes(expectedPeerPubKeyHex.lowercase())
            if (peerPub.size != PUBLIC_KEY_BYTES) return false
            val localPub = localIdentity.publicKey
            val localHex = CryptoEngine.bytesToHex(localPub)
            val peerHex = CryptoEngine.bytesToHex(peerPub)
            val nonce = ByteArray(NONCE_BYTES).also { SecureRandom().nextBytes(it) }
            val sessionKey = deriveSessionKey(localIdentity.privateKey, peerPub, nonce, localHex, peerHex)
            try {
                val body = clientMagic + byteArrayOf(VERSION.toByte()) + localPub + peerPub + nonce
                val mac = CryptoEngine.hmacSha256(sessionKey, body)
                output.write(body)
                output.write(mac)
                output.flush()

                val responseMagic = ByteArray(4)
                input.readFully(responseMagic)
                if (!responseMagic.contentEquals(serverMagic)) return false
                val peerNonce = ByteArray(NONCE_BYTES)
                input.readFully(peerNonce)
                val responseMac = ByteArray(MAC_BYTES)
                input.readFully(responseMac)
                val proof = serverProof(nonce, peerNonce, localPub, peerPub)
                val expected = CryptoEngine.hmacSha256(sessionKey, proof)
                MessageDigest.isEqual(expected, responseMac)
            } finally {
                sessionKey.fill(0)
                nonce.fill(0)
            }
        } catch (_: Exception) {
            false
        }
    }

    /** Returns authenticated peer key, or null if the handshake/allow-list check fails. */
    fun acceptClient(
        input: DataInputStream,
        output: DataOutputStream,
        localIdentity: KeyPairBytes,
        isTrustedPeer: (String) -> Boolean
    ): String? {
        return try {
            val magic = ByteArray(4)
            input.readFully(magic)
            if (!magic.contentEquals(clientMagic)) return null
            val version = input.readUnsignedByte()
            if (version != VERSION) return null
            val senderPub = ByteArray(PUBLIC_KEY_BYTES).also { input.readFully(it) }
            val receiverPub = ByteArray(PUBLIC_KEY_BYTES).also { input.readFully(it) }
            val nonce = ByteArray(NONCE_BYTES).also { input.readFully(it) }
            val receivedMac = ByteArray(MAC_BYTES).also { input.readFully(it) }
            if (!MessageDigest.isEqual(receiverPub, localIdentity.publicKey)) return null
            val senderHex = CryptoEngine.bytesToHex(senderPub).lowercase()
            val receiverHex = CryptoEngine.bytesToHex(receiverPub).lowercase()
            if (!isTrustedPeer(senderHex)) return null

            val sessionKey = deriveSessionKey(localIdentity.privateKey, senderPub, nonce, senderHex, receiverHex)
            try {
                val body = clientMagic + byteArrayOf(version.toByte()) + senderPub + receiverPub + nonce
                val expectedMac = CryptoEngine.hmacSha256(sessionKey, body)
                if (!MessageDigest.isEqual(expectedMac, receivedMac)) return null

                val serverNonce = ByteArray(NONCE_BYTES).also { SecureRandom().nextBytes(it) }
                output.write(serverMagic)
                output.write(serverNonce)
                output.write(CryptoEngine.hmacSha256(sessionKey, serverProof(nonce, serverNonce, senderPub, receiverPub)))
                output.flush()
                senderHex
            } finally {
                sessionKey.fill(0)
                nonce.fill(0)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun deriveSessionKey(
        localPrivate: ByteArray,
        peerPublic: ByteArray,
        nonce: ByteArray,
        initiatorPubHex: String,
        responderPubHex: String
    ): ByteArray {
        val shared = CryptoEngine.computeSharedSecret(localPrivate, peerPublic)
        try {
            require(shared.any { it != 0.toByte() }) { "Invalid direct-link shared secret" }
            return CryptoEngine.hkdfSha256(
                shared,
                salt = nonce,
                info = "FolkChat-DirectSocket-v1|$initiatorPubHex|$responderPubHex".toByteArray(Charsets.UTF_8),
                length = 32
            )
        } finally {
            shared.fill(0)
        }
    }

    private fun serverProof(clientNonce: ByteArray, serverNonce: ByteArray, clientPub: ByteArray, serverPub: ByteArray): ByteArray =
        "FolkChat-DirectSocket-ServerProof-v1".toByteArray(Charsets.UTF_8) + clientNonce + serverNonce + clientPub + serverPub
}
