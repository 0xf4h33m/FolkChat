package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

/**
 * Selectable typeface families. Two are bundled in the APK (Carlito, a warm
 * humanist sans, and a Times-style serif, both SIL OFL / Apache-licensed and
 * subset to Latin-1 to keep the build lean); the rest resolve to device
 * families so no extra bytes ship. All persisted names resolve defensively.
 */
enum class AppFontChoice(val label: String, val description: String) {
    SYSTEM("Default", "Roboto — the calm native Android voice"),
    CARLITO("Friendly", "Warm humanist sans, round and relaxed"),
    SERIF("Classic", "Times-style serif with editorial weight"),
    MODERN_SERIF("Modern serif", "Noto Serif — crisp, contemporary");

    companion object {
        fun fromName(name: String?): AppFontChoice =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: SYSTEM
    }
}

/** Bundled Carlito family (metric-compatible humanist sans, SIL OFL). */
private val CarlitoFamily = FontFamily(
    Font(R.font.carlito_regular, FontWeight.Normal),
    Font(R.font.carlito_bold, FontWeight.SemiBold),
    Font(R.font.carlito_bold, FontWeight.Bold)
)

/** Bundled Times-style serif family (Liberation Serif metrics, SIL OFL). */
private val ClassicSerifFamily = FontFamily(
    Font(R.font.serif_regular, FontWeight.Normal),
    Font(R.font.serif_bold, FontWeight.SemiBold),
    Font(R.font.serif_bold, FontWeight.Bold)
)

/** Resolves a persisted choice into a real family with a safe default. */
fun fontFamilyFor(choice: AppFontChoice): FontFamily = when (choice) {
    AppFontChoice.SYSTEM -> FontFamily.SansSerif
    AppFontChoice.CARLITO -> CarlitoFamily
    AppFontChoice.SERIF -> ClassicSerifFamily
    AppFontChoice.MODERN_SERIF -> FontFamily.Serif
}

/** Supported chat font scales (multipliers on the base type scale). */
enum class ChatFontScale(val label: String, val multiplier: Float) {
    EXTRA_SMALL("XS", 0.85f),
    SMALL("S", 0.92f),
    MEDIUM("M", 1.0f),
    LARGE("L", 1.12f),
    EXTRA_LARGE("XL", 1.25f);

    companion object {
        fun fromName(name: String?): ChatFontScale =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: MEDIUM

        fun fromMultiplier(value: Float): ChatFontScale =
            entries.minByOrNull { kotlin.math.abs(it.multiplier - value) } ?: MEDIUM
    }
}

/** Bubble silhouette presets consumed by MessageBubble. */
enum class BubbleStyle(val label: String) {
    CLASSIC("Classic tails"),
    MODERN("Modern rounded"),
    SQUIRCLE("Soft squircle");

    companion object {
        fun fromName(name: String?): BubbleStyle =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: CLASSIC
    }
}

/** Chat canvas backdrop drawn behind the message list. */
enum class ChatWallpaper(val label: String, val shortLabel: String = label) {
    NONE("Solid canvas", "Solid"),
    WASH("Gentle wash", "Wash"),
    DOTS("Folk dots", "Dots"),
    AURORA("Aurora", "Aurora"),
    GRID("Fine grid", "Grid"),
    PAPER("Warm paper", "Paper"),
    BLOOM("Bloom", "Bloom");

    companion object {
        fun fromName(name: String?): ChatWallpaper =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: NONE
    }
}

/**
 * Professional Material 3 type scale (Roboto system family — the native
 * Android voice). Calm, tight-tracked titles with comfortable body rhythm.
 */
val Typography = Typography(
    displaySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 32.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.25).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = (-0.2).sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        lineHeight = 25.sp,
        letterSpacing = 0.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        lineHeight = 23.sp,
        letterSpacing = 0.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        letterSpacing = 0.1.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.1.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.15.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp,
        letterSpacing = 0.2.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.2.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.2.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.4.sp
    )
)

/**
 * Builds a copy of the base type scale rendered in [family]. Weights, sizes and
 * rhythm are preserved; only the typeface changes, so every screen keeps its
 * layout metrics while the whole app adopts the chosen voice.
 */
fun typographyWith(family: FontFamily): Typography {
    fun TextStyle.refamily(): TextStyle = copy(fontFamily = family, platformStyle = PlatformTextStyle(includeFontPadding = false))
    return Typography(
        displaySmall = Typography.displaySmall.refamily(),
        headlineLarge = Typography.headlineLarge.refamily(),
        headlineMedium = Typography.headlineMedium.refamily(),
        headlineSmall = Typography.headlineSmall.refamily(),
        titleLarge = Typography.titleLarge.refamily(),
        titleMedium = Typography.titleMedium.refamily(),
        titleSmall = Typography.titleSmall.refamily(),
        bodyLarge = Typography.bodyLarge.refamily(),
        bodyMedium = Typography.bodyMedium.refamily(),
        bodySmall = Typography.bodySmall.refamily(),
        labelLarge = Typography.labelLarge.refamily(),
        labelMedium = Typography.labelMedium.refamily(),
        labelSmall = Typography.labelSmall.refamily()
    )
}

/**
 * Builds a scaled copy of the base type scale for accessibility-driven
 * font sizing. Every fontSize / lineHeight / letterSpacing is multiplied
 * by [scale]; weights and families are preserved. The multiplier is
 * clamped to a safe range so persisted values can never blow up the UI.
 */
fun scaledTypography(scale: Float, family: FontFamily = FontFamily.SansSerif): Typography {
    val s = scale.coerceIn(0.8f, 1.4f)
    fun TextStyle.scaled(): TextStyle = copy(
        fontFamily = family,
        fontSize = (fontSize.value * s).coerceIn(8f, 44f).sp,
        lineHeight = (lineHeight.value * s).coerceIn(10f, 56f).sp,
        letterSpacing = (letterSpacing.value * s).coerceIn(-1.5f, 2.5f).sp,
        platformStyle = PlatformTextStyle(includeFontPadding = false)
    )
    return Typography(
        displaySmall = Typography.displaySmall.scaled(),
        headlineLarge = Typography.headlineLarge.scaled(),
        headlineMedium = Typography.headlineMedium.scaled(),
        headlineSmall = Typography.headlineSmall.scaled(),
        titleLarge = Typography.titleLarge.scaled(),
        titleMedium = Typography.titleMedium.scaled(),
        titleSmall = Typography.titleSmall.scaled(),
        bodyLarge = Typography.bodyLarge.scaled(),
        bodyMedium = Typography.bodyMedium.scaled(),
        bodySmall = Typography.bodySmall.scaled(),
        labelLarge = Typography.labelLarge.scaled(),
        labelMedium = Typography.labelMedium.scaled(),
        labelSmall = Typography.labelSmall.scaled()
    )
}
