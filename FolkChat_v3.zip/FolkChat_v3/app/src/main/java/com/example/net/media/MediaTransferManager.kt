package com.example.net.media

import android.util.Base64
import android.util.Log
import com.example.data.ChatMessage
import com.example.data.EncryptedVault
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import com.example.data.MessageStatus
import com.example.data.TransferState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.ByteArrayOutputStream
import java.io.RandomAccessFile
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.URI
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherOutputStream
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.RequestBody
import okhttp3.MultipartBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okio.Buffer
import okio.BufferedSink
import okio.ForwardingSink
import okio.buffer
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Transfers media attachments (images, videos, documents, voice notes) as
 * chunked, end-to-end encrypted envelopes over the existing P2P transport.
 *
 * Outgoing transfers report progress, can be cancelled and retried.
 * Incoming transfers are reassembled into the app's private media directory.
 */
class MediaTransferManager(
    private val vault: EncryptedVault,
    mediaDir: File,
    private val dispatcher: suspend (String, JSONObject) -> String?,
    private val onUpdated: () -> Unit
) {
    @Volatile private var mediaDir: File = mediaDir

    /** Swaps the working media directory after explicit local-storage opt-in. */
    fun updateMediaDirectory(directory: File) {
        mediaDir = directory
        if (!directory.exists()) directory.mkdirs()
    }

    companion object {
        private const val TAG = "MediaTransfer"
        private const val CHUNK_SIZE_SOCKET = 48 * 1024
        private const val CHUNK_SIZE_BLE = 280
        private const val CHUNK_WINDOW = 8
        private const val CHUNK_ACK_TIMEOUT_MS = 20_000L
        private const val CHUNK_SEND_ATTEMPTS = 3
        private const val MAX_CHUNKS = 65_536
        private const val MAX_ACTIVE_INCOMING = 4
        private const val INCOMING_IDLE_TIMEOUT_MS = 10 * 60_000L
        // Public fallback: ciphertext only, uploaded to a short-lived anonymous file host.
        // App-level ceiling only: anonymous hosts and device storage can impose lower limits.
        private const val MAX_PUBLIC_FILE_BYTES = 100L * 1024L * 1024L * 1024L // 100 GiB
        // Smaller independently authenticated parts improve provider compatibility and make a
        // failed request cheaper to retry. The bounded pipeline keeps only a few parts in flight.
        private const val PUBLIC_SEGMENT_BYTES = 16L * 1024L * 1024L
        private const val SEGMENTED_TRANSFER_THRESHOLD_BYTES = 64L * 1024L * 1024L
        // Above this size, prefer the encrypted blob path when the selected route is a WAN relay.
        // Tiny chat/media packets retain the low-overhead receiver-acknowledged path.
        private const val WAN_CLOUD_TRANSFER_THRESHOLD_BYTES = 8L * 1024L * 1024L
        private const val SEGMENT_UPLOAD_CONCURRENCY = 3
        private const val MAX_PUBLIC_SEGMENTS = 6_400 // 100 GiB / 16 MiB
        private const val MAX_PUBLIC_MANIFEST_BYTES = 8L * 1024L * 1024L
        private const val TMPFILES_MAX_BYTES = 100L * 1024L * 1024L
        private const val PUBLIC_UPLOAD_TIMEOUT_MS = 10 * 60_000L
        private val OCTET_STREAM = "application/octet-stream".toMediaType()
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cancelled = ConcurrentHashMap.newKeySet<String>()
    private val activeTransfers = ConcurrentHashMap.newKeySet<String>()
    private val approvedIncoming = ConcurrentHashMap.newKeySet<String>()
    private val pendingAccepts = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    /** Final receiver verification distinguishes "all chunks sent" from "file delivered". */
    private val pendingMediaReceipts = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    /** A chunk is considered sent only after the receiver confirms it was accepted. */
    private val pendingChunkAcks = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val preAcceptedTransfers = ConcurrentHashMap.newKeySet<String>()
    private val activePublicDownloads = ConcurrentHashMap.newKeySet<String>()
    private val uploadedPublicFiles = ConcurrentHashMap<String, UploadedPublicFile>()
    private val uploadedPublicSegments = ConcurrentHashMap<String, List<UploadedPublicFile>>()
    // Reuse OkHttp pools across every segment. Creating a fresh client per request was preventing
    // keep-alive/TLS reuse and made large transfers unnecessarily slow on WAN links.
    private val transferClients = ConcurrentHashMap<String, OkHttpClient>()
    private data class ProgressSnapshot(val atMs: Long, val progress: Float)
    private val lastProgressSnapshots = ConcurrentHashMap<String, ProgressSnapshot>()
    private val incomingStreams = mutableMapOf<String, IncomingTransfer>()

    private data class UploadedPublicFile(
        val url: String,
        val provider: String,
        val deleteToken: String? = null
    )
    private val mutex = Mutex()

    private class IncomingTransfer(
        val file: File,
        val randomAccess: RandomAccessFile,
        val totalChunks: Int,
        val chunkSize: Int,
        val claimedSize: Long,
        val messageId: String,
        val senderPubKeyHex: String,
        var lastUpdatedAtMs: Long = System.currentTimeMillis(),
        val receivedChunks: MutableSet<Int> = mutableSetOf(),
        /** Last progress fraction actually written to the vault; gates checkpoint frequency. */
        var persistedProgress: Float = 0f
    )

    init {
        mediaDir.mkdirs()
        if (try { vault.getSettings().clearTemporaryFilesOnExit } catch (_: Exception) { true }) {
            val cutoff = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
            mediaDir.listFiles()?.forEach { file ->
                val ownedTemp = file.name.startsWith(".fc-upload-") || file.name.startsWith(".fc-segment-") ||
                    file.name.startsWith(".fc-manifest-") || file.name.startsWith(".fc-download-") ||
                    file.name.startsWith(".fc-plain-part-") || file.name.endsWith(".part")
                if (ownedTemp && file.lastModified() < cutoff) try { file.delete() } catch (_: Exception) { }
            }
        }
    }

    fun resolveLocalFile(attachment: MediaAttachment?): File? {
        val path = attachment?.localPath ?: return null
        val f = File(path)
        return if (f.exists()) f else null
    }

    /** Kick off (or resume) an outgoing media transfer for [message]. */
    fun startTransfer(message: ChatMessage, restart: Boolean = false) {
        val attachment = message.attachment ?: return
        message.recipientPubKeyHex.let { recipient ->
            if (!activeTransfers.add(attachment.id)) return
            if (restart) cancelled.remove(attachment.id)
            scope.launch {
                try {
                    runOutgoing(message, recipient)
                } finally {
                    activeTransfers.remove(attachment.id)
                    // Cover the narrow race where MEDIA_ACCEPT arrives after the waiting
                    // coroutine times out but just before it leaves activeTransfers.
                    val key = incomingKey(recipient, attachment.id)
                    val latest = vault.getMessageById(message.id)
                    if (latest?.attachment?.transferState == TransferState.COMPLETED) {
                        preAcceptedTransfers.remove(key)
                    } else if (preAcceptedTransfers.contains(key) && !isCancelled(attachment.id)) {
                        latest?.let { saved ->
                            vault.updateMessage(saved.id) {
                                it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(
                                    transferState = TransferState.PENDING, progress = 0f, error = null
                                ))
                            }
                            startTransfer(vault.getMessageById(saved.id) ?: saved, restart = true)
                        }
                    }
                }
            }
        }
    }

    /** Re-attempts a failed or cancelled transfer. */
    fun retry(messageId: String) {
        val message = vault.getMessageById(messageId) ?: return
        if (message.attachment == null) return
        if (!message.isOutgoing) {
            scope.launch { requestIncomingDownload(message) }
            return
        }
        val attachmentId = message.attachment.id
        cancelled.remove(attachmentId)
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.SENDING,
                attachment = it.attachment?.copy(
                    transferState = TransferState.PENDING,
                    progress = 0f,
                    error = null
                )
            )
        }
        onUpdated()
        startTransfer(vault.getMessageById(messageId) ?: message, restart = true)
    }

    /** Handle an authenticated MEDIA_ACCEPT from the recipient. */
    fun onRemoteAccept(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val transferId = json.optString("transferId")
        if (msgId.isBlank() || !isSafeTransferId(transferId)) return
        val message = vault.getMessageById(msgId) ?: return
        val attachment = message.attachment ?: return
        if (!message.isOutgoing || !message.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || attachment.id != transferId) return
        if (attachment.transferState == TransferState.COMPLETED && message.status == MessageStatus.DELIVERED) return
        val key = incomingKey(senderPubKeyHex, transferId)
        val waiting = pendingAccepts[key]
        if (waiting != null && waiting.complete(true)) {
            // The current sender is still waiting for this transfer's recipient consent.
        } else {
            // A recipient can accept after a previous send attempt timed out.
            preAcceptedTransfers.add(key)
            if (!activeTransfers.contains(attachment.id)) {
                vault.updateMessage(msgId) {
                    it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(
                        transferState = TransferState.PENDING, progress = 0f, error = null
                    ))
                }
                startTransfer(vault.getMessageById(msgId) ?: message, restart = true)
            }
        }
    }

    /** Handle an authenticated acknowledgement for one exact outgoing chunk. */
    fun onChunkAck(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val transferId = json.optString("transferId")
        val index = json.optInt("index", -1)
        if (msgId.isBlank() || !isSafeTransferId(transferId) || index !in 0 until MAX_CHUNKS) return
        val message = vault.getMessageById(msgId) ?: return
        val attachment = message.attachment ?: return
        if (!message.isOutgoing || attachment.id != transferId ||
            !message.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        pendingChunkAcks[chunkAckKey(senderPubKeyHex, transferId, index)]
            ?.complete(json.optBoolean("accepted", false))
    }

    /** Handle the receiver's final hash/size verification result. */
    fun onRemoteReceipt(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val transferId = json.optString("transferId")
        if (msgId.isBlank() || !isSafeTransferId(transferId)) return
        val message = vault.getMessageById(msgId) ?: return
        if (!message.isOutgoing || message.attachment?.id != transferId ||
            !message.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        val accepted = json.optBoolean("accepted", false)
        pendingMediaReceipts[incomingKey(senderPubKeyHex, transferId)]?.complete(accepted)
        // Persist the receiver's final verdict here too, so a receipt arriving just after the
        // sender's UI timeout can still turn a failed-looking transfer into a confirmed result.
        if (!(message.attachment?.transferState == TransferState.COMPLETED && message.status == MessageStatus.DELIVERED)) {
            vault.updateMessage(msgId) {
                if (accepted) it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED, progress = 1f, error = null
                )) else it.copy(status = MessageStatus.FAILED, attachment = it.attachment?.copy(
                    transferState = TransferState.FAILED, error = json.optString("error").take(140).ifBlank { "Receiver rejected the file" }
                ))
            }
            onUpdated()
        }
        uploadedPublicFiles.remove(transferId)?.let { uploaded ->
            if (uploaded.provider == "0x0.st" && !uploaded.deleteToken.isNullOrBlank()) {
                scope.launch { deletePublicUpload(uploaded) }
            }
        }
        uploadedPublicSegments.remove(transferId)?.let { uploads ->
            scope.launch { uploads.forEach { deletePublicUpload(it) } }
        }
        clearProgressSnapshot(msgId, transferId)
    }

    /** Handles an authenticated link to a client-side encrypted cloud blob. */
    fun handleCloudLink(senderPubKeyHex: String, json: JSONObject) {
        val sender = senderPubKeyHex.lowercase()
        val msgId = json.optString("msgId")
        val transferId = json.optString("transferId")
        val url = json.optString("url")
        val keyB64 = json.optString("key")
        val nonceB64 = json.optString("nonce")
        val claimedSize = json.optLong("sizeBytes", -1L)
        val digest = json.optString("sha256Hex").lowercase()
        val manifestVersion = json.optInt("manifestVersion", 0)
        if (msgId.isBlank() || !isSafeTransferId(transferId) || claimedSize !in 0..MAX_PUBLIC_FILE_BYTES ||
            !digest.matches(Regex("^[0-9a-f]{64}$")) || manifestVersion !in 0..1 ||
            (manifestVersion == 0 && claimedSize > SEGMENTED_TRANSFER_THRESHOLD_BYTES) ||
            (manifestVersion == 1 && claimedSize <= SEGMENTED_TRANSFER_THRESHOLD_BYTES)) return
        val urlUri = try { URI(url) } catch (_: Exception) { return }
        if (!isAllowedPublicBlobUrl(url) || urlUri.rawUserInfo != null ||
            urlUri.rawFragment != null || (urlUri.port != -1 && urlUri.port != 443)) return
        val key = try { Base64.decode(keyB64, Base64.NO_WRAP) } catch (_: Exception) { return }
        val nonce = try { Base64.decode(nonceB64, Base64.NO_WRAP) } catch (_: Exception) { key.fill(0); return }
        if (key.size != 32 || nonce.size != 12) {
            key.fill(0); nonce.fill(0)
            return
        }
        val message = vault.getMessageById(msgId) ?: run { key.fill(0); nonce.fill(0); return }
        val attachment = message.attachment ?: run { key.fill(0); nonce.fill(0); return }
        if (message.isOutgoing || !message.senderPubKeyHex.equals(sender, ignoreCase = true) ||
            attachment.id != transferId || attachment.sizeBytes != claimedSize ||
            attachment.sha256Hex?.equals(digest, ignoreCase = true) != true ||
            vault.getContactByPubKey(sender) == null) {
            key.fill(0); nonce.fill(0)
            return
        }
        val transferKey = incomingKey(sender, transferId)
        if (!approvedIncoming.contains(transferKey) || !activePublicDownloads.add(transferKey)) {
            key.fill(0); nonce.fill(0)
            return
        }
        scope.launch {
            try {
                if (manifestVersion == 1) {
                    downloadAndDecryptSegmentedPublicBlob(message, attachment, url, key, nonce, digest)
                } else {
                    downloadAndDecryptPublicBlob(message, attachment, url, key, nonce, digest)
                }
            } finally {
                key.fill(0)
                nonce.fill(0)
                activePublicDownloads.remove(transferKey)
            }
        }
    }

    private suspend fun requestIncomingDownload(message: ChatMessage) {
        val attachment = message.attachment ?: return
        val sender = message.senderPubKeyHex.lowercase()
        if (vault.getContactByPubKey(sender) == null) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(
                    transferState = TransferState.FAILED,
                    error = "Accept this contact request before downloading"
                ))
            }
            onUpdated()
            return
        }
        val key = incomingKey(sender, attachment.id)
        approvedIncoming.add(key)
        vault.updateMessage(message.id) {
            it.copy(attachment = it.attachment?.copy(
                transferState = TransferState.IN_PROGRESS, progress = 0f, error = null
            ))
        }
        onUpdated()
        var sent = false
        repeat(3) { attempt ->
            if (!sent) {
                sent = dispatcher(sender, JSONObject().apply {
                    put("type", "MEDIA_ACCEPT")
                    put("msgId", message.id)
                    put("transferId", attachment.id)
                }) != null
                if (!sent && attempt < 2) delay(500L * (attempt + 1))
            }
        }
        if (!sent) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(
                    transferState = TransferState.FAILED,
                    error = "Could not reach sender — tap Download to retry"
                ))
            }
            onUpdated()
        }
    }

    fun cancel(messageId: String) {
        val message = vault.getMessageById(messageId) ?: return
        val attachment = message.attachment ?: return
        cancelled.add(attachment.id)
        clearProgressSnapshot(messageId, attachment.id)
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.CANCELLED, error = "Cancelled")
            )
        }
        onUpdated()
    }

    private suspend fun runOutgoing(message: ChatMessage, recipientHex: String) {
        val attachment = message.attachment ?: return
        val sourceFile = resolveLocalFile(attachment)
        if (sourceFile == null || !sourceFile.exists()) {
            markFailed(message.id, attachment.id, "Local file missing")
            return
        }
        val acceptKey = incomingKey(recipientHex, attachment.id)
        val acceptance = CompletableDeferred<Boolean>()
        val finalReceipt = CompletableDeferred<Boolean>()
        pendingAccepts[acceptKey] = acceptance
        pendingMediaReceipts[acceptKey] = finalReceipt
        val acceptedBeforeStart = preAcceptedTransfers.remove(acceptKey)
        try {
            val totalBytes = sourceFile.length()
            if (totalBytes < 0L || totalBytes > MAX_INCOMING_BYTES) {
                markFailed(message.id, attachment.id, "File exceeds FolkChat's configured 100 GiB safety limit")
                return
            }
            // The selected file is the source of truth at send time. Persist its current size
            // alongside the digest in the initial metadata packet; otherwise a stale size from
            // a previously replaced file can cause a deterministic encrypted-length mismatch.
            val digest = sha256File(sourceFile)
            val transferAttachment = attachment.copy(sizeBytes = totalBytes, sha256Hex = digest)
            val transferMessage = message.copy(attachment = transferAttachment)
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(sizeBytes = totalBytes, sha256Hex = digest))
            }
            onUpdated()
            var chunkSize = CHUNK_SIZE_SOCKET

            // Send metadata first. The recipient explicitly accepts before bytes flow;
            // this makes NEVER/Wi-Fi-only download preferences real rather than cosmetic.
            val route = dispatchWithRetry(recipientHex, buildChatEnvelope(transferMessage))
            if (route == null) {
                markFailed(message.id, attachment.id, "Peer unreachable — check the relay connection or retry")
                return
            }
            if (route == "OFFLINE_BLE_MESH") chunkSize = CHUNK_SIZE_BLE
            if (!acceptedBeforeStart) {
                // A duplicate metadata packet can receive a final receipt when the recipient
                // already has the complete file (e.g. the previous receipt was lost). Race
                // this against explicit acceptance instead of waiting two minutes unnecessarily.
                val gate = withTimeoutOrNull<Pair<Boolean, Boolean>>(120_000L) {
                    select {
                        acceptance.onAwait { true to it }
                        finalReceipt.onAwait { false to it }
                    }
                }
                if (gate == null) {
                    // Close the waiter so a late-but-valid acceptance is recognized as a
                    // retry request instead of being lost during the finally cleanup race.
                    if (!acceptance.complete(false)) preAcceptedTransfers.add(acceptKey)
                    markFailed(message.id, attachment.id, "Waiting for recipient acceptance timed out — tap Retry")
                    return
                }
                if (!gate.first) {
                    if (gate.second) {
                        vault.updateMessage(message.id) {
                            it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                                transferState = TransferState.COMPLETED, progress = 1f, error = null
                            ))
                        }
                        onUpdated()
                    } else markFailed(message.id, attachment.id, "Receiver rejected file integrity verification")
                    return
                }
                if (!gate.second) {
                    markFailed(message.id, attachment.id, "Waiting for recipient to accept the download — tap Retry")
                    return
                }
            }
            if (isCancelled(attachment.id)) {
                markCancelled(message.id)
                return
            }

            // No custom relay URL is required for this route. The public topic carries only
            // small encrypted metadata/control packets; the actual file is separately
            // AES-GCM encrypted on-device and uploaded as an opaque, expiring blob.
            val maxIndexedChunkBytes = CHUNK_SIZE_SOCKET.toLong() * MAX_CHUNKS.toLong()
            val forceOffline = runCatching { vault.getRoutingPolicyName() == "FORCE_OFFLINE" }.getOrDefault(false)
            val needsPublicCloud = !forceOffline && (
                route == "PUBLIC_TOPIC" ||
                    (route == "ONLINE_RELAY" && totalBytes > WAN_CLOUD_TRANSFER_THRESHOLD_BYTES) ||
                    totalBytes > maxIndexedChunkBytes
                )
            if (needsPublicCloud) {
                runPublicCloudTransfer(message, transferAttachment, sourceFile, recipientHex, digest, finalReceipt)
                return
            }
            if (totalBytes > maxIndexedChunkBytes) {
                markFailed(
                    message.id,
                    attachment.id,
                    if (forceOffline) "This file exceeds the offline transport limit. Choose an internet-capable routing policy to send it over WAN."
                    else "This file exceeds the current direct transport capacity. Choose an online WAN route or retry."
                )
                return
            }

            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS))
            }
            onUpdated()

            RandomAccessFile(sourceFile, "r").use { raf ->
                val adjustedTotalLong = if (totalBytes == 0L) 1L else (totalBytes + chunkSize - 1L) / chunkSize.toLong()
                if (adjustedTotalLong !in 1..MAX_CHUNKS.toLong()) {
                    markFailed(message.id, attachment.id, "File is too large for this transport")
                    return
                }
                val adjustedTotal = adjustedTotalLong.toInt()
                var index = 0
                var offset = 0L
                while (index < adjustedTotal) {
                    if (isCancelled(attachment.id)) {
                        markCancelled(message.id)
                        return
                    }
                    val batch = ArrayList<Pair<JSONObject, Int>>(CHUNK_WINDOW)
                    repeat(CHUNK_WINDOW) {
                        if (index >= adjustedTotal) return@repeat
                        val read = if (totalBytes == 0L) 0 else minOf(chunkSize.toLong(), totalBytes - offset).toInt()
                        if (read < 0 || (read == 0 && totalBytes > 0L)) {
                            markFailed(message.id, attachment.id, "Could not read the selected file")
                            return
                        }
                        val bytes = if (read == 0) ByteArray(0) else ByteArray(read).also { target ->
                            raf.seek(offset)
                            val actual = raf.read(target)
                            if (actual != read) throw java.io.IOException("Selected file changed while sending")
                        }
                        val chunkJson = JSONObject().apply {
                            put("type", "MEDIA_CHUNK")
                            put("transferId", attachment.id)
                            put("msgId", message.id)
                            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                            put("senderDisplayName", vault.getDisplayName())
                            put("recipientPubKey", recipientHex)
                            put("index", index)
                            put("total", adjustedTotal)
                            put("chunkSize", chunkSize)
                            put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                            put("timestamp", System.currentTimeMillis())
                        }
                        batch.add(chunkJson to read)
                        offset += read.coerceAtLeast(0)
                        index++
                    }
                    val batchRoutes = coroutineScope {
                        batch.map { (chunkJson, _) ->
                            async(Dispatchers.IO) { sendChunkWithAck(recipientHex, chunkJson) }
                        }.map { it.await() }
                    }
                    if (isCancelled(attachment.id)) {
                        markCancelled(message.id)
                        return
                    }
                    if (batchRoutes.any { it == null }) {
                        // A final receiver receipt is stronger evidence than a lost per-chunk
                        // ACK: the peer has all bytes and has verified the whole-file digest.
                        val alreadyVerified = withTimeoutOrNull(1_500L) { finalReceipt.await() } == true
                        if (alreadyVerified) {
                            vault.updateMessage(message.id) {
                                it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                                    transferState = TransferState.COMPLETED, progress = 1f, error = null
                                ))
                            }
                            onUpdated()
                            return
                        }
                        markFailed(message.id, attachment.id, "Receiver did not confirm a chunk — retry the transfer")
                        return
                    }
                    val progress = if (totalBytes <= 0L) 1f else (offset.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)
                    if (shouldPersistProgress(message.id, attachment.id, progress)) {
                        vault.updateMessage(message.id) {
                            it.copy(attachment = it.attachment?.copy(progress = progress, transferState = TransferState.IN_PROGRESS))
                        }
                        onUpdated()
                    }
                }
            }

            if (isCancelled(attachment.id)) {
                markCancelled(message.id)
                return
            }
            vault.updateMessage(message.id) {
                it.copy(
                    status = MessageStatus.SENDING,
                    routeUsed = route,
                    lastAttemptAtMs = System.currentTimeMillis(),
                    attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = 1f)
                )
            }
            onUpdated()
            val verified = withTimeoutOrNull(60_000L) { finalReceipt.await() }
            if (isCancelled(attachment.id)) {
                markCancelled(message.id)
                return
            }
            if (verified != true) {
                markFailed(
                    message.id,
                    attachment.id,
                    if (verified == false) "Receiver rejected file integrity verification" else "Receiver verification timed out — tap Retry"
                )
                return
            }
            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED, progress = 1f, error = null
                ))
            }
            onUpdated()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (e: Exception) {
            Log.e(TAG, "Outgoing media transfer failed: ${e.javaClass.simpleName}: ${e.message}")
            markFailed(message.id, attachment.id, e.message?.take(160) ?: "Transfer failed; check the connection and retry")
        } finally {
            clearProgressSnapshot(message.id, attachment.id)
            pendingAccepts.remove(acceptKey, acceptance)
            pendingMediaReceipts.remove(acceptKey, finalReceipt)
        }
    }

    /**
     * WAN fallback: upload a client-encrypted temporary blob and send its opaque link through
     * the pairwise public packet bus. No file bytes, key or original filename go to the host
     * in plaintext. The recipient's end-to-end-encrypted acceptance still gates the upload.
     */
    private suspend fun runPublicCloudTransfer(
        message: ChatMessage,
        attachment: MediaAttachment,
        sourceFile: File,
        recipientHex: String,
        digest: String,
        finalReceipt: CompletableDeferred<Boolean>
    ) {
        if (sourceFile.length() > MAX_PUBLIC_FILE_BYTES) {
            markFailed(message.id, attachment.id, "FolkChat's public transfer limit is 100 GiB; available host limits may be lower")
            return
        }
        if (sourceFile.length() > SEGMENTED_TRANSFER_THRESHOLD_BYTES) {
            runSegmentedPublicCloudTransfer(message, attachment, sourceFile, recipientHex, digest, finalReceipt)
            return
        }
        val safeId = sanitize(attachment.id).take(48)
        val encryptedBlob = File(mediaDir, ".fc-upload-${safeId}-${System.currentTimeMillis()}.blob")
        val key = ByteArray(32)
        val nonce = ByteArray(12)
        SecureRandom().nextBytes(key)
        SecureRandom().nextBytes(nonce)
        var uploaded: UploadedPublicFile? = null
        try {
            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(
                    transferState = TransferState.IN_PROGRESS, progress = 0.03f, error = null
                ))
            }
            onUpdated()
            encryptFileForPublicTransfer(sourceFile, encryptedBlob, key, nonce, digest)
            updateCloudProgress(message.id, attachment.id, 0.18f)

            val uploadedBlob = uploadEncryptedBlob(encryptedBlob) { written, total ->
                if (total > 0L) {
                    val fraction = (written.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                    updateCloudProgress(message.id, attachment.id, 0.18f + 0.62f * fraction)
                }
            }
            uploaded = uploadedBlob
            uploadedPublicFiles[attachment.id] = uploadedBlob
            updateCloudProgress(message.id, attachment.id, 0.82f)

            val linkPacket = JSONObject().apply {
                put("type", "MEDIA_CLOUD_LINK")
                put("msgId", message.id)
                put("transferId", attachment.id)
                put("url", uploadedBlob.url)
                put("key", Base64.encodeToString(key, Base64.NO_WRAP))
                put("nonce", Base64.encodeToString(nonce, Base64.NO_WRAP))
                put("sizeBytes", sourceFile.length())
                put("sha256Hex", digest)
                put("manifestVersion", 0)
                put("timestamp", System.currentTimeMillis())
            }
            val linkRoute = dispatchWithRetry(recipientHex, linkPacket)
            if (linkRoute == null) {
                uploadedPublicFiles.remove(attachment.id)
                uploaded?.let { deletePublicUpload(it) }
                markFailed(message.id, attachment.id, "Encrypted file uploaded, but its download notice could not be delivered. Tap Retry.")
                return
            }

            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, routeUsed = "PUBLIC_TOPIC", lastAttemptAtMs = System.currentTimeMillis(),
                    attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = 0.96f, error = null))
            }
            onUpdated()
            val verified = withTimeoutOrNull(10 * 60_000L) { finalReceipt.await() }
            when (verified) {
                true -> {
                    vault.updateMessage(message.id) {
                        it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                            transferState = TransferState.COMPLETED, progress = 1f, error = null
                        ))
                    }
                    uploadedPublicFiles.remove(attachment.id)?.let { remote -> deletePublicUpload(remote) }
                    onUpdated()
                }
                false -> {
                    uploadedPublicFiles.remove(attachment.id)?.let { remote -> deletePublicUpload(remote) }
                    markFailed(message.id, attachment.id, "Receiver rejected the file or its integrity check failed")
                }
                null -> markFailed(message.id, attachment.id, "Waiting for receiver verification timed out. The encrypted link is temporary; tap Retry.")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Public encrypted transfer failed: ${e.javaClass.simpleName}")
            uploadedPublicFiles.remove(attachment.id)?.let { deletePublicUpload(it) }
            markFailed(message.id, attachment.id, e.message?.take(140) ?: "Public WAN transfer failed")
        } finally {
            try { encryptedBlob.delete() } catch (_: Exception) {}
            key.fill(0)
            nonce.fill(0)
        }
    }

    /**
     * Large WAN transfers upload independently authenticated 16 MiB ciphertext segments and an
     * encrypted manifest. The app-level ceiling is 100 GiB, but public hosts may apply stricter
     * size, expiry, rate, or availability policies. Only ciphertext reaches those hosts.
     */
    private suspend fun runSegmentedPublicCloudTransfer(
        message: ChatMessage,
        attachment: MediaAttachment,
        sourceFile: File,
        recipientHex: String,
        digest: String,
        finalReceipt: CompletableDeferred<Boolean>
    ) {
        val sourceSize = sourceFile.length()
        val segmentCount = ((sourceSize + PUBLIC_SEGMENT_BYTES - 1L) / PUBLIC_SEGMENT_BYTES).toInt()
        if (sourceSize !in (SEGMENTED_TRANSFER_THRESHOLD_BYTES + 1)..MAX_PUBLIC_FILE_BYTES ||
            segmentCount !in 1..MAX_PUBLIC_SEGMENTS) {
            markFailed(message.id, attachment.id, "File exceeds the supported segmented-transfer bounds")
            return
        }
        val uploadedParts = java.util.Collections.synchronizedList(mutableListOf<UploadedPublicFile>())
        var manifestUpload: UploadedPublicFile? = null
        val manifestKey = ByteArray(32).also(SecureRandom()::nextBytes)
        val manifestNonce = ByteArray(12).also(SecureRandom()::nextBytes)
        val manifestCipherFile = File(mediaDir, ".fc-manifest-${sanitize(attachment.id)}-${System.currentTimeMillis()}.blob")
        var handedOff = false
        try {
            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(
                    transferState = TransferState.IN_PROGRESS, progress = 0.02f, error = null
                ))
            }
            onUpdated()
            val segmentJson = org.json.JSONArray()
            val completedLogicalBytes = AtomicLong(0L)
            var nextOffset = 0L
            var nextIndex = 0
            while (nextOffset < sourceSize) {
                if (isCancelled(attachment.id)) throw CancellationException("Transfer cancelled")
                val batch = ArrayList<Triple<Int, Long, Long>>(SEGMENT_UPLOAD_CONCURRENCY)
                repeat(SEGMENT_UPLOAD_CONCURRENCY) {
                    if (nextOffset < sourceSize) {
                        val length = minOf(PUBLIC_SEGMENT_BYTES, sourceSize - nextOffset)
                        batch += Triple(nextIndex, nextOffset, length)
                        nextIndex++
                        nextOffset += length
                    }
                }
                // A small bounded pipeline overlaps network upload with encryption without creating
                // dozens of file buffers or hammering the UI/vault with per-kilobyte progress writes.
                val batchResults = coroutineScope {
                    batch.map { (index, offset, partLength) ->
                        async(Dispatchers.IO) {
                            if (isCancelled(attachment.id)) throw CancellationException("Transfer cancelled")
                            val encryptedPart = File(mediaDir, ".fc-segment-${sanitize(attachment.id)}-$index-${System.currentTimeMillis()}.blob")
                            val partKey = ByteArray(32).also(SecureRandom()::nextBytes)
                            val partNonce = ByteArray(12).also(SecureRandom()::nextBytes)
                            try {
                                encryptFileRangeForPublicTransfer(sourceFile, offset, partLength, encryptedPart, partKey, partNonce)
                                var remote: UploadedPublicFile? = null
                                var lastError: Exception? = null
                                repeat(2) { attempt ->
                                    if (remote == null) {
                                        try {
                                            remote = uploadEncryptedBlob(encryptedPart) { _, _ -> Unit }
                                        } catch (cancelled: CancellationException) {
                                            throw cancelled
                                        } catch (e: Exception) {
                                            lastError = e
                                            if (attempt == 0) delay(450L)
                                        }
                                    }
                                }
                                val stored = remote ?: throw IOException(
                                    "Could not upload encrypted segment ${index + 1}: ${lastError?.message ?: "temporary host unavailable"}"
                                )
                                // Track each completed upload once, so failed sibling jobs do not
                                // leak already-uploaded opaque blobs during cleanup.
                                synchronized(uploadedParts) { uploadedParts.add(stored) }
                                val completed = completedLogicalBytes.addAndGet(partLength)
                                updateCloudProgress(
                                    message.id, attachment.id,
                                    0.04f + 0.68f * (completed.toDouble() / sourceSize.toDouble()).coerceIn(0.0, 1.0).toFloat()
                                )
                                index to JSONObject().apply {
                                    put("url", stored.url)
                                    put("key", Base64.encodeToString(partKey, Base64.NO_WRAP))
                                    put("nonce", Base64.encodeToString(partNonce, Base64.NO_WRAP))
                                    put("offset", offset)
                                    put("sizeBytes", partLength)
                                    put("encryptedSizeBytes", partLength + 16L)
                                }
                            } finally {
                                encryptedPart.delete()
                                partKey.fill(0)
                                partNonce.fill(0)
                            }
                        }
                    }.awaitAll()
                }
                batchResults.sortedBy { it.first }.forEach { segmentJson.put(it.second) }
            }

            val manifestJson = JSONObject().apply {
                put("version", 1)
                put("fileSize", sourceSize)
                put("sha256Hex", digest)
                put("segmentBytes", PUBLIC_SEGMENT_BYTES)
                put("segments", segmentJson)
            }
            val manifestBytes = manifestJson.toString().toByteArray(Charsets.UTF_8)
            try {
                if (manifestBytes.size.toLong() > MAX_PUBLIC_MANIFEST_BYTES) throw IOException("Encrypted transfer manifest is too large")
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(manifestKey, "AES"), GCMParameterSpec(128, manifestNonce))
                val encryptedManifest = cipher.doFinal(manifestBytes)
                try { manifestCipherFile.writeBytes(encryptedManifest) } finally { encryptedManifest.fill(0) }
            } finally {
                manifestBytes.fill(0)
            }

            manifestUpload = uploadEncryptedBlob(manifestCipherFile) { written, total ->
                if (total > 0L) updateCloudProgress(message.id, attachment.id, 0.73f + 0.06f * (written.toFloat() / total.toFloat()).coerceIn(0f, 1f))
            }
            uploadedParts += manifestUpload!!
            uploadedPublicSegments[attachment.id] = synchronized(uploadedParts) { uploadedParts.toList() }

            val linkPacket = JSONObject().apply {
                put("type", "MEDIA_CLOUD_LINK")
                put("msgId", message.id)
                put("transferId", attachment.id)
                put("url", manifestUpload!!.url)
                put("key", Base64.encodeToString(manifestKey, Base64.NO_WRAP))
                put("nonce", Base64.encodeToString(manifestNonce, Base64.NO_WRAP))
                put("sizeBytes", sourceSize)
                put("sha256Hex", digest)
                put("manifestVersion", 1)
                put("timestamp", System.currentTimeMillis())
            }
            val route = dispatchWithRetry(recipientHex, linkPacket)
            if (route == null) throw IOException("Segments were uploaded, but the encrypted transfer manifest could not be delivered")
            handedOff = true
            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, routeUsed = "PUBLIC_TOPIC", lastAttemptAtMs = System.currentTimeMillis(),
                    attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = 0.96f, error = null))
            }
            onUpdated()
            when (withTimeoutOrNull(30 * 60_000L) { finalReceipt.await() }) {
                true -> {
                    vault.updateMessage(message.id) {
                        it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                            transferState = TransferState.COMPLETED, progress = 1f, error = null
                        ))
                    }
                    uploadedPublicSegments.remove(attachment.id)?.forEach { deletePublicUpload(it) }
                    onUpdated()
                }
                false -> {
                    uploadedPublicSegments.remove(attachment.id)?.forEach { deletePublicUpload(it) }
                    markFailed(message.id, attachment.id, "Receiver rejected the segmented file or its integrity check failed")
                }
                null -> markFailed(message.id, attachment.id, "Waiting for receiver verification timed out; encrypted temporary segments may expire. Tap Retry.")
            }
        } catch (e: CancellationException) {
            if (!handedOff) uploadedParts.forEach { deletePublicUpload(it) }
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Segmented public transfer failed: ${e.javaClass.simpleName}")
            uploadedPublicSegments.remove(attachment.id)
            uploadedParts.forEach { deletePublicUpload(it) }
            markFailed(message.id, attachment.id, e.message?.take(160) ?: "Segmented public transfer failed")
        } finally {
            manifestCipherFile.delete()
            manifestKey.fill(0)
            manifestNonce.fill(0)
            if (!handedOff) manifestUpload?.let { deletePublicUpload(it) }
        }
    }

    private fun encryptFileRangeForPublicTransfer(
        sourceFile: File,
        offset: Long,
        length: Long,
        destination: File,
        key: ByteArray,
        nonce: ByteArray
    ) {
        require(offset >= 0L && length > 0L && length <= PUBLIC_SEGMENT_BYTES)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        var remaining = length
        val buffer = ByteArray(64 * 1024)
        try {
            RandomAccessFile(sourceFile, "r").use { source ->
                source.seek(offset)
                FileOutputStream(destination).buffered(64 * 1024).use { rawOut ->
                    CipherOutputStream(rawOut, cipher).use { encryptedOut ->
                        while (remaining > 0L) {
                            val count = source.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                            if (count <= 0) throw IOException("Selected file changed during segmented encryption")
                            encryptedOut.write(buffer, 0, count)
                            remaining -= count
                        }
                    }
                }
            }
            if (destination.length() != length + 16L) throw IOException("Encrypted segment length validation failed")
        } catch (e: Exception) {
            destination.delete()
            throw e
        } finally { buffer.fill(0) }
    }

    private data class ManifestSegment(
        val url: String,
        val key: ByteArray,
        val nonce: ByteArray,
        val offset: Long,
        val sizeBytes: Long,
        val encryptedSizeBytes: Long
    )

    private suspend fun downloadAndDecryptSegmentedPublicBlob(
        message: ChatMessage,
        attachment: MediaAttachment,
        manifestUrl: String,
        manifestKey: ByteArray,
        manifestNonce: ByteArray,
        expectedDigest: String
    ) = withContext(Dispatchers.IO) {
        val transferKey = incomingKey(message.senderPubKeyHex, attachment.id)
        val target = incomingFile("${sanitize(message.senderPubKeyHex)}_${attachment.id}", attachment.fileName)
        if (target == null) {
            approvedIncoming.remove(transferKey)
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, false, "Could not create destination file")
            return@withContext
        }
        val plainTemp = File(target.parentFile, ".fc-plain-part-${sanitize(attachment.id)}-${System.currentTimeMillis()}.part")
        val encryptedPartTemp = File(mediaDir, ".fc-download-${sanitize(attachment.id)}-${System.currentTimeMillis()}.blob")
        val segments = mutableListOf<ManifestSegment>()
        try {
            if (mediaDir.usableSpace < attachment.sizeBytes + (16L * 1024L * 1024L)) {
                throw IOException("Not enough free storage for this file; free up space and retry")
            }
            updateIncomingCloudProgress(message.id, attachment.id, 0.03f)
            val manifestCiphertext = downloadBoundedBlobBytes(manifestUrl, MAX_PUBLIC_MANIFEST_BYTES + 16L)
            val manifestPlain = try {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(manifestKey, "AES"), GCMParameterSpec(128, manifestNonce))
                cipher.doFinal(manifestCiphertext)
            } catch (e: Exception) {
                throw IOException("Transfer manifest authentication failed", e)
            } finally { manifestCiphertext.fill(0) }
            val manifest = try { JSONObject(String(manifestPlain, Charsets.UTF_8)) } finally { manifestPlain.fill(0) }
            if (manifest.optInt("version", -1) != 1 || manifest.optLong("fileSize", -1L) != attachment.sizeBytes ||
                !manifest.optString("sha256Hex").equals(expectedDigest, true)) {
                throw IOException("Transfer manifest did not match the message metadata")
            }
            val manifestSegments = manifest.optJSONArray("segments") ?: throw IOException("Transfer manifest has no segment list")
            if (manifestSegments.length() !in 1..MAX_PUBLIC_SEGMENTS) throw IOException("Transfer contains too many segments")
            var expectedOffset = 0L
            for (index in 0 until manifestSegments.length()) {
                val item = manifestSegments.optJSONObject(index) ?: throw IOException("Invalid segment metadata")
                val url = item.optString("url")
                val parsedUrl = try { URI(url) } catch (_: Exception) { throw IOException("Invalid segment URL") }
                val offset = item.optLong("offset", -1L)
                val size = item.optLong("sizeBytes", -1L)
                val encryptedSize = item.optLong("encryptedSizeBytes", -1L)
                val key = try { Base64.decode(item.optString("key"), Base64.NO_WRAP) } catch (_: Exception) { throw IOException("Invalid segment key") }
                val nonce = try { Base64.decode(item.optString("nonce"), Base64.NO_WRAP) } catch (_: Exception) { key.fill(0); throw IOException("Invalid segment nonce") }
                if (!isAllowedPublicBlobUrl(url) || parsedUrl.rawUserInfo != null || parsedUrl.rawFragment != null ||
                    offset != expectedOffset || size !in 1..PUBLIC_SEGMENT_BYTES || encryptedSize != size + 16L ||
                    key.size != 32 || nonce.size != 12 || (index < manifestSegments.length() - 1 && size != PUBLIC_SEGMENT_BYTES)) {
                    key.fill(0); nonce.fill(0)
                    throw IOException("Segment metadata failed validation")
                }
                segments += ManifestSegment(url, key, nonce, offset, size, encryptedSize)
                expectedOffset += size
                if (expectedOffset > attachment.sizeBytes) throw IOException("Segment manifest exceeds the file size")
            }
            if (expectedOffset != attachment.sizeBytes) throw IOException("Segment manifest is incomplete")

            plainTemp.delete()
            FileOutputStream(plainTemp).use { /* Create/truncate before sequential assembly. */ }
            var completedBytes = 0L
            segments.forEachIndexed { index, segment ->
                var downloaded = false
                var lastDownloadError: Exception? = null
                for (attempt in 0 until 3) {
                    try {
                        downloadBoundedBlobToFile(segment.url, encryptedPartTemp, segment.encryptedSizeBytes)
                        downloaded = true
                        break
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (e: Exception) {
                        lastDownloadError = e
                        encryptedPartTemp.delete()
                        if (attempt < 2) delay(400L * (attempt + 1))
                    }
                }
                if (!downloaded) throw IOException("Could not fetch segment ${index + 1}", lastDownloadError)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(segment.key, "AES"), GCMParameterSpec(128, segment.nonce))
                try {
                    FileInputStream(encryptedPartTemp).buffered(64 * 1024).use { input ->
                        FileOutputStream(plainTemp, true).buffered(64 * 1024).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            try {
                                while (true) {
                                    val count = input.read(buffer)
                                    if (count < 0) break
                                    if (count == 0) continue
                                    val plain = cipher.update(buffer, 0, count)
                                    if (plain != null && plain.isNotEmpty()) { output.write(plain); plain.fill(0) }
                                }
                                val tail = cipher.doFinal() // Each segment must independently authenticate.
                                if (tail.isNotEmpty()) { output.write(tail); tail.fill(0) }
                            } finally { buffer.fill(0) }
                        }
                    }
                } catch (e: Exception) {
                    throw IOException("Segment ${index + 1} authentication failed", e)
                } finally {
                    segment.key.fill(0); segment.nonce.fill(0); encryptedPartTemp.delete()
                }
                completedBytes += segment.sizeBytes
                updateIncomingCloudProgress(message.id, attachment.id, 0.08f + 0.78f * (completedBytes.toDouble() / attachment.sizeBytes.toDouble()).toFloat())
            }
            if (plainTemp.length() != attachment.sizeBytes) throw IOException("Reassembled file size does not match the manifest")
            val actualDigest = sha256File(plainTemp)
            if (!actualDigest.equals(expectedDigest, true) || !actualDigest.equals(attachment.sha256Hex, true)) {
                throw IOException("SHA-256 verification failed; refusing to finalize the file")
            }
            if (target.exists() && !target.delete()) throw IOException("Could not replace an incomplete destination file")
            if (!plainTemp.renameTo(target)) throw IOException("Could not finalize downloaded file")
            approvedIncoming.remove(transferKey)
            val completedFile = placeCompletedFileInCurrentMediaDirectory(target)
                ?: throw IOException("Could not safely store the completed attachment")
            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED, progress = 1f, localPath = completedFile.absolutePath, error = null
                ))
            }
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, true, null)
            onUpdated()
        } catch (cancelled: CancellationException) {
            plainTemp.delete()
            throw cancelled
        } catch (e: Exception) {
            plainTemp.delete()
            val reason = e.message?.take(140) ?: "Segmented transfer failed authentication or verification"
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = reason))
            }
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, false, reason)
            onUpdated()
            Log.w(TAG, "Segmented download rejected: ${e.javaClass.simpleName}")
        } finally {
            segments.forEach { it.key.fill(0); it.nonce.fill(0) }
            encryptedPartTemp.delete()
        }
    }

    private suspend fun downloadBoundedBlobBytes(url: String, maxBytes: Long): ByteArray = withContext(Dispatchers.IO) {
        if (!isAllowedPublicBlobUrl(url)) throw IOException("Download URL is not on an approved temporary host")
        executePublicGet(url).use { response ->
            if (!response.isSuccessful) throw IOException("Temporary host returned HTTP ${response.code}")
            val body = response.body ?: throw IOException("Temporary host returned an empty blob")
            // A temporary host's Content-Length can be stale. Enforce the ceiling against
            // bytes actually read instead of trusting the header.
            val output = ByteArrayOutputStream()
            body.byteStream().use { input ->
                val buffer = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count == 0) continue
                    total += count
                    if (total > maxBytes) throw IOException("Encrypted manifest exceeds the size limit")
                    output.write(buffer, 0, count)
                }
                buffer.fill(0)
            }
            output.toByteArray()
        }
    }

    private suspend fun downloadBoundedBlobToFile(url: String, destination: File, expectedBytes: Long) = withContext(Dispatchers.IO) {
        if (!isAllowedPublicBlobUrl(url) || expectedBytes !in 17L..(PUBLIC_SEGMENT_BYTES + 16L)) throw IOException("Segment URL or size is invalid")
        executePublicGet(url).use { response ->
            if (!response.isSuccessful) throw IOException("Segment download returned HTTP ${response.code}")
            val body = response.body ?: throw IOException("Segment host returned an empty response")
            // Do not trust Content-Length as integrity evidence: some temporary-file hosts
            // return stale headers. The actual streamed byte count below is authoritative.
            body.byteStream().use { input ->
                FileOutputStream(destination, false).buffered(64 * 1024).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        total += count
                        if (total > expectedBytes) throw IOException("Segment exceeded the declared size")
                        output.write(buffer, 0, count)
                    }
                    buffer.fill(0)
                    if (total != expectedBytes) throw IOException("Segment was truncated")
                }
            }
        }
    }

    private fun encryptFileForPublicTransfer(
        source: File,
        destination: File,
        key: ByteArray,
        nonce: ByteArray,
        expectedSha256: String
    ) {
        val digest = MessageDigest.getInstance("SHA-256")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        try {
            source.inputStream().buffered(64 * 1024).use { input ->
                FileOutputStream(destination).buffered(64 * 1024).use { fileOut ->
                    CipherOutputStream(fileOut, cipher).use { encryptedOut ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (count == 0) continue
                            digest.update(buffer, 0, count)
                            encryptedOut.write(buffer, 0, count)
                        }
                    }
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(expectedSha256, ignoreCase = true)) {
                destination.delete()
                throw IOException("Selected file changed while sending")
            }
            if (destination.length() != source.length() + 16L) {
                destination.delete()
                throw IOException("Encrypted file length validation failed")
            }
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    private suspend fun uploadEncryptedBlob(
        encryptedFile: File,
        onProgress: (Long, Long) -> Unit
    ): UploadedPublicFile = withContext(Dispatchers.IO) {
        var firstFailure: Exception? = null
        try {
            val upload = MultipartBody.Builder().setType(MultipartBody.FORM)
                // Use a random filename and the host's secret-path option. Never disclose the
                // attachment ID, contact identity or original filename to the file host.
                .addFormDataPart("secret", "")
                .addFormDataPart(
                    "file", "blob-${randomHex(16)}.bin",
                    ProgressRequestBody(encryptedFile.asRequestBody(OCTET_STREAM), onProgress)
                )
                // Ask the host to remove ciphertext after one day; this is a request to a
                // third-party service, not a cryptographic or availability guarantee.
                .addFormDataPart("expires", "24")
                .build()
            val request = Request.Builder().url("https://0x0.st/").post(upload).build()
            transferHttpClient(allowApprovedRedirects = true).newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Temporary host returned HTTP ${response.code}")
                val url = response.body?.string()?.trim().orEmpty()
                if (!isAllowedPublicBlobUrl(url) || URI(url).host?.lowercase() != "0x0.st") {
                    throw IOException("Temporary host returned an invalid download URL")
                }
                return@withContext UploadedPublicFile(url, "0x0.st", response.header("X-Token"))
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (e: Exception) {
            firstFailure = e
            Log.i(TAG, "Primary temporary host unavailable; trying short-retention fallback")
        }

        if (encryptedFile.length() > TMPFILES_MAX_BYTES) {
            throw IOException("Public temporary hosts are unavailable for this file size", firstFailure)
        }
        val fallbackBody = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart(
                "file", "blob-${randomHex(16)}.bin",
                ProgressRequestBody(encryptedFile.asRequestBody(OCTET_STREAM), onProgress)
            )
            // The service uses seconds and defaults to one hour; request the same TTL explicitly.
            .addFormDataPart("expire", "3600")
            .build()
        val fallbackRequest = Request.Builder()
            .url("https://tmpfiles.org/api/v1/upload")
            .post(fallbackBody)
            .build()
        transferHttpClient(allowApprovedRedirects = true).newCall(fallbackRequest).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Temporary fallback returned HTTP ${response.code}", firstFailure)
            val json = JSONObject(response.body?.string().orEmpty())
            if (!json.optString("status").equals("success", ignoreCase = true)) {
                throw IOException("Temporary file host rejected the upload", firstFailure)
            }
            val pageUrl = json.optJSONObject("data")?.optString("url").orEmpty()
            val uri = try { URI(pageUrl) } catch (_: Exception) { throw IOException("Invalid temporary file URL") }
            if (uri.scheme != "https" || uri.host?.lowercase() != "tmpfiles.org" ||
                uri.rawUserInfo != null || uri.rawFragment != null ||
                (uri.port != -1 && uri.port != 443) || !uri.path.matches(Regex("^/[A-Za-z0-9_./-]+$")) ||
                uri.path.startsWith("//") || uri.path.split('/').any { it == "." || it == ".." }) {
                throw IOException("Temporary fallback returned an invalid URL")
            }
            val directPath = if (uri.path.startsWith("/dl/")) uri.path else "/dl" + uri.path
            val directUrl = URI("https", null, "tmpfiles.org", -1, directPath, null, null).toASCIIString()
            UploadedPublicFile(directUrl, "tmpfiles.org")
        }
    }

    private suspend fun downloadAndDecryptPublicBlob(
        message: ChatMessage,
        attachment: MediaAttachment,
        url: String,
        key: ByteArray,
        nonce: ByteArray,
        expectedDigest: String
    ) = withContext(Dispatchers.IO) {
        if (attachment.sizeBytes > SEGMENTED_TRANSFER_THRESHOLD_BYTES) throw IOException("Oversized files require a segmented manifest")
        val transferKey = incomingKey(message.senderPubKeyHex, attachment.id)
        val encryptedTemp = File(mediaDir, ".fc-download-${sanitize(attachment.id)}-${System.currentTimeMillis()}.blob")
        val target = try { incomingFile("${sanitize(message.senderPubKeyHex)}_${attachment.id}", attachment.fileName) }
            catch (_: Exception) { null }
        if (target == null) {
            val reason = "Could not create destination file"
            approvedIncoming.remove(transferKey)
            vault.updateMessage(message.id) { it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = reason)) }
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, false, reason)
            onUpdated()
            return@withContext
        }
        val plainTemp = File(target.parentFile, ".fc-plain-part-${sanitize(attachment.id)}-${System.currentTimeMillis()}.part")
        try {
            updateIncomingCloudProgress(message.id, attachment.id, 0.03f)
            val expectedEncryptedBytes = attachment.sizeBytes + 16L // AES-GCM appends a 128-bit tag.
            if (attachment.sizeBytes < 0L || expectedEncryptedBytes > MAX_PUBLIC_FILE_BYTES + 16L) {
                throw IOException("Encrypted download size metadata is invalid")
            }
            var completedDownload = false
            var lastDownloadError: Exception? = null
            // Retry transient host disconnects and truncated HTTP bodies. Each attempt truncates
            // the temp file; AES-GCM and the SHA-256 digest still validate the final result.
            for (attempt in 0 until 3) {
                encryptedTemp.delete()
                try {
                    executePublicGet(url).use { response ->
                        if (!response.isSuccessful) throw IOException("Could not download temporary file (HTTP ${response.code})")
                        val body = response.body ?: throw IOException("Temporary host returned an empty file")
                        val contentLength = body.contentLength() // Used only for progress, never as an integrity assertion.
                        body.byteStream().use { input ->
                            FileOutputStream(encryptedTemp, false).buffered(64 * 1024).use { output ->
                                val buffer = ByteArray(64 * 1024)
                                var total = 0L
                                var lastReported = 0L
                                try {
                                    while (true) {
                                        val count = input.read(buffer)
                                        if (count < 0) break
                                        if (count == 0) continue
                                        total += count
                                        if (total > expectedEncryptedBytes || total > MAX_PUBLIC_FILE_BYTES + 16L) {
                                            throw IOException("Encrypted download exceeded the expected size")
                                        }
                                        output.write(buffer, 0, count)
                                        if (total - lastReported >= 1024 * 1024L) {
                                            lastReported = total
                                            val fraction = if (contentLength > 0L) (total.toFloat() / contentLength.toFloat()).coerceIn(0f, 1f)
                                                else (total.toFloat() / expectedEncryptedBytes.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
                                            updateIncomingCloudProgress(message.id, attachment.id, 0.05f + 0.58f * fraction)
                                        }
                                    }
                                } finally {
                                    buffer.fill(0)
                                }
                                if (total != expectedEncryptedBytes) {
                                    throw IOException("Encrypted download incomplete (received $total of $expectedEncryptedBytes bytes)")
                                }
                            }
                        }
                    }
                    if (encryptedTemp.length() != expectedEncryptedBytes) {
                        throw IOException("Encrypted download length mismatch (received ${encryptedTemp.length()} of $expectedEncryptedBytes bytes)")
                    }
                    completedDownload = true
                    break
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (e: Exception) {
                    lastDownloadError = e
                    encryptedTemp.delete()
                    if (attempt < 2) delay(350L * (attempt + 1))
                }
            }
            if (!completedDownload) {
                throw IOException("Encrypted download failed after 3 attempts: ${lastDownloadError?.message ?: "incomplete response"}", lastDownloadError)
            }

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            try {
                // Do not use CipherInputStream for authenticated decryption: some JCE
                // implementations suppress finalization/authentication exceptions. Stream via
                // Cipher.update, then require doFinal() to validate the GCM tag before rename.
                FileInputStream(encryptedTemp).buffered(64 * 1024).use { input ->
                    FileOutputStream(plainTemp).buffered(64 * 1024).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (count == 0) continue
                            val plain = cipher.update(buffer, 0, count)
                            if (plain != null && plain.isNotEmpty()) {
                                output.write(plain)
                                plain.fill(0)
                            }
                        }
                        val finalPlain = cipher.doFinal() // Throws if the GCM tag is invalid.
                        if (finalPlain.isNotEmpty()) {
                            output.write(finalPlain)
                            finalPlain.fill(0)
                        }
                    }
                }
            } catch (e: Exception) {
                plainTemp.delete()
                throw IOException("File authentication failed; refusing to open downloaded data", e)
            }
            updateIncomingCloudProgress(message.id, attachment.id, 0.88f)
            if (plainTemp.length() != attachment.sizeBytes) throw IOException("Decrypted file size mismatch")
            val actualDigest = sha256File(plainTemp)
            if (!actualDigest.equals(expectedDigest, ignoreCase = true) ||
                !actualDigest.equals(attachment.sha256Hex, ignoreCase = true)) {
                throw IOException("SHA-256 verification failed; downloaded file was not accepted")
            }
            if (target.exists() && !target.delete()) throw IOException("Could not replace incomplete destination file")
            if (!plainTemp.renameTo(target)) throw IOException("Could not finalize downloaded file")

            approvedIncoming.remove(transferKey)
            val completedFile = placeCompletedFileInCurrentMediaDirectory(target)
                ?: throw IOException("Could not safely store the completed attachment")
            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED, progress = 1f,
                    localPath = completedFile.absolutePath, error = null
                ))
            }
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, true, null)
            onUpdated()
        } catch (e: CancellationException) {
            plainTemp.delete()
            throw e
        } catch (e: Exception) {
            plainTemp.delete()
            val messageText = e.message?.take(140) ?: "Encrypted file download failed"
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = messageText))
            }
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, false, messageText)
            onUpdated()
            Log.w(TAG, "Public file download rejected: ${e.javaClass.simpleName}")
        } finally {
            encryptedTemp.delete()
            // The generated AES key is cleared by the caller after this suspending handler.
        }
    }

    private fun shouldPersistProgress(messageId: String, transferId: String, progress: Float): Boolean {
        val key = "$messageId|$transferId"
        val now = System.currentTimeMillis()
        val value = progress.coerceIn(0f, 0.99f)
        var persist = false
        lastProgressSnapshots.compute(key) { _, previous ->
            when {
                previous == null || value <= 0.04f || value >= 0.99f -> {
                    persist = true
                    ProgressSnapshot(now, value)
                }
                value - previous.progress >= 0.025f ||
                    (now - previous.atMs >= 1_500L && value - previous.progress >= 0.002f) -> {
                    persist = true
                    ProgressSnapshot(now, value)
                }
                else -> previous
            }
        }
        return persist
    }

    private fun clearProgressSnapshot(messageId: String, transferId: String) {
        lastProgressSnapshots.remove("$messageId|$transferId")
    }

    private fun updateCloudProgress(messageId: String, transferId: String, progress: Float) {
        val value = progress.coerceIn(0f, 0.99f)
        if (!shouldPersistProgress(messageId, transferId, value)) return
        vault.updateMessage(messageId) {
            it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(
                transferState = TransferState.IN_PROGRESS, progress = value, error = null
            ))
        }
        onUpdated()
    }

    private fun updateIncomingCloudProgress(messageId: String, transferId: String, progress: Float) {
        val value = progress.coerceIn(0f, 0.99f)
        if (!shouldPersistProgress(messageId, transferId, value)) return
        vault.updateMessage(messageId) {
            it.copy(attachment = it.attachment?.copy(
                transferState = TransferState.IN_PROGRESS, progress = value, error = null
            ))
        }
        onUpdated()
    }

    private fun isAllowedPublicBlobUrl(url: String): Boolean = try {
        val uri = URI(url)
        uri.scheme == "https" && uri.host?.lowercase() in setOf("0x0.st", "tmpfiles.org") &&
            uri.rawUserInfo == null && uri.rawFragment == null && (uri.port == -1 || uri.port == 443) &&
            uri.rawPath.isNotBlank() && !uri.rawPath.startsWith("//")
    } catch (_: Exception) { false }

    private fun randomHex(byteCount: Int): String {
        val bytes = ByteArray(byteCount)
        SecureRandom().nextBytes(bytes)
        return try { bytes.joinToString("") { "%02x".format(it) } } finally { bytes.fill(0) }
    }

    private fun transferHttpClient(allowApprovedRedirects: Boolean = false): OkHttpClient {
        val tor = try { vault.getSettings().torRoutingEnabled } catch (_: Exception) { false }
        val cacheKey = "${if (tor) "tor" else "direct"}|${if (allowApprovedRedirects) "redirects" else "no-redirects"}"
        return transferClients.computeIfAbsent(cacheKey) {
            val builder = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(PUBLIC_UPLOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .callTimeout(PUBLIC_UPLOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .followRedirects(allowApprovedRedirects)
                // Never downgrade a media transfer from HTTPS to HTTP.
                .followSslRedirects(false)
                .retryOnConnectionFailure(true)
            if (allowApprovedRedirects) {
                builder.addNetworkInterceptor { chain ->
                    val response = chain.proceed(chain.request())
                    if (response.code in 300..399) {
                        val location = response.header("Location")
                        val target = location?.let { chain.request().url.resolve(it) }
                        if (target == null || !isAllowedPublicRedirect(target)) {
                            response.close()
                            // Fail closed rather than retrying a host-controlled redirect to an
                            // arbitrary domain or an HTTP downgrade.
                            throw IllegalArgumentException("Blocked unsafe temporary-file redirect")
                        }
                    }
                    response
                }
            }
            if (tor) builder.proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress.createUnresolved("127.0.0.1", 9050)))
            else builder.proxy(Proxy.NO_PROXY)
            builder.build()
        }
    }

    private fun isAllowedPublicRedirect(url: okhttp3.HttpUrl): Boolean {
        if (!url.isHttps || url.username.isNotEmpty() || url.password.isNotEmpty() || url.port != 443 && url.port != 8443) return false
        val host = url.host.lowercase()
        return host == "0x0.st" || host == "tmpfiles.org" || host.endsWith(".tmpfiles.org")
    }

    /** Safe redirect handling plus bounded retries for transient WAN loss and temporary 5xxs. */
    private suspend fun executePublicGet(url: String): Response {
        if (!isAllowedPublicBlobUrl(url)) throw IOException("Download URL is not on an approved temporary host")
        var lastFailure: IOException? = null
        for (attempt in 0 until 3) {
            val response = try {
                transferHttpClient(allowApprovedRedirects = true)
                    .newCall(Request.Builder().url(url).get().build()).execute()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                throw IOException(e.message ?: "Unsafe download redirect rejected", e)
            } catch (e: IOException) {
                lastFailure = e
                if (attempt == 2) throw IOException("Download failed after 3 network attempts", e)
                delay(350L * (attempt + 1))
                continue
            }
            if (response.isSuccessful) return response
            val code = response.code
            response.close()
            val retryable = code in setOf(408, 425, 429, 500, 502, 503, 504)
            if (!retryable || attempt == 2) {
                throw IOException("Temporary host returned HTTP $code${if (retryable) " after retries" else ""}")
            }
            delay(350L * (attempt + 1))
        }
        throw IOException("Download failed after retries", lastFailure)
    }

    private suspend fun deletePublicUpload(upload: UploadedPublicFile) = withContext(Dispatchers.IO) {
        if (upload.provider != "0x0.st" || upload.deleteToken.isNullOrBlank()) return@withContext
        try {
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("token", upload.deleteToken)
                .addFormDataPart("delete", "")
                .build()
            val request = Request.Builder().url(upload.url).post(body).build()
            transferHttpClient(allowApprovedRedirects = true).newCall(request).execute().use { /* best effort; the link has expiry as backup */ }
        } catch (_: Exception) {
            // Temporary host deletion is best-effort; uploaded content is ciphertext and has an expiry request.
        }
    }

    private class ProgressRequestBody(
        private val delegate: RequestBody,
        private val progress: (written: Long, total: Long) -> Unit
    ) : RequestBody() {
        override fun contentType() = delegate.contentType()
        override fun contentLength(): Long = delegate.contentLength()
        override fun writeTo(sink: BufferedSink) {
            val total = contentLength()
            val sent = AtomicLong(0L)
            val last = AtomicLong(0L)
            val forwarding = object : ForwardingSink(sink) {
                override fun write(source: Buffer, byteCount: Long) {
                    super.write(source, byteCount)
                    val current = sent.addAndGet(byteCount)
                    val previous = last.get()
                    if (current - previous >= 1024 * 1024L || current >= total) {
                        last.set(current)
                        progress(current, total)
                    }
                }
            }
            val buffered = forwarding.buffer()
            delegate.writeTo(buffered)
            buffered.flush()
        }
    }

    private fun chunkAckKey(peer: String, transferId: String, index: Int): String =
        "${peer.lowercase()}_${transferId}_$index"

    private suspend fun sendChunkWithAck(recipientHex: String, chunk: JSONObject): String? {
        val transferId = chunk.optString("transferId")
        val index = chunk.optInt("index", -1)
        val key = chunkAckKey(recipientHex, transferId, index)
        repeat(CHUNK_SEND_ATTEMPTS) { attempt ->
            val acknowledgement = CompletableDeferred<Boolean>()
            pendingChunkAcks[key] = acknowledgement
            var accepted = false
            var route: String? = null
            try {
                route = dispatchWithRetry(recipientHex, JSONObject(chunk.toString()))
                if (route != null) {
                    accepted = withTimeoutOrNull(CHUNK_ACK_TIMEOUT_MS) { acknowledgement.await() } ?: false
                }
            } finally {
                pendingChunkAcks.remove(key, acknowledgement)
            }
            if (accepted && route != null) return route
            if (attempt + 1 < CHUNK_SEND_ATTEMPTS) delay(400L * (attempt + 1))
        }
        return null
    }

    private fun sendChunkAck(senderKey: String, transferId: String, msgId: String, index: Int) {
        scope.launch {
            dispatcher(senderKey, JSONObject().apply {
                put("type", "MEDIA_CHUNK_ACK")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("transferId", transferId)
                put("msgId", msgId)
                put("index", index)
                put("accepted", true)
                put("timestamp", System.currentTimeMillis())
            })
        }
    }

    private fun sha256File(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(64 * 1024).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                if (read > 0) digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private suspend fun dispatchWithRetry(recipientHex: String, json: JSONObject): String? {
        repeat(3) { attempt ->
            val route = dispatcher(recipientHex, JSONObject(json.toString()))
            if (route != null) return route
            if (attempt < 2) delay(350L * (attempt + 1))
        }
        return null
    }

    private fun incomingKey(senderPubKeyHex: String, transferId: String): String =
        "${senderPubKeyHex.lowercase()}_$transferId"

    private fun buildChatEnvelope(message: ChatMessage): JSONObject {
        val attachment = message.attachment
        return JSONObject().apply {
            put("type", "CHAT_MSG")
            put("msgId", message.id)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("recipientPubKey", message.recipientPubKeyHex)
            put("text", message.content)
            put("timestamp", message.timestampMs)
            message.replyToId?.let { put("replyToId", it) }
            message.replyToPreview?.let { put("replyToPreview", it) }
            message.replyToSender?.let { put("replyToSender", it) }
            if (attachment != null) {
                put("attachment", JSONObject().apply {
                    put("id", attachment.id)
                    put("kind", attachment.kind.name)
                    put("fileName", attachment.fileName)
                    put("mimeType", attachment.mimeType)
                    put("sizeBytes", attachment.sizeBytes)
                    put("durationMs", attachment.durationMs)
                    put("width", attachment.width)
                    put("height", attachment.height)
                    put("viewLimit", attachment.viewLimit)
                    attachment.sha256Hex?.let { put("sha256Hex", it) }
                })
            }
        }
    }

    // ------------------------------------------------------------------
    // Incoming
    // ------------------------------------------------------------------

    fun isIncomingApproved(senderPubKeyHex: String, transferId: String): Boolean =
        approvedIncoming.contains(incomingKey(senderPubKeyHex, transferId))

    /** Called when a CHAT_MSG carrying an attachment arrives. Returns true if accepted. */
    fun prepareIncoming(message: ChatMessage, totalChunks: Int = -1): Boolean {
        val attachment = message.attachment ?: return false
        if (attachment.mimeType.equals("image/gif", ignoreCase = true) || attachment.fileName.endsWith(".gif", ignoreCase = true)) {
            val reason = "GIF media is not supported by this FolkChat version"
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, progress = 0f, error = reason, localPath = null))
            }
            sendMediaReceipt(message.senderPubKeyHex, message.id, attachment.id, false, reason)
            onUpdated()
            return false
        }
        if (!isSafeTransferId(attachment.id) || attachment.sizeBytes < 0L || attachment.sizeBytes > MAX_INCOMING_BYTES) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = "Invalid or oversized attachment"))
            }
            onUpdated()
            return false
        }
        // Accepting metadata also authorizes exactly this sender + transfer. This set is
        // checked on every chunk so a stranger cannot stream files before consent.
        approvedIncoming.add(incomingKey(message.senderPubKeyHex, attachment.id))
        return true
    }

    fun handleIncomingChunk(json: JSONObject, linkName: String) {
        val transferId = json.optString("transferId")
        val msgId = json.optString("msgId")
        val senderKey = json.optString("senderPubKey").lowercase()
        val index = json.optInt("index", -1)
        val total = json.optInt("total", -1)
        val chunkSize = json.optInt("chunkSize", CHUNK_SIZE_SOCKET)
        val dataB64 = json.optString("data")
        if (!isSafeTransferId(transferId) || msgId.isBlank() || msgId.length > 128 ||
            !senderKey.matches(Regex("^[0-9a-f]{64}$")) || index < 0 || total !in 1..MAX_CHUNKS ||
            chunkSize !in 1..CHUNK_SIZE_SOCKET) return
        // Scope local temp files and reassembly sessions to the authenticated sender as
        // well as attachment id; one contact must not collide with another's transfer.
        val streamKey = "${senderKey}_$transferId"

        val message = vault.getMessageById(msgId) ?: return
        val attachment = message.attachment ?: return
        if (message.isOutgoing || !message.senderPubKeyHex.equals(senderKey, ignoreCase = true) || attachment.id != transferId) return
        if (vault.getContactByPubKey(senderKey) == null) return // unknown peers cannot stream files before request acceptance
        if (attachment.sizeBytes < 0L || attachment.sizeBytes > MAX_INCOMING_BYTES) return

        // No file is written until the receiver's automatic policy or an explicit
        // Download tap has authorized this sender/transfer pair.
        if (!approvedIncoming.contains(streamKey)) return

        if (attachment.sizeBytes > CHUNK_SIZE_SOCKET.toLong() * MAX_CHUNKS.toLong()) return
        val bytes = try { Base64.decode(dataB64, Base64.NO_WRAP) } catch (_: Exception) { return }
        if (bytes.size > chunkSize) return
        val expectedTotal = maxOf(1L, (attachment.sizeBytes + chunkSize - 1L) / chunkSize.toLong())
        if (expectedTotal != total.toLong() || index >= total) return
        val expectedChunkBytes = if (index < total - 1) chunkSize else (attachment.sizeBytes - index.toLong() * chunkSize).coerceAtLeast(0L).toInt()
        if (bytes.size != expectedChunkBytes) return

        scope.launch {
            mutex.withLock {
                cleanupStaleTransfersLocked()
                var entry = incomingStreams[streamKey]
                if (entry == null) {
                    if (incomingStreams.size >= MAX_ACTIVE_INCOMING) {
                        // Previously this dropped the chunk silently: the sender exhausted its
                        // retries and failed with a generic error while the receiver saw nothing.
                        // Surface a concrete reason so the user knows to retry after other
                        // downloads finish.
                        markFailed(msgId, transferId, "Too many simultaneous downloads — retry when other transfers finish")
                        return@withLock
                    }
                    val out = incomingFile(streamKey, attachment.fileName) ?: return@withLock
                    val opened = try {
                        RandomAccessFile(out, "rw").let { raf ->
                            raf.setLength(attachment.sizeBytes)
                            IncomingTransfer(out, raf, total, chunkSize, attachment.sizeBytes, msgId, senderKey)
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Cannot open incoming file safely: ${e.message}")
                        return@withLock
                    }
                    entry = opened
                    incomingStreams[streamKey] = opened
                }
                val idx = entry ?: return@withLock
                if (idx.messageId != msgId || !idx.senderPubKeyHex.equals(senderKey, ignoreCase = true)) return@withLock
                if (idx.totalChunks != total || idx.chunkSize != chunkSize || idx.claimedSize != attachment.sizeBytes) {
                    closeAndDeleteLocked(streamKey, idx)
                    markFailed(msgId, transferId, "Attachment metadata changed during transfer")
                    return@withLock
                }
                // A replayed chunk may be re-ACKed at transport level, but must never
                // overwrite already accepted bytes in a partially completed file.
                if (index in idx.receivedChunks) {
                    sendChunkAck(senderKey, transferId, msgId, index)
                    return@withLock
                }
                try {
                    idx.randomAccess.seek(index.toLong() * chunkSize.toLong())
                    idx.randomAccess.write(bytes)
                    idx.receivedChunks.add(index)
                    sendChunkAck(senderKey, transferId, msgId, index)
                    idx.lastUpdatedAtMs = System.currentTimeMillis()
                    val progress = (idx.receivedChunks.size.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                    // Vault persistence is a full encrypted snapshot; checkpoint at a bounded
                    // cadence instead of per chunk. The old fixed 32-chunk rule left typical
                    // socket transfers (48 KB chunks) jumping 0% -> 50% -> 100%. Persist either
                    // every 8 chunks or at a 4% progress delta, whichever comes first; the delta
                    // gate also throttles small BLE chunks (~280 bytes) appropriately.
                    val shouldCheckpoint = idx.receivedChunks.size % 8 == 0 ||
                        idx.receivedChunks.size >= total ||
                        progress - idx.persistedProgress >= 0.04f
                    if (shouldCheckpoint) {
                        idx.persistedProgress = progress
                        vault.updateMessage(msgId) {
                            it.copy(attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = progress))
                        }
                    }
                    if (idx.receivedChunks.size >= total) {
                        finalize(streamKey, transferId, msgId, idx)
                    } else if (idx.receivedChunks.size % 4 == 0) onUpdated()
                } catch (e: Exception) {
                    Log.e(TAG, "Chunk write failed: ${e.message}")
                    closeAndDeleteLocked(streamKey, idx)
                    markFailed(msgId, transferId, "Invalid or incomplete transfer")
                }
            }
        }
    }

    private fun isSafeTransferId(value: String): Boolean =
        value.length in 1..64 && value.matches(Regex("^[A-Za-z0-9_-]+$"))

    private fun incomingFile(transferId: String, fileName: String): File? = try {
        if (!mediaDir.exists()) mediaDir.mkdirs()
        val root = mediaDir.canonicalFile
        val target = File(root, "${transferId}_${sanitize(fileName)}").canonicalFile
        if (target.parentFile != root) null else target
    } catch (_: Exception) { null }

    private fun cleanupStaleTransfersLocked() {
        val cutoff = System.currentTimeMillis() - INCOMING_IDLE_TIMEOUT_MS
        val stale = incomingStreams.filterValues { it.lastUpdatedAtMs < cutoff }.keys.toList()
        stale.forEach { id -> incomingStreams[id]?.let { closeAndDeleteLocked(id, it) } }
    }

    private fun closeAndDeleteLocked(id: String, entry: IncomingTransfer) {
        try { entry.randomAccess.close() } catch (_: Exception) {}
        try { entry.file.delete() } catch (_: Exception) {}
        incomingStreams.remove(id)
    }

    private fun finalize(streamKey: String, transferId: String, msgId: String, entry: IncomingTransfer) {
        val message = vault.getMessageById(msgId)
        if (message == null || !message.senderPubKeyHex.equals(entry.senderPubKeyHex, ignoreCase = true) ||
            message.attachment?.id != transferId || entry.file.length() != entry.claimedSize ||
            entry.receivedChunks.size != entry.totalChunks) {
            closeAndDeleteLocked(streamKey, entry)
            message?.let { sendMediaReceipt(it.senderPubKeyHex, msgId, transferId, false, "Attachment size verification failed") }
            markFailed(msgId, transferId, "Attachment size verification failed")
            return
        }
        try { entry.randomAccess.fd.sync() } catch (_: Exception) {}
        val expectedDigest = message.attachment?.sha256Hex
        if (expectedDigest != null) {
            val actualDigest = try { sha256File(entry.file) } catch (_: Exception) { "" }
            if (!actualDigest.equals(expectedDigest, ignoreCase = true)) {
                closeAndDeleteLocked(streamKey, entry)
                sendMediaReceipt(message.senderPubKeyHex, msgId, transferId, false, "File integrity check failed (SHA-256 mismatch)")
                markFailed(msgId, transferId, "File integrity check failed (SHA-256 mismatch)")
                return
            }
        }
        try { entry.randomAccess.close() } catch (_: Exception) {}
        incomingStreams.remove(streamKey)
        approvedIncoming.remove(streamKey)
        val completedFile = try { placeCompletedFileInCurrentMediaDirectory(entry.file) } catch (_: Exception) { null }
        if (completedFile == null) {
            sendMediaReceipt(message.senderPubKeyHex, msgId, transferId, false, "Could not safely store the completed attachment")
            markFailed(msgId, transferId, "Could not safely store the completed attachment")
            return
        }
        vault.updateMessage(msgId) {
            it.copy(
                status = MessageStatus.DELIVERED,
                attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED,
                    progress = 1f,
                    localPath = completedFile.absolutePath,
                    error = null
                )
            )
        }
        // The sender is not shown as delivered until all bytes arrive and integrity checks pass.
        sendMediaReceipt(message.senderPubKeyHex, msgId, transferId, true, null)
        onUpdated()
    }

    /**
     * A user may enable durable saving while a receive stream is already open in cacheDir. Keep that
     * stream intact, then move its fully-verified result into the newly selected media directory.
     */
    private fun placeCompletedFileInCurrentMediaDirectory(sourceFile: File): File? {
        val source = sourceFile.canonicalFile
        val currentRoot = mediaDir.canonicalFile
        if (source.parentFile == currentRoot) return source
        if (!currentRoot.exists() && !currentRoot.mkdirs()) return null
        val destination = File(currentRoot, source.name).canonicalFile
        if (destination.parentFile != currentRoot) return null
        source.copyTo(destination, overwrite = true)
        if (destination.length() != source.length()) {
            destination.delete()
            return null
        }
        // The copy is now complete; keep the source only if the filesystem refuses deletion.
        try { source.delete() } catch (_: Exception) { }
        return destination
    }

    private fun sendMediaReceipt(senderPubKeyHex: String, msgId: String, transferId: String, accepted: Boolean, error: String?) {
        scope.launch {
            dispatcher(senderPubKeyHex, JSONObject().apply {
                put("type", "MEDIA_RECEIPT")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("msgId", msgId)
                put("transferId", transferId)
                put("accepted", accepted)
                error?.let { put("error", it.take(160)) }
                put("timestamp", System.currentTimeMillis())
            })
        }
    }

    private fun markFailed(messageId: String, transferId: String, reason: String) {
        clearProgressSnapshot(messageId, transferId)
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = reason)
            )
        }
        onUpdated()
    }

    private fun markCancelled(messageId: String) {
        vault.getMessageById(messageId)?.attachment?.id?.let { clearProgressSnapshot(messageId, it) }
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.CANCELLED, error = "Cancelled")
            )
        }
        onUpdated()
    }

    private fun isCancelled(transferId: String): Boolean = cancelled.contains(transferId)

    private fun sanitize(name: String): String {
        val base = name.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (cleaned.isBlank()) "file" else cleaned.take(64)
    }

    fun registerLocalCopy(attachment: MediaAttachment): MediaAttachment {
        return attachment.copy(transferState = TransferState.COMPLETED, progress = 1f)
    }

    private val MAX_INCOMING_BYTES = MAX_PUBLIC_FILE_BYTES // Public segmented manifests are bounded to 100 GiB.
}
