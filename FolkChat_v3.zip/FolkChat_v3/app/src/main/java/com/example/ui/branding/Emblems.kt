package com.example.ui.branding

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.LocalChatColors

/**
 * In-app emblem art styles. The emblem is the small brand mark shown in the
 * welcome screen and the conversation top bar; it is independent of the
 * launcher icon variant (see [AppIconVariant] for the home-screen icon).
 */
enum class AppEmblemStyle(val label: String, val description: String) {
    FOLK("Folk", "The classic forest badge with a sage leaf"),
    LEAF("Leaf", "A single calm leaf with a curved stem"),
    BUBBLE("Bubbles", "Two overlapping conversation bubbles"),
    SHIELD("Shield", "A protective shield with a keyhole"),
    WAVE("Signal", "Calm radiating signal arcs");

    companion object {
        fun fromName(name: String?): AppEmblemStyle =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: FOLK
    }
}

/** Resolves an emblem style to its drawable resource id with a safe fallback. */
fun emblemResId(style: AppEmblemStyle): Int = when (style) {
    AppEmblemStyle.FOLK -> R.drawable.app_logo
    AppEmblemStyle.LEAF -> R.drawable.emblem_leaf
    AppEmblemStyle.BUBBLE -> R.drawable.emblem_bubble
    AppEmblemStyle.SHIELD -> R.drawable.emblem_shield
    AppEmblemStyle.WAVE -> R.drawable.emblem_wave
}

/**
 * The brand emblem rendered in a rounded brand tile. Optional slow breathing
 * halo animation (disabled with reduceMotion) keeps the mark alive without
 * distracting from content. Pass [tileVisible] = false for a bare glyph.
 */
@Composable
fun FolkEmblem(
    style: AppEmblemStyle,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    breathing: Boolean = false,
    reduceMotion: Boolean = false,
    tileVisible: Boolean = true
) {
    val chatColors = LocalChatColors.current
    val painter: Painter = painterResource(emblemResId(style))

    val haloScale: Float
    val haloAlpha: Float
    if (breathing && !reduceMotion) {
        val transition = rememberInfiniteTransition(label = "emblemBreath")
        val scale by transition.animateFloat(
            initialValue = 0.94f,
            targetValue = 1.06f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 3600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "emblemHaloScale"
        )
        val alpha by transition.animateFloat(
            initialValue = 0.12f,
            targetValue = 0.32f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 3600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "emblemHaloAlpha"
        )
        haloScale = scale
        haloAlpha = alpha
    } else {
        haloScale = 1f
        haloAlpha = 0f
    }

    val shape = RoundedCornerShape(size * 0.30f)
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        if (haloAlpha > 0f) {
            Box(
                modifier = Modifier
                    .size(size)
                    .graphicsLayer {
                        scaleX = haloScale
                        scaleY = haloScale
                        alpha = haloAlpha
                    }
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(chatColors.primaryBrand, Color.Transparent)
                        )
                    )
            )
        }
        if (tileVisible) {
            Box(
                modifier = Modifier
                    .size(size)
                    .shadow(6.dp, shape, clip = false)
                    .clip(shape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                chatColors.cardElevated,
                                chatColors.cardElevated.copy(alpha = 0.82f)
                            )
                        )
                    )
                    .border(1.dp, chatColors.primaryBrand.copy(alpha = 0.30f), shape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painter,
                    contentDescription = "FolkChat emblem",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(size * 0.70f)
                )
            }
        } else {
            Image(
                painter = painter,
                contentDescription = "FolkChat emblem",
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(size)
            )
        }
    }
}

/**
 * Preview tile used by the Settings emblem picker: a compact, borderless
 * swatch that highlights when selected. Colors adapt to light/dark canvases.
 */
@Composable
fun EmblemSwatch(
    style: AppEmblemStyle,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onSelect: () -> Unit
) {
    val chatColors = LocalChatColors.current
    val isDark = isSystemInDarkTheme()
    val tileColor = if (isDark) Color(0xFF22302A) else Color(0xFFF1F4EE)
    androidx.compose.foundation.layout.Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(tileColor)
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) chatColors.primaryBrand else chatColors.borderSubtle,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onSelect() }
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Image(
            painter = painterResource(emblemResId(style)),
            contentDescription = style.label,
            modifier = Modifier.size(40.dp)
        )
    }
}
