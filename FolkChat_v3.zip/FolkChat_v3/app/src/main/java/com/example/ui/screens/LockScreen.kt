package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.R
import com.example.ui.security.AppLockManager
import com.example.ui.theme.CallStageBg
import com.example.ui.theme.CallStageBgDeep
import com.example.ui.theme.FolkErrorDark
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkWarmIvory

/**
 * Full-screen App Lock gate. Deep forest stage, 6-dot PIN indicator and a
 * native-feeling numeric keypad with haptics; auto biometric prompt on show.
 * Improvements over the original: staggered entrance animation, error shake,
 * and a live ticking countdown while the rate-limit lockout is active (the
 * stale "Retry in Ns" text used to freeze at the value captured on failure).
 */
@Composable
fun LockScreen(
    appLock: AppLockManager,
    activity: FragmentActivity,
    onUnlocked: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var verifying by remember { mutableStateOf(false) }
    var failureCount by remember { mutableIntStateOf(0) }
    var lockoutRemainingSec by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val reduceMotion = appLock.settings().reduceMotion

    val hasPin = remember { appLock.hasPin() }
    val canBiometric = remember { appLock.settings().biometricEnabled && appLock.canUseBiometric() }

    fun tryBiometric() {
        val launched = appLock.authenticateWithBiometric(activity, onSuccess = onUnlocked)
        if (!launched) {
            errorText = "Biometric unavailable — enter your PIN"
        }
    }

    LaunchedEffect(Unit) {
        if (canBiometric) tryBiometric()
    }

    // Live lockout countdown: re-reads the persisted deadline every second so
    // the text keeps ticking instead of freezing at the first captured value.
    LaunchedEffect(failureCount, verifying) {
        while (true) {
            lockoutRemainingSec = (appLock.pinLockoutRemainingMs() / 1000L).toInt()
            if (lockoutRemainingSec <= 0) break
            delay(1000)
        }
    }

    // Error shake: a short horizontal wobble keyed on the failure counter.
    val shakeX = remember { Animatable(0f) }
    LaunchedEffect(failureCount) {
        if (failureCount > 0 && !reduceMotion) {
            shakeX.snapTo(-13f)
            shakeX.animateTo(13f, tween(durationMillis = 70))
            shakeX.animateTo(-8f, tween(durationMillis = 70))
            shakeX.animateTo(0f, tween(durationMillis = 110))
        }
    }

    // Calm entrance: content fades and settles up into place.
    val entranceProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (reduceMotion) entranceProgress.snapTo(1f)
        else entranceProgress.animateTo(1f, tween(durationMillis = 480))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(CallStageBg, CallStageBgDeep))),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .padding(horizontal = 17.dp, vertical = 44.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(FolkSage.copy(alpha = 0.035f))
                .border(1.dp, FolkSage.copy(alpha = 0.09f), RoundedCornerShape(32.dp))
        )
        Box(
            modifier = Modifier
                .size(330.dp)
                .align(Alignment.TopCenter)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(FolkSage.copy(alpha = 0.10f), androidx.compose.ui.graphics.Color.Transparent)))
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    alpha = 0.35f + 0.65f * entranceProgress.value
                    translationY = (1f - entranceProgress.value) * 26f
                    translationX = shakeX.value
                }
                .padding(horizontal = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Emblem
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .shadow(6.dp, CircleShape, clip = false)
                    .clip(CircleShape)
                    .background(FolkSage.copy(alpha = 0.14f))
                    .border(1.dp, FolkSage.copy(alpha = 0.35f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.app_logo),
                    contentDescription = "FolkChat logo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(65.dp)
                )
            }
            Spacer(modifier = Modifier.height(22.dp))
            Text(
                "FolkChat is locked",
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = FolkWarmIvory
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                if (hasPin) "Enter your 6-digit PIN" else "Confirm your identity to continue",
                fontSize = 13.sp,
                color = FolkSage
            )

            Spacer(modifier = Modifier.height(30.dp))

            // 6-dot PIN indicator
            PinDots(count = 6, filled = pin.length, isError = errorText != null)

            errorText?.let {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    if (lockoutRemainingSec > 0)
                        "Too many attempts. Retry in ${lockoutRemainingSec}s."
                    else it,
                    color = FolkErrorDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            AnimatedVisibility(
                visible = verifying,
                enter = fadeIn(tween(durationMillis = 130)),
                exit = fadeOut(tween(durationMillis = 100))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(top = 12.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(17.dp),
                        color = FolkSage,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.size(9.dp))
                    Text(
                        "Checking PIN securely…",
                        fontSize = 12.sp,
                        color = FolkSage,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(34.dp))

            if (hasPin) {
                NumericKeypad(
                    onDigit = { digit ->
                        if (!verifying && pin.length < 6) {
                            val enteredPin = pin + digit
                            pin = enteredPin
                            errorText = null
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            if (enteredPin.length == 6) {
                                verifying = true
                                scope.launch {
                                    val accepted = withContext(Dispatchers.IO) { appLock.verifyPin(enteredPin) }
                                    verifying = false
                                    if (accepted) {
                                        onUnlocked()
                                    } else {
                                        failureCount += 1
                                        val remaining = appLock.pinLockoutRemainingMs()
                                        errorText = if (remaining > 0L) "Too many attempts. Retry in ${((remaining + 999L) / 1000L)}s." else "Incorrect PIN. Try again."
                                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        pin = ""
                                    }
                                }
                            }
                        }
                    },
                    onBackspace = {
                        if (!verifying && pin.isNotEmpty()) pin = pin.dropLast(1)
                        errorText = null
                    },
                    showBiometric = canBiometric,
                    onBiometric = { tryBiometric() }
                )
            } else {
                // No PIN configured: only the biometric path remains.
                if (canBiometric) {
                    androidx.compose.material3.Button(
                        onClick = { tryBiometric() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = FolkSage,
                            contentColor = CallStageBgDeep
                        ),
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.padding(4.dp))
                        Text("Unlock with biometrics", fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Text(
                        "No unlock method available.\nDisable App Lock from Settings after signing in.",
                        fontSize = 12.sp,
                        color = FolkSage,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

/** Row of six PIN dots; filled dots reveal entry progress. */
@Composable
fun PinDots(count: Int = 6, filled: Int, isError: Boolean = false) {
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        repeat(count) { i ->
            val active = i < filled
            val targetColor = when {
                isError -> FolkErrorDark
                active -> FolkWarmIvory
                else -> FolkSage.copy(alpha = 0.35f)
            }
            val color by animateColorAsState(
                targetValue = targetColor,
                animationSpec = tween(durationMillis = 170),
                label = "pinDotColor"
            )
            val dotScale by animateFloatAsState(
                targetValue = if (active && !isError) 1.16f else 1f,
                animationSpec = tween(durationMillis = 150),
                label = "pinDotScale"
            )
            Box(
                modifier = Modifier
                    .size(13.dp)
                    .scale(dotScale)
                    .clip(CircleShape)
                    .background(color)
                    .border(1.dp, FolkSage.copy(alpha = if (active) 0.20f else 0.10f), CircleShape)
            )
        }
    }
}

/**
 * Native-feeling numeric keypad, themed for the deep lock stage.
 * Bottom row: blank, 0, backspace (or biometric when available).
 */
@Composable
fun NumericKeypad(
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    showBiometric: Boolean = false,
    onBiometric: () -> Unit = {}
) {
    val haptics = LocalHapticFeedback.current
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9")
        ).forEach { rowKeys ->
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                rowKeys.forEach { key ->
                    KeypadKey(key = key) {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDigit(key)
                    }
                }
            }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(72.dp))
            KeypadKey(key = "0") {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onDigit("0")
            }
            Box(modifier = Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                if (showBiometric) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(FolkSage.copy(alpha = 0.16f))
                            .clickable { onBiometric() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Fingerprint,
                            contentDescription = "Unlock with biometrics",
                            tint = FolkSage,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                } else {
                    Icon(
                        Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Backspace",
                        tint = FolkSage,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .clickable {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onBackspace()
                            }
                            .padding(14.dp)
                    )
                }
            }
        }
        // When biometrics replaced the backspace slot, keep backspace accessible.
        if (showBiometric) {
            Icon(
                Icons.AutoMirrored.Filled.Backspace,
                contentDescription = "Backspace",
                tint = FolkSage.copy(alpha = 0.7f),
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onBackspace()
                    }
                    .padding(8.dp)
            )
        }
    }
}

@Composable
private fun KeypadKey(key: String, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "keypadPressScale"
    )
    val surfaceAlpha by animateFloatAsState(
        targetValue = if (pressed) 0.24f else 0.14f,
        animationSpec = tween(durationMillis = 110),
        label = "keypadSurfaceAlpha"
    )
    Box(
        modifier = Modifier
            .size(72.dp)
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .shadow(3.dp, CircleShape, clip = false)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(FolkSage.copy(alpha = surfaceAlpha), FolkSage.copy(alpha = 0.07f))))
            .border(1.dp, FolkSage.copy(alpha = if (pressed) 0.28f else 0.13f), CircleShape)
            .clickable(interactionSource = interactionSource, indication = LocalIndication.current) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            key,
            fontSize = 26.sp,
            fontWeight = FontWeight.Medium,
            color = FolkWarmIvory
        )
    }
}
