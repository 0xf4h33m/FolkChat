package com.example.net.online

import android.util.Base64
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.EncryptedVault
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Proxy
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * No-configuration public WAN fallback with independently operated relay redundancy.
 *
 * The app seals the actual message to the recipient before this class receives it. The official
 * ntfy.sh route retains the original wire format for compatibility. Each community relay receives
 * a second, independently randomized AES-GCM wrapper and a host-specific pairwise topic. Only a
 * participating endpoint holding its private identity key can derive the secret needed to remove
 * a community-relay wrapper; the relay cannot, and the inner message still has to pass the app's
 * recipient-bound encryption/authentication checks.
 *
 * This is independent relay redundancy, not chained onion routing or perfect anonymity: each public provider can see the connecting IP,
 * timing, ciphertext size and activity on its own high-entropy topic. Providers can delay, replay,
 * censor, retain or drop data. For reducing the network observer's view of the sender IP, Tor mode
 * can route connections through Orbot if it is installed and running.
 *
 * Small packets only are sent here. Attachment bytes use MediaTransferManager's separate
 * client-side encrypted temporary-blob flow, with provider failover.
 */
class PublicTopicTransport(private val vault: EncryptedVault) {
    private data class PublicRelay(
        val host: String,
        val baseUrl: String,
        val legacyWireFormat: Boolean = false
    )

    private data class RelayPeer(val topic: String, val peerPubKeyHex: String)

    companion object {
        private const val TAG = "PublicTopicTransport"
        // ntfy.sh is the official service. Other entries are public community-operated instances
        // listed by the ntfy project; no uptime, retention or privacy guarantee is implied.
        private val RELAYS = listOf(
            PublicRelay("ntfy.sh", "https://ntfy.sh/", legacyWireFormat = true),
            PublicRelay("ntfy.envs.net", "https://ntfy.envs.net/"),
            PublicRelay("ntfy.adminforge.de", "https://ntfy.adminforge.de/")
        )
        private const val MAX_BASE64_PACKET_CHARS = 3500
        private const val CONTACT_SYNC_MS = 15_000L
        private const val RECONNECT_DELAY_MS = 2_000L
        private const val MAX_TOPICS_PER_SUBSCRIPTION = 20
        private const val MAX_SEEN_EVENTS = 4_000
        private const val MAX_SEEN_PACKETS = 4_000
        private const val MAX_LOCAL_ECHOES = 1_000
        private val TEXT_TYPE = "text/plain; charset=utf-8".toMediaType()
    }

    private val incoming = MutableSharedFlow<ByteArray>(extraBufferCapacity = 256)
    val incomingPayloads: SharedFlow<ByteArray> = incoming.asSharedFlow()

    @Volatile private var running = false
    @Volatile private var rootJob: Job? = null
    @Volatile private var scope: CoroutineScope? = null
    @Volatile private var client: OkHttpClient? = null
    @Volatile private var publisherClient: OkHttpClient? = null
    @Volatile private var clientTorMode: Boolean? = null

    private val subscriptionJobs = ConcurrentHashMap<String, Job>()
    private val activeCalls = ConcurrentHashMap<String, okhttp3.Call>()
    private val seenEvents = ConcurrentHashMap<String, Long>()
    private val seenPackets = ConcurrentHashMap<String, Long>()
    private val localEchoes = ConcurrentHashMap<String, Long>()
    private val relayBlockedUntilMs = ConcurrentHashMap<String, Long>()
    private val pairingSubscriptionJobs = ConcurrentHashMap<String, Job>()
    @Volatile private var activePairingTokenHex: String? = null

    @Synchronized
    fun start() {
        if (running) {
            syncContacts()
            return
        }
        running = true
        val job = SupervisorJob()
        rootJob = job
        val newScope = CoroutineScope(job + Dispatchers.IO)
        scope = newScope
        newScope.launch {
            while (isActive && running) {
                syncContacts()
                pruneCaches()
                delay(CONTACT_SYNC_MS)
            }
        }
        activePairingTokenHex?.let(::ensurePairingSubscriptions)
        Log.i(TAG, "Public WAN relay pool enabled (${RELAYS.size} relay services configured)")
    }

    @Synchronized
    fun stop() {
        running = false
        rootJob?.cancel()
        rootJob = null
        scope = null
        subscriptionJobs.values.forEach { it.cancel() }
        subscriptionJobs.clear()
        pairingSubscriptionJobs.values.forEach { it.cancel() }
        pairingSubscriptionJobs.clear()
        activeCalls.values.forEach { it.cancel() }
        activeCalls.clear()
        seenEvents.clear()
        seenPackets.clear()
        localEchoes.clear()
        relayBlockedUntilMs.clear()
    }

    /**
     * Subscribe to a short-lived QR-scoped inbox. The QR token is random and expires quickly, so
     * the receiver can accept a first contact without subscribing to a global public inbox.
     * Only a ciphertext addressed to this device's X25519 identity is published on this topic.
     */
    @Synchronized
    fun activatePairingInbox(tokenHex: String) {
        val token = tokenHex.lowercase().trim()
        if (!token.matches(Regex("^[0-9a-f]{64}$"))) return
        if (activePairingTokenHex == token && pairingSubscriptionJobs.isNotEmpty()) return
        pairingSubscriptionJobs.values.forEach { it.cancel() }
        pairingSubscriptionJobs.clear()
        activePairingTokenHex = token
        ensurePairingSubscriptions(token)
    }

    @Synchronized
    fun clearPairingInbox(tokenHex: String? = null) {
        if (tokenHex != null && activePairingTokenHex != tokenHex.lowercase().trim()) return
        activePairingTokenHex = null
        pairingSubscriptionJobs.entries.toList().forEach { (key, job) ->
            job.cancel()
            pairingSubscriptionJobs.remove(key)
            activeCalls.remove(key)?.cancel()
        }
    }

    @Synchronized
    private fun ensurePairingSubscriptions(tokenHex: String) {
        if (!running || activePairingTokenHex != tokenHex) return
        val targetScope = scope ?: return
        RELAYS.forEach { relay ->
            val key = "pairing|${relay.host}|${tokenHex.take(16)}"
            pairingSubscriptionJobs.computeIfAbsent(key) {
                targetScope.launch { subscribePairingForever(key, relay, tokenHex) }
            }
        }
    }

    /** Publishes first-contact packets to a token-scoped inbox that only the QR holder subscribes to. */
    suspend fun sendPairingEnvelope(tokenHex: String, sealedPacket: ByteArray): Boolean = withContext(Dispatchers.IO) {
        val token = tokenHex.lowercase().trim()
        if (!running || !token.matches(Regex("^[0-9a-f]{64}$")) || sealedPacket.isEmpty()) return@withContext false
        val digest = sha256Hex(sealedPacket)
        localEchoes[digest] = System.currentTimeMillis()
        val senderScope = scope ?: return@withContext false
        val result = CompletableDeferred<Boolean>()
        val remaining = AtomicInteger(RELAYS.size)
        RELAYS.forEach { relay ->
            val packetCopy = sealedPacket.copyOf()
            senderScope.launch {
                val sent = try { publishPairingToRelay(relay, token, packetCopy) }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) {
                    Log.d(TAG, "Pairing relay ${relay.host} publish exception: ${e.javaClass.simpleName}")
                    false
                } finally { packetCopy.fill(0) }
                if (sent) result.complete(true)
                else if (remaining.decrementAndGet() == 0) result.complete(false)
            }
        }
        withTimeoutOrNull(6_500L) { result.await() } ?: false
    }

    private fun publishPairingToRelay(relay: PublicRelay, tokenHex: String, packet: ByteArray): Boolean {
        if (System.currentTimeMillis() < (relayBlockedUntilMs[relay.host] ?: 0L)) return false
        val topic = pairingTopic(tokenHex, relay) ?: return false
        val wrapped = wrapForPairingRelay(tokenHex, relay, packet) ?: return false
        val body = Base64.encodeToString(wrapped, Base64.NO_WRAP)
        wrapped.fill(0)
        if (body.length > MAX_BASE64_PACKET_CHARS) return false
        val request = Request.Builder()
            .url(relay.baseUrl + topic)
            .header("Firebase", "no")
            .post(body.toRequestBody(TEXT_TYPE))
            .build()
        return try {
            publishHttpClient().newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    if (response.code == 429 || response.code == 503) {
                        val retryAfter = response.header("Retry-After")?.toLongOrNull()?.coerceIn(5L, 300L) ?: 60L
                        relayBlockedUntilMs[relay.host] = System.currentTimeMillis() + retryAfter * 1000L
                    }
                    false
                } else true
            }
        } catch (e: Exception) {
            Log.d(TAG, "Pairing relay ${relay.host} unavailable: ${e.javaClass.simpleName}")
            false
        }
    }

    private suspend fun subscribePairingForever(key: String, relay: PublicRelay, tokenHex: String) {
        var backoff = RECONNECT_DELAY_MS
        val topic = pairingTopic(tokenHex, relay) ?: return
        while (running && activePairingTokenHex == tokenHex && kotlinx.coroutines.currentCoroutineContext().isActive) {
            var call: okhttp3.Call? = null
            try {
                val request = Request.Builder().url("${relay.baseUrl}${topic}/json?since=all")
                    .header("Firebase", "no").get().build()
                call = httpClient().newCall(request)
                activeCalls[key] = call
                call.execute().use { response ->
                    if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
                    backoff = RECONNECT_DELAY_MS
                    val body = response.body ?: throw java.io.IOException("Empty pairing stream")
                    val source = body.source()
                    while (running && activePairingTokenHex == tokenHex && kotlinx.coroutines.currentCoroutineContext().isActive) {
                        val line = source.readUtf8Line() ?: break
                        if (line.isBlank()) continue
                        processPairingEvent(relay, tokenHex, topic, line)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (running && activePairingTokenHex == tokenHex) Log.d(TAG, "Pairing stream ${relay.host} reconnect: ${e.javaClass.simpleName}")
            } finally {
                if (activeCalls[key] === call) activeCalls.remove(key)
            }
            if (running && activePairingTokenHex == tokenHex && kotlinx.coroutines.currentCoroutineContext().isActive) {
                delay(backoff)
                backoff = (backoff * 2L).coerceAtMost(30_000L)
            }
        }
    }

    private suspend fun processPairingEvent(relay: PublicRelay, tokenHex: String, topic: String, line: String) {
        val event = try { JSONObject(line) } catch (_: Exception) { return }
        if (event.optString("event") != "message" || event.optString("topic") != topic || event.has("attachment")) return
        val messageId = event.optString("id")
        val eventKey = "pairing:${relay.host}:$topic:" + if (messageId.isNotBlank()) messageId
            else "${event.optLong("time", 0L)}:${event.optString("message").hashCode()}"
        if (seenEvents.putIfAbsent(eventKey, System.currentTimeMillis()) != null) return
        val encoded = event.optString("message")
        if (encoded.isBlank() || encoded.length > MAX_BASE64_PACKET_CHARS) return
        val wrapped = try { Base64.decode(encoded, Base64.NO_WRAP) } catch (_: Exception) { return }
        val packet = unwrapForPairingRelay(tokenHex, relay, wrapped) ?: return
        wrapped.fill(0)
        val digest = sha256Hex(packet)
        if (localEchoes.containsKey(digest) || seenPackets.putIfAbsent(digest, System.currentTimeMillis()) != null) {
            packet.fill(0)
            return
        }
        incoming.emit(packet)
    }

    private fun pairingTopic(tokenHex: String, relay: PublicRelay): String? {
        return try {
            if (!tokenHex.matches(Regex("^[0-9a-f]{64}$"))) return null
            val material = CryptoEngine.hkdfSha256(
                CryptoEngine.hexToBytes(tokenHex),
                salt = "FolkChat-Pairing-Topic-v1".toByteArray(Charsets.UTF_8),
                info = relay.host.toByteArray(Charsets.UTF_8),
                length = 24
            )
            try { "fp" + CryptoEngine.bytesToHex(material) } finally { material.fill(0) }
        } catch (_: Exception) { null }
    }

    private fun wrapForPairingRelay(tokenHex: String, relay: PublicRelay, packet: ByteArray): ByteArray? = try {
        val key = CryptoEngine.hkdfSha256(
            CryptoEngine.hexToBytes(tokenHex),
            salt = "FolkChat-Pairing-Relay-Wrapper-v1".toByteArray(Charsets.UTF_8),
            info = relay.host.toByteArray(Charsets.UTF_8),
            length = 32
        )
        try { RelayPacketCipher.seal(key, relay.host, packet) } finally { key.fill(0) }
    } catch (_: Exception) { null }

    private fun unwrapForPairingRelay(tokenHex: String, relay: PublicRelay, wrapped: ByteArray): ByteArray? = try {
        val key = CryptoEngine.hkdfSha256(
            CryptoEngine.hexToBytes(tokenHex),
            salt = "FolkChat-Pairing-Relay-Wrapper-v1".toByteArray(Charsets.UTF_8),
            info = relay.host.toByteArray(Charsets.UTF_8),
            length = 32
        )
        try { RelayPacketCipher.open(key, relay.host, wrapped) } finally { key.fill(0) }
    } catch (_: Exception) { null }

    /** Publishes independently wrapped copies to multiple public relays; success means >=1 accepted. */
    suspend fun sendEnvelope(recipientPubKeyHex: String, sealedPacket: ByteArray): Boolean = withContext(Dispatchers.IO) {
        if (!running || sealedPacket.isEmpty()) return@withContext false
        val peerKey = recipientPubKeyHex.lowercase()
        if (!peerKey.matches(Regex("^[0-9a-f]{64}$"))) return@withContext false

        val digest = sha256Hex(sealedPacket)
        localEchoes[digest] = System.currentTimeMillis()
        // Publish concurrently and return as soon as one relay accepts the packet. The old
        // awaitAll() path waited for the slowest community server on every message/call signal,
        // adding seconds of latency even when the official relay had already accepted it. The
        // remaining copies continue in the service scope to retain best-effort redundancy.
        val senderScope = scope ?: return@withContext false
        val result = CompletableDeferred<Boolean>()
        val remaining = AtomicInteger(RELAYS.size)
        RELAYS.forEach { relay ->
            val packetCopy = sealedPacket.copyOf()
            senderScope.launch {
                val sent = try {
                    publishToRelay(relay, peerKey, packetCopy)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.d(TAG, "Relay ${relay.host} publish exception: ${e.javaClass.simpleName}")
                    false
                } finally {
                    packetCopy.fill(0)
                }
                if (sent) result.complete(true)
                else if (remaining.decrementAndGet() == 0) result.complete(false)
            }
        }
        // Keep local-echo suppression for its normal cache lifetime even if the fast path times
        // out: a slower background relay may still accept the copy and echo it back later.
        withTimeoutOrNull(6_500L) { result.await() } ?: false
    }

    private fun publishToRelay(relay: PublicRelay, peerKey: String, sealedPacket: ByteArray): Boolean {
        if (System.currentTimeMillis() < (relayBlockedUntilMs[relay.host] ?: 0L)) return false
        val topic = pairTopic(peerKey, relay) ?: return false
        val outbound = if (relay.legacyWireFormat) sealedPacket else wrapForRelay(peerKey, relay, sealedPacket) ?: return false
        val body = Base64.encodeToString(outbound, Base64.NO_WRAP)
        if (body.length > MAX_BASE64_PACKET_CHARS) return false
        val request = Request.Builder()
            .url(relay.baseUrl + topic)
            .header("Firebase", "no")
            .post(body.toRequestBody(TEXT_TYPE))
            .build()
        return try {
            publishHttpClient().newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    if (response.code == 429 || response.code == 503) {
                        val retryAfterSeconds = response.header("Retry-After")?.toLongOrNull()
                            ?.coerceIn(5L, 300L) ?: 60L
                        relayBlockedUntilMs[relay.host] = System.currentTimeMillis() + retryAfterSeconds * 1000L
                    }
                    Log.d(TAG, "Public relay ${relay.host} rejected publish: HTTP ${response.code}")
                    false
                } else true
            }
        } catch (e: Exception) {
            Log.d(TAG, "Public relay ${relay.host} unavailable: ${e.javaClass.simpleName}")
            false
        }
    }

    /** Immediately reconcile pairwise subscriptions after a QR request has been authenticated. */
    @Synchronized
    fun refreshPeerSubscriptions() {
        syncContacts()
    }

    /**
     * A first-contact deadlock existed when only the QR owner scanned: the owner subscribed only
     * to accepted contacts, but couldn't receive the message needed to populate Message Requests.
     * Listen to recently QR-authenticated peers and already-pending requests too. This is not
     * contact acceptance; all packets still pass recipient-bound encryption, authentication and
     * block-list checks before reaching the request inbox.
     */
    @Synchronized
    private fun syncContacts() {
        if (!running) return
        val identity = try { vault.getIdentityKeyPair() } catch (_: Exception) { return }
        val ownKey = identity.publicKeyHex.lowercase()
        val desiredPeerSet = linkedSetOf<String>()
        vault.getContacts().filterNot { it.isGroup }.forEach { desiredPeerSet += it.x25519PublicKeyHex.lowercase() }
        vault.getPairingVerifiedPeerPubKeys().forEach { desiredPeerSet += it.lowercase() }
        vault.getMessageRequests().forEach { desiredPeerSet += it.senderPubKeyHex.lowercase() }
        val desiredPeers = desiredPeerSet
            .filter { it != ownKey && it.matches(Regex("^[0-9a-f]{64}$")) }
            .sorted()

        val desiredBatches = linkedMapOf<String, Pair<PublicRelay, List<RelayPeer>>>()
        RELAYS.forEach { relay ->
            val relayPeers = desiredPeers.mapNotNull { peer ->
                pairTopic(peer, relay)?.let { RelayPeer(it, peer) }
            }
            relayPeers.chunked(MAX_TOPICS_PER_SUBSCRIPTION).forEach { batch ->
                if (batch.isNotEmpty()) {
                    val key = "${relay.host}|${batch.joinToString(",") { it.topic }}"
                    desiredBatches[key] = relay to batch
                }
            }
        }

        subscriptionJobs.keys.toList().filter { it !in desiredBatches }.forEach { key ->
            subscriptionJobs.remove(key)?.cancel()
            activeCalls.remove(key)?.cancel()
        }
        val targetScope = scope ?: return
        desiredBatches.forEach { (key, relayAndPeers) ->
            subscriptionJobs.computeIfAbsent(key) {
                targetScope.launch { subscribeForever(key, relayAndPeers.first, relayAndPeers.second) }
            }
        }
    }

    private suspend fun subscribeForever(batchKey: String, relay: PublicRelay, peers: List<RelayPeer>) {
        var backoff = RECONNECT_DELAY_MS
        val topicToPeer = peers.associateBy { it.topic }
        val topics = topicToPeer.keys.toList()
        if (topics.isEmpty()) return
        val topicPath = topics.joinToString(",")
        while (running && kotlinx.coroutines.currentCoroutineContext().isActive) {
            var call: okhttp3.Call? = null
            try {
                val request = Request.Builder()
                    .url("${relay.baseUrl}${topicPath}/json?since=all")
                    .header("Firebase", "no")
                    .get()
                    .build()
                call = httpClient().newCall(request)
                activeCalls[batchKey] = call
                call.execute().use { response ->
                    if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
                    backoff = RECONNECT_DELAY_MS
                    val body = response.body ?: throw java.io.IOException("Empty public stream")
                    val source = body.source()
                    while (running && kotlinx.coroutines.currentCoroutineContext().isActive) {
                        val line = source.readUtf8Line() ?: break
                        if (line.isBlank()) continue
                        val eventTopic = try { JSONObject(line).optString("topic") } catch (_: Exception) { "" }
                        val peer = topicToPeer[eventTopic] ?: continue
                        processEvent(relay, peer.peerPubKeyHex, eventTopic, line)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (running) Log.d(TAG, "Relay reconnect ${relay.host}: ${e.javaClass.simpleName}")
            } finally {
                if (activeCalls[batchKey] === call) activeCalls.remove(batchKey)
            }
            if (running && kotlinx.coroutines.currentCoroutineContext().isActive) {
                delay(backoff)
                backoff = (backoff * 2L).coerceAtMost(30_000L)
            }
        }
    }

    private suspend fun processEvent(relay: PublicRelay, peerPubKeyHex: String, topic: String, line: String) {
        val event = try { JSONObject(line) } catch (_: Exception) { return }
        if (event.optString("event") != "message" || event.optString("topic") != topic) return
        val messageId = event.optString("id")
        val eventKey = "${relay.host}:$topic:" + if (messageId.isNotBlank()) messageId
            else "${event.optLong("time", 0L)}:${event.optString("message").hashCode()}"
        if (seenEvents.putIfAbsent(eventKey, System.currentTimeMillis()) != null) return
        if (event.has("attachment")) return
        val encoded = event.optString("message")
        if (encoded.isBlank() || encoded.length > MAX_BASE64_PACKET_CHARS) return
        val receivedBytes = try { Base64.decode(encoded, Base64.NO_WRAP) } catch (_: Exception) { return }
        if (receivedBytes.isEmpty()) return

        val packet = if (relay.legacyWireFormat) receivedBytes
            else unwrapFromRelay(peerPubKeyHex, relay, receivedBytes) ?: return
        val digest = sha256Hex(packet)
        // The same packet is deliberately delivered through several relays. Drop local echoes and
        // deduplicate the exact original packet before it reaches the application's state machine.
        if (localEchoes.containsKey(digest)) return
        if (seenPackets.putIfAbsent(digest, System.currentTimeMillis()) != null) return
        incoming.emit(packet)
    }

    /** The official route keeps the old topic derivation for existing installs; other hosts are scoped. */
    private fun pairTopic(peerPubKeyHex: String, relay: PublicRelay): String? {
        return try {
            val peerKey = peerPubKeyHex.lowercase()
            if (!peerKey.matches(Regex("^[0-9a-f]{64}$"))) return null
            val identity = vault.getIdentityKeyPair()
            if (peerKey == identity.publicKeyHex.lowercase()) return null
            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, CryptoEngine.hexToBytes(peerKey))
            try {
                require(shared.any { it != 0.toByte() })
                val info = if (relay.legacyWireFormat) "pairwise-packet-bus"
                    else "pairwise-packet-bus-v1|${relay.host}"
                val topicMaterial = CryptoEngine.hkdfSha256(
                    shared,
                    salt = "FolkChat-Public-Topic-v1".toByteArray(Charsets.UTF_8),
                    info = info.toByteArray(Charsets.UTF_8),
                    length = 24
                )
                try { "fc" + CryptoEngine.bytesToHex(topicMaterial).lowercase() }
                finally { topicMaterial.fill(0) }
            } finally { shared.fill(0) }
        } catch (_: Exception) {
            null
        }
    }

    /** Secondary relays receive a per-host randomized envelope, preventing identical-body matching. */
    private fun wrapForRelay(peerPubKeyHex: String, relay: PublicRelay, packet: ByteArray): ByteArray? {
        return try {
            val key = relayWrapperKey(peerPubKeyHex, relay) ?: return null
            try {
                RelayPacketCipher.seal(key, relay.host, packet)
            } finally {
                key.fill(0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not wrap packet for relay ${relay.host}: ${e.javaClass.simpleName}")
            null
        }
    }

    private fun unwrapFromRelay(peerPubKeyHex: String, relay: PublicRelay, wrapped: ByteArray): ByteArray? {
        return try {
            val key = relayWrapperKey(peerPubKeyHex, relay) ?: return null
            try {
                RelayPacketCipher.open(key, relay.host, wrapped) // GCM tag verifies before inner packet is returned
            } finally {
                key.fill(0)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun relayWrapperKey(peerPubKeyHex: String, relay: PublicRelay): ByteArray? {
        return try {
            val peerBytes = CryptoEngine.hexToBytes(peerPubKeyHex)
            if (peerBytes.size != 32) return null
            val identity = vault.getIdentityKeyPair()
            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, peerBytes)
            try {
                require(shared.any { it != 0.toByte() })
                CryptoEngine.hkdfSha256(
                    shared,
                    salt = "FolkChat-Relay-Wrapper-v1".toByteArray(Charsets.UTF_8),
                    info = "AES-256-GCM|${relay.host}".toByteArray(Charsets.UTF_8),
                    length = 32
                )
            } finally {
                shared.fill(0)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun httpClient(): OkHttpClient {
        val tor = try { vault.getSettings().torRoutingEnabled } catch (_: Exception) { false }
        val existing = client
        if (existing != null && clientTorMode == tor) return existing
        synchronized(this) {
            val again = client
            if (again != null && clientTorMode == tor) return again
            val builder = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .writeTimeout(8, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
            if (tor) {
                builder.proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress.createUnresolved("127.0.0.1", 9050)))
            } else {
                builder.proxy(Proxy.NO_PROXY)
            }
            val streamingClient = builder.build()
            // Subscriptions are long-lived streams and need no read timeout. Publishing should
            // not inherit that unlimited timeout, or a stuck relay can occupy a worker forever.
            val boundedPublisher = streamingClient.newBuilder()
                .readTimeout(4, TimeUnit.SECONDS)
                .callTimeout(6, TimeUnit.SECONDS)
                .build()
            client = streamingClient
            publisherClient = boundedPublisher
            clientTorMode = tor
            return streamingClient
        }
    }

    private fun publishHttpClient(): OkHttpClient {
        httpClient() // refresh the paired client if the routing/Tor policy changed
        return publisherClient ?: httpClient()
    }

    private fun pruneCaches() {
        val now = System.currentTimeMillis()
        val cutoff = now - 6 * 60 * 60 * 1000L
        seenEvents.entries.removeIf { it.value < cutoff }
        seenPackets.entries.removeIf { it.value < cutoff }
        localEchoes.entries.removeIf { it.value < now - 60_000L }
        relayBlockedUntilMs.entries.removeIf { it.value <= now }
        if (seenEvents.size > MAX_SEEN_EVENTS) {
            seenEvents.entries.sortedBy { it.value }.take(seenEvents.size - MAX_SEEN_EVENTS).forEach { seenEvents.remove(it.key) }
        }
        if (seenPackets.size > MAX_SEEN_PACKETS) {
            seenPackets.entries.sortedBy { it.value }.take(seenPackets.size - MAX_SEEN_PACKETS).forEach { seenPackets.remove(it.key) }
        }
        if (localEchoes.size > MAX_LOCAL_ECHOES) {
            localEchoes.entries.sortedBy { it.value }.take(localEchoes.size - MAX_LOCAL_ECHOES).forEach { localEchoes.remove(it.key) }
        }
    }

    private fun sha256Hex(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
