package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.BubbleChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.EmojiNature
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DisappearTimer
import com.example.data.MediaAutoDownload
import com.example.data.NotificationPreviewMode
import com.example.data.RoutingPolicy
import com.example.ui.ChatViewModel
import com.example.ui.components.ChangePinDialog
import com.example.ui.components.FolkIconTile
import com.example.ui.components.PeerAvatar
import com.example.ui.components.PinSetupDialog
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.AppFontChoice
import com.example.ui.theme.BubbleStyle
import com.example.ui.theme.ChatFontScale
import com.example.ui.theme.ChatWallpaper
import com.example.ui.theme.LocalChatColors
import com.example.ui.theme.LocalChatCustomization
import com.example.ui.branding.AppEmblemStyle
import com.example.ui.branding.AppIconVariant
import com.example.ui.branding.EmblemSwatch
import com.example.R

/**
 * Settings hub: Security Center, Privacy, Notifications, Media, Network
 * (relay + Tor), Appearance and Data. All state flows from the ViewModel.
 */
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onOpenDiagnostics: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val routingPolicy by viewModel.routingPolicy.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val networkTypeName by viewModel.networkTypeName.collectAsState()
    val relayConnected by viewModel.onlineRelay.isConnected.collectAsState()
    val relayError by viewModel.onlineRelay.lastError.collectAsState()
    val effectiveRelayUrl = viewModel.onlineRelay.configuredRelayUrl
    val themeMode by viewModel.themeMode.collectAsState()
    val blockedPeers by viewModel.blockedPeers.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val torProbe by viewModel.torProbeResult.collectAsState()
    val deviceStorageEnabled by viewModel.deviceStorageEnabled.collectAsState()
    val chatColors = LocalChatColors.current
    var selectedSection by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = selectedSection != null) { selectedSection = null }

    var showPinSetup by remember { mutableStateOf(false) }
    var showChangePin by remember { mutableStateOf(false) }
    var showBlocked by remember { mutableStateOf(false) }
    var showChatLockManager by remember { mutableStateOf(false) }
    var openChatLockManagerAfterPin by remember { mutableStateOf(false) }
    var showRelayEditor by remember { mutableStateOf(false) }
    var showCallNetworkEditor by remember { mutableStateOf(false) }
    var lockNotice by remember { mutableStateOf<String?>(null) }
    var showStorageConsent by remember { mutableStateOf(false) }

    val appLock = viewModel.appLock
    val hasPin = appLock.hasPin()
    val canBiometric = appLock.canUseBiometric()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        chatColors.searchField.copy(alpha = 0.20f),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 2.dp)
        ) {
            Text(
                selectedSection ?: "Settings",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.4).sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                if (selectedSection == null) "Privacy, connection, appearance and device controls"
                else "Configure ${selectedSection!!.lowercase()} settings",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        AnimatedVisibility(
            visible = selectedSection == null,
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Choose a section",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 3.dp, bottom = 2.dp)
                )
                SettingsCategoryRow(Icons.Default.Lock, "Security center", "App lock, PIN, biometrics and protected chats") { selectedSection = "Security center" }
                SettingsCategoryRow(Icons.Default.RemoveRedEye, "Privacy", "Blocked contacts, read receipts and message visibility") { selectedSection = "Privacy" }
                SettingsCategoryRow(Icons.Default.Notifications, "Notifications", "Alerts, sounds and notification previews") { selectedSection = "Notifications" }
                SettingsCategoryRow(Icons.Default.PhotoLibrary, "Media", "Downloads, attachment previews and media privacy") { selectedSection = "Media" }
                SettingsCategoryRow(Icons.Default.Cloud, "Calls & media transport", "Voice/video controls and call network options") { selectedSection = "Calls & media transport" }
                SettingsCategoryRow(Icons.Default.Radar, "Network & routing", "Internet routing, public relay, Tor and diagnostics") { selectedSection = "Network & routing" }
                SettingsCategoryRow(Icons.Default.Brightness6, "Appearance", "Theme, colors, text size, bubbles and wallpaper") { selectedSection = "Appearance" }
                SettingsCategoryRow(Icons.Default.Bookmark, "Data", "Saved notes and temporary-file cleanup") { selectedSection = "Data" }
            }
        }

        AnimatedVisibility(
            visible = selectedSection != null,
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 1.dp, bottom = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { selectedSection = null }
                    .padding(horizontal = 10.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = 180f })
                Spacer(modifier = Modifier.width(4.dp))
                Text("All settings", fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary)
            }
        }

        // ---------------------------------------------------------
        // Security Center
        // ---------------------------------------------------------
        AnimatedVisibility(
            visible = selectedSection == "Security center",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Security center")
        if (!deviceStorageEnabled) {
            Text(
                "Session-only mode is active. PIN and lock preferences are not saved across app restarts until you choose ‘Save on this device’ under Data.",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(13.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.70f))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(3.dp, RoundedCornerShape(21.dp), clip = false)
                .clip(RoundedCornerShape(21.dp))
                .background(chatColors.cardElevated.copy(alpha = 0.97f))
                .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(21.dp))
        ) {
            // App lock master row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (settings.appLockEnabled) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "App lock",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        when {
                            settings.appLockEnabled && hasPin -> "Locked with PIN" +
                                (if (settings.biometricEnabled && canBiometric) " + biometrics" else "")
                            settings.appLockEnabled -> "Locked with biometrics"
                            else -> "Require PIN or biometrics to open FolkChat"
                        },
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = settings.appLockEnabled,
                    onCheckedChange = { enabled ->
                        if (enabled) {
                            if (hasPin || canBiometric) {
                                appLock.setEnabled(true)
                                viewModel.refreshSettings()
                            } else {
                                // Guide the user to create a PIN first.
                                showPinSetup = true
                            }
                        } else {
                            appLock.setEnabled(false)
                            viewModel.refreshSettings()
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = MaterialTheme.colorScheme.primary,
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // PIN management
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (hasPin) showChangePin = true else showPinSetup = true
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Password,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        if (hasPin) "Change PIN" else "Set 6-digit PIN",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        if (hasPin) "Your unlock PIN is stored as a salted hash" else "Create an offline unlock PIN",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }

            // Per-conversation lock management
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (hasPin) {
                            showChatLockManager = true
                        } else {
                            openChatLockManagerAfterPin = true
                            showPinSetup = true
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Chat lock", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        if (settings.lockedChatKeys.isEmpty()) "Protect individual conversations with your PIN"
                        else "${settings.lockedChatKeys.size} conversation${if (settings.lockedChatKeys.size == 1) "" else "s"} protected · previews hidden",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }

            // Biometrics
            if (canBiometric) {
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Biometric unlock", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Fingerprint or face instead of the PIN", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = settings.biometricEnabled,
                        onCheckedChange = { enabled ->
                            appLock.setBiometricEnabled(enabled)
                            viewModel.refreshSettings()
                        },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Auto lock
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text("Auto-lock", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                Text("Lock FolkChat after this much inactivity", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AutoLockChip("Immediately", 0L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("30 s", 30_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("1 min", 60_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("5 min", 300_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("10 min", 600_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                }
                if (settings.autoLockMillis in 1..60_000L) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Short auto-lock windows pause while you are on a call or typing a message, so an active conversation never locks mid-use.",
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Blocked peers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showBlocked = true }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Blocked peers", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        if (blockedPeers.isEmpty()) "No blocked peers" else "${blockedPeers.size} blocked",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }

        // ---------------------------------------------------------
        // Privacy
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Privacy",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Privacy")
        SettingsCard {
            ToggleRow(
                icon = Icons.Default.RemoveRedEye,
                title = "Read receipts",
                subtitle = "Send ✓✓ when you read messages",
                checked = settings.readReceipts
            ) { enabled ->
                viewModel.updateSettings { it.copy(readReceipts = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Sync,
                title = "Typing indicators",
                subtitle = "Show when you are typing",
                checked = settings.typingIndicators
            ) { enabled ->
                viewModel.updateSettings { it.copy(typingIndicators = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Lock,
                title = "Block screenshots",
                subtitle = "Hide FolkChat content in the app switcher and block screen capture",
                checked = settings.screenshotProtection
            ) { enabled ->
                viewModel.updateSettings { it.copy(screenshotProtection = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.PhotoLibrary,
                title = "Share profile photo",
                subtitle = "Send a compact encrypted profile thumbnail to accepted contacts",
                checked = settings.shareProfilePhoto
            ) { enabled -> viewModel.setShareProfilePhoto(enabled) }
        }

        // ---------------------------------------------------------
        // Notifications
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Notifications",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Notifications")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Message previews", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("What notifications reveal about new messages", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Column {
                    RadioOption("Full preview", "Show sender and message text", settings.notificationPreviewMode == NotificationPreviewMode.FULL) {
                        viewModel.updateSettings { it.copy(notificationPreviewMode = NotificationPreviewMode.FULL) }
                    }
                    RadioOption("Sender only", "Show sender name, hide message text", settings.notificationPreviewMode == NotificationPreviewMode.SENDER_ONLY) {
                        viewModel.updateSettings { it.copy(notificationPreviewMode = NotificationPreviewMode.SENDER_ONLY) }
                    }
                    RadioOption("Hidden", "Only \"New message\"", settings.notificationPreviewMode == NotificationPreviewMode.HIDDEN) {
                        viewModel.updateSettings { it.copy(notificationPreviewMode = NotificationPreviewMode.HIDDEN) }
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Notifications,
                title = "Notification sound",
                subtitle = "Play the default notification sound",
                checked = settings.notificationSound
            ) { enabled ->
                viewModel.updateSettings { it.copy(notificationSound = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Notifications,
                title = "Vibration",
                subtitle = "Vibrate for new messages and calls",
                checked = settings.notificationVibrate
            ) { enabled ->
                viewModel.updateSettings { it.copy(notificationVibrate = enabled) }
            }
        }

        // ---------------------------------------------------------
        // Media
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Media",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Media")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-download media", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Incoming photos, videos and documents", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                RadioOption("Always", "Download on any connection", settings.mediaAutoDownload == MediaAutoDownload.ALWAYS) {
                    viewModel.updateSettings { it.copy(mediaAutoDownload = MediaAutoDownload.ALWAYS) }
                }
                RadioOption("Wi-Fi or LAN only", "Save mobile data", settings.mediaAutoDownload == MediaAutoDownload.WIFI_OR_LAN) {
                    viewModel.updateSettings { it.copy(mediaAutoDownload = MediaAutoDownload.WIFI_OR_LAN) }
                }
                RadioOption("Never", "Download manually per message", settings.mediaAutoDownload == MediaAutoDownload.NEVER) {
                    viewModel.updateSettings { it.copy(mediaAutoDownload = MediaAutoDownload.NEVER) }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Cloud,
                title = "Auto-download voice notes",
                subtitle = "Use the global auto-download policy for audio messages",
                checked = settings.autoDownloadVoice
            ) { enabled -> viewModel.updateSettings { it.copy(autoDownloadVoice = enabled) } }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.PhotoLibrary,
                title = "Auto-download videos",
                subtitle = "Videos can use a lot of mobile data and storage",
                checked = settings.autoDownloadVideo
            ) { enabled -> viewModel.updateSettings { it.copy(autoDownloadVideo = enabled) } }
        }

        // ---------------------------------------------------------
        // Calls & media transport
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Calls & media transport",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Calls & media transport")
        SettingsCard {
            ToggleRow(
                icon = Icons.Default.Cloud,
                title = "Call data saver",
                subtitle = "Use 480×360 at 15 fps instead of 640×480 at 24 fps",
                checked = settings.callDataSaver
            ) { enabled -> viewModel.updateSettings { it.copy(callDataSaver = enabled) } }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.VpnKey,
                title = "Relay-only calls (hide peer IP)",
                subtitle = if (settings.callRelayOnly && settings.callIceServers.isBlank())
                    "On, but no TURN server is configured; calls will fail closed" 
                else if (settings.callRelayOnly) "Media must travel through TURN; the relay still sees connection metadata"
                else "Direct ICE paths may reveal your public IP to the other peer"
                ,
                checked = settings.callRelayOnly
            ) { enabled -> viewModel.updateSettings { it.copy(callRelayOnly = enabled) } }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            SettingsActionRow(
                Icons.Default.Sync,
                "Call network / ICE servers",
                if (settings.callIceServers.isBlank()) "Built-in STUN defaults · optional TURN for restrictive networks"
                else "${settings.callIceServers.lines().count { it.isNotBlank() }} ICE URL(s) configured · credentials stored in encrypted vault"
            ) { showCallNetworkEditor = true }
            Text(
                "Voice and video use WebRTC with encrypted DTLS-SRTP media. STUN helps discover a path; TURN is required for some NATs and for relay-only privacy. No public TURN server can be promised without a maintained service and valid credentials.",
                fontSize = 11.sp,
                lineHeight = 15.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 12.dp)
            )
        }

        // ---------------------------------------------------------
        // Network & Routing
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Network & routing",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Network & routing")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isInternetAvailable) Icons.Default.Cloud else Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Routing policy", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("$networkTypeName · persisted across restarts", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                RadioOption("Auto (recommended)", "Private relay or local link first; public WAN fallback is built in", routingPolicy == RoutingPolicy.AUTO_FALLBACK) {
                    viewModel.setRoutingPolicy(RoutingPolicy.AUTO_FALLBACK)
                }
                RadioOption("Force online relay", "Internet path only; private relay preferred, public fallback available", routingPolicy == RoutingPolicy.FORCE_ONLINE) {
                    viewModel.setRoutingPolicy(RoutingPolicy.FORCE_ONLINE)
                }
                RadioOption("Force offline mesh", "Air-gapped: BLE & Wi-Fi only", routingPolicy == RoutingPolicy.FORCE_OFFLINE) {
                    viewModel.setRoutingPolicy(RoutingPolicy.FORCE_OFFLINE)
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Relay URL
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRelayEditor = true }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Radar, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Relay server", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        when {
                            effectiveRelayUrl.isBlank() -> "No server setup needed · public WAN fallback (best effort)"
                            relayConnected -> "Connected · mobile-data messaging ready"
                            !relayError.isNullOrBlank() -> relayError.orEmpty()
                            else -> "Connecting… tap to edit relay URL"
                        },
                        fontSize = 11.sp,
                        color = when {
                            relayConnected -> com.example.ui.theme.FolkSuccess
                            !relayError.isNullOrBlank() -> com.example.ui.theme.FolkWarning
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Tor routing — OFF by default
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (settings.torRoutingEnabled) Icons.Default.VpnKey else Icons.Default.VpnKey,
                        contentDescription = null,
                        tint = if (settings.torRoutingEnabled) chatColors.presenceOnline else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Tor routing", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text(
                            if (settings.torRoutingEnabled) "Public packets and file-host traffic use Orbot (Tor)" else "Off — public services can see your network IP and timing",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = settings.torRoutingEnabled,
                        onCheckedChange = { enabled ->
                            viewModel.setTorRoutingEnabled(enabled)
                        },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
                if (settings.torRoutingEnabled) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        torProbe ?: "Checking for Orbot…",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            SettingsActionRow(Icons.Default.Sync, "Link diagnostics", "Mesh & transport status") { onOpenDiagnostics() }
        }

        // ---------------------------------------------------------
        // Appearance
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Appearance",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Appearance")

        // Live preview: reflects theme, accent, bubble shape, font size and
        // wallpaper instantly because every choice re-resolves the root theme.
        AppearancePreviewCard()

        Spacer(modifier = Modifier.height(10.dp))

        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Brightness6, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Theme", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Light, deep dark, AMOLED black or follow the system", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip("Classic light", themeMode == AppThemeMode.CLASSIC_LIGHT) { viewModel.setThemeMode(AppThemeMode.CLASSIC_LIGHT) }
                    ThemeChip("Mist", themeMode == AppThemeMode.MIST_LIGHT) { viewModel.setThemeMode(AppThemeMode.MIST_LIGHT) }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip("Paper", themeMode == AppThemeMode.PAPER_LIGHT) { viewModel.setThemeMode(AppThemeMode.PAPER_LIGHT) }
                    ThemeChip("Rose light", themeMode == AppThemeMode.ROSE_LIGHT) { viewModel.setThemeMode(AppThemeMode.ROSE_LIGHT) }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip("Dark", themeMode == AppThemeMode.DEEP_DARK) { viewModel.setThemeMode(AppThemeMode.DEEP_DARK) }
                    ThemeChip("AMOLED", themeMode == AppThemeMode.AMOLED_BLACK) { viewModel.setThemeMode(AppThemeMode.AMOLED_BLACK) }
                    ThemeChip("System", themeMode == AppThemeMode.SYSTEM) { viewModel.setThemeMode(AppThemeMode.SYSTEM) }
                }
                if (themeMode == AppThemeMode.AMOLED_BLACK) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "AMOLED uses a pure-black canvas to save power on OLED screens.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Accent color palette
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Accent color", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Re-tints outgoing bubbles and brand controls", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                val isDarkCanvas = MaterialTheme.colorScheme.background.luminance() < 0.5f
                val selectedAccent = AccentPalette.fromName(settings.accentPalette)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AccentPalette.entries.take(4).forEach { palette ->
                        AccentSwatch(
                            swatch = if (isDarkCanvas) palette.dark.primary else palette.light.primary,
                            label = palette.label,
                            selected = palette == selectedAccent,
                            modifier = Modifier.weight(1f)
                        ) { viewModel.setAccentPalette(palette) }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AccentPalette.entries.drop(4).forEach { palette ->
                        AccentSwatch(
                            swatch = if (isDarkCanvas) palette.dark.primary else palette.light.primary,
                            label = palette.label,
                            selected = palette == selectedAccent,
                            modifier = Modifier.weight(1f)
                        ) { viewModel.setAccentPalette(palette) }
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Text size
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FormatSize, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Text size", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Scales every screen, with chat bubbles leading", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                val currentScale = ChatFontScale.fromMultiplier(settings.chatFontScale)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChatFontScale.entries.forEach { scale ->
                        ThemeChip(scale.label, scale == currentScale) { viewModel.setChatFontScale(scale) }
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Bubble silhouette
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.BubbleChart, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Bubble style", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Corner silhouette of your message bubbles", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                val currentBubble = BubbleStyle.fromName(settings.bubbleStyle)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BubbleStyle.entries.forEach { style ->
                        RadioOption(
                            title = style.label,
                            subtitle = when (style) {
                                BubbleStyle.CLASSIC -> "Tailed corners, the classic messenger look"
                                BubbleStyle.MODERN -> "Evenly rounded with a small tail hint"
                                BubbleStyle.SQUIRCLE -> "Large soft corners, calm and minimal"
                            },
                            selected = style == currentBubble,
                            onSelect = { viewModel.setBubbleStyle(style) }
                        )
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Chat wallpaper
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Wallpaper, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Chat wallpaper", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Backdrop drawn behind your conversations", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                val currentWallpaper = ChatWallpaper.fromName(settings.chatWallpaper)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChatWallpaper.entries.take(4).forEach { wallpaper ->
                            ThemeChip(wallpaper.shortLabel, wallpaper == currentWallpaper) { viewModel.setChatWallpaper(wallpaper) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChatWallpaper.entries.drop(4).forEach { wallpaper ->
                            ThemeChip(wallpaper.shortLabel, wallpaper == currentWallpaper) { viewModel.setChatWallpaper(wallpaper) }
                        }
                    }
                }
                if (currentWallpaper == ChatWallpaper.AURORA) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Aurora drifts slowly. Reduce motion makes it static.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Font family
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FontDownload, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Font", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Typeface for the whole app, previewed live", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                val currentFont = AppFontChoice.fromName(settings.appFont)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    AppFontChoice.entries.forEach { choice ->
                        FontOptionRow(
                            choice = choice,
                            selected = choice == currentFont,
                            onSelect = { viewModel.setAppFont(choice) }
                        )
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // In-app emblem art
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.EmojiNature, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("App emblem", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("The brand mark in the header and welcome screen", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                val currentEmblem = AppEmblemStyle.fromName(settings.appEmblem)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppEmblemStyle.entries.forEach { style ->
                        EmblemSwatch(
                            style = style,
                            selected = style == currentEmblem,
                            modifier = Modifier.weight(1f)
                        ) { viewModel.setAppEmblem(style) }
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Launcher icon variant
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Apps, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("App icon", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Changes the home-screen launcher icon", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                val currentIconVariant = viewModel.activeAppIconVariant()
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    AppIconVariant.entries.chunked(4).forEach { variants ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            variants.forEach { variant ->
                                LauncherIconTile(
                                    variant = variant,
                                    selected = variant == currentIconVariant,
                                    modifier = Modifier.weight(1f)
                                ) { viewModel.setAppIconVariant(variant) }
                            }
                            repeat(4 - variants.size) { Spacer(modifier = Modifier.weight(1f)) }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Your launcher may take a moment to redraw the new icon. Some launchers keep the old icon until they restart.",
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            ToggleRow(
                icon = Icons.Default.PhotoLibrary,
                title = "Compact chat density",
                subtitle = "Tighter message spacing fits more of the conversation on screen",
                checked = settings.compactChat
            ) { enabled -> viewModel.updateSettings { it.copy(compactChat = enabled) } }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            ToggleRow(
                icon = Icons.Default.Brightness6,
                title = "Outgoing bubble emphasis",
                subtitle = "Keep your bubbles visually stronger than incoming ones",
                checked = settings.outgoingBubbleEmphasis
            ) { enabled -> viewModel.updateSettings { it.copy(outgoingBubbleEmphasis = enabled) } }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            ToggleRow(
                icon = Icons.Default.Brightness6,
                title = "Reduce motion",
                subtitle = "Reduce pulsing and animated movement for accessibility",
                checked = settings.reduceMotion
            ) { enabled -> viewModel.updateSettings { it.copy(reduceMotion = enabled) } }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            ToggleRow(
                icon = Icons.Default.Vibration,
                title = "Haptic feedback",
                subtitle = "Tactile taps on keys, sends and toggles",
                checked = settings.hapticFeedback
            ) { enabled -> viewModel.setHapticFeedback(enabled) }
        }

        // ---------------------------------------------------------
        // Data
        // ---------------------------------------------------------
        }

        AnimatedVisibility(
            visible = selectedSection == "Data",
            enter = fadeIn() + slideInHorizontally(initialOffsetX = { it / 18 }),
            exit = fadeOut()
        ) {
        SectionHeader("Data & local storage")
        SettingsCard {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FolkIconTile(
                        icon = if (deviceStorageEnabled) Icons.Default.Save else Icons.Default.CloudOff,
                        size = 42.dp,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        container = MaterialTheme.colorScheme.primaryContainer
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (deviceStorageEnabled) "Encrypted device saving is on" else "Session-only storage",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            if (deviceStorageEnabled)
                                "Chat history, identity and settings are saved in the encrypted local vault."
                            else
                                "A fresh install keeps chat history and identity in memory until you explicitly save. Temporary attachments use app cache and can be evicted by Android.",
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (!deviceStorageEnabled) {
                    TextButton(
                        onClick = { showStorageConsent = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(7.dp))
                        Text("Save on this device", fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(7.dp))
                        Text(
                            "Local vault encrypted with a device-bound Android Keystore key.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            SettingsActionRow(Icons.Default.Bookmark, "Saved Notes", "Encrypted personal vault") { viewModel.openSavedNotes() }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.CloudOff,
                title = "Clean interrupted transfer files",
                subtitle = "Remove app-owned transfer temp files older than 24 hours at next launch",
                checked = settings.clearTemporaryFilesOnExit
            ) { enabled -> viewModel.updateSettings { it.copy(clearTemporaryFilesOnExit = enabled) } }
        }

        }

        if (selectedSection != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "FolkChat · Private messaging, by design.\nConnect by QR or public key · No phone number required.",
            fontSize = 11.sp,
            lineHeight = 16.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // ---------------- Dialogs ----------------

    if (showPinSetup) {
        PinSetupDialog(
            appLock = appLock,
            onDone = {
                showPinSetup = false
                if (openChatLockManagerAfterPin) {
                    openChatLockManagerAfterPin = false
                    showChatLockManager = true
                } else {
                    appLock.setEnabled(true)
                }
                viewModel.refreshSettings()
            },
            onDismiss = {
                showPinSetup = false
                openChatLockManagerAfterPin = false
            }
        )
    }

    if (showChangePin) {
        ChangePinDialog(
            appLock = appLock,
            onDone = {
                showChangePin = false
                viewModel.refreshSettings()
            },
            onDismiss = { showChangePin = false }
        )
    }

    if (showChatLockManager) {
        com.example.ui.components.ChatLockManagerDialog(
            contacts = contacts,
            lockedKeys = settings.lockedChatKeys,
            hasPin = appLock.hasPin(),
            onSetLocked = { contact, locked ->
                val changed = appLock.setChatLocked(contact.x25519PublicKeyHex, locked)
                viewModel.refreshSettings()
                changed
            },
            onDismiss = {
                showChatLockManager = false
                viewModel.refreshSettings()
            }
        )
    }

    if (showBlocked) {
        BlockedListDialog(
            blocked = blockedPeers,
            onUnblock = { key -> viewModel.unblockPeer(key) },
            onDismiss = { showBlocked = false }
        )
    }

    if (showRelayEditor) {
        RelayUrlDialog(
            initial = effectiveRelayUrl,
            onSave = { url ->
                viewModel.setRelayUrl(url)
                showRelayEditor = false
            },
            onDismiss = { showRelayEditor = false }
        )
    }

    if (showCallNetworkEditor) {
        CallNetworkSettingsDialog(
            initialUrls = settings.callIceServers,
            initialUsername = settings.callTurnUsername,
            initialCredential = settings.callTurnCredential,
            onSave = { urls, username, credential ->
                viewModel.updateSettings {
                    it.copy(
                        callIceServers = urls,
                        callTurnUsername = username,
                        callTurnCredential = credential
                    )
                }
                showCallNetworkEditor = false
            },
            onDismiss = { showCallNetworkEditor = false }
        )
    }

    if (showStorageConsent) {
        AlertDialog(
            onDismissRequest = { showStorageConsent = false },
            icon = { Icon(Icons.Default.Save, contentDescription = null) },
            title = { Text("Save current data on this device?") },
            text = {
                Text(
                    "FolkChat will promote current session media into app-private storage and write your current identity, chats and settings to the encrypted local vault. The device-bound wrapping key stays in Android Keystore. This does not hide network metadata or make the app anonymous."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showStorageConsent = false
                    viewModel.enableDeviceStorageAndSave()
                }) { Text("Save on this device") }
            },
            dismissButton = {
                TextButton(onClick = { showStorageConsent = false }) { Text("Not now") }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(22.dp)
        )
    }

    lockNotice?.let {
        AlertDialog(
            onDismissRequest = { lockNotice = null },
            title = { Text("App lock") },
            text = { Text(it) },
            confirmButton = { TextButton(onClick = { lockNotice = null }) { Text("OK") } }
        )
    }
}

// ---------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------


@Composable
private fun SettingsCategoryRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val chatColors = LocalChatColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(chatColors.cardElevated)
            .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 14.dp)
            .animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FolkIconTile(
            icon = icon,
            size = 46.dp,
            cornerRadius = 15.dp,
            tint = MaterialTheme.colorScheme.primary,
            container = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.96f),
            borderColor = chatColors.borderSubtle.copy(alpha = 0.75f),
            iconSize = 22.dp
        )
        Spacer(modifier = Modifier.width(13.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Open $title", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun SectionHeader(title: String) {
    Row(
        modifier = Modifier.padding(start = 3.dp, top = 18.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(17.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.primary)
        )
        Spacer(modifier = Modifier.width(9.dp))
        Text(
            title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.85.sp,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    val chatColors = LocalChatColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .shadow(3.dp, RoundedCornerShape(21.dp), clip = false)
            .clip(RoundedCornerShape(21.dp))
            .background(chatColors.cardElevated.copy(alpha = 0.97f))
            .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(21.dp))
    ) {
        content()
    }
}

@Composable
private fun ToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FolkIconTile(
            icon = icon,
            size = 39.dp,
            cornerRadius = 13.dp,
            container = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.64f),
            tint = MaterialTheme.colorScheme.primary,
            iconSize = 20.dp
        )
        Spacer(modifier = Modifier.width(13.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary
            )
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .animateContentSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FolkIconTile(
            icon = icon,
            size = 39.dp,
            cornerRadius = 13.dp,
            container = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.64f),
            tint = MaterialTheme.colorScheme.primary,
            iconSize = 20.dp
        )
        Spacer(modifier = Modifier.width(13.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun RadioOption(title: String, subtitle: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onSelect,
            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Column {
            Text(title, fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AutoLockChip(label: String, value: Long, current: Long, onSelect: (Long) -> Unit) {
    val selected = current == value
    val background by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        animationSpec = tween(170),
        label = "autoLockChipBackground"
    )
    val foreground by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(170),
        label = "autoLockChipForeground"
    )
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .clickable { onSelect(value) }
            .animateContentSize(tween(170))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = foreground)
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onSelect: () -> Unit) {
    val background by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        animationSpec = tween(190),
        label = "themeChipBackground"
    )
    val foreground by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(190),
        label = "themeChipForeground"
    )
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .clickable { onSelect() }
            .animateContentSize(tween(190))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = foreground)
    }
}

/**
 * Accent color swatch: a filled circle in the palette's brand color with
 * the palette name beneath. Selected state draws a contrasting ring and
 * a check badge so the active choice is unambiguous.
 */
@Composable
private fun AccentSwatch(
    swatch: androidx.compose.ui.graphics.Color,
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onSelect: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .padding(vertical = 4.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            val ringColor by animateColorAsState(
                targetValue = if (selected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                animationSpec = tween(190),
                label = "accentRing"
            )
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .border(2.5.dp, ringColor, CircleShape)
                    .padding(3.dp)
                    .clip(CircleShape)
                    .background(swatch)
            )
            if (selected) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(androidx.compose.ui.graphics.Color(0x52000000))
                        .padding(2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Miniature conversation preview. Because every customization choice
 * re-resolves the root theme, this card updates live: the bubbles use
 * the active accent, silhouette and text scale, and the canvas uses the
 * active wallpaper.
 */
@Composable
private fun AppearancePreviewCard() {
    val chatColors = LocalChatColors.current
    val customization = LocalChatCustomization.current

    val previewShape = when (customization.bubbleStyle) {
        BubbleStyle.CLASSIC -> RoundedCornerShape(
            topStart = 18.dp, topEnd = 18.dp,
            bottomStart = 18.dp, bottomEnd = 4.dp
        )
        BubbleStyle.MODERN -> RoundedCornerShape(
            topStart = 16.dp, topEnd = 16.dp,
            bottomStart = 16.dp, bottomEnd = 7.dp
        )
        BubbleStyle.SQUIRCLE -> RoundedCornerShape(24.dp)
    }
    val bodyFont = (14f * customization.fontScale).coerceIn(11f, 20f).sp
    val previewBrush = when (customization.chatWallpaper) {
        ChatWallpaper.NONE -> Brush.verticalGradient(
            listOf(
                MaterialTheme.colorScheme.background,
                MaterialTheme.colorScheme.background
            )
        )
        ChatWallpaper.WASH, ChatWallpaper.DOTS, ChatWallpaper.PAPER -> Brush.verticalGradient(
            listOf(
                MaterialTheme.colorScheme.background,
                chatColors.searchField.copy(alpha = 0.30f),
                MaterialTheme.colorScheme.background
            )
        )
        ChatWallpaper.AURORA -> Brush.linearGradient(
            listOf(
                chatColors.primaryBrand.copy(alpha = 0.10f),
                MaterialTheme.colorScheme.background,
                chatColors.sageAccent.copy(alpha = 0.12f)
            )
        )
        ChatWallpaper.GRID -> Brush.verticalGradient(
            listOf(
                MaterialTheme.colorScheme.background,
                chatColors.searchField.copy(alpha = 0.16f),
                MaterialTheme.colorScheme.background
            )
        )
        ChatWallpaper.BLOOM -> Brush.linearGradient(
            listOf(
                chatColors.primaryBrand.copy(alpha = 0.09f),
                MaterialTheme.colorScheme.background,
                chatColors.sageAccent.copy(alpha = 0.10f)
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(3.dp, RoundedCornerShape(21.dp), clip = false)
            .clip(RoundedCornerShape(21.dp))
            .background(previewBrush)
            .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(21.dp))
            .padding(horizontal = 14.dp, vertical = 14.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .background(chatColors.incomingBubbleBg, previewShape)
                    .border(1.dp, chatColors.incomingBubbleBorder, previewShape)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Column {
                    Text("Hey! How's the new look?", fontSize = bodyFont, color = chatColors.incomingText)
                    Text("10:02 AM", fontSize = 9.sp, color = chatColors.incomingMeta)
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                modifier = Modifier
                    .background(chatColors.outgoingBubbleBg, previewShape)
                    .border(0.7.dp, chatColors.outgoingBubbleBorder.copy(alpha = 0.6f), previewShape)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Column {
                    Text("Loving it — feels like mine.", fontSize = bodyFont, color = chatColors.outgoingText)
                    Text("10:03 AM", fontSize = 9.sp, color = chatColors.outgoingMeta)
                }
            }
        }
    }
}

/**
 * Font option row: renders a live "Aa" sample in the real family so the user
 * sees the actual typeface, not just a name.
 */
@Composable
private fun FontOptionRow(
    choice: AppFontChoice,
    selected: Boolean,
    onSelect: () -> Unit
) {
    val previewFamily = com.example.ui.theme.fontFamilyFor(choice)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            .clickable { onSelect() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Aa",
            fontFamily = previewFamily,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                choice.label,
                fontFamily = previewFamily,
                fontSize = 14.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                choice.description,
                fontFamily = previewFamily,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (selected) {
            Icon(
                Icons.Default.Check,
                contentDescription = "Selected",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Launcher icon variant tile: a small rounded preview of the variant's home-
 * screen icon (background color + accent art hint) with a selection ring.
 */
@Composable
private fun LauncherIconTile(
    variant: AppIconVariant,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onSelect: () -> Unit
) {
    val chatColors = LocalChatColors.current
    val tileScale by animateFloatAsState(
        targetValue = if (selected) 1.045f else 1f,
        animationSpec = tween(durationMillis = 180),
        label = "launcherIconSelectionScale"
    )
    val tileColor = when (variant) {
        AppIconVariant.FOREST -> colorResource(R.color.folk_sage)
        AppIconVariant.OCEAN -> colorResource(R.color.launcher_ocean_bg)
        AppIconVariant.SUNSET -> colorResource(R.color.launcher_sunset_bg)
        AppIconVariant.MONO -> colorResource(R.color.launcher_mono_bg)
        AppIconVariant.CALCULATOR -> colorResource(R.color.launcher_calculator_bg)
        AppIconVariant.NOTES -> colorResource(R.color.launcher_notes_bg)
        AppIconVariant.CALENDAR -> colorResource(R.color.launcher_calendar_bg)
        AppIconVariant.WEATHER -> colorResource(R.color.launcher_weather_bg)
        AppIconVariant.CLOCK -> colorResource(R.color.launcher_clock_bg)
        AppIconVariant.FILES -> colorResource(R.color.launcher_files_bg)
    }
    val preview = when (variant) {
        AppIconVariant.FOREST -> R.drawable.app_logo
        AppIconVariant.OCEAN -> R.drawable.ic_launcher_ocean_fg
        AppIconVariant.SUNSET -> R.drawable.ic_launcher_sunset_fg
        AppIconVariant.MONO -> R.drawable.ic_launcher_mono_fg
        AppIconVariant.CALCULATOR -> R.drawable.ic_disguise_calculator
        AppIconVariant.NOTES -> R.drawable.ic_disguise_notes
        AppIconVariant.CALENDAR -> R.drawable.ic_disguise_calendar
        AppIconVariant.WEATHER -> R.drawable.ic_disguise_weather
        AppIconVariant.CLOCK -> R.drawable.ic_disguise_clock
        AppIconVariant.FILES -> R.drawable.ic_disguise_files
    }
    androidx.compose.foundation.layout.Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .graphicsLayer { scaleX = tileScale; scaleY = tileScale }
                .clip(RoundedCornerShape(14.dp))
                .background(tileColor)
                .border(
                    width = if (selected) 2.5.dp else 0.dp,
                    color = if (selected) chatColors.primaryBrand else androidx.compose.ui.graphics.Color.Transparent,
                    shape = RoundedCornerShape(14.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(preview),
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                modifier = Modifier.size(if (variant == AppIconVariant.FOREST) 41.dp else 31.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            variant.label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) chatColors.primaryBrand else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ---------------------------------------------------------------------
// Dialogs
// ---------------------------------------------------------------------

@Composable
private fun CallNetworkSettingsDialog(
    initialUrls: String,
    initialUsername: String,
    initialCredential: String,
    onSave: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var urls by remember(initialUrls) { mutableStateOf(initialUrls) }
    var username by remember(initialUsername) { mutableStateOf(initialUsername) }
    var credential by remember(initialCredential) { mutableStateOf(initialCredential) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Call network settings", fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Enter one STUN or TURN URL per line, for example stun:stun.l.google.com:19302 or turns:turn.example.net:5349. TURN username and credential are stored inside FolkChat's encrypted vault. Avoid public TURN credentials shared on forums.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = urls,
                    onValueChange = { urls = it.take(2048) },
                    label = { Text("STUN / TURN URLs") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.take(256) },
                    singleLine = true,
                    label = { Text("TURN username") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = credential,
                    onValueChange = { credential = it.take(512) },
                    singleLine = true,
                    label = { Text("TURN credential") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(urls.trim(), username.trim(), credential) }) { Text("Save securely") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun BlockedListDialog(
    blocked: List<Pair<String, String>>,
    onUnblock: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Blocked peers", fontWeight = FontWeight.SemiBold) },
        text = {
            if (blocked.isEmpty()) {
                Text(
                    "No blocked peers. Block someone from their profile or a message request.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    blocked.forEach { (key, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PeerAvatar(name = name, avatarPath = null, size = 36.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text("${key.take(16)}…", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { onUnblock(key) }) {
                                Text("Unblock", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun RelayUrlDialog(
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var url by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Relay server", fontWeight = FontWeight.SemiBold) },
        text = {
            Column {
                Text(
                    "Leave this blank to use the relay address embedded in the official release APK, when the build has one. Only enter a URL if you intentionally use a self-hosted relay. A real public relay is required for phones on different networks; mobile data alone cannot bypass carrier NAT. Text and file payloads are end-to-end encrypted, while the relay still sees routing keys, ciphertext sizes, timing, and queued-delivery metadata. Use wss:// for public relays; use .onion only through Tor.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    singleLine = true,
                    placeholder = { Text("wss://your-host.example/ws") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(url.trim()) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
