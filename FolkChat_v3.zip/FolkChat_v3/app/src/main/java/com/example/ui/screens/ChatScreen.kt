package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.snap
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shortcut
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.crypto.CryptoEngine
import com.example.data.ChatMessage
import com.example.data.EncryptedVault
import com.example.data.Contact
import com.example.data.DisappearTimer
import com.example.data.DiscoveredPeer
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import com.example.data.MessageStatus
import com.example.data.TransferState
import com.example.data.ViewLimit
import com.example.ui.components.FolkIconButton
import com.example.ui.components.PeerAvatar
import com.example.ui.components.formatChatDivider
import com.example.ui.theme.FolkError
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkWarning
import com.example.ui.theme.LocalChatColors
import com.example.ui.theme.LocalChatCustomization
import com.example.ui.theme.BubbleStyle
import com.example.ui.theme.ChatWallpaper
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.cos
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val QUICK_REACTIONS = listOf("❤️", "👍", "😂", "😮", "😢", "🙏")

/** LazyColumn item model: day dividers interleaved with messages. */
private sealed interface ChatListItem {
    data class DayDivider(val label: String) : ChatListItem
    data class MessageItem(val message: ChatMessage) : ChatListItem
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(
    contact: Contact,
    messages: List<ChatMessage>,
    peers: List<DiscoveredPeer>,
    isInternetAvailable: Boolean = true,
    onSendMessage: (String) -> Unit,
    onSendMessageWithMeta: ((String, String?, String?, String?) -> Unit)? = null,
    onDeleteMessage: (String) -> Unit,
    onEditMessage: ((String, String) -> Unit)? = null,
    onDeleteForEveryone: ((String) -> Unit)? = null,
    onTogglePin: ((String) -> Unit)? = null,
    onToggleReaction: ((String, String) -> Unit)? = null,
    onResendMessage: ((String) -> Unit)? = null,
    onSendAttachment: ((MediaAttachment, String) -> Unit)? = null,
    onCancelTransfer: ((String) -> Unit)? = null,
    onRetryTransfer: ((String) -> Unit)? = null,
    resolveLocalFile: ((MediaAttachment?) -> File?)? = null,
    onOpenContactProfile: () -> Unit,
    onBack: () -> Unit,
    onStartCall: ((Contact, Boolean) -> Unit)? = null,
    // v2 additions
    contactsForForward: List<Contact> = emptyList(),
    onToggleStar: ((String) -> Unit)? = null,
    onForward: ((String, String) -> Unit)? = null,
    onConsumeView: ((String) -> Unit)? = null,
    onSetDisappearTimer: ((DisappearTimer) -> Unit)? = null,
    onTypingSignal: (() -> Unit)? = null,
    isPeerTyping: Boolean = false,
    peerLastReadMs: Long = 0L,
    readReceiptsEnabled: Boolean = true,
    compactChat: Boolean = false,
    isChatLocked: Boolean = false,
    onLockChat: (() -> Unit)? = null,
    onExternalActivityLaunch: (() -> Unit)? = null,
    onExternalActivityResult: (() -> Unit)? = null,
    reduceMotion: Boolean = false,
    // Composition draft persistence + app-lock activity heartbeat.
    draft: String = "",
    onDraftChange: ((String) -> Unit)? = null,
    onUserActivity: (() -> Unit)? = null
) {
    BackHandler { onBack() }

    val chatColors = LocalChatColors.current
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val clipboardManager = LocalClipboardManager.current
    var inputText by remember(contact.id) { mutableStateOf(draft) }
    val listState = rememberLazyListState()
    var showMenu by remember { mutableStateOf(false) }
    var showQueueInfoBanner by remember { mutableStateOf(false) }
    var showAttachSheet by remember { mutableStateOf(false) }
    var fileViewer by remember { mutableStateOf<Pair<MediaAttachment, File>?>(null) }
    var forwardTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var showDisappearSheet by remember { mutableStateOf(false) }
    var viewOnceTarget by remember { mutableStateOf<ChatMessage?>(null) }

    // Voice message recorder
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordPath by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var recordElapsedMs by remember { mutableLongStateOf(0L) }
    var recordTotalMs by remember { mutableLongStateOf(0L) }
    var voiceError by remember { mutableStateOf<String?>(null) }
    val micPulseState = remember { Animatable(0.25f) }
    LaunchedEffect(recording, reduceMotion) {
        if (recording && !reduceMotion) {
            while (true) {
                micPulseState.animateTo(1f, tween(durationMillis = 520, easing = FastOutSlowInEasing))
                micPulseState.animateTo(0.25f, tween(durationMillis = 520, easing = FastOutSlowInEasing))
            }
        } else {
            micPulseState.snapTo(if (recording) 0.58f else 0.25f)
        }
    }
    val micPulse = micPulseState.value

    fun stopRecordingAndSend() {
        val rec = recorder ?: return
        voiceError = null
        val path = recordPath
        val elapsed = recordElapsedMs
        recorder = null
        recordPath = null
        recording = false
        recordElapsedMs = 0L
        try { rec.stop() } catch (_: Exception) {}
        try { rec.release() } catch (_: Exception) {}
        if (path != null) {
            val f = File(path)
            if (f.exists() && f.length() > 0L) {
                onSendAttachment?.invoke(
                    MediaAttachment(
                        id = UUID.randomUUID().toString(),
                        kind = MediaKind.VOICE,
                        fileName = f.name,
                        mimeType = "audio/mp4",
                        sizeBytes = f.length(),
                        durationMs = if (elapsed > 0) elapsed else recordTotalMs,
                        localPath = f.absolutePath,
                        transferState = TransferState.PENDING
                    ),
                    ""
                )
            } else {
                // stop() can throw before the container is finalized (tap-to-send racing
                // recorder start, storage pressure). Previously the recording vanished
                // silently and the half-written file leaked in media/.
                try { if (f.exists()) f.delete() } catch (_: Exception) {}
                voiceError = "The recording was too short to send. Hold the mic a little longer."
            }
        }
    }

    fun discardRecording() {
        val rec = recorder ?: return
        voiceError = null
        val path = recordPath
        recorder = null
        recordPath = null
        recording = false
        recordElapsedMs = 0L
        try { rec.stop() } catch (_: Exception) {}
        try { rec.release() } catch (_: Exception) {}
        path?.let { File(it).delete() }
    }

    fun startRecording() {
        if (recorder != null) return
        var createdRecorder: MediaRecorder? = null
        var createdPath: String? = null
        voiceError = null
        try {
            val dir = File(EncryptedVault.dataRootFor(context), "media").apply { mkdirs() }
            val path = File(dir, "voice_${UUID.randomUUID()}.m4a").absolutePath
            @Suppress("DEPRECATION")
            val rec = MediaRecorder()
            createdRecorder = rec
            createdPath = path
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(64_000)
            rec.setAudioSamplingRate(16_000)
            rec.setOutputFile(path)
            rec.setMaxDuration(300_000)
            rec.prepare()
            rec.start()
            recorder = rec
            recordPath = path
            recording = true
            recordElapsedMs = 0L
            recordTotalMs = 0L
        } catch (e: Exception) {
            try { createdRecorder?.release() } catch (_: Exception) {}
            createdPath?.let { File(it).delete() }
            recorder = null
            recordPath = null
            recording = false
            voiceError = "Couldn't start recording. Check microphone access and try again."
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        onExternalActivityResult?.invoke()
        if (granted) startRecording()
        else voiceError = "Microphone permission is required to record voice messages."
    }

    LaunchedEffect(recording) {
        if (recording) {
            val startedAt = System.currentTimeMillis()
            while (recording) {
                recordElapsedMs = System.currentTimeMillis() - startedAt
                recordTotalMs = recordElapsedMs
                delay(300)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            recorder?.let {
                try { it.stop() } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
        }
    }

    // Messaging tools state
    var replyTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var editTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var reactionTarget by remember { mutableStateOf<ChatMessage?>(null) }

    // Search state
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val focusManagerVal = focusManager

    val isSelf = contact.id == "self_notes"

    val isNearby = remember(peers, contact, isSelf) {
        if (contact.isGroup) false
        else if (isSelf) true
        else {
            try {
                val pubBytes = CryptoEngine.hexToBytes(contact.x25519PublicKeyHex)
                val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(pubBytes))
                peers.any { p ->
                    p.tagHex.equals(expectedTag, ignoreCase = true) ||
                        (p.tagHex.length >= 16 && expectedTag.startsWith(p.tagHex, ignoreCase = true)) ||
                        (expectedTag.length >= 16 && p.tagHex.startsWith(expectedTag.take(16), ignoreCase = true)) ||
                        (p.linkType == "WIFI_SOCKET" && p.tagHex == "manual")
                }
            } catch (e: Exception) {
                false
            }
        }
    }

    val hasQueuedMessages = remember(messages) {
        messages.any { it.status == MessageStatus.QUEUED }
    }

    val displayMessages = remember(messages, searchQuery) {
        if (searchQuery.isBlank()) messages
        else messages.filter {
            it.content.contains(searchQuery, ignoreCase = true) &&
                !it.isDeleted
        }
    }

    // Chat list items with day dividers between dates.
    val chatListItems = remember(displayMessages) {
        val out = mutableListOf<ChatListItem>()
        var lastDay = -1
        val cal = java.util.Calendar.getInstance()
        for (m in displayMessages) {
            cal.timeInMillis = m.timestampMs
            val day = cal.get(java.util.Calendar.DAY_OF_YEAR) + cal.get(java.util.Calendar.YEAR) * 1000
            if (day != lastDay) {
                out.add(ChatListItem.DayDivider(formatChatDivider(m.timestampMs)))
                lastDay = day
            }
            out.add(ChatListItem.MessageItem(m))
        }
        out
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LaunchedEffect(searchQuery) {
        if (searchQuery.isNotBlank() && displayMessages.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    LaunchedEffect(editTarget) {
        if (editTarget != null) {
            inputText = editTarget?.content ?: ""
        }
    }

    val submitMessage = {
        val text = inputText
        if (text.isNotBlank()) {
            if (editTarget != null) {
                onEditMessage?.invoke(editTarget!!.id, text)
                editTarget = null
            } else {
                val reply = replyTarget
                if (reply != null && onSendMessageWithMeta != null) {
                    onSendMessageWithMeta(
                        text,
                        reply.id,
                        reply.previewText,
                        if (reply.isOutgoing) "You"
                        else contact.displayName
                    )
                } else {
                    onSendMessage(text)
                }
                replyTarget = null
            }
            inputText = ""
            onDraftChange?.invoke("")
        }
        focusManagerVal.clearFocus()
    }

    val composerActionIcon = when {
        recording -> Icons.Default.Stop
        editTarget != null -> Icons.Default.Check
        inputText.isNotBlank() -> Icons.AutoMirrored.Filled.Send
        else -> Icons.Default.Mic
    }
    val composerActionDescription = when {
        recording -> "Stop and send voice message"
        editTarget != null -> "Save edit"
        inputText.isNotBlank() -> "Send message"
        else -> "Record voice message"
    }
    val composerActionColor by animateColorAsState(
        targetValue = if (recording) FolkError else chatColors.primaryBrand,
        animationSpec = tween(durationMillis = if (reduceMotion) 0 else 190),
        label = "composerActionColor"
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    if (searchOpen) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search in chat", fontSize = 14.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = chatColors.searchField,
                                unfocusedContainerColor = chatColors.searchField,
                                focusedBorderColor = chatColors.sageAccent,
                                unfocusedBorderColor = chatColors.borderSubtle
                            ),
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear search")
                                    }
                                }
                            }
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(enabled = !contact.isGroup) { onOpenContactProfile() }
                        ) {
                            if (contact.isGroup) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .border(1.dp, chatColors.borderSubtle, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.People, contentDescription = "Group conversation", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(23.dp))
                                }
                            } else {
                                PeerAvatar(
                                    name = contact.displayName,
                                    avatarPath = contact.avatarPath,
                                    size = 42.dp,
                                    isOnline = isNearby || isInternetAvailable,
                                    showPresence = !isSelf
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    if (isSelf) "Saved Notes" else contact.displayName,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (isChatLocked) {
                                        Text(
                                            "PIN protected · re-locks on exit",
                                            fontSize = 11.sp,
                                            color = chatColors.presenceOnline,
                                            fontWeight = FontWeight.Medium
                                        )
                                    } else if (contact.isGroup) {
                                        Text(
                                            "${contact.groupMemberPubKeyHexes.size} members · End-to-end encrypted fan-out",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    } else if (isPeerTyping) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            com.example.ui.components.AnimatedTypingDots(
                                                dotColor = chatColors.presenceOnline,
                                                reduceMotion = reduceMotion
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                "typing…",
                                                fontSize = 11.sp,
                                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                                color = chatColors.presenceOnline,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when {
                                                        isSelf -> chatColors.presenceOnline
                                                        isNearby -> chatColors.presenceOnline
                                                        isInternetAvailable -> chatColors.presenceAway
                                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                    }
                                                )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = when {
                                                isSelf -> "Encrypted personal vault"
                                                isNearby -> "Online · direct mesh link"
                                                isInternetAvailable -> "Online · E2EE relay"
                                                else -> "Offline · messages queue"
                                            },
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                navigationIcon = {
                    FolkIconButton(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        onClick = {
                            if (searchOpen) {
                                searchOpen = false
                                searchQuery = ""
                            } else onBack()
                        },
                        reduceMotion = reduceMotion,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    )
                },
                actions = {
                    if (!isSelf) {
                        FolkIconButton(
                            icon = Icons.Default.Search,
                            contentDescription = "Search messages",
                            onClick = { searchOpen = !searchOpen; if (!searchOpen) searchQuery = "" },
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.48f),
                            contentColor = MaterialTheme.colorScheme.primary,
                            reduceMotion = reduceMotion
                        )
                        if (onStartCall != null && !contact.isGroup) {
                            FolkIconButton(
                                icon = Icons.Default.Call,
                                contentDescription = "Voice call",
                                onClick = { onStartCall(contact, false) },
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
                                contentColor = MaterialTheme.colorScheme.primary,
                                reduceMotion = reduceMotion
                            )
                            FolkIconButton(
                                icon = Icons.Default.Videocam,
                                contentDescription = "Video call",
                                onClick = { onStartCall(contact, true) },
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
                                contentColor = MaterialTheme.colorScheme.primary,
                                reduceMotion = reduceMotion
                            )
                        }
                    }

                    Box {
                        FolkIconButton(
                            icon = Icons.Default.MoreVert,
                            contentDescription = "More options",
                            onClick = { showMenu = true },
                            reduceMotion = reduceMotion
                        )
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            if (!contact.isGroup) {
                                DropdownMenuItem(
                                    text = { Text("View profile & safety number") },
                                    onClick = { showMenu = false; onOpenContactProfile() }
                                )
                            } else {
                                DropdownMenuItem(
                                    text = { Text("Group details") },
                                    onClick = { showMenu = false; showQueueInfoBanner = true }
                                )
                            }
                            if (onLockChat != null && !isSelf) {
                                DropdownMenuItem(
                                    text = { Text(if (isChatLocked) "Lock this chat now" else "Lock this chat") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    onClick = { showMenu = false; onLockChat() }
                                )
                            }
                            if (!isSelf) {
                                DropdownMenuItem(
                                    text = { Text("Search messages") },
                                    onClick = { showMenu = false; searchOpen = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Disappearing messages") },
                                    onClick = { showMenu = false; showDisappearSheet = true }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Why messages are queued") },
                                onClick = { showMenu = false; showQueueInfoBanner = !showQueueInfoBanner }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = chatColors.topBar)
            )
        }
    ) { padding ->
        // Canvas backdrop is user-customizable: solid, gentle wash, folk dots,
        // animated aurora, fine grid, warm paper or radial bloom.
        val wallpaper = LocalChatCustomization.current.chatWallpaper
        val canvasBrush = when (wallpaper) {
            ChatWallpaper.NONE, ChatWallpaper.GRID, ChatWallpaper.PAPER, ChatWallpaper.AURORA, ChatWallpaper.BLOOM -> Brush.verticalGradient(
                listOf(
                    MaterialTheme.colorScheme.background,
                    MaterialTheme.colorScheme.background
                )
            )
            ChatWallpaper.WASH, ChatWallpaper.DOTS -> Brush.verticalGradient(
                colors = listOf(
                    MaterialTheme.colorScheme.background,
                    chatColors.searchField.copy(alpha = 0.17f),
                    MaterialTheme.colorScheme.background
                )
            )
        }

        // Aurora drifts slowly through two soft brand-tinted blobs. Static (and
        // cheap) when reduce-motion is on or the wallpaper is not aurora.
        val auroraPhase: State<Float> = if (wallpaper == ChatWallpaper.AURORA && !reduceMotion) {
            rememberInfiniteTransition(label = "auroraDrift").animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(durationMillis = 14000, easing = LinearEasing)),
                label = "auroraPhase"
            )
        } else {
            remember { mutableStateOf(0.6f) }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(canvasBrush)
                .drawBehind {
                    when (wallpaper) {
                        ChatWallpaper.DOTS -> {
                            // Quiet, low-contrast dot texture inspired by modern messenger wallpapers.
                            // It is deliberately non-interactive and uses the existing brand palette.
                            val step = 34.dp.toPx()
                            val dotRadius = 0.85.dp.toPx()
                            val dotColor = chatColors.textMuted.copy(alpha = 0.075f)
                            var x = step * 0.5f
                            while (x < size.width) {
                                var y = step * 0.5f
                                while (y < size.height) {
                                    drawCircle(color = dotColor, radius = dotRadius, center = Offset(x, y))
                                    y += step
                                }
                                x += step
                            }
                        }
                        ChatWallpaper.GRID -> {
                            // Fine engineering grid, whisper-quiet.
                            val step = 26.dp.toPx()
                            val lineColor = chatColors.textMuted.copy(alpha = 0.055f)
                            var x = 0f
                            while (x < size.width) {
                                drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), 0.8f)
                                x += step
                            }
                            var y = 0f
                            while (y < size.height) {
                                drawLine(lineColor, Offset(0f, y), Offset(size.width, y), 0.8f)
                                y += step
                            }
                        }
                        ChatWallpaper.PAPER -> {
                            // Warm paper: diagonal hatch with a soft wash overlay.
                            val step = 23.dp.toPx()
                            val lineColor = chatColors.textMuted.copy(alpha = 0.06f)
                            drawRect(Brush.verticalGradient(listOf(chatColors.searchField.copy(alpha = 0.10f), Color.Transparent)))
                            var d = -size.height
                            while (d < size.width) {
                                drawLine(lineColor, Offset(d, 0f), Offset(d + size.height, size.height), 0.9f)
                                d += step
                            }
                        }
                        ChatWallpaper.AURORA -> {
                            val phase = auroraPhase.value
                            val drift = phase * 2f * PI.toFloat()
                            val accentA = chatColors.primaryBrand.copy(alpha = 0.10f)
                            val accentB = chatColors.sageAccent.copy(alpha = 0.08f)
                            val r1 = size.width * 0.62f
                            val c1 = Offset(
                                size.width * (0.30f + 0.22f * sin(drift)),
                                size.height * (0.24f + 0.10f * cos(drift * 1.3f))
                            )
                            drawCircle(
                                brush = Brush.radialGradient(colors = listOf(accentA, Color.Transparent), center = c1, radius = r1),
                                radius = r1,
                                center = c1
                            )
                            val r2 = size.width * 0.55f
                            val c2 = Offset(
                                size.width * (0.72f + 0.18f * sin(drift + PI.toFloat())),
                                size.height * (0.72f + 0.09f * cos(drift * 0.7f))
                            )
                            drawCircle(
                                brush = Brush.radialGradient(colors = listOf(accentB, Color.Transparent), center = c2, radius = r2),
                                radius = r2,
                                center = c2
                            )
                        }
                        ChatWallpaper.BLOOM -> {
                            // Two fixed radial blooms hugging opposite corners.
                            val r1 = size.width * 0.75f
                            val c1 = Offset(size.width * 0.12f, size.height * 0.16f)
                            drawCircle(
                                brush = Brush.radialGradient(colors = listOf(chatColors.primaryBrand.copy(alpha = 0.09f), Color.Transparent), center = c1, radius = r1),
                                radius = r1,
                                center = c1
                            )
                            val r2 = size.width * 0.65f
                            val c2 = Offset(size.width * 0.88f, size.height * 0.86f)
                            drawCircle(
                                brush = Brush.radialGradient(colors = listOf(chatColors.sageAccent.copy(alpha = 0.07f), Color.Transparent), center = c2, radius = r2),
                                radius = r2,
                                center = c2
                            )
                        }
                        else -> Unit
                    }
                }
                .padding(padding)
                .imePadding()
        ) {
            AnimatedVisibility(
                visible = hasQueuedMessages || showQueueInfoBanner,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, FolkWarning.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = FolkWarning, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Message queued in encrypted local outbox. FolkChat will auto-deliver it over BLE/LAN as soon as this peer comes into range.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 15.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (searchOpen && searchQuery.isNotBlank()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "${displayMessages.size} match${if (displayMessages.size == 1) "" else "es"}",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            val pinnedMessages = remember(messages) { messages.filter { it.isPinned && !it.isDeleted } }

            if (pinnedMessages.isNotEmpty() && searchQuery.isBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(14.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.PushPin,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = pinnedMessages.last().previewText,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (displayMessages.isEmpty() && searchQuery.isNotBlank()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No messages match \"$searchQuery\"",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, chatColors.borderSubtle),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = chatColors.sageAccent, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Private conversation · Encrypted messages",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    items(chatListItems, key = { 
                        when (it) {
                            is ChatListItem.DayDivider -> "divider_${it.label}_${it.hashCode()}"
                            is ChatListItem.MessageItem -> it.message.id
                        }
                    }) { listItem ->
                        when (listItem) {
                            is ChatListItem.DayDivider -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = listItem.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(chatColors.searchField)
                                            .border(1.dp, chatColors.borderSubtle.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
                                            .padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }
                            }
                            is ChatListItem.MessageItem -> {
                                val message = listItem.message
                                if (message.isSystemEvent) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = message.systemEvent ?: "",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(chatColors.searchField)
                                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                        )
                                    }
                                } else {
                                    // Fresh messages (both directions) settle into place with a
                                    // gentle rise+fade; history scrolled back stays static.
                                    val messageIsFresh = remember(message.id) {
                                        System.currentTimeMillis() - message.timestampMs < 9000L
                                    }
                                    val appear = remember(message.id) {
                                        Animatable(if (messageIsFresh && !reduceMotion) 0f else 1f)
                                    }
                                    LaunchedEffect(message.id) {
                                        if (appear.value < 1f) appear.animateTo(1f, tween(durationMillis = 340, easing = FastOutSlowInEasing))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .then(if (reduceMotion) Modifier else Modifier.animateItem())
                                            .graphicsLayer {
                                                alpha = appear.value
                                                translationY = (1f - appear.value) * 16f
                                            }
                                    ) {
                                    MessageBubble(
                                        message = message,
                                        highlight = searchQuery,
                                        isSelfNotes = isSelf,
                                        peerLastReadMs = peerLastReadMs,
                                        readReceiptsEnabled = readReceiptsEnabled,
                                        compact = compactChat,
                                        reduceMotion = reduceMotion,
                                        onReply = { replyTarget = message; editTarget = null },
                                        onEdit = { editTarget = message; replyTarget = null },
                                        onCopy = { clipboardManager.setText(AnnotatedString(message.previewText)) },
                                        onDeleteLocal = { onDeleteMessage(message.id) },
                                        onDeleteForAll = { onDeleteForEveryone?.invoke(message.id) ?: onDeleteMessage(message.id) },
                                        onPin = { onTogglePin?.invoke(message.id) },
                                        onStar = { onToggleStar?.invoke(message.id) },
                                        onForward = { forwardTarget = message },
                                        onReact = { emoji -> onToggleReaction?.invoke(message.id, emoji) },
                                        onPickReaction = { reactionTarget = message },
                                        onOpenViewOnce = { viewOnceTarget = message },
                                        onResend = { onResendMessage?.invoke(message.id) },
                                        resolveLocalFile = resolveLocalFile,
                                        onOpenAttachment = { attachment, file -> fileViewer = attachment to file },
                                        onCancelTransfer = { onCancelTransfer?.invoke(message.id) },
                                        onRetryTransfer = { onRetryTransfer?.invoke(message.id) }
                                    )
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(8.dp)) }
                }
            }

            // Edit / reply context strip
            val contextMessage = editTarget ?: replyTarget
            AnimatedVisibility(visible = contextMessage != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, chatColors.borderSubtle),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (editTarget != null) Icons.Default.Edit else Icons.Default.Reply,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                if (editTarget != null) "Editing message"
                                else "Replying to ${contextMessage?.let { if (it.isOutgoing) "yourself" else contact.displayName }}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                contextMessage?.previewText.orEmpty(),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = {
                            if (editTarget != null) { editTarget = null; inputText = "" }
                            replyTarget = null
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            voiceError?.let { error ->
                Text(
                    text = error,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp
                )
            }

            AnimatedVisibility(visible = recording || recordElapsedMs > 0L) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = FolkError.copy(alpha = 0.12f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size((6f + micPulse * 4f).dp)
                                .clip(CircleShape)
                                .background(FolkError)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recording voice message… ${formatDurationShort(recordElapsedMs)}",
                            fontSize = 12.sp,
                            color = FolkError,
                            modifier = Modifier.weight(1f)
                        )
                        Row(
                            modifier = Modifier.height(22.dp).padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(5) { bar ->
                                Box(
                                    modifier = Modifier
                                        .width(3.dp)
                                        .height((4f + micPulse * (7f + (bar % 3) * 3f)).dp)
                                        .clip(CircleShape)
                                        .background(FolkError.copy(alpha = 0.55f + micPulse * 0.4f))
                                )
                            }
                        }
                        Text(
                            "Cancel",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.clickable { discardRecording() }.padding(4.dp)
                        )
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), clip = false)
                    .border(
                        1.dp,
                        chatColors.borderSubtle,
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                    )
                    .animateContentSize(tween(durationMillis = if (reduceMotion) 0 else 180))
                    .navigationBarsPadding(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                color = chatColors.topBar,
                tonalElevation = 5.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isSelf && !contact.isGroup && onSendAttachment != null) {
                        FolkIconButton(
                            icon = Icons.Default.AttachFile,
                            contentDescription = "Attach file or media",
                            onClick = { showAttachSheet = true },
                            size = 44.dp,
                            iconSize = 22.dp,
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f),
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            reduceMotion = reduceMotion
                        )
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { 
                            inputText = it
                            onDraftChange?.invoke(it)
                            // IME composition is real user activity: keep the
                            // app-lock idle countdown alive while typing.
                            onUserActivity?.invoke()
                            if (it.isNotBlank()) onTypingSignal?.invoke()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTagCompat("chat_input_text_field"),
                        placeholder = {
                            Text(
                                when {
                                    editTarget != null -> "Edit message…"
                                    isSelf -> "Write a private note..."
                                    else -> "Message..."
                                },
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = chatColors.searchField,
                            unfocusedContainerColor = chatColors.searchField,
                            focusedBorderColor = chatColors.sageAccent,
                            unfocusedBorderColor = chatColors.borderSubtle
                        ),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    FilledIconButton(
                        onClick = {
                            if (recording) {
                                stopRecordingAndSend()
                            } else if (editTarget != null || inputText.isNotBlank()) {
                                submitMessage()
                            } else {
                                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                if (hasMic) startRecording() else {
                                    onExternalActivityLaunch?.invoke()
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = composerActionColor,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(17.dp),
                        modifier = Modifier
                            .size(50.dp)
                            .testTagCompat("chat_send_button")
                            .graphicsLayer {
                                val scale = if (recording) 1.02f + micPulse * 0.10f else 1f
                                scaleX = scale
                                scaleY = scale
                            }
                    ) {
                        AnimatedContent(
                            targetState = composerActionIcon,
                            transitionSpec = {
                                if (reduceMotion) {
                                    fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                                } else {
                                    (fadeIn(tween(130)) + slideInVertically(tween(160)) { it / 3 }) togetherWith
                                        (fadeOut(tween(90)) + slideOutVertically(tween(140)) { -it / 3 })
                                }
                            },
                            label = "composerActionIconTransition"
                        ) { actionIcon ->
                            Icon(
                                imageVector = actionIcon,
                                contentDescription = composerActionDescription,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAttachSheet && onSendAttachment != null) {
        AttachmentSheet(
            onDismiss = { showAttachSheet = false },
            onExternalActivityLaunch = { onExternalActivityLaunch?.invoke() },
            onExternalActivityResult = { onExternalActivityResult?.invoke() },
            onSend = { attachment ->
                onSendAttachment(attachment, inputText.trim())
                inputText = ""
                onDraftChange?.invoke("")
                showAttachSheet = false
            }
        )
    }

    reactionTarget?.let { target ->
        ReactionPickerSheet(
            onDismiss = { reactionTarget = null },
            onPick = { emoji ->
                onToggleReaction?.invoke(target.id, emoji)
                reactionTarget = null
            }
        )
    }

    // Forward picker
    forwardTarget?.let { target ->
        ForwardMessageDialog(
            contacts = contactsForForward.filter { it.id != "self_notes" && !it.isGroup },
            onForward = { targetContact ->
                onForward?.invoke(target.id, targetContact.x25519PublicKeyHex)
                forwardTarget = null
            },
            onDismiss = { forwardTarget = null }
        )
    }

    // View-once / view-twice media viewer
    viewOnceTarget?.let { target ->
        ViewOnceMediaDialog(
            message = target,
            resolveLocalFile = resolveLocalFile,
            onDismiss = {
                val local = resolveLocalFile?.invoke(target.attachment)
                if (local?.isFile == true) onConsumeView?.invoke(target.id)
                viewOnceTarget = null
            }
        )
    }

    // Disappearing messages timer picker
    if (showDisappearSheet) {
        DisappearTimerSheet(
            currentSeconds = contact.disappearAfterSec,
            onSelect = { timer ->
                onSetDisappearTimer?.invoke(timer)
                showDisappearSheet = false
            },
            onDismiss = { showDisappearSheet = false }
        )
    }

    fileViewer?.let { (attachment, file) ->
        InAppFileViewerDialog(
            attachment = attachment,
            file = file,
            onDismiss = { fileViewer = null },
            onOpenExternally = {
                try {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, attachment.mimeType)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Open file"))
                } catch (_: Exception) {
                    android.widget.Toast.makeText(context, "No compatible app found for this file.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

private fun Modifier.testTagCompat(tag: String): Modifier = this.then(
    Modifier.testTag(tag)
)

// ------------------------------------------------------------------
// Message bubble
// ------------------------------------------------------------------

@Composable
private fun MessageBubble(
    message: ChatMessage,
    highlight: String,
    isSelfNotes: Boolean,
    peerLastReadMs: Long = 0L,
    readReceiptsEnabled: Boolean = true,
    compact: Boolean = false,
    reduceMotion: Boolean = false,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onDeleteLocal: () -> Unit,
    onDeleteForAll: () -> Unit,
    onPin: () -> Unit,
    onStar: () -> Unit,
    onForward: () -> Unit,
    onReact: (String) -> Unit,
    onPickReaction: () -> Unit,
    onOpenViewOnce: () -> Unit,
    onResend: (() -> Unit)? = null,
    resolveLocalFile: ((MediaAttachment?) -> File?)?,
    onOpenAttachment: (MediaAttachment, File) -> Unit,
    onCancelTransfer: () -> Unit,
    onRetryTransfer: () -> Unit
) {
    val chatColors = LocalChatColors.current
    val customization = LocalChatCustomization.current
    var showMenu by remember { mutableStateOf(false) }

    val isOutgoing = message.isOutgoing
    val alignment = if (isOutgoing) Alignment.End else Alignment.Start
    val bubbleBg = if (isOutgoing) chatColors.outgoingBubbleBg else chatColors.incomingBubbleBg
    val metaColor = if (isOutgoing) chatColors.outgoingMeta else chatColors.incomingMeta
    val contentColor = if (isOutgoing) chatColors.outgoingText else chatColors.incomingText

    // User-selected bubble silhouette.
    val bubbleShape = when (customization.bubbleStyle) {
        BubbleStyle.CLASSIC -> RoundedCornerShape(
            topStart = 18.dp,
            topEnd = 18.dp,
            bottomStart = if (isOutgoing) 18.dp else 4.dp,
            bottomEnd = if (isOutgoing) 4.dp else 18.dp
        )
        BubbleStyle.MODERN -> RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 16.dp,
            bottomStart = if (isOutgoing) 16.dp else 7.dp,
            bottomEnd = if (isOutgoing) 7.dp else 16.dp
        )
        BubbleStyle.SQUIRCLE -> RoundedCornerShape(24.dp)
    }

    // Accessibility font scaling for the message body.
    val bodyFont = (14f * customization.fontScale).coerceIn(11f, 20f).sp
    val bodyLineHeight = (19f * customization.fontScale).coerceIn(15f, 27f).sp

    val att = message.attachment
    val isViewLimited = att?.isViewLimited == true
    val isViewExpired = att?.isViewExpired == true
    // Incoming view-limited media that has not been opened yet renders sealed.
    val isSealedViewOnce = !isOutgoing && isViewLimited && !isViewExpired &&
        att?.transferState == TransferState.COMPLETED

    val timeFormatted = remember(message.timestampMs) {
        SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestampMs))
    }

    val hPad = if (compact) 10.dp else 13.dp
    val vPad = if (compact) 6.dp else 9.dp

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        if (message.groupId != null && !isOutgoing && !message.isDeleted) {
            Text(
                text = message.senderDisplayName?.takeIf { it.isNotBlank() } ?: "Group member",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 8.dp, bottom = 2.dp)
            )
        }
        if (message.isPinned && !message.isDeleted) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 2.dp)
            ) {
                Icon(Icons.Default.PushPin, contentDescription = "Pinned", tint = chatColors.textMuted, modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("Pinned", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (message.isStarred) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(Icons.Default.Star, contentDescription = "Starred", tint = chatColors.statusWarning, modifier = Modifier.size(11.dp))
                }
            }
        }

        Box {
            Card(
                shape = bubbleShape,
                colors = CardDefaults.cardColors(containerColor = bubbleBg),
                border = androidx.compose.foundation.BorderStroke(
                    if (isOutgoing) 0.7.dp else 1.dp,
                    if (isOutgoing) chatColors.outgoingBubbleBorder.copy(alpha = 0.60f) else chatColors.incomingBubbleBorder
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (isOutgoing) 1.5.dp else 0.5.dp),
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .animateContentSize()
                    .pointerInput(message.id) {
                        detectTapGestures(
                            onLongPress = { showMenu = true },
                            onTap = {
                                // Tap opens sealed view-once media; otherwise no-op.
                                if (isSealedViewOnce) onOpenViewOnce()
                            }
                        )
                    }
            ) {
                Column(modifier = Modifier.padding(horizontal = hPad, vertical = vPad)) {
                    message.replyToPreview?.let { replyPreview ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isOutgoing) chatColors.outgoingBubbleBorder.copy(alpha = 0.45f) else chatColors.searchField,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (isOutgoing) chatColors.outgoingBubbleBorder.copy(alpha = 0.7f) else chatColors.borderSubtle,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(bottom = 6.dp)
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                Text(
                                    text = message.replyToSender ?: "",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isOutgoing) metaColor else MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = replyPreview,
                                    fontSize = 11.sp,
                                    color = if (isOutgoing) metaColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    if (message.isDeleted) {
                        Text(
                            text = "This message was deleted",
                            fontSize = 13.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = metaColor
                        )
                    } else if (isSealedViewOnce) {
                        // Sealed view-once media bubble
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isOutgoing) chatColors.outgoingBubbleBorder.copy(alpha = 0.4f) else chatColors.searchField)
                                .clickable { onOpenViewOnce() }
                                .padding(horizontal = 12.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                Icons.Default.Visibility,
                                contentDescription = null,
                                tint = if (isOutgoing) metaColor else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = when (att?.kind) {
                                        MediaKind.VIDEO -> if ((att?.viewLimit ?: 1) == 2) "View-twice video" else "View-once video"
                                        else -> if ((att?.viewLimit ?: 1) == 2) "View-twice photo" else "View-once photo"
                                    },
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = contentColor
                                )
                                Text(
                                    text = "Tap to view · " + (att?.remainingViews ?: 1) + " of " + (att?.viewLimit ?: 1) + " views left",
                                    fontSize = 11.sp,
                                    color = metaColor
                                )
                            }
                        }
                    } else if (isViewLimited && isViewExpired) {
                        // Expired view-once: content destroyed on this device.
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = metaColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isOutgoing) "View-limited media viewed" else "Media expired after viewing",
                                fontSize = 12.sp,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                color = metaColor
                            )
                        }
                    } else {
                        // Incoming view-limited media that has not finished downloading must still
                        // show the progress/Download UI. Previously the not-yet-downloaded
                        // view-once bubble rendered nothing at all, leaving no way to fetch it.
                        val showAttachmentUi = message.attachment != null && (
                            !isViewLimited || isOutgoing ||
                                message.attachment?.transferState != TransferState.COMPLETED
                            )
                        if (showAttachmentUi) {
                            Box {
                                AttachmentContentView(
                                    attachment = message.attachment,
                                    resolveLocalFile = resolveLocalFile,
                                    isOutgoing = isOutgoing,
                                    reduceMotion = reduceMotion,
                                    onOpenAttachment = onOpenAttachment,
                                    onCancelTransfer = onCancelTransfer,
                                    onRetryTransfer = onRetryTransfer
                                )
                                if (isViewLimited && isOutgoing) {
                                    // Sender-side: badge over the local preview copy.
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(chatColors.scrim)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = chatColors.outgoingText,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            " " + (att?.viewLimit ?: 1),
                                            fontSize = 10.sp,
                                            color = chatColors.outgoingText,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        if (message.content.isNotBlank()) {
                            if (highlight.isNotBlank() && message.content.contains(highlight, ignoreCase = true)) {
                                val annotated = remember(message.content, highlight) {
                                    buildAnnotatedHighlight(message.content, highlight)
                                }
                                Text(
                                    text = annotated,
                                    fontSize = bodyFont,
                                    color = contentColor,
                                    lineHeight = bodyLineHeight
                                )
                            } else {
                                Text(
                                    text = message.content,
                                    fontSize = bodyFont,
                                    color = contentColor,
                                    lineHeight = bodyLineHeight
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (message.isStarred && !message.isPinned) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = "Starred",
                                tint = metaColor,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        if (message.isEdited && !message.isDeleted) {
                            Text("edited", fontSize = 9.sp, color = metaColor)
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = timeFormatted,
                            fontSize = 10.sp,
                            color = metaColor
                        )

                        if (isOutgoing && !isSelfNotes) {
                            Spacer(modifier = Modifier.width(4.dp))
                            val isRead = readReceiptsEnabled && peerLastReadMs > 0 &&
                                message.timestampMs <= peerLastReadMs
                            when (message.status) {
                                MessageStatus.QUEUED -> Icon(
                                    Icons.Default.AccessTime, "Queued",
                                    tint = metaColor, modifier = Modifier.size(12.dp)
                                )
                                MessageStatus.SENDING -> Icon(
                                    Icons.Default.Check, "Sending",
                                    tint = metaColor, modifier = Modifier.size(12.dp)
                                )
                                MessageStatus.DELIVERED -> Icon(
                                    Icons.Default.DoneAll,
                                    if (isRead) "Read" else "Delivered",
                                    tint = if (isRead) chatColors.statusSuccess else metaColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                MessageStatus.FAILED -> Icon(
                                    Icons.Default.ErrorOutline, "Failed",
                                    tint = chatColors.statusError,
                                    modifier = Modifier
                                        .size(13.dp)
                                        // A failed text message has no other affordance; the tick
                                        // itself offers one-tap resend when a handler is wired.
                                        .let { m ->
                                            if (onResend != null && message.attachment == null) {
                                                m.clip(RoundedCornerShape(6.dp)).clickable { onResend.invoke() }.padding(2.dp)
                                            } else m
                                        }
                                )
                            }
                        }
                    }
                }
            }

            if (message.reactions.isNotEmpty() && !message.isDeleted) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = 12.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
                        message.reactions.forEach { (emoji, senders) ->
                            Text(
                                text = "$emoji ${senders.size}",
                                fontSize = 11.sp,
                                color = if (senders.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onReact(emoji) }
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                if (!message.isDeleted) {
                    DropdownMenuItem(
                        text = { Text("Reply") },
                        leadingIcon = { Icon(Icons.Default.Reply, contentDescription = null) },
                        onClick = { onReply(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("React") },
                        leadingIcon = { Icon(Icons.Default.EmojiEmotions, contentDescription = null) },
                        onClick = { onPickReaction(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Forward") },
                        leadingIcon = { Icon(Icons.Default.Shortcut, contentDescription = null) },
                        onClick = { onForward(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(if (message.isStarred) "Unstar" else "Star") },
                        leadingIcon = { Icon(Icons.Default.Star, contentDescription = null) },
                        onClick = { onStar(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Copy") },
                        leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                        onClick = { onCopy(); showMenu = false }
                    )
                    if (isOutgoing && message.attachment == null && message.content.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = { onEdit(); showMenu = false }
                        )
                    }
                    if (isOutgoing && message.status == MessageStatus.FAILED &&
                        message.attachment == null && onResend != null) {
                        DropdownMenuItem(
                            text = { Text("Resend") },
                            leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) },
                            onClick = { onResend.invoke(); showMenu = false }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (message.isPinned) "Unpin" else "Pin") },
                        leadingIcon = { Icon(Icons.Default.PushPin, contentDescription = null) },
                        onClick = { onPin(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete for me", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        onClick = { onDeleteLocal(); showMenu = false }
                    )
                    if (isOutgoing) {
                        DropdownMenuItem(
                            text = { Text("Delete for everyone", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = { onDeleteForAll(); showMenu = false }
                        )
                    }
                }
            }
        }
    }
}

private fun buildAnnotatedHighlight(text: String, query: String): AnnotatedString {
    val builder = AnnotatedString.Builder()
    var index = text.indexOf(query, ignoreCase = true)
    if (index < 0) {
        builder.append(text)
        return builder.toAnnotatedString()
    }
    var last = 0
    while (index >= 0) {
        builder.append(text.substring(last, index))
        builder.pushStyle(androidx.compose.ui.text.SpanStyle(background = FolkWarning.copy(alpha = 0.45f)))
        builder.append(text.substring(index, index + query.length))
        builder.pop()
        last = index + query.length
        index = text.indexOf(query, startIndex = last, ignoreCase = true)
    }
    builder.append(text.substring(last))
    return builder.toAnnotatedString()
}

// ------------------------------------------------------------------
// Attachments
// ------------------------------------------------------------------

@Composable
private fun AttachmentContentView(
    attachment: MediaAttachment,
    resolveLocalFile: ((MediaAttachment?) -> File?)?,
    isOutgoing: Boolean,
    reduceMotion: Boolean,
    onOpenAttachment: (MediaAttachment, File) -> Unit,
    onCancelTransfer: () -> Unit,
    onRetryTransfer: () -> Unit
) {
    val context = LocalContext.current
    val chatColors = LocalChatColors.current
    val file = remember(attachment.localPath, attachment.transferState) {
        resolveLocalFile?.invoke(attachment)
    }
    val animatedProgress by animateFloatAsState(
        targetValue = attachment.progress.coerceIn(0f, 1f),
        animationSpec = if (reduceMotion) snap() else tween(durationMillis = 260, easing = FastOutSlowInEasing),
        label = "attachment-transfer-progress"
    )

    when (attachment.transferState) {
        TransferState.PENDING, TransferState.IN_PROGRESS -> {
            Column(
                modifier = Modifier
                    .widthIn(min = 200.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isOutgoing) chatColors.sageAccent.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant)
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "${if (isOutgoing) "Sending" else "Downloading"} ${(attachment.progress * 100).toInt()}%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = animatedProgress,
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCancelTransfer, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", modifier = Modifier.size(16.dp), tint = FolkError)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        attachment.fileName,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        TransferState.FAILED, TransferState.CANCELLED -> {
            Column(
                modifier = Modifier
                    .widthIn(min = 200.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(FolkError.copy(alpha = 0.12f))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = FolkError, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        attachment.error ?: "Transfer failed",
                        fontSize = 11.sp,
                        color = FolkError,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    // Any failed incoming attachment is retryable: the download pipeline
                    // (requestIncomingDownload) re-validates the contact and consent itself, so
                    // showing Download is always safe. Previously media that arrived before a
                    // message request was accepted stayed stuck with no retry path at all, and
                    // only errors containing "tap Download" showed the button.
                    val canManuallyDownload = !isOutgoing && attachment.transferState == TransferState.FAILED
                    if (attachment.transferState == TransferState.CANCELLED || isOutgoing || canManuallyDownload) {
                        Text(
                            if (canManuallyDownload) "Download" else "Retry",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { onRetryTransfer() }.padding(end = 14.dp)
                        )
                    }
                    Text(
                        "Cancel",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = FolkError,
                        modifier = Modifier.clickable { onCancelTransfer() }
                    )
                }
            }
        }
        TransferState.COMPLETED -> {
            when (attachment.kind) {
                MediaKind.IMAGE -> {
                    if (file != null) {
                        AsyncImage(
                            model = file,
                            contentDescription = attachment.fileName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .widthIn(max = 260.dp)
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onOpenAttachment(attachment, file) }
                        )
                    } else {
                        MediaUnavailableBox(attachment, "Image not downloaded")
                    }
                }
                MediaKind.VIDEO -> {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 260.dp)
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(chatColors.primaryBrand.copy(alpha = 0.85f))
                    ) {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play video",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                attachment.fileName,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp)
                            )
                        }
                        if (file != null) {
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .clickable { onOpenAttachment(attachment, file) }
                            )
                        }
                    }
                }
                MediaKind.DOCUMENT -> {
                    Row(
                        modifier = Modifier
                            .widthIn(min = 230.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(10.dp)
                            .clickable(enabled = file != null) {
                                file?.let { onOpenAttachment(attachment, it) }
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FileCopy, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                attachment.fileName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                formatBytes(attachment.sizeBytes),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                MediaKind.VOICE -> VoiceNotePlayer(attachment, file, isOutgoing)
            }
        }
    }
}

@Composable
private fun MediaUnavailableBox(attachment: MediaAttachment, reason: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.widthIn(min = 180.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = FolkWarning, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("$reason — ${attachment.fileName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun VoiceNotePlayer(
    attachment: MediaAttachment,
    file: File?,
    isOutgoing: Boolean
) {
    var playing by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var progress by remember { mutableFloatStateOf(0f) }
    var playerError by remember { mutableStateOf<String?>(null) }
    val chatColors = LocalChatColors.current
    val sourcePath = file?.absolutePath ?: attachment.localPath
    val sourceExists = !sourcePath.isNullOrBlank() && File(sourcePath).exists()
    val player = remember(sourcePath) {
        if (sourceExists) {
            try { MediaPlayer() } catch (_: Exception) { null }
        } else null
    }
    var prepared by remember(sourcePath) { mutableStateOf(false) }

    DisposableEffect(player) {
        onDispose {
            try { player?.release() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(player) {
        val p = player ?: return@LaunchedEffect
        if (!prepared) {
            try {
                p.setDataSource(sourcePath)
                p.setOnPreparedListener {
                    prepared = true
                    playerError = null
                }
                p.setOnCompletionListener { playing = false; positionMs = 0L; progress = 0f }
                p.setOnErrorListener { _, what, extra ->
                    // Real MediaPlayer failures (bad container, I/O error) previously left
                    // the play button dead with zero feedback.
                    playerError = "Playback failed ($what/$extra); the recording may be damaged."
                    playing = false
                    true
                }
                p.prepareAsync()
            } catch (_: Exception) {
                playerError = "Couldn't open this voice message on this device."
            }
        }
    }

    LaunchedEffect(playing, player) {
        val p = player ?: return@LaunchedEffect
        while (playing) {
            try {
                positionMs = p.currentPosition.toLong()
                val total = p.duration
                progress = if (total > 0) positionMs.toFloat() / total.toFloat() else 0f
                if (!p.isPlaying) { playing = false; break }
            } catch (_: Exception) { break }
            delay(250)
        }
    }

    Row(
        modifier = Modifier
            .widthIn(min = 210.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (isOutgoing) chatColors.sageAccent.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (sourceExists) chatColors.primaryBrand else MaterialTheme.colorScheme.outline)
                .clickable {
                    val p = player ?: return@clickable
                    if (!prepared) return@clickable // still buffering; ignore taps
                    try {
                        if (playing) { p.pause(); playing = false }
                        else { p.start(); playing = true }
                    } catch (_: Exception) {
                        playing = false
                        playerError = "Playback failed; try tapping play again."
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (playing) "Pause" else "Play",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Voice message", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(4.dp)
                        .background(chatColors.primaryBrand)
                )
            }
            Text(
                playerError
                    ?: if (!sourceExists) "Not available on this device yet"
                    else if (!prepared) "Preparing…"
                    else formatDurationShort(positionMs),
                fontSize = 10.sp,
                color = if (playerError != null) FolkError else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ------------------------------------------------------------------
// Attachment picker sheet
// ------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AttachmentSheet(
    onDismiss: () -> Unit,
    onExternalActivityLaunch: () -> Unit,
    onExternalActivityResult: () -> Unit,
    onSend: (MediaAttachment) -> Unit
) {
    val context = LocalContext.current
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var viewLimit by remember { mutableStateOf(0) } // 0 normal, 1 once, 2 twice
    var attachmentError by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) pendingUri = uri
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) pendingUri = uri
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) pendingUri = uri
    }

    LaunchedEffect(pendingUri) {
        val uri = pendingUri ?: return@LaunchedEffect
        attachmentError = null
        try {
            // Copy on IO; surface the precise failure instead of silently swallowing it.
            val attachment = withContext(Dispatchers.IO) { buildAttachmentFromUri(context, uri) }
            pendingUri = null
            val supportsViewLimit = attachment.kind == MediaKind.IMAGE || attachment.kind == MediaKind.VIDEO
            if (viewLimit > 0 && !supportsViewLimit) {
                android.widget.Toast.makeText(
                    context,
                    "View once/twice is available for photos and videos only; this file will be sent normally.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            onSend(attachment.copy(viewLimit = if (supportsViewLimit) viewLimit else 0))
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (failure: Exception) {
            pendingUri = null
            attachmentError = failure.message?.take(180) ?: "Could not read this file. Choose it again."
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(bottom = 20.dp)) {
            Text(
                "Share media",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            AnimatedVisibility(attachmentError != null, enter = fadeIn(), exit = fadeOut()) {
                Text(
                    attachmentError.orEmpty(),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    fontSize = 12.sp,
                    color = FolkError
                )
            }
            SheetRow(Icons.Default.PlayArrow, "Photo", "Send an image over the encrypted link") {
                onExternalActivityLaunch()
                imagePicker.launch(arrayOf("image/*"))
            }
            SheetRow(Icons.Default.Videocam, "Video", "Send an encrypted video") {
                onExternalActivityLaunch()
                videoPicker.launch(arrayOf("video/*"))
            }
            SheetRow(Icons.Default.FileCopy, "Document", "Send documents or large files in encrypted segments") {
                onExternalActivityLaunch()
                docPicker.launch(arrayOf("*/*"))
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "Photo & video privacy",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ViewLimitChip("Normal", viewLimit == 0) { viewLimit = 0 }
                ViewLimitChip("View once", viewLimit == 1) { viewLimit = 1 }
                ViewLimitChip("View twice", viewLimit == 2) { viewLimit = 2 }
            }
            Text(
                if (viewLimit == 0) "Media stays in the chat"
                else "Media disappears after " + (if (viewLimit == 1) "one view" else "two views"),
                modifier = Modifier.padding(horizontal = 20.dp),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun buildAttachmentFromUri(context: android.content.Context, uri: Uri): MediaAttachment {
    val resolver = context.contentResolver
    val mime = (resolver.getType(uri) ?: "application/octet-stream").substringBefore(';').trim().lowercase()
    var displayName = "attachment"
    var declaredSize = -1L
    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (nameIdx >= 0) displayName = cursor.getString(nameIdx)?.take(240) ?: displayName
            if (sizeIdx >= 0) declaredSize = cursor.getLong(sizeIdx)
        }
    }

    if (mime == "image/gif" || displayName.endsWith(".gif", ignoreCase = true)) {
        throw IllegalArgumentException("GIF files have been removed from FolkChat. Choose a photo or video instead.")
    }
    val maxFileBytes = 100L * 1024L * 1024L * 1024L
    if (declaredSize > maxFileBytes) throw IllegalArgumentException("Files larger than 100 GiB are not supported by this build")

    val kind = when {
        mime.startsWith("image/") -> MediaKind.IMAGE
        mime.startsWith("video/") -> MediaKind.VIDEO
        mime.startsWith("audio/") -> MediaKind.VOICE
        else -> MediaKind.DOCUMENT
    }
    val mediaDir = File(EncryptedVault.dataRootFor(context), "media").apply { if (!exists() && !mkdirs()) throw java.io.IOException("Could not create FolkChat media storage") }
    if (declaredSize > 0L && mediaDir.usableSpace < declaredSize + 64L * 1024L * 1024L) {
        throw java.io.IOException("Not enough free device storage to prepare this file")
    }

    var width = 0
    var height = 0
    if (kind == MediaKind.IMAGE) {
        val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
        width = opts.outWidth
        height = opts.outHeight
    }

    val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(180).ifBlank { "attachment" }
    val dest = File(mediaDir, "${UUID.randomUUID()}_${safeName}")
    try {
        var total = 0L
        val buffer = ByteArray(64 * 1024)
        val input = resolver.openInputStream(uri) ?: throw java.io.IOException("Android could not open the selected file")
        input.use { stream ->
            dest.outputStream().buffered(128 * 1024).use { output ->
                while (true) {
                    val read = stream.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    total += read
                    if (total > maxFileBytes) throw IllegalArgumentException("File exceeds FolkChat's 100 GiB app limit")
                    if (mediaDir.usableSpace < read.toLong() + 16L * 1024L * 1024L) {
                        throw java.io.IOException("Device storage is nearly full; free space and try again")
                    }
                    output.write(buffer, 0, read)
                }
                output.flush()
            }
        }
        buffer.fill(0)
        if (!dest.isFile || dest.length() == 0L) throw java.io.IOException("The selected file is empty or unreadable")

        // Check signatures too: some providers return a generic MIME type or a misleading filename.
        FileInputStream(dest).use { inputStream ->
            val signature = ByteArray(6)
            val got = inputStream.read(signature)
            val isGif = got >= 6 && String(signature, Charsets.US_ASCII).let { it == "GIF87a" || it == "GIF89a" }
            signature.fill(0)
            if (isGif) throw IllegalArgumentException("GIF files are no longer supported in FolkChat")
        }

        return MediaAttachment(
            id = UUID.randomUUID().toString(), kind = kind, fileName = displayName, mimeType = mime,
            sizeBytes = dest.length(), width = width, height = height, localPath = dest.absolutePath,
            transferState = TransferState.PENDING, progress = 0f
        )
    } catch (failure: Exception) {
        try { dest.delete() } catch (_: Exception) { }
        throw failure
    }
}

// ------------------------------------------------------------------
// Reaction picker
// ------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReactionPickerSheet(
    onDismiss: () -> Unit,
    onPick: (String) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            "React",
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            QUICK_REACTIONS.forEach { emoji ->
                Text(
                    text = emoji,
                    fontSize = 30.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { onPick(emoji) }
                        .padding(8.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
    }
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

private fun formatBytes(bytes: Long): String = when {
    bytes <= 0 -> "0 B"
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

private fun formatDurationShort(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}

// ---------------------------------------------------------------------
// v2: Forward / view-once viewer / disappearing timer sheet
// ---------------------------------------------------------------------

@Composable
private fun ForwardMessageDialog(
    contacts: List<Contact>,
    onForward: (Contact) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        title = { Text("Forward to", fontWeight = FontWeight.SemiBold) },
        text = {
            if (contacts.isEmpty()) {
                Text("Add more contacts to forward messages.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(
                    modifier = Modifier.height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(contacts, key = { it.x25519PublicKeyHex }) { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onForward(contact) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PeerAvatar(name = contact.displayName, avatarPath = contact.avatarPath, size = 38.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                contact.displayName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    )
}

/**
 * Full-screen viewer for view-once / view-twice media. Closing the viewer
 * consumes one view.
 */
@Composable
private fun ViewOnceMediaDialog(
    message: ChatMessage,
    resolveLocalFile: ((MediaAttachment?) -> File?)?,
    onDismiss: () -> Unit
) {
    val att = message.attachment ?: run { onDismiss(); return }
    val file = remember(att.localPath) { resolveLocalFile?.invoke(att) }
    var videoStarted by remember(message.id, file?.absolutePath) { mutableStateOf(false) }
    var videoFinished by remember(message.id, file?.absolutePath) { mutableStateOf(false) }
    var videoError by remember(message.id, file?.absolutePath) { mutableStateOf<String?>(null) }
    var activeVideoView by remember(message.id, file?.absolutePath) { mutableStateOf<android.widget.VideoView?>(null) }
    var videoScale by remember(message.id, file?.absolutePath) { mutableFloatStateOf(1f) }
    var closeHandled by remember(message.id, file?.absolutePath) { mutableStateOf(false) }
    // Both the toolbar button and Android's back/outside-dismiss path share this callback.
    // Consume a view at most once per dialog instance, even if the platform delivers duplicate
    // dismissal events during a recomposition/transition.
    val closeViewer: () -> Unit = {
        if (!closeHandled) {
            closeHandled = true
            onDismiss()
        }
    }

    DisposableEffect(message.id, file?.absolutePath) {
        onDispose {
            try { activeVideoView?.stopPlayback() } catch (_: Exception) { }
            activeVideoView = null
        }
    }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = closeViewer,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier.fillMaxSize().background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Visibility,
                        contentDescription = null,
                        tint = FolkSage,
                        modifier = Modifier.size(21.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (att.viewLimit == 2) "View-twice media" else "View-once media",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Text(
                            "${att.remainingViews.coerceAtLeast(0)} of ${att.viewLimit} views remaining",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.70f)
                        )
                    }
                    if (att.kind == MediaKind.VIDEO) {
                        IconButton(onClick = { videoScale = (videoScale - 0.25f).coerceAtLeast(1f) }) {
                            Icon(Icons.Default.Remove, contentDescription = "Zoom video out", tint = Color.White)
                        }
                        Text("${(videoScale * 100).toInt()}%", fontSize = 10.sp, color = Color.White)
                        IconButton(onClick = { videoScale = (videoScale + 0.25f).coerceAtMost(2.5f) }) {
                            Icon(Icons.Default.Add, contentDescription = "Zoom video in", tint = Color.White)
                        }
                    }
                    IconButton(onClick = closeViewer) {
                        Icon(Icons.Default.Close, contentDescription = "Close media", tint = Color.White)
                    }
                }

                Box(
                    modifier = Modifier.fillMaxWidth().weight(1f).clipToBounds().background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    when {
                        file != null && file.isFile && att.kind == MediaKind.IMAGE -> {
                            ZoomableMediaImage(
                                file = file,
                                contentDescription = "Private view-limited media",
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        file != null && file.isFile && att.kind == MediaKind.VIDEO -> {
                            if (videoStarted) {
                                androidx.compose.ui.viewinterop.AndroidView(
                                    factory = { viewContext ->
                                        android.widget.VideoView(viewContext).apply {
                                            activeVideoView = this
                                            val controller = android.widget.MediaController(viewContext)
                                            controller.setAnchorView(this)
                                            setMediaController(controller)
                                            setVideoURI(Uri.fromFile(file))
                                            setOnPreparedListener { player ->
                                                player.isLooping = false
                                                start()
                                            }
                                            setOnCompletionListener {
                                                videoFinished = true
                                                pause()
                                            }
                                            setOnErrorListener { _, what, extra ->
                                                videoError = "Video playback failed ($what/$extra). Close and retry the transfer if the file is damaged."
                                                true
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = videoScale; scaleY = videoScale }
                                )
                            } else {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(28.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(Color.White.copy(alpha = 0.08f))
                                        .clickable { videoStarted = true }
                                        .padding(vertical = 34.dp, horizontal = 20.dp),
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = "Play private video",
                                        tint = Color.White,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text("Tap to play", fontSize = 15.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text("This view is consumed when you close the viewer", fontSize = 12.sp, color = Color.White.copy(alpha = 0.72f), textAlign = TextAlign.Center)
                                }
                            }
                            if (videoError != null) {
                                Text(videoError.orEmpty(), color = FolkError, fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp))
                            } else if (videoFinished) {
                                Text("Video finished · close when done", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f), modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp))
                            }
                        }
                        else -> Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(28.dp)
                        ) {
                            Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(44.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("Media is no longer available on this device.", fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                        }
                    }
                }

                Text(
                    if (att.remainingViews > 1) "Close to use this view · ${att.remainingViews - 1} view(s) will remain"
                    else "Close to consume the final view and remove the local media",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.72f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DisappearTimerSheet(
    currentSeconds: Int,
    onSelect: (DisappearTimer) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(bottom = 28.dp)) {
            Text(
                "Disappearing messages",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "New messages vanish from both devices after the timer. Setting it here syncs to your peer.",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            DisappearTimer.entries.forEach { timer ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(timer) }
                        .padding(horizontal = 20.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.RadioButton(
                        selected = currentSeconds == timer.seconds,
                        onClick = { onSelect(timer) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        timer.label,
                        fontSize = 14.sp,
                        fontWeight = if (currentSeconds == timer.seconds) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun SheetRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ViewLimitChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
