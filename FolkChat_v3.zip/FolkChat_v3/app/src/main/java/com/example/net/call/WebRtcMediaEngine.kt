package com.example.net.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.crypto.CryptoEngine
import com.example.data.AppSettings
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * WebRTC media plane for WAN voice/video calls. Signaling is still sent through FolkChat's
 * authenticated, recipient-encrypted control transport. WebRTC negotiates ICE paths and uses
 * DTLS-SRTP for media encryption; TURN, when configured, forwards encrypted packets.
 *
 * STUN helps discover direct candidate paths; STUN alone cannot guarantee reachability through
 * every carrier/symmetric NAT. Relay-only mode intentionally fails closed unless a reachable TURN
 * service with valid credentials is configured.
 */
class WebRtcMediaEngine(
    context: Context,
    private val settingsProvider: () -> AppSettings,
    private val onLocalIceCandidate: (IceCandidate) -> Unit,
    private val onConnectionState: (PeerConnection.PeerConnectionState) -> Unit
) {
    companion object {
        private const val TAG = "FolkChatWebRTC"
        private val initLock = Any()
        @Volatile private var factoryInitialized = false
        private val DEFAULT_STUN_URLS = listOf(
            "stun:stun.l.google.com:19302",
            "stun:stun1.l.google.com:19302",
            "stun:stun2.l.google.com:19302"
        )
    }

    private val appContext = context.applicationContext
    private val eglBase: EglBase = EglBase.create()
    private val factory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var localAudio: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var localVideo: VideoTrack? = null
    private var cameraCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var callId: String? = null
    private var requestedVideo = false
    private var remoteDescriptionSet = false
    private var localCandidatesReleased = false
    private val pendingLocalCandidates = mutableListOf<IceCandidate>()
    private val pendingRemoteCandidates = ArrayDeque<IceCandidate>()
    private val disposed = AtomicBoolean(false)

    private val _localVideoTrack = MutableStateFlow<VideoTrack?>(null)
    val localVideoTrack: StateFlow<VideoTrack?> = _localVideoTrack.asStateFlow()
    private val _remoteVideoTrack = MutableStateFlow<VideoTrack?>(null)
    val remoteVideoTrack: StateFlow<VideoTrack?> = _remoteVideoTrack.asStateFlow()

    val eglBaseContext: EglBase.Context get() = eglBase.eglBaseContext

    init {
        synchronized(initLock) {
            if (!factoryInitialized) {
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(appContext)
                        .setEnableInternalTracer(false)
                        .createInitializationOptions()
                )
                factoryInitialized = true
            }
        }
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
    }

    suspend fun createOffer(callId: String, video: Boolean): String = withContext(Dispatchers.IO) {
        preparePeerConnection(callId, video)
        val pc = peerConnection ?: error("Could not create WebRTC peer connection")
        val offer = createDescription { observer -> pc.createOffer(observer, MediaConstraints()) }
        setLocalDescription(offer)
        offer.description
    }

    suspend fun createAnswer(
        callId: String,
        offerSdp: String,
        video: Boolean,
        receiveVideo: Boolean = video
    ): String = withContext(Dispatchers.IO) {
        requireValidSdp(offerSdp)
        preparePeerConnection(callId, video)
        val pc = peerConnection ?: error("Could not create WebRTC peer connection")
        // Camera permission controls whether this device sends camera frames, not whether it can
        // receive the other participant's video. Without a RECV_ONLY transceiver Android can
        // reject the offer's video m-line and both users end up with an audio-only call.
        if (receiveVideo && !video) {
            val existingVideoTransceiver = pc.transceivers.any {
                it.mediaType == MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO
            }
            if (!existingVideoTransceiver) {
                pc.addTransceiver(
                    MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO,
                    RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.RECV_ONLY)
                ) ?: throw IllegalStateException("Could not prepare incoming video track")
            }
        }
        setRemoteDescription(SessionDescription(SessionDescription.Type.OFFER, offerSdp))
        val answer = createDescription { observer -> pc.createAnswer(observer, MediaConstraints()) }
        setLocalDescription(answer)
        answer.description
    }

    suspend fun acceptAnswer(answerSdp: String) = withContext(Dispatchers.IO) {
        requireValidSdp(answerSdp)
        setRemoteDescription(SessionDescription(SessionDescription.Type.ANSWER, answerSdp))
    }

    /** Called only after the initial SDP signal has been submitted, preserving signaling order. */
    fun releaseLocalIceCandidates() {
        val ready = synchronized(pendingLocalCandidates) {
            localCandidatesReleased = true
            pendingLocalCandidates.toList().also { pendingLocalCandidates.clear() }
        }
        ready.forEach { candidate ->
            try { onLocalIceCandidate(candidate) } catch (e: Exception) { Log.w(TAG, "Could not publish ICE candidate", e) }
        }
    }

    fun addRemoteIceCandidate(sdpMid: String?, sdpMLineIndex: Int, candidate: String) {
        if (candidate.isBlank() || candidate.length > 4_096 || sdpMLineIndex !in 0..32) return
        val item = IceCandidate(sdpMid, sdpMLineIndex, candidate)
        val pc = peerConnection
        synchronized(pendingRemoteCandidates) {
            if (!remoteDescriptionSet || pc == null) {
                if (pendingRemoteCandidates.size < 256) pendingRemoteCandidates.addLast(item)
                return
            }
        }
        try { pc?.addIceCandidate(item) } catch (e: Exception) { Log.w(TAG, "Could not add remote ICE candidate", e) }
    }

    fun setMicrophoneEnabled(enabled: Boolean) {
        localAudio?.setEnabled(enabled)
    }

    fun setCameraEnabled(enabled: Boolean) {
        localVideo?.setEnabled(enabled)
    }

    /** Switches between front and rear cameras when this call negotiated video. */
    fun switchCamera() {
        try { cameraCapturer?.switchCamera(null) }
        catch (e: Exception) { Log.w(TAG, "Could not switch call camera: ${e.javaClass.simpleName}") }
    }

    /** Live aggregate connection state, used by the disconnect grace-period logic. */
    fun currentConnectionState(): PeerConnection.PeerConnectionState? =
        try { peerConnection?.connectionState() } catch (_: Exception) { null }

    fun closeCall() {
        synchronized(pendingLocalCandidates) {
            pendingLocalCandidates.clear()
            localCandidatesReleased = false
        }
        synchronized(pendingRemoteCandidates) {
            pendingRemoteCandidates.clear()
            remoteDescriptionSet = false
        }
        _localVideoTrack.value = null
        _remoteVideoTrack.value = null
        try { cameraCapturer?.stopCapture() } catch (_: Exception) { }
        try { cameraCapturer?.dispose() } catch (_: Exception) { }
        cameraCapturer = null
        try { surfaceTextureHelper?.dispose() } catch (_: Exception) { }
        surfaceTextureHelper = null
        try { peerConnection?.close() } catch (_: Exception) { }
        try { peerConnection?.dispose() } catch (_: Exception) { }
        peerConnection = null
        try { localAudio?.dispose() } catch (_: Exception) { }
        localAudio = null
        try { audioSource?.dispose() } catch (_: Exception) { }
        audioSource = null
        try { localVideo?.dispose() } catch (_: Exception) { }
        localVideo = null
        try { videoSource?.dispose() } catch (_: Exception) { }
        videoSource = null
        callId = null
        requestedVideo = false
    }

    private fun preparePeerConnection(id: String, video: Boolean) {
        if (peerConnection != null && callId == id) return
        closeCall()
        check(!disposed.get()) { "WebRTC engine is disposed" }
        check(ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            "Microphone permission is required for calls"
        }
        callId = id
        requestedVideo = video
        val settings = settingsProvider()
        val hasTurnUrl = settings.callIceServers.split(Regex("[,\\n\\r]+"))
            .map { it.trim() }
            .any { it.startsWith("turn:", true) || it.startsWith("turns:", true) }
        if (settings.callRelayOnly && (!hasTurnUrl || settings.callTurnUsername.isBlank() || settings.callTurnCredential.isBlank())) {
            throw IllegalStateException("Relay-only calling needs a TURN URL, username, and credential in Settings")
        }

        val iceServers = buildIceServers(settings)
        if (settings.callRelayOnly && iceServers.none { server -> server.urls.any { it.startsWith("turn:", true) || it.startsWith("turns:", true) } }) {
            throw IllegalStateException("No valid TURN server could be built from the call network settings")
        }
        val config = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            iceTransportsType = if (settings.callRelayOnly) PeerConnection.IceTransportsType.RELAY else PeerConnection.IceTransportsType.ALL
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        peerConnection = factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) = Unit
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                if (state == PeerConnection.IceConnectionState.FAILED) onConnectionState(PeerConnection.PeerConnectionState.FAILED)
                else if (state == PeerConnection.IceConnectionState.CONNECTED || state == PeerConnection.IceConnectionState.COMPLETED) {
                    onConnectionState(PeerConnection.PeerConnectionState.CONNECTED)
                } else if (state == PeerConnection.IceConnectionState.DISCONNECTED) {
                    onConnectionState(PeerConnection.PeerConnectionState.DISCONNECTED)
                }
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) = Unit
            override fun onIceCandidate(candidate: IceCandidate?) {
                if (candidate == null) return
                val publishNow = synchronized(pendingLocalCandidates) {
                    if (localCandidatesReleased) true else {
                        if (pendingLocalCandidates.size < 256) pendingLocalCandidates.add(candidate)
                        false
                    }
                }
                if (publishNow) {
                    try { onLocalIceCandidate(candidate) } catch (e: Exception) { Log.w(TAG, "ICE publish callback failed", e) }
                }
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) = Unit
            override fun onAddStream(stream: org.webrtc.MediaStream?) {
                stream?.videoTracks?.firstOrNull()?.let { remote ->
                    remote.setEnabled(true)
                    _remoteVideoTrack.value = remote
                }
            }
            override fun onRemoveStream(stream: org.webrtc.MediaStream?) {
                _remoteVideoTrack.value = null
            }
            override fun onDataChannel(channel: org.webrtc.DataChannel?) = Unit
            override fun onRenegotiationNeeded() = Unit
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out org.webrtc.MediaStream>?) {
                (receiver?.track() as? VideoTrack)?.let { remote ->
                    remote.setEnabled(true)
                    _remoteVideoTrack.value = remote
                }
            }
            override fun onTrack(transceiver: RtpTransceiver?) {
                (transceiver?.receiver?.track() as? VideoTrack)?.let { remote ->
                    remote.setEnabled(true)
                    _remoteVideoTrack.value = remote
                }
            }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                if (newState != null) onConnectionState(newState)
            }
            override fun onStandardizedIceConnectionChange(newState: PeerConnection.IceConnectionState?) = Unit
            override fun onSelectedCandidatePairChanged(event: org.webrtc.CandidatePairChangeEvent?) = Unit
            override fun onIceCandidateError(event: org.webrtc.IceCandidateErrorEvent?) = Unit
        }) ?: throw IllegalStateException("WebRTC could not create a peer connection")

        val audioConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
        }
        audioSource = factory.createAudioSource(audioConstraints)
        localAudio = factory.createAudioTrack("folkchat-audio-$id", audioSource)
        peerConnection?.addTrack(localAudio, listOf("folkchat-stream-$id"))

        if (video) {
            check(ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                "Camera permission is required for video calls"
            }
            createLocalCameraTrack(id)
        }
    }

    private fun createLocalCameraTrack(id: String) {
        val enumerator = Camera2Enumerator(appContext)
        val names = enumerator.deviceNames
        val selected = names.firstOrNull { enumerator.isFrontFacing(it) } ?: names.firstOrNull { enumerator.isBackFacing(it) }
            ?: throw IllegalStateException("No usable camera is available")
        val capturer = enumerator.createCapturer(selected, null) as? CameraVideoCapturer
            ?: throw IllegalStateException("Could not initialize the selected camera")
        cameraCapturer = capturer
        val source = factory.createVideoSource(false)
        videoSource = source
        val helper = SurfaceTextureHelper.create("FolkChat-camera-$id", eglBase.eglBaseContext)
            ?: throw IllegalStateException("Could not create camera texture helper")
        surfaceTextureHelper = helper
        capturer.initialize(helper, appContext, source.capturerObserver)
        val dataSaver = settingsProvider().callDataSaver
        capturer.startCapture(if (dataSaver) 320 else 640, if (dataSaver) 240 else 360, if (dataSaver) 12 else 20)
        val track = factory.createVideoTrack("folkchat-video-$id", source)
        localVideo = track
        _localVideoTrack.value = track
        peerConnection?.addTrack(track, listOf("folkchat-stream-$id"))
        track.setEnabled(true)
    }

    private fun buildIceServers(settings: AppSettings): List<PeerConnection.IceServer> {
        val configuredUrls = settings.callIceServers
            .split(Regex("[,\\n\\r]+"))
            .map { it.trim() }
            .filter { it.matches(Regex("^(stun|stuns|turn|turns):[A-Za-z0-9.\\-]+(?::[0-9]{1,5})?(?:\\?transport=(udp|tcp))?$", RegexOption.IGNORE_CASE)) }
            .distinct()
        val serverList = if (configuredUrls.isEmpty()) DEFAULT_STUN_URLS else configuredUrls
        val result = mutableListOf<PeerConnection.IceServer>()
        serverList.forEach { url ->
            val isTurn = url.startsWith("turn:", true) || url.startsWith("turns:", true)
            if (isTurn && (settings.callTurnUsername.isBlank() || settings.callTurnCredential.isBlank())) return@forEach
            try {
                val builder = PeerConnection.IceServer.builder(url)
                if (isTurn) builder.setUsername(settings.callTurnUsername).setPassword(settings.callTurnCredential)
                result += builder.createIceServer()
            } catch (e: Exception) { Log.w(TAG, "Ignoring invalid ICE server URL") }
        }
        return result.ifEmpty {
            DEFAULT_STUN_URLS.mapNotNull { url ->
                try { PeerConnection.IceServer.builder(url).createIceServer() } catch (_: Exception) { null }
            }
        }
    }

    private suspend fun createDescription(create: (SdpObserver) -> Unit): SessionDescription =
        suspendCancellableCoroutine { continuation ->
            create(object : SdpObserver {
                override fun onCreateSuccess(description: SessionDescription?) {
                    if (description == null) continuation.resumeWithException(IllegalStateException("WebRTC returned an empty SDP"))
                    else if (continuation.isActive) continuation.resume(description)
                }
                override fun onSetSuccess() = Unit
                override fun onCreateFailure(error: String?) {
                    if (continuation.isActive) continuation.resumeWithException(IllegalStateException(error ?: "SDP creation failed"))
                }
                override fun onSetFailure(error: String?) = Unit
            })
        }

    private suspend fun setLocalDescription(description: SessionDescription) =
        suspendCancellableCoroutine { continuation ->
            val pc = peerConnection ?: run {
                continuation.resumeWithException(IllegalStateException("WebRTC peer connection is closed")); return@suspendCancellableCoroutine
            }
            pc.setLocalDescription(object : SdpObserver {
                override fun onCreateSuccess(description: SessionDescription?) = Unit
                override fun onSetSuccess() { if (continuation.isActive) continuation.resume(Unit) }
                override fun onCreateFailure(error: String?) = Unit
                override fun onSetFailure(error: String?) {
                    if (continuation.isActive) continuation.resumeWithException(IllegalStateException(error ?: "Could not set local SDP"))
                }
            }, description)
        }

    private suspend fun setRemoteDescription(description: SessionDescription) =
        suspendCancellableCoroutine { continuation ->
            val pc = peerConnection ?: run {
                continuation.resumeWithException(IllegalStateException("WebRTC peer connection is closed")); return@suspendCancellableCoroutine
            }
            pc.setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(description: SessionDescription?) = Unit
                override fun onSetSuccess() {
                    remoteDescriptionSet = true
                    val queued = synchronized(pendingRemoteCandidates) {
                        pendingRemoteCandidates.toList().also { pendingRemoteCandidates.clear() }
                    }
                    queued.forEach { try { pc.addIceCandidate(it) } catch (_: Exception) { } }
                    if (continuation.isActive) continuation.resume(Unit)
                }
                override fun onCreateFailure(error: String?) = Unit
                override fun onSetFailure(error: String?) {
                    if (continuation.isActive) continuation.resumeWithException(IllegalStateException(error ?: "Could not set remote SDP"))
                }
            }, description)
        }

    private fun requireValidSdp(sdp: String) {
        require(sdp.length in 20..64_000 && sdp.startsWith("v=0") && sdp.contains("\nm=") ||
            sdp.length in 20..64_000 && sdp.startsWith("v=0") && sdp.contains("\r\nm=")) {
            "Invalid or oversized WebRTC SDP"
        }
    }
}
