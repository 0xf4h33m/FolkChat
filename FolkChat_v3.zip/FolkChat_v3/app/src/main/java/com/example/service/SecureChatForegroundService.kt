package com.example.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.SecureChatApp
import com.example.data.ChatMessage
import com.example.data.NotificationPreviewMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive

class SecureChatForegroundService : Service() {
    companion object {
        private const val NOTIFICATION_ID = 9001
        private const val MESSAGE_NOTIFICATION_BASE_ID = 10000
        private const val CALL_NOTIFICATION_ID = 12000

        const val ACTION_START = "com.example.securechat.START_SERVICE"
        const val ACTION_STOP = "com.example.securechat.STOP_SERVICE"
        const val ACTION_CALL_ACTIVE = "com.example.securechat.CALL_ACTIVE"
        const val ACTION_CALL_ENDED = "com.example.securechat.CALL_ENDED"
        const val EXTRA_CALL_AUDIO = "call_audio_enabled"
        const val EXTRA_CALL_VIDEO = "call_video_enabled"
        const val EXTRA_OPEN_PEER = "open_peer_pubkey"

        fun start(context: Context) {
            val intent = Intent(context, SecureChatForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, SecureChatForegroundService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }

        /** Promote the existing mesh service to a microphone/camera service only for a live call. */
        fun updateCallForeground(context: Context, active: Boolean, audio: Boolean = false, video: Boolean = false) {
            val intent = Intent(context, SecureChatForegroundService::class.java).apply {
                action = if (active) ACTION_CALL_ACTIVE else ACTION_CALL_ENDED
                putExtra(EXTRA_CALL_AUDIO, audio)
                putExtra(EXTRA_CALL_VIDEO, video)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var messageCollectorJob: Job? = null
    @Volatile private var callAudioEnabled = false
    @Volatile private var callVideoEnabled = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SecureChat:BackgroundLock")?.apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L) // 10 min chunks
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                try { SecureChatApp.instance.transportCoordinator.stopTransports() } catch (_: Exception) {}
                serviceScope.cancel()
                try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_CALL_ACTIVE -> {
                callAudioEnabled = intent.getBooleanExtra(EXTRA_CALL_AUDIO, false)
                callVideoEnabled = intent.getBooleanExtra(EXTRA_CALL_VIDEO, false)
            }
            ACTION_CALL_ENDED -> {
                callAudioEnabled = false
                callVideoEnabled = false
            }
        }

        val notification = createServiceNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            var foregroundTypes = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            // Android 14+ requires call-specific types and the matching permissions only while
            // capturing these sensors. dataSync is deliberately omitted to avoid the Android 15
            // six-hour budget for a service that is really maintaining a user-started connection.
            if (callAudioEnabled) foregroundTypes = foregroundTypes or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (callVideoEnabled) foregroundTypes = foregroundTypes or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            startForeground(NOTIFICATION_ID, notification, foregroundTypes)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val app = SecureChatApp.instance
        app.transportCoordinator.startTransports()
        // onStartCommand can run repeatedly for start/stop-call actions. A single collector avoids
        // duplicate message notifications after every call or service restart.
        if (messageCollectorJob?.isActive != true) {
            messageCollectorJob = serviceScope.launch {
                app.transportCoordinator.onNewMessageReceived.collectLatest { msg -> showMessageNotification(msg) }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        messageCollectorJob?.cancel()
        messageCollectorJob = null
        serviceScope.cancel()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    private fun createServiceNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, SecureChatApp.CHANNEL_SERVICE_ID)
            .setContentTitle("Connection active")
            .setContentText("Listening for permitted device connections")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun showMessageNotification(msg: ChatMessage) {
        val app = SecureChatApp.instance
        val settings = app.vault.getSettings()
        val contacts = app.vault.getContacts()
        val senderContact = contacts.firstOrNull { it.x25519PublicKeyHex.equals(msg.senderPubKeyHex, ignoreCase = true) }

        // Muted conversations never ring or notify.
        if (senderContact?.isMuted == true) return

        val senderName = senderContact?.displayName ?: "New Peer"

        // Locked conversations never reveal sender identity or content in system notifications,
        // regardless of the global notification-preview preference.
        val lockedConversation = msg.conversationPeerPubKeyHex.lowercase() in settings.lockedChatKeys
        val (title, text) = if (lockedConversation) {
            Pair("New message", "Open to view")
        } else when (settings.notificationPreviewMode) {
            NotificationPreviewMode.FULL -> Pair(senderName, msg.previewText)
            NotificationPreviewMode.SENDER_ONLY -> Pair(senderName, "New message")
            NotificationPreviewMode.HIDDEN -> Pair("New message", "Open to view")
        }

        // Deep link: open the conversation directly.
        val openIntent = Intent(this, MainActivity::class.java).apply {
            putExtra(EXTRA_OPEN_PEER, msg.conversationPeerPubKeyHex)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            msg.id.hashCode(),
            openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, SecureChatApp.CHANNEL_MESSAGES_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(
                if (!lockedConversation && settings.notificationPreviewMode == NotificationPreviewMode.FULL && msg.content.length > 40)
                    NotificationCompat.BigTextStyle().bigText(msg.previewText)
                else null
            )
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        // Honor the notification sound & vibration settings.
        builder.setDefaults(0)
        if (settings.notificationSound) {
            try {
                builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            } catch (_: Exception) {}
        }
        if (settings.notificationVibrate) {
            builder.setVibrate(longArrayOf(0, 120, 80, 120))
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(MESSAGE_NOTIFICATION_BASE_ID + (msg.id.hashCode() and 0x7FFF), builder.build())
    }

    /** High-priority heads-up notification for an incoming call while backgrounded. */
    fun showIncomingCallNotification(peerName: String, callTypeLabel: String) {
        val app = SecureChatApp.instance
        val settings = app.vault.getSettings()

        val pendingIntent = PendingIntent.getActivity(
            this,
            CALL_NOTIFICATION_ID,
            Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, SecureChatApp.CHANNEL_CALLS_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Incoming $callTypeLabel call")
            .setContentText(peerName)
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setDefaults(0)

        if (settings.notificationSound) {
            try {
                builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            } catch (_: Exception) {}
        }
        if (settings.notificationVibrate) {
            try {
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 300, 400), 0))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 400, 300, 400), 0)
                }
            } catch (_: Exception) {}
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(CALL_NOTIFICATION_ID, builder.build())
    }

    fun dismissIncomingCallNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(CALL_NOTIFICATION_ID)
    }

}
