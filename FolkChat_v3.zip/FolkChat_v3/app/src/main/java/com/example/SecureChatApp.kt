package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.example.data.EncryptedVault
import com.example.net.transport.TransportCoordinator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SecureChatApp : Application(), ImageLoaderFactory {
    companion object {
        const val CHANNEL_SERVICE_ID = "securechat_link_service"
        const val CHANNEL_MESSAGES_ID = "securechat_messages"
        const val CHANNEL_CALLS_ID = "securechat_calls"

        lateinit var instance: SecureChatApp
            private set
    }

    lateinit var vault: EncryptedVault
        private set

    lateinit var transportCoordinator: TransportCoordinator
        private set

    lateinit var callManager: com.example.net.call.CallManager
        private set

    lateinit var appLockManager: com.example.ui.security.AppLockManager
        private set

    lateinit var appIconManager: com.example.ui.branding.AppIconManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        vault = EncryptedVault(this)
        transportCoordinator = TransportCoordinator(this, vault)
        callManager = com.example.net.call.CallManager(
            context = this,
            vault = vault,
            signalSender = { peer, json -> transportCoordinator.dispatchEncryptedJson(peer, json) }
        )
        appLockManager = com.example.ui.security.AppLockManager(vault, this)

        // Cold-start enforcement: if App Lock is enabled, the app must be gated
        // from the very first frame after process death.
        appLockManager.onAppCreated()

        // Launcher icon aliases: guarantee exactly one entry point stays enabled
        // so the app can never disappear from the home screen.
        appIconManager = com.example.ui.branding.AppIconManager(this)
        appIconManager.ensureLauncherAvailable()

        // Restore persisted routing policy.
        try {
            val persisted = com.example.data.RoutingPolicy.valueOf(vault.getRoutingPolicyName())
            transportCoordinator.routingEngine.setRoutingPolicy(persisted)
        } catch (e: Exception) {
            // keep default AUTO_FALLBACK
        }

        CoroutineScope(Dispatchers.IO).launch {
            transportCoordinator.onCallSignal.collect { signal -> callManager.onSignal(signal) }
        }

        createNotificationChannels()
    }

    /** Keep image loading lightweight; animated GIF decoding is intentionally disabled. */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .crossfade(true)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE_ID,
                "Connection service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps permitted device links listening in the background"
                setShowBadge(false)
            }

            val messagesChannel = NotificationChannel(
                CHANNEL_MESSAGES_ID,
                "Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for incoming conversations"
                enableVibration(true)
                setShowBadge(true)
            }

            val callsChannel = NotificationChannel(
                CHANNEL_CALLS_ID,
                "Calls",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming voice and video call alerts"
                enableVibration(true)
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(serviceChannel)
            notificationManager.createNotificationChannel(messagesChannel)
            notificationManager.createNotificationChannel(callsChannel)
        }
    }
}
