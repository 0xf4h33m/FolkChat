package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SecureChatApp
import com.example.crypto.CryptoEngine
import com.example.crypto.KeyPairBytes
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.GroupConversation
import com.example.data.DisappearTimer
import com.example.data.DiscoveredPeer
import com.example.data.MediaAttachment
import com.example.data.MessageStatus
import com.example.data.RoutingPolicy
import com.example.service.SecureChatForegroundService
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/** A transient, user-visible message surfaced via the root snackbar host. */
data class UiEvent(
    val id: Long = System.nanoTime(),
    val message: String,
    val kind: UiEventKind = UiEventKind.INFO
)

enum class UiEventKind { INFO, SUCCESS, ERROR }

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as SecureChatApp
    private val vault = app.vault
    private val transportCoordinator = app.transportCoordinator

    private val _identity = MutableStateFlow(vault.getIdentityKeyPair())
    val identity: StateFlow<KeyPairBytes> = _identity.asStateFlow()

    private val _displayName = MutableStateFlow(vault.getDisplayName())
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    private val _contacts = MutableStateFlow(buildContactTiles())
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()

    private val _allMessages = MutableStateFlow(vault.getAllMessages())
    val allMessages: StateFlow<List<ChatMessage>> = _allMessages.asStateFlow()

    private val _messageRequests = MutableStateFlow(vault.getMessageRequests())
    val messageRequests: StateFlow<List<com.example.data.MessageRequest>> = _messageRequests.asStateFlow()

    private val _activeContact = MutableStateFlow<Contact?>(null)
    val activeContact: StateFlow<Contact?> = _activeContact.asStateFlow()

    private val _settings = MutableStateFlow(vault.getSettings())
    val settings: StateFlow<com.example.data.AppSettings> = _settings.asStateFlow()

    private val _deviceStorageEnabled = MutableStateFlow(vault.isDeviceStorageEnabled())
    /** True only when the user has enabled durable local saving (legacy saved installs are preserved). */
    val deviceStorageEnabled: StateFlow<Boolean> = _deviceStorageEnabled.asStateFlow()

    private val _callLogs = MutableStateFlow(vault.getCallLogs())
    val callLogs: StateFlow<List<com.example.data.CallLogEntry>> = _callLogs.asStateFlow()

    // ------------------------------------------------------------------
    // v2 state: typing indicators, unread badges, blocked peers, my avatar
    // ------------------------------------------------------------------

    /** pubKeys of peers currently typing (auto-expire after ~5s of silence). */
    private val _typingPeers = MutableStateFlow<Set<String>>(emptySet())
    val typingPeers: StateFlow<Set<String>> = _typingPeers.asStateFlow()

    /** conversation pubKey -> unread count, refreshed whenever data changes. */
    private val _unreadCounts = MutableStateFlow<Map<String, Int>>(emptyMap())
    val unreadCounts: StateFlow<Map<String, Int>> = _unreadCounts.asStateFlow()

    val totalUnread: Int get() = _unreadCounts.value.values.sum()

    private val _blockedPeers = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val blockedPeers: StateFlow<List<Pair<String, String>>> = _blockedPeers.asStateFlow()

    /** Count of outgoing text messages still waiting for a usable route. */
    private val _queuedOutboxCount = MutableStateFlow(0)
    val queuedOutboxCount: StateFlow<Int> = _queuedOutboxCount.asStateFlow()

    private val _myAvatarPath = MutableStateFlow<String?>(vault.getMyAvatarPath())
    val myAvatarPath: StateFlow<String?> = _myAvatarPath.asStateFlow()

    private val _torProbeResult = MutableStateFlow<String?>(null)
    val torProbeResult: StateFlow<String?> = _torProbeResult.asStateFlow()

    /** One-shot, user-visible events (errors, confirmations) shown in the snackbar. */
    private val _uiEvents = MutableStateFlow<UiEvent?>(null)
    val uiEvents: StateFlow<UiEvent?> = _uiEvents.asStateFlow()

    /** Report a non-fatal failure to the user instead of failing silently. */
    fun reportError(message: String) {
        _uiEvents.value = UiEvent(message = message.take(220), kind = UiEventKind.ERROR)
    }

    /** Report a positive confirmation to the user. */
    fun reportSuccess(message: String) {
        _uiEvents.value = UiEvent(message = message.take(220), kind = UiEventKind.SUCCESS)
    }

    /** Called by the snackbar host after an event has been displayed. */
    fun consumeUiEvent() { _uiEvents.value = null }

    val callManager = app.callManager
    val appLock = app.appLockManager
    val mediaTransfer = transportCoordinator.mediaTransferManager
    val onlineRelay = transportCoordinator.onlineRelayManager

    private val _selectedTab = MutableStateFlow(BottomTab.CHATS)
    val selectedTab: StateFlow<BottomTab> = _selectedTab.asStateFlow()

    fun setSelectedTab(tab: BottomTab) { _selectedTab.value = tab }

    fun refreshSettings() { _settings.value = vault.getSettings() }
    fun refreshCallLogs() { _callLogs.value = vault.getCallLogs() }

    /** Explicitly opts into persistent, encrypted on-device storage and promotes session files. */
    fun enableDeviceStorageAndSave() {
        viewModelScope.launch(Dispatchers.IO) {
            val enabled = vault.enableDeviceStorageAndSave {
                transportCoordinator.refreshLocalStorageDirectory()
            }
            if (enabled) {
                _deviceStorageEnabled.value = true
                refreshData()
                reportSuccess("Device saving is on. Current chats and settings were saved to the encrypted local vault.")
            } else {
                _deviceStorageEnabled.value = vault.isDeviceStorageEnabled()
                reportError("Could not save to this device. Your current session remains available; check available storage and try again.")
            }
        }
    }

    fun updateSettings(transform: (com.example.data.AppSettings) -> com.example.data.AppSettings) {
        vault.updateSettings(transform)
        _settings.value = vault.getSettings()
    }

    /** Profile photo sharing takes effect immediately for every accepted contact. */
    fun setShareProfilePhoto(enabled: Boolean) {
        updateSettings { it.copy(shareProfilePhoto = enabled) }
        broadcastProfileUpdate()
    }

    val discoveredPeers: StateFlow<List<DiscoveredPeer>> = transportCoordinator.allDiscoveredPeers

    private val _themeMode = MutableStateFlow(
        com.example.ui.theme.AppThemeMode.fromName(vault.getThemeMode())
    )
    val themeMode: StateFlow<com.example.ui.theme.AppThemeMode> = _themeMode.asStateFlow()

    private val _isOnboardingCompleted = MutableStateFlow(vault.isOnboardingCompleted())
    val isOnboardingCompleted: StateFlow<Boolean> = _isOnboardingCompleted.asStateFlow()

    val routingEngine = transportCoordinator.routingEngine
    val routingPolicy: StateFlow<RoutingPolicy> = routingEngine.routingPolicy
    val isInternetAvailable: StateFlow<Boolean> = routingEngine.isInternetAvailable
    val networkTypeName: StateFlow<String> = routingEngine.networkTypeName

    fun setRoutingPolicy(policy: RoutingPolicy) {
        routingEngine.setRoutingPolicy(policy)
        vault.setRoutingPolicyName(policy.name)
        triggerOutboxFlush()
    }

    fun toggleSimulatedOffline() {
        routingEngine.toggleSimulatedOffline()
        triggerOutboxFlush()
    }

    // ------------------------------------------------------------------
    // Tor routing (OFF by default) & relay URL
    // ------------------------------------------------------------------

    fun setTorRoutingEnabled(enabled: Boolean) {
        updateSettings { it.copy(torRoutingEnabled = enabled) }
        viewModelScope.launch {
            if (enabled) {
                // Discover Orbot's actual SOCKS listener on IO before constructing the relay client.
                withContext(Dispatchers.IO) { transportCoordinator.onlineRelayManager.isTorProxyReachable() }
            }
            // restartPrivacyTransports rebuilds the relay from the updated settings; do not
            // immediately restart it a second time and create duplicate sockets.
            transportCoordinator.restartPrivacyTransports()
            probeTor()
        }
    }

    fun setRelayUrl(url: String) {
        updateSettings { it.copy(relayUrl = url.trim()) }
        viewModelScope.launch {
            transportCoordinator.onlineRelayManager.restart()
        }
    }

    /** Check whether the Orbot SOCKS proxy is reachable and expose the result. */
    fun probeTor() {
        viewModelScope.launch {
            val reachable = withContext(Dispatchers.IO) {
                transportCoordinator.onlineRelayManager.isTorProxyReachable()
            }
            _torProbeResult.value = if (reachable) "Orbot SOCKS proxy detected" else "Orbot proxy not detected — install or start Orbot before enabling Tor routing"
        }
    }

    fun completeOnboardingWithName(name: String) {
        val trimmed = name.trim()
        if (trimmed.isNotEmpty()) {
            vault.setDisplayName(trimmed)
            _displayName.value = trimmed
        }
        vault.setOnboardingCompleted(true)
        _isOnboardingCompleted.value = true
    }

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    val activeConversationMessages: StateFlow<List<ChatMessage>> = combine(
        _allMessages,
        _activeContact
    ) { messages, active ->
        if (active == null) emptyList()
        else messages.filter {
            it.conversationPeerPubKeyHex.equals(active.x25519PublicKeyHex, ignoreCase = true)
        }.sortedBy { it.timestampMs }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val typingExpiryJobs = mutableMapOf<String, Job>()
    private var housekeepingJob: Job? = null

    init {
        // MainActivity starts relay-only or the foreground local-link service after checking
        // runtime permissions. Starting a connected-device FGS here can race the permission prompt.
        refreshUnread()
        refreshBlocked()

        // Listen for new incoming messages from coordinator
        viewModelScope.launch {
            transportCoordinator.onNewMessageReceived.collect {
                refreshData()
                maybeSendReadReceipt()
            }
        }

        viewModelScope.launch {
            transportCoordinator.onConversationUpdated.collect {
                refreshData()
                _settings.value = vault.getSettings()
                _callLogs.value = vault.getCallLogs()
            }
        }

        // Live typing indicators with 5-second auto-expiry, tracked per peer: a single
        // shared expiry job previously wiped every peer's indicator whenever one peer
        // stopped typing or timed out.
        viewModelScope.launch {
            transportCoordinator.onTypingUpdate.collect { (rawPeer, isTyping) ->
                val peer = rawPeer.lowercase()
                if (isTyping) {
                    _typingPeers.value = _typingPeers.value + peer
                    typingExpiryJobs.remove(peer)?.cancel()
                    typingExpiryJobs[peer] = viewModelScope.launch {
                        delay(5000)
                        _typingPeers.value = _typingPeers.value - peer
                        typingExpiryJobs.remove(peer)
                    }
                } else {
                    typingExpiryJobs.remove(peer)?.cancel()
                    _typingPeers.value = _typingPeers.value - peer
                }
            }
        }

        // Presence traffic refreshes contact list (last-seen timestamps).
        viewModelScope.launch {
            transportCoordinator.onPresenceSeen.collect {
                _contacts.value = buildContactTiles()
            }
        }

        // Periodic housekeeping: purge expired disappearing messages.
        housekeepingJob = viewModelScope.launch {
            while (true) {
                delay(15_000)
                val had = vault.getAllMessages().size
                vault.purgeExpiredDisappearingMessages()
                if (vault.getAllMessages().size != had) {
                    refreshData()
                } else {
                    refreshUnread()
                }
            }
        }
    }

    fun refreshData() {
        _contacts.value = buildContactTiles()
        _allMessages.value = vault.getAllMessages()
        _messageRequests.value = vault.getMessageRequests()
        _displayName.value = vault.getDisplayName()
        _myAvatarPath.value = vault.getMyAvatarPath()
        _settings.value = vault.getSettings()
        _queuedOutboxCount.value = _allMessages.value.count {
            it.isOutgoing && it.attachment == null && it.status == MessageStatus.QUEUED
        }
        refreshUnread()
        refreshBlocked()
    }

    private fun buildContactTiles(): List<Contact> {
        val direct = vault.getContacts()
        val groups = vault.getGroups().map { group ->
            Contact(
                id = "group:${group.id}",
                displayName = group.name,
                x25519PublicKeyHex = group.id,
                isVerified = true,
                isGroup = true,
                groupMemberPubKeyHexes = group.memberPubKeyHexes
            )
        }
        return direct + groups
    }

    private fun refreshUnread() {
        val map = mutableMapOf<String, Int>()
        for (c in _contacts.value) {
            val n = vault.getUnreadCount(c.x25519PublicKeyHex)
            if (n > 0) map[c.x25519PublicKeyHex.lowercase()] = n
        }
        _unreadCounts.value = map
    }

    private fun refreshBlocked() {
        _blockedPeers.value = vault.getBlockedPeers()
    }

    fun getUnreadFor(contact: Contact): Int =
        _unreadCounts.value[contact.x25519PublicKeyHex.lowercase()] ?: 0

    // ------------------------------------------------------------------
    // Conversation open + read receipts
    // ------------------------------------------------------------------

    fun selectContact(contact: Contact?) {
        _activeContact.value = contact
        if (contact != null) {
            val key = contact.x25519PublicKeyHex
            // Do not mark messages read or send a read receipt until a protected chat is unlocked.
            if (!appLock.isChatLocked(key) || appLock.isChatUnlocked(key)) {
                vault.markConversationRead(key)
                refreshUnread()
                if (!contact.isGroup) maybeSendReadReceipt()
            }
        }
    }

    /** Call only after the PIN gate has successfully opened the currently active chat. */
    fun onActiveChatUnlocked() {
        val active = _activeContact.value ?: return
        vault.markConversationRead(active.x25519PublicKeyHex)
        refreshUnread()
        maybeSendReadReceipt()
    }

    /** Sends an encrypted read-receipt cursor to the active peer (if enabled). */
    private fun maybeSendReadReceipt() {
        val active = _activeContact.value ?: return
        if (active.isGroup) return
        val s = vault.getSettings()
        if (!s.readReceipts) return
        val isSelfChat = active.x25519PublicKeyHex.equals(vault.getIdentityKeyPair().publicKeyHex, ignoreCase = true)
        if (isSelfChat) return
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                active.x25519PublicKeyHex,
                JSONObject().apply {
                    put("type", "CHAT_READ")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("lastReadMs", System.currentTimeMillis())
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // Typing indicator send side
    // ------------------------------------------------------------------

    private var lastTypingSentAt = 0L

    fun sendTypingSignal() {
        val active = _activeContact.value ?: return
        if (active.isGroup) return
        val s = vault.getSettings()
        if (!s.typingIndicators) return
        val isSelfChat = active.x25519PublicKeyHex.equals(vault.getIdentityKeyPair().publicKeyHex, ignoreCase = true)
        if (isSelfChat) return
        val now = System.currentTimeMillis()
        if (now - lastTypingSentAt < 2500) return // throttle
        lastTypingSentAt = now
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                active.x25519PublicKeyHex,
                JSONObject().apply {
                    put("type", "CHAT_TYPING")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("typing", true)
                    put("timestamp", System.currentTimeMillis())
                }
            )
        }
    }

    fun isPeerTyping(contact: Contact?): Boolean =
        contact != null && !contact.isGroup && _typingPeers.value.contains(contact.x25519PublicKeyHex.lowercase())

    // ------------------------------------------------------------------
    // Group conversations
    // ------------------------------------------------------------------

    /** Creates a group and sends the initial membership snapshot to each selected contact. */
    fun createGroup(name: String, memberPubKeyHexes: Set<String>): Contact? {
        val cleanName = name.trim().take(80)
        val myKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val members = (memberPubKeyHexes.map { it.lowercase().trim() } + myKey).distinct()
            .filter { it.matches(Regex("^[0-9a-f]{64}$")) }
        if (cleanName.isBlank() || members.size !in 2..64 || members.any { key ->
                key != myKey && vault.getContactByPubKey(key) == null
            }) return null

        val rawId = UUID.randomUUID().toString() + "|" + myKey + "|" + System.nanoTime()
        val groupId = CryptoEngine.bytesToHex(
            java.security.MessageDigest.getInstance("SHA-256").digest(rawId.toByteArray(Charsets.UTF_8))
        )
        val now = System.currentTimeMillis()
        val group = GroupConversation(
            id = groupId,
            name = cleanName,
            memberPubKeyHexes = members,
            createdByPubKeyHex = myKey,
            createdAtMs = now,
            updatedAtMs = now
        )
        if (!vault.addOrUpdateGroup(group)) return null
        refreshData()
        val tile = group.toContactTile()
        selectContact(tile)

        viewModelScope.launch {
            val invite = groupSyncPayload(group)
            members.filter { it != myKey }.forEach { peer ->
                transportCoordinator.dispatchEncryptedJson(peer, JSONObject(invite.toString()))
            }
            refreshData()
        }
        return tile
    }

    fun deleteGroup(groupId: String) {
        if (_activeContact.value?.isGroup == true &&
            _activeContact.value?.x25519PublicKeyHex.equals(groupId, ignoreCase = true)) {
            _activeContact.value = null
        }
        vault.deleteGroup(groupId)
        refreshData()
    }

    private fun GroupConversation.toContactTile(): Contact = Contact(
        id = "group:$id",
        displayName = name,
        x25519PublicKeyHex = id,
        isVerified = true,
        isGroup = true,
        groupMemberPubKeyHexes = memberPubKeyHexes
    )

    private fun groupSyncPayload(group: GroupConversation): JSONObject = JSONObject().apply {
        put("type", "GROUP_SYNC")
        put("groupId", group.id)
        put("groupName", group.name)
        put("groupMembers", org.json.JSONArray(group.memberPubKeyHexes))
        put("createdByPubKey", group.createdByPubKeyHex)
        put("createdAtMs", group.createdAtMs)
        put("updatedAtMs", group.updatedAtMs)
        put("timestamp", System.currentTimeMillis())
    }

    private fun groupMessagePayload(group: GroupConversation, message: ChatMessage): JSONObject = JSONObject().apply {
        put("type", "CHAT_MSG")
        put("msgId", message.id)
        put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
        put("senderDisplayName", vault.getDisplayName())
        put("text", message.content)
        put("timestamp", message.timestampMs)
        put("groupId", group.id)
        put("groupName", group.name)
        put("groupMembers", org.json.JSONArray(group.memberPubKeyHexes))
        put("createdByPubKey", group.createdByPubKeyHex)
        put("groupCreatedAtMs", group.createdAtMs)
        put("groupUpdatedAtMs", group.updatedAtMs)
        message.replyToId?.let { put("replyToId", it) }
        message.replyToPreview?.let { put("replyToPreview", it) }
        message.replyToSender?.let { put("replyToSender", it) }
    }

    private suspend fun sendGroupText(group: GroupConversation, message: ChatMessage) {
        val myKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val recipients = group.memberPubKeyHexes.filter { it != myKey }
        var successfulRoutes = 0
        for (peer in recipients) {
            val route = transportCoordinator.dispatchEncryptedJson(peer, groupMessagePayload(group, message))
            if (route != null) successfulRoutes++
        }
        vault.updateMessage(message.id) { current ->
            if (successfulRoutes == 0) current.copy(status = MessageStatus.FAILED, routeUsed = "GROUP_FANOUT")
            else current.copy(status = if (current.deliveryPeerPubKeyHexes.containsAll(recipients)) MessageStatus.DELIVERED else MessageStatus.SENDING, routeUsed = "GROUP_FANOUT")
        }
        refreshData()
    }

    // ------------------------------------------------------------------
    // Contacts
    // ------------------------------------------------------------------

    fun addContact(codeOrPubKey: String, name: String): Boolean {
        val trimmed = codeOrPubKey.trim()
        val pairingQr = CryptoEngine.parsePairingQrCode(trimmed)
        if (pairingQr != null) {
            return confirmAddContact(pairingQr.pubKeyHex, name.ifBlank { pairingQr.displayName }, pairingQr.tokenHex) != null
        }
        val parsed = CryptoEngine.parseContactCode(trimmed)

        val (pubKeyHex, finalName) = if (parsed != null) {
            Pair(parsed.first.lowercase(), if (name.isNotBlank()) name.trim() else parsed.second)
        } else if (trimmed.length == 64 && trimmed.matches(Regex("^[0-9a-fA-F]+$"))) {
            Pair(trimmed.lowercase(), if (name.isNotBlank()) name.trim() else "Peer " + trimmed.take(6))
        } else {
            return false
        }

        // Adding a code must never silently undo an explicit block; unblock is a separate action.
        if (vault.isBlocked(pubKeyHex)) return false
        val existing = vault.getContactByPubKey(pubKeyHex)
        val contact = (existing ?: Contact(
            id = UUID.randomUUID().toString(),
            displayName = finalName.take(80),
            x25519PublicKeyHex = pubKeyHex,
            isVerified = false
        )).copy(
            displayName = finalName.take(80),
            x25519PublicKeyHex = pubKeyHex,
            isVerified = existing?.isVerified ?: false
        )
        vault.addOrUpdateContact(contact)
        refreshData()
        announceProfileToPeer(pubKeyHex)
        requestProfileFromPeer(pubKeyHex)
        return true
    }

    fun confirmAddContact(pubKeyHex: String, displayName: String, pairingTokenHex: String? = null): Contact? {
        val cleanKey = pubKeyHex.lowercase().trim()
        if (!cleanKey.matches(Regex("^[0-9a-f]{64}$")) || vault.isBlocked(cleanKey)) return null
        // A supplied pairing token must never be silently downgraded into an ordinary contact add.
        val cleanPairingToken = pairingTokenHex?.lowercase()?.trim()
        if (cleanPairingToken != null && !cleanPairingToken.matches(Regex("^[0-9a-f]{64}$"))) return null
        val existing = vault.getContactByPubKey(cleanKey)
        val finalName = displayName.trim().take(80).ifBlank {
            existing?.displayName?.takeIf { it.isNotBlank() } ?: "Peer " + cleanKey.take(6)
        }
        // Preserve chat settings/avatar/read state when the same contact is added again.
        val contact = (existing ?: Contact(
            id = UUID.randomUUID().toString(),
            displayName = finalName,
            x25519PublicKeyHex = cleanKey,
            isVerified = false
        )).copy(
            displayName = finalName,
            x25519PublicKeyHex = cleanKey,
            isVerified = existing?.isVerified ?: false
        )
        vault.addOrUpdateContact(contact)
        refreshData()
        _activeContact.value = contact
        val pairingToken = cleanPairingToken
        if (pairingToken != null) {
            // Do not exchange profile/avatar metadata until the recipient has authenticated the
            // reciprocal PAIR_ACK. A scanned QR is a pairing request, not yet a verified contact.
            transportCoordinator.beginQrPairing(cleanKey, finalName, pairingToken.lowercase())
        } else {
            announceProfileToPeer(cleanKey)
            requestProfileFromPeer(cleanKey)
        }
        return contact
    }

    /** Activate the expiring, single-use QR challenge only while the identity QR is displayed. */
    fun activatePairingChallenge(tokenHex: String, expiresAtMs: Long) {
        try {
            vault.activatePairingChallenge(tokenHex, expiresAtMs)
            transportCoordinator.activatePairingInbox(tokenHex)
        } catch (e: Exception) {
            android.util.Log.w("ChatViewModel", "Could not activate QR pairing challenge: ${e.javaClass.simpleName}")
        }
    }

    fun clearPairingChallenge(tokenHex: String? = null) {
        vault.clearPairingChallenge(tokenHex)
        transportCoordinator.clearPairingInbox(tokenHex)
    }

    /** Mark a peer verified only after the mutual QR handshake or out-of-band fingerprint comparison. */
    fun markContactVerified(pubKeyHex: String) {
        val key = pubKeyHex.lowercase().trim()
        val contact = vault.getContactByPubKey(key) ?: return
        vault.addOrUpdateContact(contact.copy(isVerified = true))
        refreshData()
    }

    fun acceptMessageRequest(senderPubKeyHex: String, displayName: String) {
        val contact = vault.acceptMessageRequest(senderPubKeyHex, displayName)
        refreshData()
        _activeContact.value = contact
        // Exchange profile snapshots immediately on acceptance so avatars do not depend on
        // the other user changing their profile after we became contacts.
        announceProfileToPeer(contact.x25519PublicKeyHex)
        requestProfileFromPeer(contact.x25519PublicKeyHex)
    }

    fun declineMessageRequest(senderPubKeyHex: String) {
        vault.declineMessageRequest(senderPubKeyHex)
        refreshData()
    }

    /** Block a peer permanently: drop their request / contact and all traffic. */
    fun blockPeer(pubKeyHex: String, displayName: String) {
        val key = pubKeyHex.lowercase().trim()
        vault.blockPeer(key, displayName)
        vault.deleteContact(key)
        if (_activeContact.value?.x25519PublicKeyHex?.equals(key, ignoreCase = true) == true) {
            _activeContact.value = null
        }
        refreshData()
    }

    fun unblockPeer(pubKeyHex: String) {
        vault.unblockPeer(pubKeyHex)
        refreshBlocked()
    }

    fun isPeerBlocked(pubKeyHex: String): Boolean = vault.isBlocked(pubKeyHex)

    fun deleteContact(pubKeyHex: String) {
        if (vault.getGroupById(pubKeyHex) != null) {
            deleteGroup(pubKeyHex)
            return
        }
        vault.deleteContact(pubKeyHex)
        if (_activeContact.value?.x25519PublicKeyHex.equals(pubKeyHex, ignoreCase = true)) {
            _activeContact.value = null
        }
        refreshData()
    }

    fun clearChatHistory(contactPubKey: String) {
        vault.clearAllMessagesForContact(contactPubKey)
        refreshData()
    }

    fun updateDisplayName(name: String) {
        vault.setDisplayName(name)
        _displayName.value = name
        broadcastProfileUpdate()
    }

    // ------------------------------------------------------------------
    // Profile image flow
    // ------------------------------------------------------------------

    /** Saves a local profile image and announces a wire-budget-safe avatar to all contacts. */
    fun setMyAvatar(imageBytes: ByteArray) {
        viewModelScope.launch(Dispatchers.IO) {
            val compressed = compressAvatar(imageBytes, maxDim = 320, quality = 62)
            if (compressed != null) {
                try {
                    val path = vault.saveAvatarImage(compressed)
                    _myAvatarPath.value = path
                    broadcastProfileUpdate()
                } catch (e: Exception) {
                    reportError("Could not save the new profile photo: ${e.message ?: "storage error"}")
                }
            } else {
                reportError("That image could not be processed. Try a different photo.")
            }
        }
    }

    fun clearMyAvatar() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                vault.clearMyAvatar()
                _myAvatarPath.value = null
                broadcastProfileUpdate()
                reportSuccess("Profile photo removed.")
            } catch (e: Exception) {
                reportError("Could not remove the profile photo: ${e.message ?: "storage error"}")
            }
        }
    }

    private fun compressAvatar(imageBytes: ByteArray, maxDim: Int = 320, quality: Int = 62): ByteArray? {
        val src = try { BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size) } catch (_: Exception) { null } ?: return null
        return try {
            val scale = minOf(1f, maxDim.toFloat() / maxOf(src.width, src.height))
            val w = (src.width * scale).toInt().coerceAtLeast(1)
            val h = (src.height * scale).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            try {
                val bos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
                bos.toByteArray()
            } finally {
                if (scaled !== src) scaled.recycle()
            }
        } catch (_: Exception) {
            null
        } finally {
            src.recycle()
        }
    }

    /**
     * The public packet bus caps the encoded packet at about 3.5 KB. A normal 320px avatar
     * exceeded that limit, so the name packet succeeded on some links while the avatar packet
     * was rejected on WAN. Make a separate thumbnail guaranteed to fit the wire budget.
     */
    private fun compressAvatarForWire(imageBytes: ByteArray): ByteArray? {
        val src = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size) ?: return null
        try {
            val attempts = listOf(160 to 48, 128 to 42, 112 to 36, 96 to 32, 80 to 28, 64 to 24, 48 to 20)
            for ((dimension, quality) in attempts) {
                val scale = minOf(1f, dimension.toFloat() / maxOf(src.width, src.height))
                val w = (src.width * scale).toInt().coerceAtLeast(1)
                val h = (src.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(src, w, h, true)
                try {
                    val bos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
                    val encoded = bos.toByteArray()
                    if (encoded.size <= 1_250) return encoded
                } finally {
                    if (scaled !== src) scaled.recycle()
                }
            }
            return null
        } catch (_: Exception) {
            return null
        } finally {
            src.recycle()
        }
    }

    /** Announces the current profile to all accepted direct contacts. */
    private fun broadcastProfileUpdate() {
        viewModelScope.launch(Dispatchers.IO) {
            val recipients = _contacts.value.asSequence()
                .filter { !it.isGroup }
                .map { it.x25519PublicKeyHex.lowercase() }
                .filter { it != vault.getIdentityKeyPair().publicKeyHex.lowercase() }
                .distinct()
                .toList()
            recipients.forEach { sendProfileUpdateToPeer(it) }
        }
    }

    private fun announceProfileToPeer(pubKeyHex: String) {
        viewModelScope.launch(Dispatchers.IO) { sendProfileUpdateToPeer(pubKeyHex) }
    }

    private fun requestProfileFromPeer(pubKeyHex: String) {
        val peer = pubKeyHex.trim().lowercase()
        if (!peer.matches(Regex("^[0-9a-f]{64}$")) || peer == vault.getIdentityKeyPair().publicKeyHex.lowercase()) return
        viewModelScope.launch(Dispatchers.IO) {
            transportCoordinator.dispatchEncryptedJson(peer, JSONObject().apply {
                put("type", "PROFILE_REQUEST")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("timestamp", System.currentTimeMillis())
            })
        }
    }

    private suspend fun sendProfileUpdateToPeer(pubKeyHex: String) {
        val peer = pubKeyHex.trim().lowercase()
        val ownKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        if (peer == ownKey || !peer.matches(Regex("^[0-9a-f]{64}$")) || vault.getContactByPubKey(peer) == null) return
        val settings = vault.getSettings()
        val wireAvatar: ByteArray? = if (settings.shareProfilePhoto) {
            _myAvatarPath.value?.let { path ->
                try {
                    val file = File(path)
                    if (file.isFile && file.length() in 1..(512L * 1024L)) compressAvatarForWire(file.readBytes()) else null
                } catch (_: Exception) { null }
            }
        } else null
        val json = JSONObject().apply {
            put("type", "PROFILE_UPDATE")
            put("senderPubKey", ownKey)
            put("displayName", vault.getDisplayName())
            put("timestamp", System.currentTimeMillis())
            put("avatarClear", !settings.shareProfilePhoto || _myAvatarPath.value == null)
            wireAvatar?.let { put("avatarBase64", Base64.encodeToString(it, Base64.NO_WRAP)) }
        }
        try {
            transportCoordinator.dispatchEncryptedJson(peer, json)
        } finally {
            wireAvatar?.fill(0)
        }
    }

    // ------------------------------------------------------------------
    // Messaging tools: reply / edit / delete / pin / reaction / star / forward
    // ------------------------------------------------------------------

    fun sendMessage(
        text: String,
        replyToId: String? = null,
        replyToPreview: String? = null,
        replyToSender: String? = null
    ) {
        val active = _activeContact.value ?: return
        if (text.isBlank()) return

        if (active.isGroup) {
            val group = vault.getGroupById(active.x25519PublicKeyHex) ?: return
            val myIdentity = vault.getIdentityKeyPair()
            val groupMessage = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationPeerPubKeyHex = group.id,
                senderPubKeyHex = myIdentity.publicKeyHex,
                recipientPubKeyHex = group.id,
                content = text.trim(),
                timestampMs = System.currentTimeMillis(),
                status = MessageStatus.SENDING,
                isOutgoing = true,
                routeUsed = "GROUP_FANOUT",
                replyToId = replyToId,
                replyToPreview = replyToPreview,
                replyToSender = replyToSender,
                groupId = group.id,
                senderDisplayName = vault.getDisplayName()
            )
            vault.saveMessage(groupMessage)
            refreshData()
            viewModelScope.launch { sendGroupText(group, groupMessage) }
            return
        }

        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = active.x25519PublicKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = active.x25519PublicKeyHex.lowercase().trim(),
            content = text.trim(),
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.QUEUED,
            isOutgoing = true,
            routeUsed = "AUTO",
            replyToId = replyToId,
            replyToPreview = replyToPreview,
            replyToSender = replyToSender
        )
        vault.saveMessage(msg)
        viewModelScope.launch {
            transportCoordinator.flushOutbox()
            refreshData()
        }
        refreshData()
    }

    /** Forward a message (text or media) to another contact. */
    fun forwardMessage(messageId: String, toContactPubKeyHex: String) {
        val msg = vault.getMessageById(messageId) ?: run {
            reportError("That message no longer exists on this device")
            return
        }
        val target = vault.getContactByPubKey(toContactPubKeyHex) ?: run {
            reportError("That contact no longer exists")
            return
        }
        val myIdentity = vault.getIdentityKeyPair()

        if (msg.attachment != null) {
            val path = msg.attachment.localPath
            val source = path?.let { File(it) }
            if (path == null || source == null || !source.exists()) {
                reportError("The original media file is no longer on this device, so it can't be forwarded")
                return
            }
            val attachment = msg.attachment.copy(
                id = UUID.randomUUID().toString(),
                transferState = com.example.data.TransferState.PENDING,
                progress = 0f,
                error = null,
                viewsUsed = 0
            )
            val forwarded = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationPeerPubKeyHex = target.x25519PublicKeyHex,
                senderPubKeyHex = myIdentity.publicKeyHex,
                recipientPubKeyHex = target.x25519PublicKeyHex.lowercase(),
                content = msg.content,
                timestampMs = System.currentTimeMillis(),
                status = MessageStatus.SENDING,
                isOutgoing = true,
                routeUsed = "AUTO",
                attachment = attachment
            )
            vault.saveMessage(forwarded)
            // MediaTransferManager streams straight from attachment.localPath.
            mediaTransfer.startTransfer(forwarded)
        } else {
            val forwarded = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationPeerPubKeyHex = target.x25519PublicKeyHex,
                senderPubKeyHex = myIdentity.publicKeyHex,
                recipientPubKeyHex = target.x25519PublicKeyHex.lowercase(),
                content = msg.content,
                timestampMs = System.currentTimeMillis(),
                status = MessageStatus.QUEUED,
                isOutgoing = true,
                routeUsed = "AUTO"
            )
            vault.saveMessage(forwarded)
            viewModelScope.launch {
                transportCoordinator.flushOutbox()
                refreshData()
            }
        }
        refreshData()
    }

    fun editMessage(messageId: String, newText: String) {
        val trimmed = newText.trim()
        if (trimmed.isBlank()) return
        val updated = vault.updateMessage(messageId) {
            it.copy(content = trimmed, isEdited = true, editedAtMs = System.currentTimeMillis())
        } ?: return
        viewModelScope.launch {
            if (updated.isOutgoing) {
                val payload = JSONObject().apply {
                    put("type", "CHAT_EDIT")
                    put("msgId", messageId)
                    put("text", trimmed)
                    put("timestamp", updated.editedAtMs)
                }
                if (updated.groupId != null) dispatchGroupAction(updated.groupId, payload)
                else transportCoordinator.dispatchEncryptedJson(updated.recipientPubKeyHex, payload)
            }
            refreshData()
        }
        refreshData()
    }

    /**
     * Requeues a failed outgoing text message for dispatch. A FAILED text previously had no
     * recovery path at all: the outbox only re-dispatches QUEUED/eligible-SENDING messages,
     * so a message that failed while the peer was unreachable stayed failed forever.
     */
    fun resendMessage(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        if (!msg.isOutgoing || msg.attachment != null || msg.groupId != null) return
        if (msg.status != MessageStatus.FAILED) return
        try {
            // QUEUED re-adds the message to the persisted outbox; clearing the attempt stamp
            // bypasses the offline retry throttle so this send is dispatched right away.
            vault.updateMessageStatusAndRoute(messageId, MessageStatus.QUEUED, "AUTO")
            vault.updateMessage(messageId) { it.copy(lastAttemptAtMs = 0L) }
            refreshData()
            triggerOutboxFlush()
        } catch (e: Exception) {
            reportError("Could not requeue message: ${e.message ?: "vault error"}")
        }
    }

    fun deleteMessageLocally(messageId: String) {
        vault.updateMessage(messageId) {
            it.copy(deletedAtMs = System.currentTimeMillis(), content = "")
        }
        refreshData()
    }

    /** Soft-delete for me + notify the peer to soft-delete on their side. */
    fun deleteMessageForEveryone(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val deletedAt = System.currentTimeMillis()
        vault.updateMessage(messageId) { it.copy(deletedAtMs = deletedAt, content = "") }
        refreshData()
        viewModelScope.launch {
            if (msg.isOutgoing) {
                val payload = JSONObject().apply {
                    put("type", "CHAT_DELETE")
                    put("msgId", messageId)
                    put("timestamp", deletedAt)
                }
                if (msg.groupId != null) dispatchGroupAction(msg.groupId, payload)
                else transportCoordinator.dispatchEncryptedJson(msg.recipientPubKeyHex, payload)
            }
            refreshData()
        }
    }

    fun togglePin(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val nowPinned = !msg.isPinned
        val updatedAt = System.currentTimeMillis()
        vault.updateMessage(messageId) { it.copy(isPinned = nowPinned, pinUpdatedAtMs = updatedAt) }
        refreshData()
        viewModelScope.launch {
            val payload = JSONObject().apply {
                put("type", "CHAT_PIN")
                put("msgId", messageId)
                put("pinned", nowPinned)
                put("timestamp", updatedAt)
            }
            // A pin is local UI state unless the original author is the current user;
            // peers only accept pin sync for the author of the target message.
            if (msg.groupId != null && msg.isOutgoing) dispatchGroupAction(msg.groupId, payload)
            else if (msg.groupId == null) transportCoordinator.dispatchEncryptedJson(msg.recipientPubKeyHex, payload)
        }
    }

    fun toggleStar(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        vault.setStarred(messageId, !msg.isStarred)
        refreshData()
    }

    fun getStarredMessages(): List<ChatMessage> = vault.getStarredMessages()

    fun toggleReaction(messageId: String, emoji: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val me = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val map = msg.reactions.toMutableMap()
        val current = map[emoji]?.toMutableList() ?: mutableListOf()
        val add = !current.contains(me)
        if (add) current.add(me) else current.remove(me)
        if (current.isEmpty()) map.remove(emoji) else map[emoji] = current
        vault.updateMessage(messageId) { it.copy(reactions = map) }
        refreshData()
        viewModelScope.launch {
            val payload = JSONObject().apply {
                put("type", "CHAT_REACTION")
                put("msgId", messageId)
                put("emoji", emoji)
                put("add", add)
                put("timestamp", System.currentTimeMillis())
                put("senderPubKey", me)
            }
            if (msg.groupId != null) dispatchGroupAction(msg.groupId, payload)
            else transportCoordinator.dispatchEncryptedJson(msg.recipientPubKeyHex, payload)
        }
    }

    /** Fan out an authenticated group control packet to each other member. */
    private suspend fun dispatchGroupAction(groupId: String, payload: JSONObject) {
        val group = vault.getGroupById(groupId) ?: return
        val myKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        group.memberPubKeyHexes.filter { it != myKey }.forEach { peer ->
            transportCoordinator.dispatchEncryptedJson(peer, JSONObject(payload.toString()))
        }
    }

    // ------------------------------------------------------------------
    // Archive / mute / disappearing
    // ------------------------------------------------------------------

    fun toggleArchive(contact: Contact) {
        if (contact.isGroup) return
        vault.addOrUpdateContact(contact.copy(isArchived = !contact.isArchived))
        refreshData()
    }

    fun toggleMute(contact: Contact) {
        if (contact.isGroup) return
        vault.addOrUpdateContact(contact.copy(isMuted = !contact.isMuted))
        refreshData()
    }

    fun setDisappearTimer(contact: Contact, timer: DisappearTimer) {
        val nowMs = System.currentTimeMillis()
        vault.addOrUpdateContact(contact.copy(
            disappearAfterSec = timer.seconds,
            disappearAfterSetAtMs = nowMs,
            disappearTimerUpdatedAtMs = nowMs
        ))
        val event = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = contact.x25519PublicKeyHex,
            senderPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            recipientPubKeyHex = contact.x25519PublicKeyHex,
            content = "",
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.DELIVERED,
            isOutgoing = true,
            routeUsed = "SYNC",
            systemEvent = "You set disappearing messages to ${timer.label.lowercase()}"
        )
        vault.saveMessage(event)
        refreshData()
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                contact.x25519PublicKeyHex,
                JSONObject().apply {
                    put("type", "DISAPPEAR_SYNC")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("seconds", timer.seconds)
                    put("timestamp", nowMs)
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // View-limited media (view once / view twice)
    // ------------------------------------------------------------------

    /**
     * Record that the recipient opened a view-limited attachment. Deletes the
     * local file once the view budget is spent and informs the sender.
     */
    fun consumeViewLimitedMedia(messageId: String) {
        val before = vault.getMessageById(messageId) ?: return
        val beforeAttachment = before.attachment ?: return
        if (beforeAttachment.viewLimit <= 0 || beforeAttachment.isViewExpired) return

        // Compute the next counter inside EncryptedVault's synchronized update, not from the
        // stale message object captured when the dialog was opened. This prevents two fast opens
        // (or duplicate UI events) from both writing the same count for a view-twice attachment.
        var oldPath: String? = null
        var consumed = false
        val updated = vault.updateMessage(messageId) { current ->
            val currentAttachment = current.attachment ?: return@updateMessage current
            if (current.isOutgoing || currentAttachment.viewLimit <= 0 || currentAttachment.isViewExpired) {
                return@updateMessage current
            }
            val nextViews = (currentAttachment.viewsUsed + 1).coerceAtMost(currentAttachment.viewLimit)
            oldPath = currentAttachment.localPath
            consumed = nextViews > currentAttachment.viewsUsed
            current.copy(attachment = currentAttachment.copy(viewsUsed = nextViews))
        } ?: return
        val updatedAttachment = updated.attachment ?: return
        if (!consumed) return
        val newViews = updatedAttachment.viewsUsed
        val spent = newViews >= updatedAttachment.viewLimit
        if (spent) {
            oldPath?.let(vault::deleteManagedMedia)
            vault.updateMessage(messageId) { m ->
                val current = m.attachment ?: return@updateMessage m
                if (current.viewLimit > 0 && current.viewsUsed >= current.viewLimit) {
                    m.copy(attachment = current.copy(localPath = null))
                } else m
            }
        }
        refreshData()
        if (before.isOutgoing) return // local self-notes: no network notify needed
        viewModelScope.launch {
            // A received attachment belongs to its original sender. Send the cumulative count to
            // that sender; using recipientPubKeyHex here would loop the receipt back to ourselves.
            transportCoordinator.dispatchEncryptedJson(
                before.senderPubKeyHex,
                JSONObject().apply {
                    put("type", "ATTACHMENT_VIEWED")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("msgId", messageId)
                    put("viewsUsed", newViews)
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // Media transfers
    // ------------------------------------------------------------------

    fun sendMediaAttachment(attachment: MediaAttachment, caption: String = "") {
        val active = _activeContact.value ?: return
        if (active.isGroup) return // Group attachment fan-out is not enabled until per-member receipts are surfaced.
        transportCoordinator.queueMediaMessage(
            active.x25519PublicKeyHex.lowercase().trim(),
            attachment,
            caption
        )
        refreshData()
    }

    fun cancelMediaTransfer(messageId: String) {
        mediaTransfer.cancel(messageId)
        refreshData()
    }

    fun retryMediaTransfer(messageId: String) {
        mediaTransfer.retry(messageId)
        refreshData()
    }

    fun resolveMediaFile(attachment: MediaAttachment?) =
        mediaTransfer.resolveLocalFile(attachment)

    // ------------------------------------------------------------------
    // Calls
    // ------------------------------------------------------------------

    fun startCall(contact: Contact, isVideo: Boolean) {
        if (contact.isGroup) return
        callManager.startOutgoing(
            contact,
            if (isVideo) com.example.data.CallType.VIDEO else com.example.data.CallType.VOICE
        )
        refreshCallLogs()
    }

    fun endActiveCall() {
        callManager.endCall()
        refreshCallLogs()
    }

    fun clearCallHistory() {
        vault.clearCallLogs()
        refreshCallLogs()
    }

    // ------------------------------------------------------------------
    // Service & misc
    // ------------------------------------------------------------------

    fun startBackgroundService() {
        SecureChatForegroundService.start(getApplication())
        _isServiceRunning.value = true
    }

    /** Relay-only fallback: internet messages/media can work without camera, microphone,
     * or nearby-device permissions while FolkChat is open. Background reliability requires
     * the foreground link service (and its platform-required permissions). */
    fun startInternetMessagingOnly() {
        transportCoordinator.startOnlineRelayOnly()
        _isServiceRunning.value = false
    }

    fun stopBackgroundService() {
        SecureChatForegroundService.stop(getApplication())
        _isServiceRunning.value = false
    }

    fun triggerOutboxFlush() {
        viewModelScope.launch {
            transportCoordinator.flushOutbox()
            refreshData()
        }
    }

    fun registerManualPeer(ipAddress: String) {
        transportCoordinator.socketManager.registerPeerManually(ipAddress)
        triggerOutboxFlush()
    }

    fun setThemeMode(mode: com.example.ui.theme.AppThemeMode) {
        try {
            _themeMode.value = mode
            vault.setThemeMode(mode.name)
        } catch (e: Exception) {
            _themeMode.value = com.example.ui.theme.AppThemeMode.CLASSIC_LIGHT
            reportError("Could not save theme preference: ${e.message ?: "vault error"}")
        }
    }

    // ------------------------------------------------------------------
    // Appearance customization (accent, font scale, bubbles, wallpaper)
    // ------------------------------------------------------------------

    fun setAccentPalette(palette: com.example.ui.theme.AccentPalette) {
        try {
            updateSettings { it.copy(accentPalette = palette.name) }
        } catch (e: Exception) {
            reportError("Could not save accent color: ${e.message ?: "vault error"}")
        }
    }

    fun setChatFontScale(scale: com.example.ui.theme.ChatFontScale) {
        try {
            updateSettings { it.copy(chatFontScale = scale.multiplier) }
        } catch (e: Exception) {
            reportError("Could not save text size: ${e.message ?: "vault error"}")
        }
    }

    fun setBubbleStyle(style: com.example.ui.theme.BubbleStyle) {
        try {
            updateSettings { it.copy(bubbleStyle = style.name) }
        } catch (e: Exception) {
            reportError("Could not save bubble style: ${e.message ?: "vault error"}")
        }
    }

    fun setChatWallpaper(wallpaper: com.example.ui.theme.ChatWallpaper) {
        try {
            updateSettings { it.copy(chatWallpaper = wallpaper.name) }
        } catch (e: Exception) {
            reportError("Could not save wallpaper: ${e.message ?: "vault error"}")
        }
    }

    fun setAppFont(choice: com.example.ui.theme.AppFontChoice) {
        try {
            updateSettings { it.copy(appFont = choice.name) }
        } catch (e: Exception) {
            reportError("Could not save font: ${e.message ?: "vault error"}")
        }
    }

    fun setAppEmblem(style: com.example.ui.branding.AppEmblemStyle) {
        try {
            updateSettings { it.copy(appEmblem = style.name) }
        } catch (e: Exception) {
            reportError("Could not save emblem: ${e.message ?: "vault error"}")
        }
    }

    fun setHapticFeedback(enabled: Boolean) {
        try {
            updateSettings { it.copy(hapticFeedback = enabled) }
        } catch (e: Exception) {
            reportError("Could not save haptics: ${e.message ?: "vault error"}")
        }
    }

    /**
     * Switches the home-screen launcher icon. The manifest alias is toggled
     * first-class (new enabled before old disabled), the choice is persisted,
     * and a confirmation event tells the user the launcher may need a moment
     * to redraw the new icon.
     */
    fun activeAppIconVariant(): com.example.ui.branding.AppIconVariant = app.appIconManager.activeVariant()

    fun setAppIconVariant(variant: com.example.ui.branding.AppIconVariant) {
        try {
            val switched = app.appIconManager.setLauncherVariant(variant)
            updateSettings { it.copy(appIconVariant = variant.name) }
            if (switched) {
                reportSuccess("App icon set to ${variant.label}. Your launcher may take a moment to refresh it.")
            }
        } catch (e: Exception) {
            reportError("Could not change the app icon: ${e.message ?: "component error"}")
        }
    }

    // ------------------------------------------------------------------
    // Per-conversation message drafts (memory-only; switching chats must
    // never silently destroy an unsent composition).
    // ------------------------------------------------------------------

    private val conversationDrafts = mutableMapOf<String, String>()

    fun getConversationDraft(peerPubKeyHex: String): String =
        conversationDrafts[peerPubKeyHex.lowercase()] ?: ""

    fun saveConversationDraft(peerPubKeyHex: String, draft: String) {
        val key = peerPubKeyHex.lowercase()
        if (draft.isBlank()) conversationDrafts.remove(key)
        else conversationDrafts[key] = draft.take(4000)
    }

    fun clearConversationDraft(peerPubKeyHex: String) {
        conversationDrafts.remove(peerPubKeyHex.lowercase())
    }

    fun openSavedNotes() {
        val myPubKey = identity.value.publicKeyHex.lowercase()
        val existing = contacts.value.firstOrNull { it.x25519PublicKeyHex.equals(myPubKey, ignoreCase = true) }
        if (existing != null) {
            _activeContact.value = existing
        } else {
            val self = Contact(
                id = "self_notes",
                displayName = "Saved Notes",
                x25519PublicKeyHex = myPubKey,
                isVerified = true
            )
            vault.addOrUpdateContact(self)
            refreshData()
            _activeContact.value = self
        }
    }

    /** Handle notification deep link: jump straight into a conversation. */
    fun openConversationByPubKey(pubKeyHex: String) {
        val contact = _contacts.value.firstOrNull {
            it.x25519PublicKeyHex.equals(pubKeyHex, ignoreCase = true)
        }
        if (contact != null) {
            selectContact(contact)
            _selectedTab.value = BottomTab.CHATS
        }
    }

    override fun onCleared() {
        housekeepingJob?.cancel()
        typingExpiryJobs.values.forEach { it.cancel() }
        typingExpiryJobs.clear()
        super.onCleared()
    }
}

enum class BottomTab { CHATS, CALLS, PEOPLE, PROFILE, SETTINGS }
