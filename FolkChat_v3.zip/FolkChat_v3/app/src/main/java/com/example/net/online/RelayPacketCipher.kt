package com.example.net.online

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cryptographic framing for an additional per-relay copy. This is not the app's primary
 * end-to-end message encryption; the inner packet remains recipient-encrypted and authenticated.
 */
internal object RelayPacketCipher {
    private val magic = byteArrayOf(0x46, 0x43, 0x52, 0x31) // FCR1
    private const val NONCE_BYTES = 12
    private const val TAG_BITS = 128
    private val random = SecureRandom()

    /** Returns [magic | random 96-bit nonce | AES-GCM ciphertext and tag]. */
    fun seal(key: ByteArray, relayHost: String, packet: ByteArray): ByteArray {
        require(key.size == 32) { "Relay wrapper key must be 256 bits" }
        require(relayHost.matches(Regex("^[a-z0-9.-]{1,253}$"))) { "Invalid relay host identifier" }
        require(packet.isNotEmpty()) { "Cannot wrap an empty packet" }
        val nonce = ByteArray(NONCE_BYTES).also { random.nextBytes(it) }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
            cipher.updateAAD(aad(relayHost))
            magic + nonce + cipher.doFinal(packet)
        } finally {
            nonce.fill(0)
        }
    }

    /** Throws on malformed data, wrong key/host, or an invalid GCM authentication tag. */
    fun open(key: ByteArray, relayHost: String, wrapped: ByteArray): ByteArray {
        require(key.size == 32) { "Relay wrapper key must be 256 bits" }
        require(relayHost.matches(Regex("^[a-z0-9.-]{1,253}$"))) { "Invalid relay host identifier" }
        require(wrapped.size >= magic.size + NONCE_BYTES + 16) { "Wrapped packet is too short" }
        require(wrapped.copyOfRange(0, magic.size).contentEquals(magic)) { "Unknown relay wrapper format" }

        val nonceStart = magic.size
        val nonce = wrapped.copyOfRange(nonceStart, nonceStart + NONCE_BYTES)
        val ciphertextAndTag = wrapped.copyOfRange(nonceStart + NONCE_BYTES, wrapped.size)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
            cipher.updateAAD(aad(relayHost))
            cipher.doFinal(ciphertextAndTag)
        } finally {
            nonce.fill(0)
        }
    }

    private fun aad(host: String): ByteArray =
        "FolkChat relay packet wrapper v1|$host".toByteArray(Charsets.UTF_8)
}
