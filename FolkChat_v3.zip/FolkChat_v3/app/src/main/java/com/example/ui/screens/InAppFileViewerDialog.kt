package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.widget.VideoView
import android.widget.MediaController
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.charset.StandardCharsets

/**
 * Private, local-only preview for received/sent media. PDF rendering is bounded to 10 pages;
 * plain-text previews are bounded to the first MiB to avoid loading untrusted huge files.
 */
@Composable
fun InAppFileViewerDialog(
    attachment: MediaAttachment,
    file: File,
    onDismiss: () -> Unit,
    onOpenExternally: () -> Unit
) {
    val context = LocalContext.current
    val isVisual = attachment.kind == MediaKind.IMAGE || attachment.kind == MediaKind.VIDEO ||
        attachment.mimeType.startsWith("image/") || attachment.mimeType.startsWith("video/")
    val foreground = if (isVisual) Color.White else MaterialTheme.colorScheme.onSurface
    val panelColor = if (isVisual) Color.Black else MaterialTheme.colorScheme.surface
    var videoScale by remember(file) { mutableFloatStateOf(1f) }
    val isVideo = attachment.kind == MediaKind.VIDEO || attachment.mimeType.startsWith("video/")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = !isVisual)
    ) {
        Surface(
            modifier = if (isVisual) Modifier.fillMaxSize() else Modifier.fillMaxWidth(0.96f).heightIn(max = 760.dp),
            shape = if (isVisual) RoundedCornerShape(0.dp) else RoundedCornerShape(24.dp),
            color = panelColor,
            tonalElevation = if (isVisual) 0.dp else 8.dp
        ) {
            Column(modifier = if (isVisual) Modifier.fillMaxSize() else Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (attachment.kind == MediaKind.VIDEO) Icons.Default.PlayArrow else Icons.Default.Description,
                        null,
                        tint = if (isVisual) Color.White else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(attachment.fileName, maxLines = 1, fontWeight = FontWeight.SemiBold, color = foreground)
                        Text(
                            "${formatViewerBytes(file.length())} · ${attachment.mimeType}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isVisual) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                    if (isVideo) {
                        IconButton(onClick = { videoScale = (videoScale - 0.25f).coerceAtLeast(1f) }) {
                            Icon(Icons.Default.Remove, contentDescription = "Zoom video out", tint = foreground)
                        }
                        Text("${(videoScale * 100).toInt()}%", color = foreground, style = MaterialTheme.typography.labelSmall)
                        IconButton(onClick = { videoScale = (videoScale + 0.25f).coerceAtMost(2.5f) }) {
                            Icon(Icons.Default.Add, contentDescription = "Zoom video in", tint = foreground)
                        }
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close viewer", tint = foreground) }
                }
                Box(
                    modifier = if (isVisual) Modifier.fillMaxWidth().weight(1f).clipToBounds().background(Color.Black)
                    else Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(min = 200.dp, max = 620.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    when {
                        attachment.kind == MediaKind.IMAGE || attachment.mimeType.startsWith("image/") -> {
                            ZoomableMediaImage(
                                file = file,
                                contentDescription = attachment.fileName,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        attachment.kind == MediaKind.VIDEO || attachment.mimeType.startsWith("video/") -> {
                            val video = remember(file) {
                                VideoView(context).apply {
                                    val controls = MediaController(context)
                                    controls.setAnchorView(this)
                                    setMediaController(controls)
                                    setVideoURI(Uri.fromFile(file))
                                    setOnPreparedListener { player ->
                                        player.isLooping = false
                                        start()
                                    }
                                }
                            }
                            DisposableEffect(video) {
                                onDispose { try { video.stopPlayback() } catch (_: Exception) { } }
                            }
                            AndroidView(
                                factory = { video },
                                modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = videoScale; scaleY = videoScale }
                            )
                        }
                        attachment.mimeType.equals("application/pdf", ignoreCase = true) || file.extension.equals("pdf", ignoreCase = true) -> {
                            PdfPagesPreview(file)
                        }
                        isTextFile(attachment, file) -> TextFilePreview(file)
                        else -> Column(
                            modifier = Modifier.fillMaxWidth().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Description, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Preview isn't available for this file type", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "The file remains stored locally. Open it in a compatible app to view its contents.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isVisual) {
                        Text(
                            if (attachment.kind == MediaKind.IMAGE) "Pinch to zoom · double-tap to reset" else "Use + / − to zoom · playback controls to seek",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.68f),
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    TextButton(onClick = onOpenExternally) {
                        Icon(Icons.Default.OpenInNew, null, modifier = Modifier.size(17.dp), tint = foreground)
                        Spacer(Modifier.width(6.dp))
                        Text("Open with…", color = foreground)
                    }
                }
            }
        }
    }
}

/** Full-screen local image surface with pinch/pan and double-tap zoom. */
@Composable
fun ZoomableMediaImage(
    file: File,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    var scale by remember(file) { mutableFloatStateOf(1f) }
    var offsetX by remember(file) { mutableFloatStateOf(0f) }
    var offsetY by remember(file) { mutableFloatStateOf(0f) }
    var containerSize by remember(file) { mutableStateOf(IntSize.Zero) }

    Box(modifier = modifier.background(Color.Black).clipToBounds()) {
        AsyncImage(
            model = file,
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
                .onSizeChanged { containerSize = it }
                .pointerInput(file, containerSize) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val nextScale = (scale * zoom).coerceIn(1f, 5f)
                        scale = nextScale
                        if (nextScale <= 1.01f) {
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            val maxX = (containerSize.width * (nextScale - 1f) / 2f).coerceAtLeast(0f)
                            val maxY = (containerSize.height * (nextScale - 1f) / 2f).coerceAtLeast(0f)
                            offsetX = (offsetX + pan.x).coerceIn(-maxX, maxX)
                            offsetY = (offsetY + pan.y).coerceIn(-maxY, maxY)
                        }
                    }
                }
                .pointerInput(file) {
                    detectTapGestures(onDoubleTap = {
                        if (scale > 1.05f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            scale = 2.5f
                            offsetX = 0f
                            offsetY = 0f
                        }
                    })
                }
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                    translationY = offsetY
                }
        )
        Column(
            modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp)
                .background(Color.Black.copy(alpha = 0.56f), RoundedCornerShape(18.dp)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconButton(onClick = {
                scale = (scale + 0.5f).coerceAtMost(5f)
                if (containerSize != IntSize.Zero) {
                    offsetX = offsetX.coerceIn(-containerSize.width * (scale - 1f) / 2f, containerSize.width * (scale - 1f) / 2f)
                    offsetY = offsetY.coerceIn(-containerSize.height * (scale - 1f) / 2f, containerSize.height * (scale - 1f) / 2f)
                }
            }) {
                Icon(Icons.Default.Add, contentDescription = "Zoom in", tint = Color.White)
            }
            Text("${(scale * 100).toInt()}%", color = Color.White, style = MaterialTheme.typography.labelSmall)
            IconButton(onClick = {
                val nextScale = (scale - 0.5f).coerceAtLeast(1f)
                scale = nextScale
                if (nextScale == 1f) {
                    offsetX = 0f
                    offsetY = 0f
                } else if (containerSize != IntSize.Zero) {
                    val maxX = containerSize.width * (nextScale - 1f) / 2f
                    val maxY = containerSize.height * (nextScale - 1f) / 2f
                    offsetX = offsetX.coerceIn(-maxX, maxX)
                    offsetY = offsetY.coerceIn(-maxY, maxY)
                }
            }) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom out", tint = Color.White)
            }
        }
    }
}

@Composable
private fun PdfPagesPreview(file: File) {
    var pages by remember(file) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var loading by remember(file) { mutableStateOf(true) }
    var error by remember(file) { mutableStateOf<String?>(null) }
    DisposableEffect(pages) {
        onDispose { pages.forEach { bitmap -> if (!bitmap.isRecycled) bitmap.recycle() } }
    }
    LaunchedEffect(file) {
        loading = true
        val result = withContext(Dispatchers.IO) {
            try {
                val rendered = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        val count = minOf(renderer.pageCount, 10)
                        buildList {
                            for (index in 0 until count) {
                                renderer.openPage(index).use { page ->
                                    val width = 560
                                    val height = (width.toFloat() * page.height / page.width).toInt().coerceIn(1, 1000)
                                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    add(bitmap)
                                }
                            }
                        }
                    }
                }
                rendered to null
            } catch (e: Exception) {
                emptyList<Bitmap>() to (e.message ?: "Could not render this PDF")
            }
        }
        pages = result.first
        error = result.second
        loading = false
    }
    when {
        loading -> CircularProgressIndicator()
        error != null -> Text(error ?: "PDF preview error", modifier = Modifier.padding(20.dp), color = MaterialTheme.colorScheme.error)
        pages.isEmpty() -> Text("This PDF has no pages", modifier = Modifier.padding(20.dp))
        else -> LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 610.dp)) {
            itemsIndexed(pages) { index, bitmap ->
                Image(bitmap = bitmap.asImageBitmap(), contentDescription = "PDF page ${index + 1}", contentScale = ContentScale.FillWidth, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp))
            }
            item {
                if (pages.size == 10) Text("Preview limited to the first 10 pages.", modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun TextFilePreview(file: File) {
    var content by remember(file) { mutableStateOf<String?>(null) }
    var error by remember(file) { mutableStateOf<String?>(null) }
    LaunchedEffect(file) {
        val result = withContext(Dispatchers.IO) {
            try {
                val loaded = BufferedInputStream(file.inputStream()).use { input ->
                    val limit = 1024 * 1024
                    val output = ByteArrayOutputStream(minOf(file.length(), limit.toLong()).toInt())
                    val buffer = ByteArray(8192)
                    var remaining = limit
                    while (remaining > 0) {
                        val count = input.read(buffer, 0, minOf(buffer.size, remaining))
                        if (count <= 0) break
                        output.write(buffer, 0, count)
                        remaining -= count
                    }
                    String(output.toByteArray(), StandardCharsets.UTF_8)
                }
                loaded to null
            } catch (e: Exception) {
                "" to (e.message ?: "Could not read this file")
            }
        }
        content = result.first
        error = result.second
    }
    when {
        error != null -> Text(error ?: "Text preview error", modifier = Modifier.padding(20.dp), color = MaterialTheme.colorScheme.error)
        content == null -> CircularProgressIndicator()
        else -> Column(modifier = Modifier.fillMaxWidth().heightIn(max = 610.dp).verticalScroll(rememberScrollState()).padding(14.dp)) {
            Text(content.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
            if (file.length() > 1024L * 1024L) {
                Spacer(Modifier.height(8.dp))
                Text("Preview limited to the first 1 MiB.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun isTextFile(attachment: MediaAttachment, file: File): Boolean {
    val extension = file.extension.lowercase()
    return attachment.mimeType.startsWith("text/") || extension in setOf(
        "txt", "md", "csv", "json", "xml", "html", "htm", "css", "js", "ts", "kt", "java", "py", "log", "yaml", "yml", "toml", "ini", "sh"
    )
}

private fun formatViewerBytes(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024L -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
}
