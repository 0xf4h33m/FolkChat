package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FolkIconTile
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full-screen PIN gate for a locked conversation. The underlying conversation
 * is not composed while this screen is shown.
 *
 * Deep-craft edition: mirrors the App-Lock keypad (haptic numeric keys,
 * animated PIN dots, error shake) instead of a bare text field, ticks down the
 * rate-limit lockout live, and animates its entrance.
 */
@Composable
fun ChatLockScreen(
    contactName: String,
    externalError: String?,
    lockoutRemainingMs: Long = 0L,
    onVerifyPin: suspend (String) -> Boolean,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var pin by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    var failureCount by remember { mutableIntStateOf(0) }
    var lockoutRemainingSec by remember { mutableIntStateOf(((lockoutRemainingMs + 999L) / 1000L).toInt()) }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current

    // Live lockout countdown: keeps ticking instead of freezing on first value.
    LaunchedEffect(failureCount, working) {
        if (lockoutRemainingSec > 0) {
            while (lockoutRemainingSec > 0) {
                delay(1000)
                lockoutRemainingSec -= 1
            }
        }
    }

    // Error shake, keyed on failures.
    val shakeX = remember { Animatable(0f) }
    LaunchedEffect(failureCount) {
        if (failureCount > 0) {
            shakeX.snapTo(-13f)
            shakeX.animateTo(13f, tween(durationMillis = 70))
            shakeX.animateTo(-8f, tween(durationMillis = 70))
            shakeX.animateTo(0f, tween(durationMillis = 110))
        }
    }

    // Calm entrance.
    val entranceProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { entranceProgress.animateTo(1f, tween(durationMillis = 460)) }

    fun submitFullPin() {
        if (pin.length != 6 || working) return
        scope.launch {
            working = true
            val accepted = try { onVerifyPin(pin) } catch (_: Exception) { false }
            working = false
            if (accepted) {
                pin = ""
                localError = ""
            } else {
                failureCount += 1
                localError = if (lockoutRemainingSec > 0)
                    "Too many attempts. Retry in ${lockoutRemainingSec}s."
                else "PIN was not accepted. Try again."
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                pin = ""
            }
        }
    }

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.44f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .graphicsLayer {
                        alpha = 0.35f + 0.65f * entranceProgress.value
                        translationY = (1f - entranceProgress.value) * 22f
                        translationX = shakeX.value
                    }
                    .padding(horizontal = 30.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                FolkIconTile(
                    icon = Icons.Default.Lock,
                    size = 82.dp,
                    cornerRadius = 26.dp,
                    iconSize = 33.dp,
                    container = MaterialTheme.colorScheme.primaryContainer,
                    tint = MaterialTheme.colorScheme.primary,
                    borderColor = MaterialTheme.colorScheme.outlineVariant
                )
                Spacer(Modifier.height(20.dp))
                Text(
                    "Chat locked",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = (-0.4).sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Enter your FolkChat PIN to open $contactName.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(22.dp))
                PinDots(count = 6, filled = pin.length, isError = localError != null || externalError != null)
                Spacer(Modifier.height(10.dp))
                val error = when {
                    lockoutRemainingSec > 0 -> "Too many attempts. Retry in ${lockoutRemainingSec}s."
                    !localError.isNullOrBlank() -> localError
                    !externalError.isNullOrBlank() -> externalError
                    else -> null
                }
                if (error != null) {
                    Text(
                        error,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(22.dp))

                // Same haptic keypad family as the App-Lock gate for muscle memory.
                NumericKeypad(
                    onDigit = { digit ->
                        if (!working && pin.length < 6) {
                            pin += digit
                            localError = ""
                            if (pin.length == 6) submitFullPin()
                        }
                    },
                    onBackspace = {
                        if (!working && pin.isNotEmpty()) {
                            pin = pin.dropLast(1)
                            localError = ""
                        }
                    }
                )

                Spacer(Modifier.height(14.dp))
                if (working) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(9.dp))
                        Text("Checking securely…", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = onBack, enabled = !working) {
                    Text("Back to chats", fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}
