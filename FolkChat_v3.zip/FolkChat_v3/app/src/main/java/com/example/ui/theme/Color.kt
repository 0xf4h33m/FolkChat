package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =====================================================================
// FolkChat Design System — "Folk Forest" unified palette
// One palette across every screen: chats, calls, QR, lock, settings.
// =====================================================================

// ---- Brand anchors ---------------------------------------------------
val FolkForestGreen = Color(0xFF174A3A)      // Primary actions, active states, outgoing bubbles (light)
val FolkDeepForest = Color(0xFF103D31)       // Emphasis headings, emblem strokes, dark accents
val FolkSage = Color(0xFF92AD96)             // Sage accent, secondary highlights
val FolkLightSage = Color(0xFFE4EBDD)        // Soft sage tint surface
val FolkWarmIvory = Color(0xFFF7F5EA)        // Primary background, chat canvas
val FolkCardSurface = Color(0xFFF0F0E4)      // Elevated cards, incoming bubbles (light)
val FolkMutedGreen = Color(0xFF71877A)       // Muted icons, tertiary controls
val FolkTextPrimary = Color(0xFF18372E)      // Deep green-black body text (light)
val FolkTextSecondary = Color(0xFF728277)    // Secondary text (light)
val FolkBorderSubtle = Color(0xFFD8E0D2)     // Hairline dividers (light)
val FolkSuccess = Color(0xFF378653)          // Verified, online, delivered
val FolkError = Color(0xFFB94D48)            // Danger, delete, failed
val FolkWarning = Color(0xFFC97A2E)          // Queued, warnings
val FolkOnboarding = Color(0xFF2E7D5B)       // Fresh emerald for gradients / onboarding

// ---- Light theme tokens ----------------------------------------------
val LightBg = FolkWarmIvory
val LightSurface = FolkCardSurface
val LightSurfaceElevated = Color(0xFFFAF8F2)
val LightSurfaceSearch = Color(0xFFEDEDE0)
val LightOutline = FolkBorderSubtle
val LightOutlineSubtle = Color(0xFFEAEFE6)
val LightTopBar = Color(0xFFF3F1E4)

val LightTextPrimary = FolkTextPrimary
val LightTextSecondary = FolkTextSecondary
val LightTextMuted = FolkMutedGreen

val LightOutgoingBubble = FolkForestGreen
val LightOutgoingBubbleBorder = FolkDeepForest
val LightOutgoingText = FolkWarmIvory
val LightOutgoingMeta = Color(0xFFBCCFC2)

val LightIncomingBubble = Color(0xFFF3F2E6)
val LightIncomingBubbleBorder = FolkBorderSubtle
val LightIncomingText = FolkTextPrimary
val LightIncomingMeta = FolkTextSecondary

// ---- Dark theme tokens ("Deep Forest Dark") --------------------------
val DarkBg = Color(0xFF07120E)               // Rich dark forest background (not pure black)
val DarkSurfaceClean = Color(0xFF0C1D16)     // Deep forest card surface
val DarkSurfaceElevatedClean = Color(0xFF132A20)
val DarkSurfaceSearch = Color(0xFF0A1912)
val DarkOutlineClean = Color(0xFF244235)
val DarkTopBar = Color(0xFF091A12)

val DarkTextPrimaryClean = Color(0xFFE8F2EC)
val DarkTextSecondaryClean = Color(0xFFA5BDB0)
val DarkTextMutedClean = Color(0xFF7A9788)

val DarkOutgoingBubbleClean = Color(0xFF174C36)
val DarkOutgoingBubbleBorderClean = Color(0xFF246350)
val DarkOutgoingTextClean = Color(0xFFF5FAF7)
val DarkOutgoingMetaClean = Color(0xFF9DC0AC)

val DarkIncomingBubbleClean = Color(0xFF10271D)
val DarkIncomingBubbleBorderClean = Color(0xFF244439)
val DarkIncomingTextClean = Color(0xFFE8F2EC)
val DarkIncomingMetaClean = Color(0xFF8FAD9E)

// ---- Status colors: identical family in both modes (brighter for dark) ----
val FolkSuccessDark = Color(0xFF66C285)
val FolkWarningDark = Color(0xFFE0A458)
val FolkErrorDark = Color(0xFFE07B75)

// ---- Call surface (WhatsApp-style deep stage, same in both modes) ----
val CallStageBg = Color(0xFF0B1A15)
val CallStageBgDeep = Color(0xFF071310)
val CallControlSurface = Color(0xFF1C3A2F)
val CallControlSurfaceActive = Color(0xFF2E7D5B)
val CallAccent = Color(0xFF9FCBAD)

// ---- QR scanner chrome ------------------------------------------------
val QrScrim = Color(0x99000000)
val QrFrame = FolkSage

// =====================================================================
// Accent palette system — 8 selectable tints layered on top of the
// neutral Folk surfaces. Each palette only re-tints "brand" slots
// (primary, outgoing bubbles, emphasis, accents); neutrals, incoming
// bubbles and status colors remain theme-owned for consistent
// readability in both light and dark modes.
// =====================================================================

/** Brand slots an accent palette is allowed to re-tint. */
data class AccentTint(
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val outgoingBubbleBg: Color,
    val outgoingBubbleBorder: Color,
    val outgoingText: Color,
    val outgoingMeta: Color
)

/** Light-mode variants (bubbles slightly deeper, text stays ivory). */
val ForestAccentLight = AccentTint(
    primary = FolkForestGreen,
    onPrimary = FolkWarmIvory,
    primaryContainer = FolkLightSage,
    onPrimaryContainer = FolkDeepForest,
    outgoingBubbleBg = LightOutgoingBubble,
    outgoingBubbleBorder = LightOutgoingBubbleBorder,
    outgoingText = LightOutgoingText,
    outgoingMeta = LightOutgoingMeta
)

val ForestAccentDark = AccentTint(
    primary = FolkSage,
    onPrimary = FolkDeepForest,
    primaryContainer = DarkOutgoingBubbleClean,
    onPrimaryContainer = Color(0xFFD4E8DC),
    outgoingBubbleBg = DarkOutgoingBubbleClean,
    outgoingBubbleBorder = DarkOutgoingBubbleBorderClean,
    outgoingText = DarkOutgoingTextClean,
    outgoingMeta = DarkOutgoingMetaClean
)

// Emerald — vivid spring green.
val EmeraldAccentLight = ForestAccentLight.copy(
    primary = Color(0xFF0E7A51),
    primaryContainer = Color(0xFFD2F1E0),
    outgoingBubbleBg = Color(0xFF0E7A51),
    outgoingBubbleBorder = Color(0xFF0A5739)
)
val EmeraldAccentDark = ForestAccentDark.copy(
    primary = Color(0xFF6FD9A6),
    primaryContainer = Color(0xFF0E3A29),
    outgoingBubbleBg = Color(0xFF10513A),
    outgoingBubbleBorder = Color(0xFF1D6E4E)
)

// Ocean — deep teal blue.
val OceanAccentLight = AccentTint(
    primary = Color(0xFF175C6E),
    onPrimary = Color(0xFFF2F8F9),
    primaryContainer = Color(0xFFD0E9F0),
    onPrimaryContainer = Color(0xFF0A3340),
    outgoingBubbleBg = Color(0xFF175C6E),
    outgoingBubbleBorder = Color(0xFF0F3F4C),
    outgoingText = Color(0xFFF2F8F9),
    outgoingMeta = Color(0xFFA8CBD5)
)
val OceanAccentDark = AccentTint(
    primary = Color(0xFF7FCAD9),
    onPrimary = Color(0xFF062730),
    primaryContainer = Color(0xFF0D3440),
    onPrimaryContainer = Color(0xFFCFE9F0),
    outgoingBubbleBg = Color(0xFF0F3E4C),
    outgoingBubbleBorder = Color(0xFF1B5B6D),
    outgoingText = Color(0xFFEFF9FB),
    outgoingMeta = Color(0xFF9CC5CF)
)

// Dusk — calm indigo.
val DuskAccentLight = AccentTint(
    primary = Color(0xFF3B4A8C),
    onPrimary = Color(0xFFF4F5FA),
    primaryContainer = Color(0xFFDEE2F2),
    onPrimaryContainer = Color(0xFF1D2547),
    outgoingBubbleBg = Color(0xFF3B4A8C),
    outgoingBubbleBorder = Color(0xFF283261),
    outgoingText = Color(0xFFF4F5FA),
    outgoingMeta = Color(0xFFB4BCE0)
)
val DuskAccentDark = AccentTint(
    primary = Color(0xFF9FAEE8),
    onPrimary = Color(0xFF171E3A),
    primaryContainer = Color(0xFF252D57),
    onPrimaryContainer = Color(0xFFDFE3F5),
    outgoingBubbleBg = Color(0xFF2B3560),
    outgoingBubbleBorder = Color(0xFF3D4A85),
    outgoingText = Color(0xFFF0F2FB),
    outgoingMeta = Color(0xFFA5B0DC)
)

// Sunset — warm terracotta amber.
val SunsetAccentLight = AccentTint(
    primary = Color(0xFF9C4A1E),
    onPrimary = Color(0xFFFDF7F1),
    primaryContainer = Color(0xFFFAE1D2),
    onPrimaryContainer = Color(0xFF54240C),
    outgoingBubbleBg = Color(0xFF9C4A1E),
    outgoingBubbleBorder = Color(0xFF733413),
    outgoingText = Color(0xFFFDF7F1),
    outgoingMeta = Color(0xFFE7C2A8)
)
val SunsetAccentDark = AccentTint(
    primary = Color(0xFFEEA97E),
    onPrimary = Color(0xFF471D08),
    primaryContainer = Color(0xFF5C2A10),
    onPrimaryContainer = Color(0xFFFBE4D4),
    outgoingBubbleBg = Color(0xFF66300F),
    outgoingBubbleBorder = Color(0xFF8A4620),
    outgoingText = Color(0xFFFDF5EE),
    outgoingMeta = Color(0xFFE0B58F)
)

// Rose — deep ruby.
val RoseAccentLight = AccentTint(
    primary = Color(0xFF93314B),
    onPrimary = Color(0xFFFDF4F6),
    primaryContainer = Color(0xFFFADEE5),
    onPrimaryContainer = Color(0xFF4E1425),
    outgoingBubbleBg = Color(0xFF93314B),
    outgoingBubbleBorder = Color(0xFF6C2133),
    outgoingText = Color(0xFFFDF4F6),
    outgoingMeta = Color(0xFFE5BCC7)
)
val RoseAccentDark = AccentTint(
    primary = Color(0xFFEC9FB5),
    onPrimary = Color(0xFF4A1425),
    primaryContainer = Color(0xFF5C2033),
    onPrimaryContainer = Color(0xFFFAE0E7),
    outgoingBubbleBg = Color(0xFF632437),
    outgoingBubbleBorder = Color(0xFF8B3950),
    outgoingText = Color(0xFFFDF2F5),
    outgoingMeta = Color(0xFFDFB0BE)
)

// Amethyst — muted violet.
val AmethystAccentLight = AccentTint(
    primary = Color(0xFF6F44A5),
    onPrimary = Color(0xFFF8F5FD),
    primaryContainer = Color(0xFFEDE3F8),
    onPrimaryContainer = Color(0xFF38215A),
    outgoingBubbleBg = Color(0xFF6F44A5),
    outgoingBubbleBorder = Color(0xFF51307A),
    outgoingText = Color(0xFFF8F5FD),
    outgoingMeta = Color(0xFFCBB8E4)
)
val AmethystAccentDark = AccentTint(
    primary = Color(0xFFBFA3E4),
    onPrimary = Color(0xFF33215A),
    primaryContainer = Color(0xFF453070),
    onPrimaryContainer = Color(0xFFEEE4F9),
    outgoingBubbleBg = Color(0xFF4A3275),
    outgoingBubbleBorder = Color(0xFF68499B),
    outgoingText = Color(0xFFF7F3FD),
    outgoingMeta = Color(0xFFC1ABE3)
)

// Graphite — neutral minimal (accent-free grayscale).
val GraphiteAccentLight = AccentTint(
    primary = Color(0xFF3A4038),
    onPrimary = Color(0xFFF3F3EC),
    primaryContainer = Color(0xFFE4E4DA),
    onPrimaryContainer = Color(0xFF1F231D),
    outgoingBubbleBg = Color(0xFF3A4038),
    outgoingBubbleBorder = Color(0xFF272B25),
    outgoingText = Color(0xFFF3F3EC),
    outgoingMeta = Color(0xFFBFC3B9)
)
val GraphiteAccentDark = AccentTint(
    primary = Color(0xFFB3BBAF),
    onPrimary = Color(0xFF1F231D),
    primaryContainer = Color(0xFF2C3229),
    onPrimaryContainer = Color(0xFFDCE1D8),
    outgoingBubbleBg = Color(0xFF2E352C),
    outgoingBubbleBorder = Color(0xFF454D41),
    outgoingText = Color(0xFFEFF1EB),
    outgoingMeta = Color(0xFFA5AC9F)
)

// ---- AMOLED deep-black surfaces (pure black power-saving mode) ------
val AmoledBg = Color(0xFF000000)
val AmoledSurface = Color(0xFF050805)
val AmoledSurfaceElevated = Color(0xFF0B120D)
val AmoledSurfaceSearch = Color(0xFF030603)
val AmoledTopBar = Color(0xFF030705)
val AmoledOutline = Color(0xFF1A241C)
