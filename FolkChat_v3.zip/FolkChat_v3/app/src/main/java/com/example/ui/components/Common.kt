package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.LocalChatColors
import java.io.File

/**
 * Brand-consistent icon tile for feature rows, setting categories and profile actions.
 * It uses existing theme tokens only, so light/dark mode and the FolkChat palette stay coherent.
 */
@Composable
fun FolkIconTile(
    icon: ImageVector,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    cornerRadius: Dp = 14.dp,
    tint: Color = MaterialTheme.colorScheme.primary,
    container: Color = MaterialTheme.colorScheme.primaryContainer,
    borderColor: Color = LocalChatColors.current.borderSubtle.copy(alpha = 0.78f),
    iconSize: Dp = 20.dp
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(listOf(container, container.copy(alpha = 0.72f))))
            .border(1.dp, borderColor, shape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(iconSize))
    }
}

/**
 * Small action button with tactile press scaling. This changes only presentation;
 * callers continue to provide the original action and accessibility label.
 */
@Composable
fun FolkIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 20.dp,
    enabled: Boolean = true,
    reduceMotion: Boolean = false,
    containerColor: Color = Color.Transparent,
    contentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant
) {
    val interactions = androidx.compose.runtime.remember { MutableInteractionSource() }
    val isPressed by interactions.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed && !reduceMotion && enabled) 0.91f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "folkIconButtonPressScale"
    )
    IconButton(
        onClick = onClick,
        enabled = enabled,
        interactionSource = interactions,
        colors = IconButtonDefaults.iconButtonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = containerColor.copy(alpha = 0.28f),
            disabledContentColor = contentColor.copy(alpha = 0.42f)
        ),
        modifier = modifier
            .size(size)
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
    ) {
        Icon(icon, contentDescription = contentDescription, modifier = Modifier.size(iconSize))
    }
}

/**
 * Shared identity avatar used throughout FolkChat. The outer ring, soft two-tone
 * fallback and restrained presence badge keep identity treatment consistent
 * across chat lists, chat headers, people and call screens.
 */
@Composable
fun PeerAvatar(
    name: String,
    avatarPath: String?,
    size: Dp = 52.dp,
    isOnline: Boolean = false,
    showPresence: Boolean = false
) {
    val chatColors = LocalChatColors.current
    val context = LocalContext.current
    val presenceScale by animateFloatAsState(
        targetValue = if (isOnline) 1f else 0.94f,
        animationSpec = tween(durationMillis = 220),
        label = "avatarPresenceScale"
    )
    val avatarBorder by animateColorAsState(
        targetValue = if (showPresence && isOnline) chatColors.presenceOnline.copy(alpha = 0.88f)
        else chatColors.borderSubtle.copy(alpha = 0.82f),
        animationSpec = tween(durationMillis = 240),
        label = "avatarBorderColor"
    )
    val avatarShape = CircleShape
    val avatarFile = avatarPath?.let { File(it) }?.takeIf { it.exists() }

    Box(
        modifier = Modifier
            .size(size)
            .clip(avatarShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(if (showPresence && isOnline) 1.6.dp else 1.dp, avatarBorder, avatarShape)
    ) {
        if (avatarFile != null) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(avatarFile)
                    .crossfade(true)
                    .build(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size - 2.dp)
                    .align(Alignment.Center)
                    .clip(avatarShape)
            )
        } else {
            Box(
                modifier = Modifier
                    .size(size - 2.dp)
                    .align(Alignment.Center)
                    .clip(avatarShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.secondaryContainer
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initialsOf(name),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontSize = (size.value * 0.34f).sp,
                    letterSpacing = (-0.4).sp
                )
            }
        }

        if (showPresence) {
            val ring = size * 0.055f
            Box(
                modifier = Modifier
                    .size(size * 0.27f)
                    .align(Alignment.BottomEnd)
                    .then(
                        Modifier
                            .clip(CircleShape)
                            .background(if (isOnline) chatColors.presenceOnline else MaterialTheme.colorScheme.surfaceVariant)
                            .border(ring, MaterialTheme.colorScheme.surface, CircleShape)
                    )
            ) {
                if (isOnline) {
                    Box(
                        modifier = Modifier
                            .size((size * 0.27f) - ring * 2f)
                            .align(Alignment.Center)
                            .scale(presenceScale)
                            .clip(CircleShape)
                            .background(chatColors.presenceOnline)
                    )
                }
            }
        }
    }
}

fun initialsOf(name: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return when {
        parts.isEmpty() -> "?"
        parts.size == 1 -> parts[0].take(1).uppercase()
        else -> (parts[0].take(1) + parts[1].take(1)).uppercase()
    }
}

/**
 * Messenger-class animated typing indicator: three dots that breathe in a
 * rolling phase. Falls back to static dots when [reduceMotion] is on.
 */
@Composable
fun AnimatedTypingDots(
    dotColor: Color = LocalChatColors.current.presenceOnline,
    reduceMotion: Boolean = false,
    dotSize: Dp = 4.5.dp
) {
    if (reduceMotion) {
        androidx.compose.foundation.layout.Row(
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp)
        ) {
            repeat(3) {
                Box(
                    modifier = Modifier
                        .size(dotSize)
                        .clip(CircleShape)
                        .background(dotColor.copy(alpha = 0.75f))
                )
            }
        }
        return
    }
    androidx.compose.foundation.layout.Row(
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp)
    ) {
        repeat(3) { index ->
            val phase = remember { androidx.compose.animation.core.Animatable(0.35f) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(index * 160L)
                while (true) {
                    phase.animateTo(1f, tween(durationMillis = 340, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                    phase.animateTo(0.35f, tween(durationMillis = 340, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                    kotlinx.coroutines.delay(280L)
                }
            }
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .graphicsLayer { alpha = phase.value }
                    .scale(0.8f + phase.value * 0.35f)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
    }
}

// ---------------------------------------------------------------------
// Time formatting helpers (shared across screens)
// ---------------------------------------------------------------------

private val timeFormat by lazy { java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault()) }
private val dayMonthFormat by lazy { java.text.SimpleDateFormat("MMM d", java.util.Locale.getDefault()) }
private val fullDateFormat by lazy { java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.getDefault()) }
private val dayOfWeekFormat by lazy { java.text.SimpleDateFormat("EEEE", java.util.Locale.getDefault()) }

private fun startOfDay(ms: Long): Long {
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = ms
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

/** Compact list timestamp: time today, "Yesterday", weekday this week, else date. */
fun formatListTimestamp(ms: Long): String {
    val today = startOfDay(System.currentTimeMillis())
    val day = startOfDay(ms)
    return when {
        day == today -> timeFormat.format(java.util.Date(ms))
        day == today - 86_400_000L -> "Yesterday"
        day > today - 6 * 86_400_000L -> dayOfWeekFormat.format(java.util.Date(ms)).take(3)
        else -> dayMonthFormat.format(java.util.Date(ms))
    }
}

/** In-chat date divider label. */
fun formatChatDivider(ms: Long): String {
    val today = startOfDay(System.currentTimeMillis())
    val day = startOfDay(ms)
    return when {
        day == today -> "Today"
        day == today - 86_400_000L -> "Yesterday"
        day > today - 7 * 86_400_000L -> dayOfWeekFormat.format(java.util.Date(ms))
        else -> fullDateFormat.format(java.util.Date(ms))
    }
}

/** Presence subtitle: "Online", "Last seen today at 3:42 PM", "Offline". */
fun formatPresence(isOnline: Boolean, lastSeenMs: Long): String {
    if (isOnline) return "Online"
    if (lastSeenMs <= 0L) return "Offline"
    val today = startOfDay(System.currentTimeMillis())
    val day = startOfDay(lastSeenMs)
    return when {
        day == today -> "Last seen today at ${timeFormat.format(java.util.Date(lastSeenMs))}"
        day == today - 86_400_000L -> "Last seen yesterday at ${timeFormat.format(java.util.Date(lastSeenMs))}"
        else -> "Last seen ${fullDateFormat.format(java.util.Date(lastSeenMs))}"
    }
}
