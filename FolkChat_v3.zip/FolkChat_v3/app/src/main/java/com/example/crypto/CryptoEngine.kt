package com.example.crypto

import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.generators.Ed25519KeyPairGenerator
import org.bouncycastle.crypto.generators.HKDFBytesGenerator
import org.bouncycastle.crypto.generators.X25519KeyPairGenerator
import org.bouncycastle.crypto.macs.HMac
import org.bouncycastle.crypto.modes.ChaCha20Poly1305
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.Ed25519KeyGenerationParameters
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.params.HKDFParameters
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.crypto.params.X25519KeyGenerationParameters
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import java.nio.ByteBuffer
import java.security.SecureRandom

data class KeyPairBytes(
    val privateKey: ByteArray,
    val publicKey: ByteArray
) {
    val privateKeyHex: String get() = CryptoEngine.bytesToHex(privateKey)
    val publicKeyHex: String get() = CryptoEngine.bytesToHex(publicKey)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is KeyPairBytes) return false
        return privateKey.contentEquals(other.privateKey) && publicKey.contentEquals(other.publicKey)
    }

    override fun hashCode(): Int = 31 * privateKey.contentHashCode() + publicKey.contentHashCode()
}

data class PairingQrCode(
    val pubKeyHex: String,
    val displayName: String,
    val tokenHex: String,
    val expiresAtMs: Long
)

data class EncryptedEnvelope(
    val ephemeralPublicKey: ByteArray,
    val nonce: ByteArray,
    val ciphertext: ByteArray
) {
    fun toByteArray(): ByteArray {
        val buffer = ByteBuffer.allocate(ephemeralPublicKey.size + nonce.size + ciphertext.size)
        buffer.put(ephemeralPublicKey)
        buffer.put(nonce)
        buffer.put(ciphertext)
        return buffer.array()
    }

    companion object {
        fun fromByteArray(bytes: ByteArray): EncryptedEnvelope {
            require(bytes.size >= 32 + 12 + 16) { "Envelope too small: ${bytes.size}" }
            val ephPub = bytes.copyOfRange(0, 32)
            val nonce = bytes.copyOfRange(32, 44)
            val cipher = bytes.copyOfRange(44, bytes.size)
            return EncryptedEnvelope(ephPub, nonce, cipher)
        }
    }
}

object CryptoEngine {
    private val secureRandom = SecureRandom()

    fun generateX25519KeyPair(): KeyPairBytes {
        val gen = X25519KeyPairGenerator()
        gen.init(X25519KeyGenerationParameters(secureRandom))
        val pair = gen.generateKeyPair()
        val priv = (pair.private as X25519PrivateKeyParameters).encoded
        val pub = (pair.public as X25519PublicKeyParameters).encoded
        return KeyPairBytes(priv, pub)
    }

    fun generateEd25519KeyPair(): KeyPairBytes {
        val gen = Ed25519KeyPairGenerator()
        gen.init(Ed25519KeyGenerationParameters(secureRandom))
        val pair = gen.generateKeyPair()
        val priv = (pair.private as Ed25519PrivateKeyParameters).encoded
        val pub = (pair.public as Ed25519PublicKeyParameters).encoded
        return KeyPairBytes(priv, pub)
    }

    fun computeSharedSecret(myPrivateKey: ByteArray, peerPublicKey: ByteArray): ByteArray {
        require(myPrivateKey.size == 32) { "X25519 private key must be 32 bytes" }
        require(peerPublicKey.size == 32) { "X25519 public key must be 32 bytes" }
        val agreement = X25519Agreement()
        val privParams = X25519PrivateKeyParameters(myPrivateKey, 0)
        val pubParams = X25519PublicKeyParameters(peerPublicKey, 0)
        agreement.init(privParams)
        val secret = ByteArray(agreement.agreementSize)
        try {
            agreement.calculateAgreement(pubParams, secret, 0)
            // RFC 7748 requires rejecting an all-zero shared secret (e.g. low-order peer points).
            require(secret.any { it != 0.toByte() }) { "Invalid X25519 peer public key" }
            return secret
        } catch (e: Exception) {
            secret.fill(0)
            throw e
        }
    }

    fun hkdfSha256(ikm: ByteArray, salt: ByteArray? = null, info: ByteArray? = null, length: Int = 32): ByteArray {
        val hkdf = HKDFBytesGenerator(SHA256Digest())
        hkdf.init(HKDFParameters(ikm, salt, info))
        val output = ByteArray(length)
        hkdf.generateBytes(output, 0, length)
        return output
    }

    /** HMAC-SHA-256 for authenticated peer packets and protocol handshakes. */
    fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray {
        val hmac = HMac(SHA256Digest())
        hmac.init(KeyParameter(key))
        hmac.update(data, 0, data.size)
        return ByteArray(hmac.macSize).also { hmac.doFinal(it, 0) }
    }

    fun encryptChaCha20Poly1305(key: ByteArray, nonce: ByteArray, plaintext: ByteArray, associatedData: ByteArray? = null): ByteArray {
        require(key.size == 32) { "Key must be 32 bytes" }
        require(nonce.size == 12) { "Nonce must be 12 bytes" }
        val cipher = ChaCha20Poly1305()
        val params = AEADParameters(KeyParameter(key), 128, nonce, associatedData)
        cipher.init(true, params)
        val output = ByteArray(cipher.getOutputSize(plaintext.size))
        val len = cipher.processBytes(plaintext, 0, plaintext.size, output, 0)
        cipher.doFinal(output, len)
        return output
    }

    fun decryptChaCha20Poly1305(key: ByteArray, nonce: ByteArray, ciphertext: ByteArray, associatedData: ByteArray? = null): ByteArray {
        require(key.size == 32) { "Key must be 32 bytes" }
        require(nonce.size == 12) { "Nonce must be 12 bytes" }
        val cipher = ChaCha20Poly1305()
        val params = AEADParameters(KeyParameter(key), 128, nonce, associatedData)
        cipher.init(false, params)
        val output = ByteArray(cipher.getOutputSize(ciphertext.size))
        val len = cipher.processBytes(ciphertext, 0, ciphertext.size, output, 0)
        val finalLen = cipher.doFinal(output, len)
        return output.copyOf(len + finalLen)
    }

    @Suppress("UNUSED_PARAMETER")
    fun encryptToPeer(recipientPublicKey: ByteArray, plaintext: ByteArray, senderStaticPrivKey: ByteArray? = null): EncryptedEnvelope {
        // senderStaticPrivKey is retained for source compatibility with older callers; sender
        // authentication is provided by TransportCoordinator's authenticated envelope.
        val ephemeralKeyPair = generateX25519KeyPair()
        try {
            val ecdhSecret = computeSharedSecret(ephemeralKeyPair.privateKey, recipientPublicKey)
            try {
                val symmetricKey = hkdfSha256(
                    ecdhSecret,
                    salt = "SecureChat-v1".toByteArray(),
                    info = "message-key".toByteArray(),
                    length = 32
                )
                try {
                    val nonce = ByteArray(12).apply { secureRandom.nextBytes(this) }
                    val ciphertext = encryptChaCha20Poly1305(symmetricKey, nonce, plaintext)
                    return EncryptedEnvelope(ephemeralKeyPair.publicKey.copyOf(), nonce, ciphertext)
                } finally {
                    symmetricKey.fill(0)
                }
            } finally {
                ecdhSecret.fill(0)
            }
        } finally {
            ephemeralKeyPair.privateKey.fill(0)
        }
    }

    fun decryptFromPeer(myPrivateKey: ByteArray, envelope: EncryptedEnvelope): ByteArray {
        val ecdhSecret = computeSharedSecret(myPrivateKey, envelope.ephemeralPublicKey)
        try {
            val symmetricKey = hkdfSha256(
                ecdhSecret,
                salt = "SecureChat-v1".toByteArray(),
                info = "message-key".toByteArray(),
                length = 32
            )
            try {
                return decryptChaCha20Poly1305(symmetricKey, envelope.nonce, envelope.ciphertext)
            } finally {
                symmetricKey.fill(0)
            }
        } finally {
            ecdhSecret.fill(0)
        }
    }

    /**
     * Computes a rotating 16-byte discovery tag. The default epoch is one minute; rotating
     * tags reduce passive linkability but are not anonymous, especially when derived from a
     * public identity key rather than a secret shared only by peers.
     */
    fun computeRotatingTag(sharedSecretOrIdentity: ByteArray, epochSlot: Long = currentEpochSlot()): ByteArray {
        val hmac = HMac(SHA256Digest())
        hmac.init(KeyParameter(sharedSecretOrIdentity))
        val slotBytes = ByteBuffer.allocate(8).putLong(epochSlot).array()
        hmac.update(slotBytes, 0, slotBytes.size)
        val fullTag = ByteArray(hmac.macSize)
        hmac.doFinal(fullTag, 0)
        return fullTag.copyOf(16) // Truncate to 16 bytes for BLE payload efficiency
    }

    fun currentEpochSlot(epochIntervalSec: Long = 60L): Long {
        require(epochIntervalSec > 0L) { "Epoch interval must be positive" }
        return (System.currentTimeMillis() / 1000L) / epochIntervalSec
    }

    /**
     * Computes a longer display fingerprint for out-of-band identity comparison.
     * Six 4-digit groups carry about 80 bits of displayed fingerprint material.
     */
    fun computeSafetyNumber(pubKey1: ByteArray, pubKey2: ByteArray): String {
        val sorted = if (bytesToHex(pubKey1) < bytesToHex(pubKey2)) pubKey1 + pubKey2 else pubKey2 + pubKey1
        val digest = SHA256Digest()
        digest.update(sorted, 0, sorted.size)
        val hash = ByteArray(digest.digestSize)
        digest.doFinal(hash, 0)
        return formatFingerprint(hash)
    }

    fun computeVerificationFingerprint(pubKey: ByteArray): String {
        val digest = SHA256Digest()
        digest.update(pubKey, 0, pubKey.size)
        val hash = ByteArray(digest.digestSize)
        digest.doFinal(hash, 0)
        return formatFingerprint(hash)
    }

    private fun formatFingerprint(hash: ByteArray): String = (0 until 6).joinToString(" ") { index ->
        val offset = index * 2
        val value = ((hash[offset].toInt() and 0xff) shl 8) or (hash[offset + 1].toInt() and 0xff)
        String.format(java.util.Locale.ROOT, "%04d", value % 10_000)
    }

    /** Generates a cryptographically random, single-use QR pairing token. */
    fun randomTokenHex(byteCount: Int = 32): String {
        require(byteCount in 16..64) { "Token size must be between 16 and 64 bytes" }
        return ByteArray(byteCount).also { secureRandom.nextBytes(it) }.let(::bytesToHex)
    }

    /** Encodes a short-lived consent-to-pair QR. The token is a bearer secret; never log it. */
    fun createPairingQrCode(pubKeyHex: String, displayName: String, tokenHex: String, expiresAtMs: Long): String {
        val key = pubKeyHex.lowercase().trim()
        val token = tokenHex.lowercase().trim()
        require(key.matches(Regex("^[0-9a-f]{64}$"))) { "Invalid public key" }
        require(token.matches(Regex("^[0-9a-f]{64}$"))) { "Invalid pairing token" }
        val safeName = java.net.URLEncoder.encode(sanitizeDisplayName(displayName), "UTF-8")
        return "fc2:$key:$token:$expiresAtMs:$safeName"
    }

    /** Parses a short-lived pairing QR while rejecting expired/far-future challenges. */
    fun parsePairingQrCode(rawCode: String, nowMs: Long = System.currentTimeMillis()): PairingQrCode? {
        return try {
            val code = rawCode.trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
            val parts = code.split(":", limit = 5)
            if (parts.size != 5 || parts[0] != "fc2") return null
            val key = parts[1].lowercase()
            val token = parts[2].lowercase()
            val expires = parts[3].toLongOrNull() ?: return null
            if (!key.matches(Regex("^[0-9a-f]{64}$")) || !token.matches(Regex("^[0-9a-f]{64}$"))) return null
            if (expires <= nowMs || expires > nowMs + 3 * 60_000L) return null
            val name = sanitizeDisplayName(java.net.URLDecoder.decode(parts[4], "UTF-8"))
                .ifBlank { "Peer ${key.take(6)}" }
            PairingQrCode(key, name, token, expires)
        } catch (_: Exception) {
            null
        }
    }

    fun parseContactCode(rawCode: String): Pair<String, String>? {
        var code = rawCode.trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
        if (code.startsWith("folkchat://contact?code=")) {
            code = code.removePrefix("folkchat://contact?code=")
        } else if (code.startsWith("folkchat:")) {
            code = code.removePrefix("folkchat:")
        }

        // Try sc1:pubKey:displayName
        val parts = code.split(":")
        if (parts.size >= 3 && parts[0] == "sc1") {
            val pubKeyHex = parts[1].trim()
            val name = sanitizeDisplayName(parts.drop(2).joinToString(":"))
            if (pubKeyHex.length == 64 && pubKeyHex.matches(Regex("^[0-9a-fA-F]+$"))) {
                return Pair(pubKeyHex.lowercase(), name.ifBlank { "Peer " + pubKeyHex.take(6) })
            }
        } else if (parts.size == 2 && parts[0] == "sc1") {
            val pubKeyHex = parts[1].trim()
            if (pubKeyHex.length == 64 && pubKeyHex.matches(Regex("^[0-9a-fA-F]+$"))) {
                return Pair(pubKeyHex.lowercase(), "Peer " + pubKeyHex.take(6))
            }
        }

        // Check for URI query params like folkchat://peer?key=xxx&name=yyy
        if (code.contains("key=") || code.contains("pubkey=")) {
            val keyRegex = Regex("(?:key|pubkey)=([0-9a-fA-F]{64})", RegexOption.IGNORE_CASE)
            val keyMatch = keyRegex.find(code)
            if (keyMatch != null) {
                val pubHex = keyMatch.groupValues[1].lowercase()
                val nameRegex = Regex("(?:name|user)=([^&]+)", RegexOption.IGNORE_CASE)
                val nameMatch = nameRegex.find(code)
                // Malformed URL-encoding in an untrusted QR must not crash the scanner callback.
                val decodedName = nameMatch?.groupValues?.get(1)?.let { encoded ->
                    runCatching { java.net.URLDecoder.decode(encoded, "UTF-8") }.getOrNull()
                }
                val name = sanitizeDisplayName(decodedName.orEmpty()).ifBlank { "Peer " + pubHex.take(6) }
                return Pair(pubHex, name)
            }
        }

        // Check if raw 64 hex characters
        if (code.length == 64 && code.matches(Regex("^[0-9a-fA-F]+$"))) {
            return Pair(code.lowercase(), "Peer " + code.take(6))
        }

        return null
    }

    private fun sanitizeDisplayName(name: String): String =
        name.filterNot { Character.isISOControl(it) }.trim().take(80)

    fun bytesToHex(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        val alphabet = "0123456789abcdef"
        val chars = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val value = bytes[i].toInt() and 0xff
            chars[i * 2] = alphabet[value ushr 4]
            chars[i * 2 + 1] = alphabet[value and 0x0f]
        }
        return String(chars)
    }

    /** Strict hexadecimal decoder: malformed/odd-length values are rejected, never truncated. */
    fun hexToBytes(hex: String): ByteArray {
        val cleaned = hex.trim()
        require(cleaned.length % 2 == 0) { "Hexadecimal input must have an even length" }
        require(cleaned.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
            "Hexadecimal input contains invalid characters"
        }
        val result = ByteArray(cleaned.length / 2)
        for (i in result.indices) {
            val index = i * 2
            result[i] = cleaned.substring(index, index + 2).toInt(16).toByte()
        }
        return result
    }
}
