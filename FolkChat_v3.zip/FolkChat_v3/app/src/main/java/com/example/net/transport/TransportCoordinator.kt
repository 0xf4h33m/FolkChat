package com.example.net.transport

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptedEnvelope
import com.example.data.ActiveRouteType
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DiscoveredPeer
import com.example.data.EncryptedVault
import com.example.data.GroupConversation
import com.example.data.MediaAutoDownload
import com.example.data.MediaKind
import com.example.data.MediaAttachment
import com.example.data.MessageRequest
import com.example.data.MessageStatus
import com.example.data.RoutingPolicy
import com.example.data.TransferState
import com.example.net.ble.BleManager
import com.example.net.call.CallSignalType
import com.example.net.call.IncomingCallSignal
import com.example.net.media.MediaTransferManager
import com.example.net.online.OnlineRelayManager
import com.example.net.online.PublicTopicTransport
import com.example.net.routing.RoutingEngine
import com.example.net.socket.SocketManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.ByteArrayOutputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class TransportCoordinator(
    private val context: Context,
    val vault: EncryptedVault
) {
    companion object {
        private const val TAG = "TransportCoordinator"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val routingEngine = RoutingEngine(context)
    val onlineRelayManager = OnlineRelayManager(context, vault)
    /** Public, pairwise-secret WAN fallback requiring no user-supplied relay URL or API key. */
    val publicTopicTransport = PublicTopicTransport(vault)
    val bleManager = BleManager(context)
    val socketManager = SocketManager(context, vault)

    val mediaTransferManager = MediaTransferManager(
        vault = vault,
        mediaDir = File(vault.dataRoot(), "media"),
        dispatcher = { recipient, json -> dispatchEncryptedJson(recipient, json) },
        onUpdated = { _onConversationUpdated.tryEmit(Unit) }
    )

    /** Called after a user changes from session-only cache to durable storage. */
    fun refreshLocalStorageDirectory() {
        mediaTransferManager.updateMediaDirectory(File(vault.dataRoot(), "media"))
    }

    private val _allDiscoveredPeers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val allDiscoveredPeers: StateFlow<List<DiscoveredPeer>> = _allDiscoveredPeers.asStateFlow()

    private val _onNewMessageReceived = MutableSharedFlow<ChatMessage>(extraBufferCapacity = 64)
    val onNewMessageReceived: SharedFlow<ChatMessage> = _onNewMessageReceived.asSharedFlow()

    private val _onConversationUpdated = MutableSharedFlow<Unit>(extraBufferCapacity = 64)
    val onConversationUpdated: SharedFlow<Unit> = _onConversationUpdated.asSharedFlow()

    private val _onCallSignal = MutableSharedFlow<IncomingCallSignal>(extraBufferCapacity = 32)
    val onCallSignal: SharedFlow<IncomingCallSignal> = _onCallSignal.asSharedFlow()

    /** peerPubKeyHex -> isTyping events for live "typing…" indicators. */
    private val _onTypingUpdate = MutableSharedFlow<Pair<String, Boolean>>(extraBufferCapacity = 32)
    val onTypingUpdate: SharedFlow<Pair<String, Boolean>> = _onTypingUpdate.asSharedFlow()

    /** peerPubKeyHex of any peer that just produced traffic (presence refresh). */
    private val _onPresenceSeen = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val onPresenceSeen: SharedFlow<String> = _onPresenceSeen.asSharedFlow()

    private var outboxWorkerJob: Job? = null
    private val lastTypingAtByPeer = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** Serializes outbox flushes: an immediate flush (new message) racing the 2-second worker
     * previously read the same QUEUED list twice and dispatched duplicate sealed envelopes. */
    private val flushMutex = Mutex()

    private data class CallSdpAssembly(
        val sender: String,
        val callId: String,
        val signalType: CallSignalType,
        val callType: com.example.data.CallType,
        val senderDisplayName: String,
        val sdpType: String,
        val fragmentCount: Int,
        val createdAtMs: Long,
        val fragments: Array<String?>
    )
    private val callSdpAssemblyLock = Any()
    private val callSdpAssemblies = LinkedHashMap<String, CallSdpAssembly>()

    private data class PendingQrPairing(
        val tokenHex: String,
        val requestId: String,
        val displayName: String,
        val expiresAtMs: Long
    )
    private val pendingQrPairings = ConcurrentHashMap<String, PendingQrPairing>()

    init {
        // Observe peers from BLE and Socket
        scope.launch {
            bleManager.discoveredPeers.collectLatest { blePeers ->
                val socketPeers = socketManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }
        scope.launch {
            socketManager.discoveredPeers.collectLatest { socketPeers ->
                val blePeers = bleManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }

        // Listen for incoming payloads from Online Relay
        scope.launch {
            // Use ordered collection here (not collectLatest): a new packet must not
            // cancel processing of a previous durable relay envelope. Acknowledge the
            // relay mailbox only after authenticated processing has returned.
            onlineRelayManager.incomingPayloads.collect { envelope ->
                try {
                    handleIncomingRawPayload(envelope.payload, "ONLINE_RELAY")
                } finally {
                    envelope.deliveryId?.let(onlineRelayManager::acknowledgeDelivery)
                }
            }
        }

        // Listen for the public WAN fallback. Packets remain E2E-encrypted and are
        // authenticated again by handleIncomingRawPayload before any state is changed.
        scope.launch {
            publicTopicTransport.incomingPayloads.collect { rawPayload ->
                handleIncomingRawPayload(rawPayload, "PUBLIC_TOPIC")
            }
        }

        // Listen for incoming payloads from BLE
        scope.launch {
            bleManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "BLE")
            }
        }

        // Listen for incoming payloads from Wi-Fi Socket
        scope.launch {
            socketManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "WIFI_SOCKET")
            }
        }

        startOutboxWorker()
    }

    private fun mergePeers(blePeers: Collection<DiscoveredPeer>, socketPeers: Collection<DiscoveredPeer>) {
        val now = System.currentTimeMillis()
        // Prune peers whose beacon went silent. A cached Wi-Fi IP that is no longer announcing
        // used to stay in the list forever; dispatches then preferred a dead address for every
        // message (each send waited for the full 5s connect timeout) before falling back.
        val bleFresh = blePeers.filter { now - it.lastSeenEpochMs <= 20_000L }
        val socketFresh = socketPeers.filter {
            // Manually registered endpoints (lastSeen == 0) are kept until they explicitly fail.
            it.lastSeenEpochMs == 0L || now - it.lastSeenEpochMs <= 25_000L
        }
        val list = mutableListOf<DiscoveredPeer>()
        list.addAll(bleFresh)
        list.addAll(socketFresh)
        _allDiscoveredPeers.value = list.sortedByDescending { it.lastSeenEpochMs }
    }

    /** Start listening on a QR-token-derived, short-lived public inbox while the own QR is shown. */
    fun activatePairingInbox(tokenHex: String) = publicTopicTransport.activatePairingInbox(tokenHex)

    fun clearPairingInbox(tokenHex: String? = null) = publicTopicTransport.clearPairingInbox(tokenHex)

    /** Dispatch a one-time QR pairing request. Repeats with the same request ID until ACK or expiry. */
    fun beginQrPairing(peerPubKeyHex: String, peerDisplayName: String, tokenHex: String) {
        val peerKey = peerPubKeyHex.lowercase().trim()
        val token = tokenHex.lowercase().trim()
        if (routingEngine.routingPolicy.value == RoutingPolicy.FORCE_OFFLINE) return
        if (!peerKey.matches(Regex("^[0-9a-f]{64}$")) ||
            !token.matches(Regex("^[0-9a-f]{64}$")) ||
            peerKey == vault.getIdentityKeyPair().publicKeyHex.lowercase()) return
        val pairing = PendingQrPairing(token, UUID.randomUUID().toString(), peerDisplayName.take(80), System.currentTimeMillis() + 90_000L)
        pendingQrPairings[peerKey] = pairing
        // The scanned QR creates the local contact immediately. Start its pairwise relay
        // subscriptions before the first PAIR_REQUEST so a fast PAIR_ACK cannot race the
        // next 15-second periodic contact refresh.
        publicTopicTransport.refreshPeerSubscriptions()
        scope.launch {
            repeat(5) {
                if (pendingQrPairings[peerKey] != pairing || System.currentTimeMillis() >= pairing.expiresAtMs) return@launch
                val request = JSONObject().apply {
                    put("type", "PAIR_REQUEST")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("senderDisplayName", vault.getDisplayName())
                    put("pairingToken", pairing.tokenHex)
                    put("pairingRequestId", pairing.requestId)
                    put("timestamp", System.currentTimeMillis())
                }
                dispatchEncryptedJson(peerKey, request)
                delay(2_500L)
            }
        }
    }

    /** Start internet messaging without Bluetooth/Wi-Fi discovery permissions.
     * This keeps cellular/WAN chat available when the user declines optional mesh permissions. */
    fun startOnlineRelayOnly() {
        bleManager.cleanUp()
        socketManager.stop()
        onlineRelayManager.start(vault.getIdentityKeyPair().publicKey)
        publicTopicTransport.start()
    }

    fun startTransports() {
        val identity = vault.getIdentityKeyPair()
        onlineRelayManager.start(identity.publicKey)
        publicTopicTransport.start()
        // Tor/high-privacy mode avoids local Wi-Fi beacons and BLE advertising, which
        // otherwise reveal proximity and a stable device presence outside the tunnel.
        if (!vault.getSettings().torRoutingEnabled) {
            bleManager.startAdvertising(identity.publicKey)
            bleManager.startScanning()
            socketManager.start(identity.publicKey)
        } else {
            bleManager.stopScanning()
            bleManager.stopAdvertising()
            socketManager.stop()
        }
    }

    fun restartPrivacyTransports() {
        stopTransports()
        startTransports()
    }

    fun stopTransports() {
        onlineRelayManager.stop()
        publicTopicTransport.stop()
        bleManager.cleanUp()
        socketManager.stop()
    }

    private fun startOutboxWorker() {
        outboxWorkerJob = scope.launch {
            while (isActive) {
                flushOutbox()
                delay(2000)
            }
        }
    }

    suspend fun flushOutbox() = flushMutex.withLock {
        val queued = vault.getQueuedOutbox()
        if (queued.isEmpty()) return@withLock

        for (msg in queued) {
            // Media messages are dispatched by the MediaTransferManager, not the text outbox.
            if (msg.attachment != null) continue

            val recipientHex = msg.recipientPubKeyHex.lowercase()

            // 1. Self-loopback delivery (e.g. Saved Notes or testing)
            if (recipientHex == vault.getIdentityKeyPair().publicKeyHex.lowercase()) {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.DELIVERED, "LOOPBACK")
                val incomingCopy = msg.copy(
                    id = UUID.randomUUID().toString(),
                    isOutgoing = false,
                    status = MessageStatus.DELIVERED,
                    routeUsed = "LOOPBACK"
                )
                vault.saveMessage(incomingCopy)
                _onNewMessageReceived.tryEmit(incomingCopy)
                continue
            }

            val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
            val json = buildChatJson(msg)
            val route = dispatchToPeer(recipientHex, recipientPubKeyBytes, json)
            if (route != null) {
                // Transport acceptance is not recipient delivery. Keep the message pending
                // until a signed peer receipt arrives; the outbox applies a bounded retry interval.
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.SENDING, route)
                _onConversationUpdated.tryEmit(Unit)
            } else {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.QUEUED, "OFFLINE_QUEUED")
            }
        }
    }

    private fun buildChatJson(msg: ChatMessage): JSONObject {
        return JSONObject().apply {
            put("type", "CHAT_MSG")
            put("msgId", msg.id)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("recipientPubKey", msg.recipientPubKeyHex)
            put("text", msg.content)
            put("timestamp", msg.timestampMs)
            msg.replyToId?.let { put("replyToId", it) }
            msg.replyToPreview?.let { put("replyToPreview", it) }
            msg.replyToSender?.let { put("replyToSender", it) }
        }
    }

    /** Canonical JSON prevents serializer key order from changing the authenticated bytes. */
    private fun canonicalJson(value: Any?): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> value.keys().asSequence().toList().sorted().joinToString(",", "{", "}") { key ->
            JSONObject.quote(key) + ":" + canonicalJson(value.get(key))
        }
        is JSONArray -> (0 until value.length()).joinToString(",", "[", "]") { i -> canonicalJson(value.get(i)) }
        is String -> JSONObject.quote(value)
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }

    private fun peerAuthKey(sharedSecret: ByteArray, senderHex: String, recipientHex: String): ByteArray =
        CryptoEngine.hkdfSha256(
            sharedSecret,
            salt = "FolkChat-PacketAuth-v1".toByteArray(Charsets.UTF_8),
            info = "$senderHex|$recipientHex".toByteArray(Charsets.UTF_8),
            length = 32
        )

    private fun seal(recipientPubKeyBytes: ByteArray, json: JSONObject): ByteArray? {
        return try {
            require(recipientPubKeyBytes.size == 32) { "Recipient key must be 32 bytes" }
            val identity = vault.getIdentityKeyPair()
            val senderHex = identity.publicKeyHex.lowercase()
            val recipientHex = CryptoEngine.bytesToHex(recipientPubKeyBytes).lowercase()
            json.put("senderPubKey", senderHex)
            json.put("recipientPubKey", recipientHex)
            json.put("authVersion", 1)
            json.remove("authTag")

            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, recipientPubKeyBytes)
            try {
                val authKey = peerAuthKey(shared, senderHex, recipientHex)
                try {
                    val canonical = canonicalJson(json).toByteArray(Charsets.UTF_8)
                    try {
                        val tag = CryptoEngine.hmacSha256(authKey, canonical)
                        try {
                            json.put("authTag", CryptoEngine.bytesToHex(tag))
                        } finally {
                            tag.fill(0)
                        }
                    } finally {
                        canonical.fill(0)
                    }

                    val plaintext = json.toString().toByteArray(Charsets.UTF_8)
                    try {
                        CryptoEngine.encryptToPeer(
                            recipientPublicKey = recipientPubKeyBytes,
                            plaintext = plaintext
                        ).toByteArray()
                    } finally {
                        plaintext.fill(0)
                    }
                } finally {
                    authKey.fill(0)
                }
            } finally {
                shared.fill(0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed authenticating/encrypting payload: ${e.message}")
            null
        }
    }

    /** Require proof that the sender possesses the long-term X25519 private key they claim. */
    private fun verifyAuthenticatedPayload(json: JSONObject): Boolean {
        return try {
            if (json.optInt("authVersion", 0) != 1) return false
            val identity = vault.getIdentityKeyPair()
            val senderHex = json.optString("senderPubKey").lowercase().trim()
            val recipientHex = json.optString("recipientPubKey").lowercase().trim()
            val tagHex = json.optString("authTag").lowercase().trim()
            if (senderHex.length != 64 || !senderHex.matches(Regex("^[0-9a-f]{64}$"))) return false
            if (recipientHex != identity.publicKeyHex.lowercase()) return false
            if (tagHex.length != 64 || !tagHex.matches(Regex("^[0-9a-f]{64}$"))) return false

            val tag = CryptoEngine.hexToBytes(tagHex)
            json.remove("authTag")
            val senderBytes = CryptoEngine.hexToBytes(senderHex)
            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, senderBytes)
            try {
                val authKey = peerAuthKey(shared, senderHex, recipientHex)
                try {
                    val canonical = canonicalJson(json).toByteArray(Charsets.UTF_8)
                    try {
                        val expected = CryptoEngine.hmacSha256(authKey, canonical)
                        try {
                            MessageDigest.isEqual(expected, tag)
                        } finally {
                            expected.fill(0)
                        }
                    } finally {
                        canonical.fill(0)
                    }
                } finally {
                    authKey.fill(0)
                }
            } finally {
                shared.fill(0)
                tag.fill(0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Rejected unauthenticated packet: ${e.message}")
            false
        }
    }

    private fun sendDeliveryReceipt(senderPubKeyHex: String, messageId: String, mediaTransferId: String? = null) {
        if (senderPubKeyHex.isBlank() || messageId.isBlank()) return
        scope.launch {
            val json = JSONObject().apply {
                put("type", if (mediaTransferId == null) "DELIVERY_RECEIPT" else "MEDIA_RECEIPT")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("msgId", messageId)
                mediaTransferId?.let { put("transferId", it) }
            }
            dispatchEncryptedJson(senderPubKeyHex, json)
        }
    }

    private fun handleDeliveryReceipt(senderPubKeyHex: String, json: JSONObject, isMediaReceipt: Boolean) {
        val msgId = json.optString("msgId")
        if (senderPubKeyHex.isBlank() || msgId.isBlank()) return
        val existing = vault.getMessageById(msgId) ?: return
        if (!existing.isOutgoing) return
        if (existing.groupId != null) {
            // Every member returns a normal end-to-end receipt to the original sender.
            // The group is complete only after every other member has acknowledged it.
            if (isMediaReceipt || existing.attachment != null) return
            val group = vault.getGroupById(existing.groupId) ?: return
            val peer = senderPubKeyHex.lowercase()
            val myKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
            if (peer == myKey || peer !in group.memberPubKeyHexes) return
            val recipients = group.memberPubKeyHexes.filter { it != myKey }.toSet()
            vault.updateMessage(msgId) { current ->
                val delivered = current.deliveryPeerPubKeyHexes + peer
                current.copy(
                    deliveryPeerPubKeyHexes = delivered,
                    status = if (delivered.containsAll(recipients)) MessageStatus.DELIVERED else MessageStatus.SENDING
                )
            }
            _onConversationUpdated.tryEmit(Unit)
            return
        }
        if (!existing.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        if (isMediaReceipt) {
            val att = existing.attachment ?: return
            if (att.id != json.optString("transferId")) return
            val accepted = json.optBoolean("accepted", false)
            vault.updateMessage(msgId) {
                if (accepted) it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED, progress = 1f, error = null
                )) else it.copy(status = MessageStatus.FAILED, attachment = it.attachment?.copy(
                    transferState = TransferState.FAILED, error = json.optString("error", "Receiver rejected the completed file")
                ))
            }
        } else {
            if (existing.attachment != null) return
            vault.updateMessageStatusAndRoute(msgId, MessageStatus.DELIVERED, "PEER_RECEIPT")
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun findWifiPeer(expectedTag: String): DiscoveredPeer? {
        // Rotating-tag match for beacon-discovered peers. A manually registered endpoint has
        // no tag, but it is still worth attempting for a verified contact: the direct-socket
        // handshake independently proves the peer's X25519 identity, so a wrong address simply
        // fails the handshake. Previously manual peers were impossible to send to at all.
        return _allDiscoveredPeers.value.firstOrNull { peer ->
            peer.linkType == "WIFI_SOCKET" && peer.hostAddress != null && peer.port > 0 &&
                (peer.tagHex == "manual" ||
                    (peer.tagHex.length >= 16 && expectedTag.startsWith(peer.tagHex, ignoreCase = true)))
        }
    }

    /**
     * Encrypts and dispatches [json] to [recipientPubKeyHex] using the best available
     * route. Returns the route used, or null if the peer was unreachable.
     */
    suspend fun dispatchEncryptedJson(recipientPubKeyHex: String, json: JSONObject): String? {
        val recipientHex = recipientPubKeyHex.lowercase()
        val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
        return dispatchToPeer(recipientHex, recipientPubKeyBytes, json)
    }

    private suspend fun dispatchToPeer(recipientHex: String, recipientPubKeyBytes: ByteArray, json: JSONObject): String? {
        val myHex = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val wireBytes = seal(recipientPubKeyBytes, json) ?: return null

        // First-contact pairing cannot use the regular pairwise topic: the receiver does not yet
        // know the sender's public key. The time-limited QR token supplies a private, ephemeral inbox.
        if (json.optString("type") == "PAIR_REQUEST") {
            // Explicit offline mode must never silently publish pairing traffic to the internet.
            if (routingEngine.routingPolicy.value == RoutingPolicy.FORCE_OFFLINE) return null
            val token = json.optString("pairingToken").lowercase()
            if (publicTopicTransport.sendPairingEnvelope(token, wireBytes)) return "PUBLIC_PAIRING"
            if (onlineRelayManager.sendEnvelope(recipientHex, wireBytes, queueIfOffline = true)) return "ONLINE_RELAY_PAIRING"
            return null
        }

        // Self loopback
        if (recipientHex == myHex) {
            handleIncomingRawPayload(wireBytes, "LOOPBACK")
            return "LOOPBACK"
        }

        val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(recipientPubKeyBytes))
        val contactVerified = vault.getContactByPubKey(recipientHex)?.isVerified == true && !vault.isBlocked(recipientHex)
        // Discovery is only a location hint. Do not attempt a direct IP route until the peer's
        // long-term key is trusted; the socket handshake independently proves that same identity.
        val peers = if (contactVerified) _allDiscoveredPeers.value else emptyList()
        val policy = routingEngine.routingPolicy.value
        val preferred = routingEngine.resolveRoute(recipientHex, peers, expectedTag)

        // Attempt the preferred route first, then gracefully fall back to any other
        // usable link. Previously a single failed attempt (e.g. an unconfigured online
        // relay, or "internet up" hiding a reachable LAN peer) left the message stuck
        // in the outbox even though the peer was reachable on another transport.
        val order = LinkedHashSet<ActiveRouteType>()
        order.add(preferred)
        // Only probe local transports when routing identified a fresh local peer. On separate
        // Wi-Fi networks the peers cannot discover each other over LAN; probing absent local
        // links first previously added several seconds to every WAN message and call signal.
        // A manually registered direct endpoint is an explicit user instruction, so it is
        // probed even when the routing engine prefers the online relay.
        val hasManualDirectPeer = contactVerified &&
            _allDiscoveredPeers.value.any { it.linkType == "WIFI_SOCKET" && it.tagHex == "manual" }
        if (policy != RoutingPolicy.FORCE_ONLINE && (preferred != ActiveRouteType.ONLINE_RELAY || hasManualDirectPeer)) {
            order.add(ActiveRouteType.OFFLINE_DIRECT_WIFI)
            if (preferred != ActiveRouteType.ONLINE_RELAY) order.add(ActiveRouteType.OFFLINE_BLE_MESH)
        }
        if (policy != RoutingPolicy.FORCE_OFFLINE) {
            order.add(ActiveRouteType.ONLINE_RELAY)
        }

        for (route in order) {
            val used = when (route) {
                ActiveRouteType.ONLINE_RELAY -> {
                    val packetType = json.optString("type", "CHAT_MSG").uppercase()
                    val queueIfOffline = packetType !in setOf("MEDIA_CHUNK", "MEDIA_CHUNK_ACK", "CHAT_TYPING", "CALL_SIGNAL")
                    if (onlineRelayManager.sendEnvelope(recipientHex, wireBytes, queueIfOffline)) "ONLINE_RELAY" else null
                }
                ActiveRouteType.OFFLINE_DIRECT_WIFI -> {
                    val peer = findWifiPeer(expectedTag)
                    if (peer?.hostAddress != null && peer.port > 0 &&
                        socketManager.sendPayload(peer.hostAddress, peer.port, wireBytes, recipientHex)
                    ) "OFFLINE_DIRECT_WIFI" else null
                }
                ActiveRouteType.OFFLINE_BLE_MESH -> {
                    val peer = peers.firstOrNull {
                        it.linkType == "BLE_GATT" && it.tagHex.length >= 16 &&
                            expectedTag.startsWith(it.tagHex, ignoreCase = true)
                    }
                    if (peer != null && bleManager.sendPayloadToDevice(peer.id, wireBytes)) "OFFLINE_BLE_MESH" else null
                }
                ActiveRouteType.OFFLINE_STORE_AND_FORWARD -> null
            }
            if (used != null) return used
        }
        // Public no-config fallback is deliberately last so a deployed private relay and
        // local Wi-Fi/Bluetooth retain priority. Large media chunks never traverse ntfy;
        // their file bytes use the encrypted temporary-blob route instead.
        if (policy != RoutingPolicy.FORCE_OFFLINE && json.optString("type") != "MEDIA_CHUNK" &&
            publicTopicTransport.sendEnvelope(recipientHex, wireBytes)) {
            return "PUBLIC_TOPIC"
        }
        return null
    }

    fun queueMessage(recipientPubKeyHex: String, text: String): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = text,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.QUEUED,
            isOutgoing = true,
            routeUsed = "AUTO"
        )
        vault.saveMessage(msg)
        scope.launch { flushOutbox() }
        return msg
    }

    fun queueMediaMessage(
        recipientPubKeyHex: String,
        attachment: MediaAttachment,
        caption: String = ""
    ): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = caption,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.SENDING,
            isOutgoing = true,
            routeUsed = "AUTO",
            attachment = attachment
        )
        vault.saveMessage(msg)
        mediaTransferManager.startTransfer(msg)
        _onConversationUpdated.tryEmit(Unit)
        return msg
    }

    private fun handleIncomingRawPayload(rawPayload: ByteArray, linkName: String) {
        try {
            val myIdentity = vault.getIdentityKeyPair()
            val envelope = EncryptedEnvelope.fromByteArray(rawPayload)
            val decryptedBytes = CryptoEngine.decryptFromPeer(myIdentity.privateKey, envelope)
            val json = try {
                JSONObject(String(decryptedBytes, Charsets.UTF_8))
            } finally {
                // The parsed JSONObject owns the fields it needs; erase the temporary wire buffer.
                decryptedBytes.fill(0)
            }
            if (!verifyAuthenticatedPayload(json)) {
                Log.w(TAG, "Dropped unauthenticated packet received over $linkName")
                return
            }

            // Privacy-first block list: only authenticated sender identities are considered.
            val senderKey = json.optString("senderPubKey").lowercase().trim()
            if (vault.isBlocked(senderKey)) {
                Log.i(TAG, "Dropped payload from blocked peer ${senderKey.take(8)}")
                return
            }

            // Presence: any incoming traffic marks the sender as recently seen.
            if (senderKey.isNotEmpty() && senderKey != myIdentity.publicKeyHex.lowercase()) {
                touchContactPresence(senderKey)
            }

            when (json.optString("type", "CHAT_MSG")) {
                "PAIR_REQUEST" -> handleQrPairingRequest(senderKey, json)
                "PAIR_ACK" -> handleQrPairingAck(senderKey, json)
                "CHAT_MSG" -> handleIncomingChat(json, linkName)
                "CHAT_EDIT" -> handleIncomingEdit(senderKey, json)
                "CHAT_DELETE" -> handleIncomingDelete(senderKey, json)
                "CHAT_REACTION" -> handleIncomingReaction(senderKey, json)
                "CHAT_PIN" -> handleIncomingPin(senderKey, json)
                "CHAT_TYPING" -> {
                    val timestamp = json.optLong("timestamp", 0L)
                    val now = System.currentTimeMillis()
                    if (timestamp in (now - 15_000L)..(now + 30_000L)) {
                        val previous = lastTypingAtByPeer[senderKey] ?: 0L
                        if (timestamp > previous) {
                            lastTypingAtByPeer[senderKey] = timestamp
                            _onTypingUpdate.tryEmit(Pair(senderKey, json.optBoolean("typing", true)))
                        }
                    }
                }
                "CHAT_READ" -> handleIncomingRead(senderKey, json)
                "CHAT_PRESENCE" -> _onPresenceSeen.tryEmit(senderKey)
                "PROFILE_UPDATE" -> handleIncomingProfileUpdate(senderKey, json)
                "PROFILE_REQUEST" -> {
                    if (vault.getContactByPubKey(senderKey) != null && !vault.isBlocked(senderKey)) {
                        scope.launch(Dispatchers.IO) {
                            val avatar = if (vault.getSettings().shareProfilePhoto) compactProfileAvatarForWire(vault.getMyAvatarPath()) else null
                            val profile = JSONObject().apply {
                                put("type", "PROFILE_UPDATE")
                                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                                put("displayName", vault.getDisplayName())
                                put("timestamp", System.currentTimeMillis())
                                put("avatarClear", !vault.getSettings().shareProfilePhoto || avatar == null)
                                if (avatar != null) put("avatarBase64", android.util.Base64.encodeToString(avatar, android.util.Base64.NO_WRAP))
                            }
                            dispatchEncryptedJson(senderKey, profile)
                            avatar?.fill(0)
                        }
                    }
                }
                "ATTACHMENT_VIEWED" -> handleIncomingAttachmentViewed(senderKey, json)
                "DISAPPEAR_SYNC" -> handleIncomingDisappearSync(senderKey, json)
                "DELIVERY_RECEIPT" -> handleDeliveryReceipt(senderKey, json, false)
                "MEDIA_ACCEPT" -> mediaTransferManager.onRemoteAccept(senderKey, json)
                "MEDIA_RECEIPT" -> {
                    mediaTransferManager.onRemoteReceipt(senderKey, json)
                    handleDeliveryReceipt(senderKey, json, true)
                }
                "MEDIA_CHUNK" -> mediaTransferManager.handleIncomingChunk(json, linkName)
                "MEDIA_CHUNK_ACK" -> mediaTransferManager.onChunkAck(senderKey, json)
                "MEDIA_CLOUD_LINK" -> mediaTransferManager.handleCloudLink(senderKey, json)
                "GROUP_SYNC" -> handleIncomingGroupSync(senderKey, json)
                "CALL_SIGNAL" -> handleIncomingCallSignal(json)
                else -> Log.w(TAG, "Unknown payload type: ${json.optString("type")}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt incoming payload from $linkName: ${e.message}")
        }
    }

    private fun handleQrPairingRequest(senderPubKeyHex: String, json: JSONObject) {
        val sender = senderPubKeyHex.lowercase().trim()
        val token = json.optString("pairingToken").lowercase().trim()
        val requestId = json.optString("pairingRequestId").trim()
        if (sender.isBlank() || sender == vault.getIdentityKeyPair().publicKeyHex.lowercase() ||
            vault.isBlocked(sender) || !vault.consumePairingChallenge(token, sender, requestId)) {
            Log.w(TAG, "Rejected invalid, expired, or replayed QR pairing request")
            return
        }
        val claimedName = json.optString("senderDisplayName").trim().take(80).ifBlank { "Peer ${sender.take(6)}" }

        // The pairing handshake authenticates the scanner's identity, but it must NOT silently
        // create a contact on the QR owner's side. The scanner's first message still arrives in
        // Message Requests; accepting it promotes the pairing-verified peer into a verified
        // contact. Previously the auto-created contact routed that message straight into the
        // inbox, which is not what the QR owner consented to.
        val existingContact = vault.getContactByPubKey(sender)
        if (existingContact != null) {
            // Re-pairing with an already-known contact only upgrades its trust level.
            vault.addOrUpdateContact(existingContact.copy(
                displayName = existingContact.displayName.takeIf { it.isNotBlank() } ?: claimedName,
                isVerified = true
            ))
            _onConversationUpdated.tryEmit(Unit)
        } else {
            vault.markPairingVerifiedPeer(sender, claimedName)
        }
        // Do not wait for the periodic subscription refresh: a QR-authenticated peer may send
        // their first message immediately, and that message must be able to reach Message Requests.
        publicTopicTransport.refreshPeerSubscriptions()

        // Showing the fresh QR is explicit intent to pair. ACK is recipient-encrypted and
        // authenticates the same X25519 identity, so the scanner verifies the reciprocal trust.
        scope.launch {
            val ack = JSONObject().apply {
                put("type", "PAIR_ACK")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("pairingToken", token)
                put("pairingRequestId", requestId)
                put("timestamp", System.currentTimeMillis())
            }
            dispatchEncryptedJson(sender, ack)
        }
    }

    private fun handleQrPairingAck(senderPubKeyHex: String, json: JSONObject) {
        val sender = senderPubKeyHex.lowercase().trim()
        val pending = pendingQrPairings[sender] ?: return
        if (System.currentTimeMillis() >= pending.expiresAtMs ||
            json.optString("pairingRequestId") != pending.requestId ||
            json.optString("pairingToken").lowercase() != pending.tokenHex) return
        val contact = vault.getContactByPubKey(sender) ?: return
        vault.addOrUpdateContact(contact.copy(isVerified = true))
        pendingQrPairings.remove(sender, pending)
        _onConversationUpdated.tryEmit(Unit)
        scope.launch {
            // Announce our full profile first: the QR owner previously never learned the
            // scanner's display name or avatar because only a PROFILE_REQUEST was sent and
            // the owner's side had no reason to answer or ask. Now the owner stores it as soon
            // as the request is accepted, and re-pairing contacts get an immediate refresh.
            val settings = vault.getSettings()
            val wireAvatar = if (settings.shareProfilePhoto) compactProfileAvatarForWire(vault.getMyAvatarPath()) else null
            try {
                dispatchEncryptedJson(sender, JSONObject().apply {
                    put("type", "PROFILE_UPDATE")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("displayName", vault.getDisplayName())
                    put("timestamp", System.currentTimeMillis())
                    put("avatarClear", !settings.shareProfilePhoto || wireAvatar == null)
                    wireAvatar?.let { put("avatarBase64", android.util.Base64.encodeToString(it, android.util.Base64.NO_WRAP)) }
                })
            } finally {
                wireAvatar?.fill(0)
            }
            dispatchEncryptedJson(sender, JSONObject().apply {
                put("type", "PROFILE_REQUEST")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("timestamp", System.currentTimeMillis())
            })
        }
        Log.i(TAG, "QR pairing mutually verified for ${sender.take(10)}")
    }

    private fun touchContactPresence(senderPubKeyHex: String) {
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        if (System.currentTimeMillis() - contact.lastSeenEpochMs > 5_000L) {
            vault.addOrUpdateContact(contact.copy(lastSeenEpochMs = System.currentTimeMillis()))
        }
        _onPresenceSeen.tryEmit(senderPubKeyHex)
    }

    /** True when the active network is Wi-Fi/Ethernet (unmetered-class for auto-download). */
    private fun isOnWifiLikeNetwork(): Boolean {
        val net = routingEngine.networkTypeName.value
        return net.contains("Wi-Fi", ignoreCase = true) || net.contains("Ethernet", ignoreCase = true)
    }

    private fun handleIncomingChat(json: JSONObject, linkName: String) {
        val senderPubKey = json.getString("senderPubKey").lowercase()
        val msgId = json.getString("msgId")
        if (msgId.isBlank() || msgId.length > 128) return
        if (json.has("groupId")) {
            handleIncomingGroupChat(senderPubKey, msgId, json, linkName)
            return
        }
        val alreadyStored = vault.getMessageById(msgId)
        if (alreadyStored != null) {
            if (alreadyStored.senderPubKeyHex.equals(senderPubKey, ignoreCase = true)) {
                val storedAttachment = alreadyStored.attachment
                if (storedAttachment == null) {
                    sendDeliveryReceipt(senderPubKey, msgId)
                } else if (!alreadyStored.isOutgoing && storedAttachment.transferState == TransferState.COMPLETED &&
                    storedAttachment.localPath?.let { File(it).isFile } == true) {
                    // Idempotently recover a lost final receipt without retransmitting a file.
                    sendDeliveryReceipt(senderPubKey, msgId, storedAttachment.id)
                } else if (!alreadyStored.isOutgoing && storedAttachment.transferState != TransferState.COMPLETED &&
                    vault.getContactByPubKey(senderPubKey) != null) {
                    val currentSettings = vault.getSettings()
                    val mode = currentSettings.mediaAutoDownload
                    val alreadyApproved = mediaTransferManager.isIncomingApproved(senderPubKey, storedAttachment.id)
                    val typeAllowed = when (storedAttachment.kind) {
                        com.example.data.MediaKind.VOICE -> currentSettings.autoDownloadVoice
                        com.example.data.MediaKind.VIDEO -> currentSettings.autoDownloadVideo
                        else -> true
                    }
                    val autoAllowed = typeAllowed && (mode == MediaAutoDownload.ALWAYS ||
                        (mode == MediaAutoDownload.WIFI_OR_LAN && isOnWifiLikeNetwork()))
                    if (alreadyApproved || autoAllowed) {
                        if (mediaTransferManager.prepareIncoming(alreadyStored)) {
                            sendMediaAccept(senderPubKey, msgId, storedAttachment.id)
                        }
                    }
                }
            }
            return
        }
        val senderContact = vault.getContactByPubKey(senderPubKey)
        // Prefer the name authenticated during the QR pairing handshake for pending requests.
        val senderDisplayName = senderContact?.displayName
            ?: vault.getPairingVerifiedPeerName(senderPubKey)
            ?: json.optString("senderDisplayName", "").ifBlank {
                "Peer " + senderPubKey.take(6)
            }
        val text = json.optString("text", "")
        val timestamp = json.optLong("timestamp", System.currentTimeMillis()).coerceAtMost(System.currentTimeMillis() + 5 * 60_000L)
        val attachment = if (json.has("attachment")) parseAttachment(json.getJSONObject("attachment")) else null

        val incomingMessage = ChatMessage(
            id = msgId,
            conversationPeerPubKeyHex = senderPubKey,
            senderPubKeyHex = senderPubKey,
            recipientPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            content = text,
            timestampMs = timestamp,
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = linkName,
            replyToId = if (json.has("replyToId")) json.getString("replyToId") else null,
            replyToPreview = if (json.has("replyToPreview")) json.getString("replyToPreview") else null,
            replyToSender = if (json.has("replyToSender")) json.getString("replyToSender") else null,
            attachment = attachment
        )

        vault.saveMessage(incomingMessage)

        val isKnown = senderContact != null
        if (attachment != null) {
            val currentSettings = vault.getSettings()
            val mode = currentSettings.mediaAutoDownload
            val typeAllowed = when (attachment.kind) {
                com.example.data.MediaKind.VOICE -> currentSettings.autoDownloadVoice
                com.example.data.MediaKind.VIDEO -> currentSettings.autoDownloadVideo
                else -> true
            }
            when {
                !isKnown -> vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = "Accept this contact request before downloading"
                    ))
                }
                mode == MediaAutoDownload.NEVER || !typeAllowed -> vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = if (!typeAllowed) "Auto-download for this media type is off — tap Download to get it" else "Auto-download is off — tap Download to get this file"
                    ))
                }
                mode == MediaAutoDownload.WIFI_OR_LAN && !isOnWifiLikeNetwork() -> vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = "Paused on mobile data — tap Download to get this file"
                    ))
                }
                else -> {
                    if (mediaTransferManager.prepareIncoming(incomingMessage)) {
                        sendMediaAccept(senderPubKey, msgId, attachment.id)
                    }
                }
            }
        }

        if (!isKnown) {
            val existingRequests = vault.getMessageRequests()
            val currentReq = existingRequests.firstOrNull { it.senderPubKeyHex.equals(senderPubKey, ignoreCase = true) }
            val newCount = (currentReq?.messageCount ?: 0) + 1
            val request = MessageRequest(
                senderPubKeyHex = senderPubKey,
                senderDisplayName = senderDisplayName,
                latestMessageText = incomingMessage.previewText,
                timestampMs = timestamp,
                messageCount = newCount
            )
            vault.addOrUpdateMessageRequest(request)
            // Keep the pending requester subscribed immediately. They remain a request until
            // the user accepts; this only enables replies/updates for the request inbox.
            publicTopicTransport.refreshPeerSubscriptions()
            Log.i(TAG, "Message request received from unknown peer: $senderDisplayName ($senderPubKey)")
        }

        if (attachment == null) sendDeliveryReceipt(senderPubKey, msgId)
        _onNewMessageReceived.tryEmit(incomingMessage)
        _onConversationUpdated.tryEmit(Unit)
    }

    /**
     * Groups are encrypted fan-out conversations, not server-side rooms. Every recipient
     * validates the creator-authenticated membership snapshot, stores the group locally, and sends
     * their delivery receipt directly to the original sender.
     */
    private fun handleIncomingGroupSync(senderKey: String, json: JSONObject) {
        if (senderKey.isBlank() || vault.getContactByPubKey(senderKey) == null) return
        val group = parseAndValidateGroupSnapshot(senderKey, json) ?: return
        val existing = vault.getGroupById(group.id)
        if (existing != null && !existing.createdByPubKeyHex.equals(senderKey, ignoreCase = true)) return
        if (vault.addOrUpdateGroup(group)) _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingGroupChat(senderKey: String, msgId: String, json: JSONObject, linkName: String) {
        if (json.has("attachment")) return
        val groupId = json.optString("groupId").lowercase().trim()
        if (!groupId.matches(Regex("^[0-9a-f]{64}$"))) return
        val myKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        var group = vault.getGroupById(groupId)
        if (group == null) {
            // A message can race its invitation only if the transport reordered packets;
            // only a known contact acting as the creator may bootstrap that snapshot.
            if (vault.getContactByPubKey(senderKey) == null) return
            group = parseAndValidateGroupSnapshot(senderKey, json, groupId) ?: return
            if (!vault.addOrUpdateGroup(group)) return
        }
        if (myKey !in group.memberPubKeyHexes || senderKey !in group.memberPubKeyHexes) return
        if (group.createdByPubKeyHex != json.optString("createdByPubKey").lowercase()) return
        if (json.optString("groupName") != group.name) return
        val incomingMembers = readGroupMembers(json.optJSONArray("groupMembers")) ?: return
        if (incomingMembers.toSet() != group.memberPubKeyHexes.toSet()) return
        val existingMessage = vault.getMessageById(msgId)
        if (existingMessage != null) {
            if (existingMessage.groupId == groupId && existingMessage.senderPubKeyHex.equals(senderKey, ignoreCase = true)) {
                sendDeliveryReceipt(senderKey, msgId)
            }
            return
        }
        val timestamp = json.optLong("timestamp", System.currentTimeMillis())
            .coerceIn(0L, System.currentTimeMillis() + 5 * 60_000L)
        val message = ChatMessage(
            id = msgId,
            conversationPeerPubKeyHex = groupId,
            senderPubKeyHex = senderKey,
            recipientPubKeyHex = myKey,
            content = json.optString("text", "").take(100_000),
            timestampMs = timestamp,
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = linkName,
            replyToId = json.optString("replyToId").takeIf { it.isNotBlank() },
            replyToPreview = json.optString("replyToPreview").takeIf { it.isNotBlank() },
            replyToSender = json.optString("replyToSender").takeIf { it.isNotBlank() },
            groupId = groupId,
            senderDisplayName = json.optString("senderDisplayName").takeIf { it.isNotBlank() }?.take(80)
                ?: vault.getContactByPubKey(senderKey)?.displayName
        )
        vault.saveMessage(message)
        sendDeliveryReceipt(senderKey, msgId)
        _onNewMessageReceived.tryEmit(message)
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun parseAndValidateGroupSnapshot(
        senderKey: String,
        json: JSONObject,
        requiredGroupId: String? = null
    ): GroupConversation? {
        val groupId = (requiredGroupId ?: json.optString("groupId")).lowercase().trim()
        val creator = json.optString("createdByPubKey").lowercase().trim()
        val name = json.optString("groupName").trim()
        val members = readGroupMembers(json.optJSONArray("groupMembers")) ?: return null
        val myKey = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val createdAt = json.optLong("createdAtMs", json.optLong("groupCreatedAtMs", 0L))
        val updatedAt = json.optLong("updatedAtMs", json.optLong("groupUpdatedAtMs", createdAt))
        val now = System.currentTimeMillis()
        if (!groupId.matches(Regex("^[0-9a-f]{64}$")) || name.isBlank() || name.length > 80 ||
            creator != senderKey || !creator.matches(Regex("^[0-9a-f]{64}$")) ||
            members.size !in 2..64 || members.distinct().size != members.size ||
            members.any { !it.matches(Regex("^[0-9a-f]{64}$")) } ||
            senderKey !in members || myKey !in members || createdAt <= 0L || createdAt > now + 5 * 60_000L ||
            updatedAt < createdAt || updatedAt > now + 5 * 60_000L) return null
        return GroupConversation(
            id = groupId,
            name = name,
            memberPubKeyHexes = members,
            createdByPubKeyHex = creator,
            createdAtMs = createdAt,
            updatedAtMs = updatedAt
        )
    }

    private fun readGroupMembers(array: JSONArray?): List<String>? {
        if (array == null || array.length() !in 2..64) return null
        val members = ArrayList<String>(array.length())
        for (index in 0 until array.length()) {
            val key = array.optString(index).lowercase().trim()
            if (!key.matches(Regex("^[0-9a-f]{64}$"))) return null
            members.add(key)
        }
        return members.takeIf { it.distinct().size == it.size }
    }

    private fun sendMediaAccept(senderPubKeyHex: String, messageId: String, transferId: String) {
        scope.launch {
            dispatchEncryptedJson(senderPubKeyHex, JSONObject().apply {
                put("type", "MEDIA_ACCEPT")
                put("msgId", messageId)
                put("transferId", transferId)
            })
        }
    }

    private fun parseAttachment(obj: JSONObject): MediaAttachment {
        return MediaAttachment(
            id = obj.getString("id"),
            kind = try { MediaKind.valueOf(obj.getString("kind")) } catch (e: Exception) { MediaKind.DOCUMENT },
            fileName = obj.optString("fileName", "file"),
            mimeType = obj.optString("mimeType", "application/octet-stream"),
            sizeBytes = obj.optLong("sizeBytes", 0L),
            durationMs = obj.optLong("durationMs", 0L),
            width = obj.optInt("width", 0),
            height = obj.optInt("height", 0),
            viewLimit = obj.optInt("viewLimit", 0),
            sha256Hex = obj.optString("sha256Hex", "").takeIf { it.matches(Regex("^[0-9a-fA-F]{64}$")) },
            transferState = TransferState.PENDING
        )
    }

    private fun handleIncomingEdit(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val newText = json.optString("text")
        val editAt = json.optLong("timestamp", System.currentTimeMillis())
        val target = vault.getMessageById(msgId) ?: return
        if (target.isOutgoing || !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        if (editAt < target.timestampMs || editAt > System.currentTimeMillis() + 5 * 60_000L) return
        if (target.isDeleted || editAt <= target.editedAtMs) return
        vault.updateMessage(msgId) {
            if (it.isOutgoing || !it.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || it.isDeleted || editAt <= it.editedAtMs) it
            else it.copy(content = newText.take(100_000), isEdited = true, editedAtMs = editAt)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingDelete(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val deletedAt = json.optLong("timestamp", System.currentTimeMillis())
        val target = vault.getMessageById(msgId) ?: return
        if (target.isOutgoing || !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        if (deletedAt < target.timestampMs || deletedAt > System.currentTimeMillis() + 5 * 60_000L) return
        if (target.deletedAtMs >= deletedAt) return
        target.attachment?.localPath?.let { path ->
            vault.deleteManagedMedia(path)
        }
        vault.updateMessage(msgId) {
            if (it.isOutgoing || !it.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || it.deletedAtMs >= deletedAt) it
            else it.copy(deletedAtMs = deletedAt, content = "", attachment = it.attachment?.copy(localPath = null))
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingReaction(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val emoji = json.optString("emoji")
        val add = json.optBoolean("add", true)
        val updatedAt = json.optLong("timestamp", 0L)
        if (emoji.isBlank() || emoji.length > 32 || updatedAt <= 0L || updatedAt > System.currentTimeMillis() + 5 * 60_000L) return
        val target = vault.getMessageById(msgId) ?: return
        if (updatedAt <= target.reactionUpdatedAtMs) return
        val allowedReactionSender = if (target.groupId != null) {
            vault.getGroupById(target.groupId)?.memberPubKeyHexes?.contains(senderPubKeyHex.lowercase()) == true
        } else {
            target.conversationPeerPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) ||
                target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) ||
                target.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)
        }
        if (!allowedReactionSender) return
        vault.updateMessage(msgId) { msg ->
            if (updatedAt <= msg.reactionUpdatedAtMs) return@updateMessage msg
            val map = msg.reactions.toMutableMap()
            val current = (map[emoji] ?: emptyList()).toMutableList()
            if (add) {
                if (!current.contains(senderPubKeyHex) && current.size < 100) current.add(senderPubKeyHex)
            } else current.remove(senderPubKeyHex)
            if (current.isEmpty()) map.remove(emoji) else map[emoji] = current
            msg.copy(reactions = map, reactionUpdatedAtMs = updatedAt)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingPin(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val target = vault.getMessageById(msgId) ?: return
        // A peer may synchronize pin state only for their own authored message; never mutate yours.
        val updatedAt = json.optLong("timestamp", 0L)
        if (updatedAt < target.timestampMs || updatedAt > System.currentTimeMillis() + 5 * 60_000L) return
        if (updatedAt <= target.pinUpdatedAtMs) return
        if (target.isOutgoing || !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        vault.updateMessage(msgId) {
            if (it.isOutgoing || !it.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || updatedAt <= it.pinUpdatedAtMs) it
            else it.copy(isPinned = json.optBoolean("pinned", true), pinUpdatedAtMs = updatedAt)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingCallSignal(json: JSONObject) {
        val signalType = try { CallSignalType.valueOf(json.optString("signal")) } catch (_: Exception) { return }
        val callType = try { com.example.data.CallType.valueOf(json.optString("callType", "VOICE")) } catch (_: Exception) { return }
        val callId = json.optString("callId")
        if (!callId.matches(Regex("^[A-Za-z0-9_-]{1,64}$"))) return
        val sender = json.optString("senderPubKey").lowercase()
        if (!sender.matches(Regex("^[0-9a-f]{64}$")) || vault.isBlocked(sender) || vault.getContactByPubKey(sender) == null) return
        val signalTimestamp = json.optLong("timestamp", 0L)
        val now = System.currentTimeMillis()
        if (signalTimestamp <= now - 120_000L || signalTimestamp > now + 30_000L) return

        val fragmentCount = json.optInt("sdpFragmentCount", 0)
        if (fragmentCount > 0) {
            if (signalType !in setOf(CallSignalType.OFFER, CallSignalType.ACCEPT) || fragmentCount !in 1..64) return
            val fragmentIndex = json.optInt("sdpFragmentIndex", -1)
            val fragment = json.optString("sdpFragment", "")
            val sdpType = json.optString("sdpType", "")
            if (fragmentIndex !in 0 until fragmentCount || fragment.isEmpty() || fragment.length > 1_100 ||
                sdpType !in setOf("offer", "answer")) return

            val assemblyKey = "$sender:$callId:${signalType.name}"
            var completedSdp: String? = null
            synchronized(callSdpAssemblyLock) {
                val staleBefore = now - 60_000L
                val iterator = callSdpAssemblies.entries.iterator()
                while (iterator.hasNext()) {
                    if (iterator.next().value.createdAtMs < staleBefore) iterator.remove()
                }
                var assembly = callSdpAssemblies[assemblyKey]
                if (assembly != null && (assembly.fragmentCount != fragmentCount || assembly.sdpType != sdpType ||
                        assembly.callType != callType)) {
                    callSdpAssemblies.remove(assemblyKey)
                    assembly = null
                    return@synchronized
                }
                if (assembly == null) {
                    while (callSdpAssemblies.size >= 16) callSdpAssemblies.remove(callSdpAssemblies.keys.first())
                    assembly = CallSdpAssembly(
                        sender, callId, signalType, callType, json.optString("senderDisplayName", "Peer").take(80),
                        sdpType, fragmentCount, now, arrayOfNulls(fragmentCount)
                    )
                    callSdpAssemblies[assemblyKey] = assembly
                }
                val prior = assembly.fragments[fragmentIndex]
                if (prior != null && prior != fragment) {
                    callSdpAssemblies.remove(assemblyKey)
                    return@synchronized
                }
                assembly.fragments[fragmentIndex] = fragment
                if (assembly.fragments.all { it != null }) {
                    val joined = assembly.fragments.joinToString("") { it.orEmpty() }
                    callSdpAssemblies.remove(assemblyKey)
                    if (joined.length in 20..64_000 && joined.startsWith("v=0") &&
                        (joined.contains("\nm=") || joined.contains("\r\nm="))) completedSdp = joined
                }
            }
            val complete = completedSdp ?: return
            _onCallSignal.tryEmit(IncomingCallSignal(
                callId = callId,
                type = signalType,
                callType = callType,
                senderPubKeyHex = sender,
                senderDisplayName = json.optString("senderDisplayName", "Peer").take(80),
                payload = mapOf("sdpType" to sdpType, "sdp" to complete)
            ))
            return
        }

        val payload = buildMap {
            listOf("host", "port", "sdpType", "sdp", "candidate", "sdpMid", "sdpMLineIndex").forEach { field ->
                val value = json.optString(field, "")
                if (value.isNotEmpty() && value.length <= if (field == "sdp") 64_000 else 4_096) put(field, value)
            }
        }
        _onCallSignal.tryEmit(IncomingCallSignal(
            callId = callId,
            type = signalType,
            callType = callType,
            senderPubKeyHex = sender,
            senderDisplayName = json.optString("senderDisplayName", "Peer").take(80),
            payload = payload
        ))
    }

    // ------------------------------------------------------------------
    // v2 protocol: read receipts / presence / profile / view-once / disappearing
    // ------------------------------------------------------------------

    /** Peer reports they have read everything up to lastReadMs in our conversation. */
    private fun handleIncomingRead(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val lastReadMs = json.optLong("lastReadMs", 0L)
        if (lastReadMs <= 0L) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        if (lastReadMs > contact.peerLastReadMs) {
            vault.addOrUpdateContact(contact.copy(peerLastReadMs = lastReadMs))
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Creates a small JPEG thumbnail that survives the public relay's packet-size limit. */
    private fun compactProfileAvatarForWire(path: String?): ByteArray? {
        if (path.isNullOrBlank()) return null
        val file = try { File(path) } catch (_: Exception) { return null }
        if (!file.isFile || file.length() !in 1..(512L * 1024L)) return null
        val source = try { BitmapFactory.decodeFile(file.absolutePath) } catch (_: Exception) { null } ?: return null
        return try {
            for ((dimension, quality) in listOf(160 to 48, 128 to 42, 112 to 36, 96 to 32, 80 to 28, 64 to 24, 48 to 20)) {
                val scale = minOf(1f, dimension.toFloat() / maxOf(source.width, source.height))
                val width = (source.width * scale).toInt().coerceAtLeast(1)
                val height = (source.height * scale).toInt().coerceAtLeast(1)
                val thumb = Bitmap.createScaledBitmap(source, width, height, true)
                try {
                    val output = ByteArrayOutputStream()
                    thumb.compress(Bitmap.CompressFormat.JPEG, quality, output)
                    if (output.size() <= 1_250) return output.toByteArray()
                } finally {
                    if (thumb !== source) thumb.recycle()
                }
            }
            null
        } catch (_: Exception) {
            null
        } finally {
            source.recycle()
        }
    }

    /** Peer updated their profile (display name and/or avatar). */
    private fun handleIncomingProfileUpdate(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        val timestamp = json.optLong("timestamp", 0L)
        val now = System.currentTimeMillis()
        if (timestamp <= contact.profileUpdatedAtMs || timestamp <= 0L || timestamp > now + 5 * 60_000L || timestamp < now - 7L * 24 * 60 * 60 * 1000) return
        val newName = json.optString("displayName").trim().take(80)
        vault.addOrUpdateContact(contact.copy(
            displayName = if (newName.isNotEmpty()) newName else contact.displayName,
            profileUpdatedAtMs = timestamp
        ))

        val avatarB64 = json.optString("avatarBase64", "")
        if (json.optBoolean("avatarClear", false) && avatarB64.isEmpty()) {
            vault.setContactAvatar(senderPubKeyHex, null)
        } else if (avatarB64.isNotEmpty()) {
            try {
                // Reject oversized profile image packets before allocating / writing files.
                if (avatarB64.length <= 2_000) {
                    val bytes = android.util.Base64.decode(avatarB64, android.util.Base64.NO_WRAP)
                    if (bytes.isNotEmpty() && bytes.size <= 1_500) {
                        val dir = File(vault.dataRoot(), "avatars")
                        if (!dir.exists()) dir.mkdirs()
                        // A new path prevents Coil's file-key cache from showing the previous
                        // avatar after the file contents change. Vault replacement cleans the old file.
                        val f = File(dir, "peer_${senderPubKeyHex.take(12)}_${timestamp}.jpg")
                        FileOutputStream(f).use { output -> output.write(bytes); output.fd.sync() }
                        vault.setContactAvatar(senderPubKeyHex, f.absolutePath)
                        bytes.fill(0)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to store peer avatar: ${e.javaClass.simpleName}")
            }
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Recipient opened a view-limited attachment; increment and expire when spent. */
    private fun handleIncomingAttachmentViewed(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        if (msgId.isEmpty()) return
        val target = vault.getMessageById(msgId) ?: return
        if (!target.isOutgoing || !target.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        vault.updateMessage(msgId) { m ->
            val att = m.attachment ?: return@updateMessage m
            if (att.viewLimit <= 0) return@updateMessage m
            val currentViews = att.viewsUsed.coerceIn(0, att.viewLimit)
            val reportedViews = json.optInt("viewsUsed", currentViews + 1).coerceIn(0, att.viewLimit)
            // Cumulative counts are idempotent and safe when view receipts arrive out of order.
            val views = maxOf(currentViews, reportedViews)
            m.copy(attachment = att.copy(viewsUsed = views))
        }
        // If the limit is now spent, wipe the local copy of the media.
        vault.getMessageById(msgId)?.attachment?.let { att ->
            if (att.viewLimit > 0 && att.viewsUsed >= att.viewLimit) {
                att.localPath?.let { path ->
                    vault.deleteManagedMedia(path)
                }
                vault.updateMessage(msgId) { m ->
                    m.copy(attachment = m.attachment?.copy(localPath = null))
                }
            }
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Peer changed the disappearing-message timer for our conversation. */
    private fun handleIncomingDisappearSync(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        val seconds = json.optInt("seconds", 0)
        if (seconds !in setOf(0, 30, 300, 3600, 86400, 604800)) return
        val updatedAt = json.optLong("timestamp", 0L)
        val now = System.currentTimeMillis()
        if (updatedAt <= contact.disappearTimerUpdatedAtMs || updatedAt <= 0L ||
            updatedAt > now + 5 * 60_000L || updatedAt < now - 7L * 24 * 60 * 60 * 1000) return
        vault.addOrUpdateContact(contact.copy(
            disappearAfterSec = seconds,
            disappearAfterSetAtMs = updatedAt,
            disappearTimerUpdatedAtMs = updatedAt
        ))

        val label = com.example.data.DisappearTimer.fromSeconds(seconds).label
        val event = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = senderPubKeyHex,
            senderPubKeyHex = senderPubKeyHex,
            recipientPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            content = "",
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = "SYNC",
            systemEvent = "${contact.displayName} set disappearing messages to $label"
        )
        vault.saveMessage(event)
        vault.purgeExpiredDisappearingMessages()
        _onConversationUpdated.tryEmit(Unit)
    }
}
