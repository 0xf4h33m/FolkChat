package com.example.net.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.CallLogEntry
import com.example.data.CallOutcome
import com.example.data.CallType
import com.example.data.Contact
import com.example.data.EncryptedVault
import com.example.service.SecureChatForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection
import org.webrtc.VideoTrack
import java.util.LinkedHashSet
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

enum class CallState {
    IDLE,
    OUTGOING_RINGING,
    INCOMING_RINGING,
    CONNECTING,
    ACTIVE,
    ENDED
}

data class CallSession(
    val callId: String,
    val peerPubKeyHex: String,
    val peerName: String,
    val type: CallType,
    val isOutgoing: Boolean,
    val state: CallState,
    val startedAtMs: Long = System.currentTimeMillis(),
    val connectedAtMs: Long = 0L,
    val error: String? = null,
    val muted: Boolean = false,
    val speakerOn: Boolean = true,
    val videoEnabled: Boolean = false
)

/**
 * End-to-end authenticated call control + WebRTC media plane. Signaling is transported through
 * FolkChat's recipient-encrypted protocol, while audio/video use WebRTC ICE and DTLS-SRTP. A
 * configured TURN server is required for relay-only IP privacy and for networks where direct ICE
 * paths cannot be established; public STUN defaults improve reachability but cannot guarantee all NATs.
 */
class CallManager(
    private val context: Context,
    private val vault: EncryptedVault,
    private val signalSender: suspend (String, JSONObject) -> String?
) {
    companion object {
        private const val TAG = "CallManager"
        private const val RING_TIMEOUT_MS = 45_000L
        /** The callee stops ringing on its own; a lost caller END signal must not ring forever. */
        private const val INCOMING_RING_TIMEOUT_MS = 50_000L
        private const val CONNECT_TIMEOUT_MS = 15_000
        /** Media paths (especially TURN relayed) can take a while to settle. */
        private const val CONNECTING_TIMEOUT_MS = 30_000L
        /** Brief transport blips (Wi-Fi handoff, cell handover) recover within this window. */
        private const val DISCONNECT_GRACE_MS = 12_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _session = MutableStateFlow<CallSession?>(null)
    val session: StateFlow<CallSession?> = _session.asStateFlow()

    private val _durationSeconds = MutableStateFlow(0L)
    val durationSeconds: StateFlow<Long> = _durationSeconds.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val recentOfferIds = LinkedHashSet<String>()
    private var audioManager: AudioManager? = null
    private var tickerJob: Job? = null
    private var ringTimeoutJob: Job? = null
    private var incomingRingTimeoutJob: Job? = null
    private var disconnectGraceJob: Job? = null
    private var connectTimeoutJob: Job? = null
    private val running = AtomicBoolean(false)
    private data class BufferedIce(val mid: String?, val lineIndex: Int, val candidate: String)
    private val earlyIceByCall = LinkedHashMap<String, MutableList<BufferedIce>>()
    @Volatile private var pendingOfferSdp: String? = null
    private val webRtcMedia = WebRtcMediaEngine(
        context = context,
        settingsProvider = { vault.getSettings() },
        onLocalIceCandidate = { candidate -> onLocalIceGenerated(candidate) },
        onConnectionState = { state -> scope.launch { handleWebRtcConnectionState(state) } }
    )
    val localVideoTrack get() = webRtcMedia.localVideoTrack
    val remoteVideoTrack get() = webRtcMedia.remoteVideoTrack
    val eglBaseContext: EglBase.Context get() = webRtcMedia.eglBaseContext

    init {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        // Do not bind a LAN TCP port. WAN and LAN calls both use ICE-negotiated WebRTC paths.
    }

    // ------------------------------------------------------------------
    // Outgoing / incoming control
    // ------------------------------------------------------------------

    fun startOutgoing(contact: Contact, type: CallType) {
        if (vault.getSettings().torRoutingEnabled) {
            _statusMessage.value = "Calls are disabled while Tor privacy mode is enabled"
            return
        }
        if (contact.x25519PublicKeyHex.length != 64 || !contact.x25519PublicKeyHex.matches(Regex("^[0-9a-fA-F]{64}$"))) return
        if (_session.value != null && _session.value?.state != CallState.ENDED) return
        val callId = UUID.randomUUID().toString()
        val session = CallSession(
            callId = callId,
            peerPubKeyHex = contact.x25519PublicKeyHex,
            peerName = contact.displayName,
            type = type,
            isOutgoing = true,
            state = CallState.OUTGOING_RINGING,
            videoEnabled = type == CallType.VIDEO
        )
        _session.value = session
        _statusMessage.value = "Preparing encrypted call…"
        scope.launch {
            try {
                val offerSdp = webRtcMedia.createOffer(callId, type == CallType.VIDEO)
                val route = sendSdpSignalAwait(
                    contact.x25519PublicKeyHex, callId, CallSignalType.OFFER, type, "offer", offerSdp
                )
                webRtcMedia.releaseLocalIceCandidates()
                if (route == null) {
                    finishCall(CallOutcome.FAILED, contact.x25519PublicKeyHex, contact.displayName, type,
                        outgoing = true, reason = "Could not deliver call setup over the available network")
                } else {
                    _statusMessage.value = "Ringing…"
                    scheduleRingTimeout()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not create WebRTC offer: ${e.javaClass.simpleName}")
                finishCall(CallOutcome.FAILED, contact.x25519PublicKeyHex, contact.displayName, type,
                    outgoing = true, reason = e.message?.take(140) ?: "Could not initialize secure calling")
            }
        }
    }

    fun onSignal(signal: IncomingCallSignal) {
        val sender = signal.senderPubKeyHex.lowercase()
        if (!sender.matches(Regex("^[0-9a-f]{64}$")) || sender == vault.getIdentityKeyPair().publicKeyHex.lowercase()) return
        val current = _session.value
        when (signal.type) {
            CallSignalType.OFFER -> handleOffer(signal)
            CallSignalType.RINGING -> {
                if (current != null && current.isOutgoing && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    _statusMessage.value = "Ringing…"
                }
            }
            CallSignalType.ACCEPT -> {
                if (current != null && current.isOutgoing && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    handleAccept(signal)
                }
            }
            CallSignalType.REJECT, CallSignalType.BUSY -> {
                if (current != null && current.isOutgoing && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    _statusMessage.value = if (signal.type == CallSignalType.BUSY) "Peer is busy" else "Call declined"
                    finishCall(CallOutcome.DECLINED, sender, current.peerName, current.type, outgoing = true)
                }
            }
            CallSignalType.END -> {
                if (current != null && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    val outcome = if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.CANCELED
                    finishActive(outcome)
                }
            }
            CallSignalType.ICE -> handleRemoteIce(signal)
        }
    }

    private fun handleOffer(signal: IncomingCallSignal) {
        val sender = signal.senderPubKeyHex.lowercase()
        if (!signal.callId.matches(Regex("^[A-Za-z0-9_-]{1,64}$"))) return
        val offerSdp = signal.payload["sdp"]
        if (signal.payload["sdpType"] != "offer" || offerSdp.isNullOrBlank() || offerSdp.length > 64_000 ||
            !offerSdp.startsWith("v=0") || !(offerSdp.contains("\nm=") || offerSdp.contains("\r\nm="))) {
            sendSignal(sender, signal.callId, CallSignalType.REJECT, signal.callType)
            _statusMessage.value = "The caller sent an invalid or unsupported call offer"
            return
        }
        val contact = vault.getContactByPubKey(sender)
        if (contact == null || vault.isBlocked(sender) || sender == vault.getIdentityKeyPair().publicKeyHex.lowercase()) {
            sendSignal(sender, signal.callId, CallSignalType.REJECT, signal.callType)
            return
        }
        synchronized(recentOfferIds) {
            if (!recentOfferIds.add("$sender:${signal.callId}")) return
            while (recentOfferIds.size > 256) recentOfferIds.remove(recentOfferIds.first())
        }
        if (vault.getSettings().torRoutingEnabled) {
            sendSignal(sender, signal.callId, CallSignalType.REJECT, signal.callType)
            return
        }
        val existing = _session.value
        if (existing != null && existing.state != CallState.ENDED) {
            if (existing.callId != signal.callId) {
                sendSignal(sender, signal.callId, CallSignalType.BUSY, signal.callType)
            }
            return
        }
        pendingOfferSdp = offerSdp
        _session.value = CallSession(
            callId = signal.callId,
            peerPubKeyHex = sender,
            peerName = contact.displayName,
            type = signal.callType,
            isOutgoing = false,
            state = CallState.INCOMING_RINGING,
            videoEnabled = signal.callType == CallType.VIDEO
        )
        _statusMessage.value = "Incoming ${if (signal.callType == CallType.VIDEO) "video" else "voice"} call"
        sendSignal(sender, signal.callId, CallSignalType.RINGING, signal.callType)
        scheduleIncomingRingTimeout(signal.callId)
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.notify(12000, buildIncomingCallNotification(signal.copy(senderDisplayName = contact.displayName)))
        } catch (_: Exception) {}
    }

    private fun buildIncomingCallNotification(signal: IncomingCallSignal): android.app.Notification {
        val pendingIntent = android.app.PendingIntent.getActivity(
            context,
            12000,
            android.content.Intent(context, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val label = if (signal.callType == CallType.VIDEO) "video" else "voice"
        return androidx.core.app.NotificationCompat.Builder(context, com.example.SecureChatApp.CHANNEL_CALLS_ID)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setContentTitle("Incoming $label call")
            .setContentText(signal.senderDisplayName)
            .setContentIntent(pendingIntent)
            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setOngoing(true)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setDefaults(0)
            .build()
    }

    private fun dismissIncomingCallNotification() {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(12000)
        } catch (_: Exception) {}
    }

    fun acceptIncoming() {
        val current = _session.value ?: return
        if (current.state != CallState.INCOMING_RINGING) return
        if (vault.getSettings().torRoutingEnabled) {
            sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.REJECT, current.type)
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = false,
                reason = "Calls are disabled while Tor privacy mode is enabled")
            return
        }
        val offer = pendingOfferSdp ?: run {
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = false,
                reason = "Call offer expired; ask the caller to call again")
            return
        }
        dismissIncomingCallNotification()
        _session.value = current.copy(state = CallState.CONNECTING)
        _statusMessage.value = "Negotiating encrypted media…"
        scope.launch {
            try {
                // A video call must not fail outright just because the CAMERA permission was
                // revoked mid-call or never granted: answer audio-only instead, so the caller
                // still gets a usable (audio) connection instead of a dropped call.
                val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                val answerWithVideo = current.type == CallType.VIDEO && cameraGranted
                if (current.type == CallType.VIDEO && !answerWithVideo) {
                    _session.value = _session.value?.copy(videoEnabled = false)
                }
                val answerSdp = webRtcMedia.createAnswer(
                    current.callId,
                    offer,
                    video = answerWithVideo,
                    receiveVideo = current.type == CallType.VIDEO
                )
                val route = sendSdpSignalAwait(
                    current.peerPubKeyHex, current.callId, CallSignalType.ACCEPT, current.type, "answer", answerSdp
                )
                if (route == null) throw IllegalStateException("Could not deliver call answer over the available network")
                webRtcMedia.releaseLocalIceCandidates()
                flushBufferedIce(current.peerPubKeyHex, current.callId)
                pendingOfferSdp = null
                scheduleConnectTimeout()
            } catch (e: Exception) {
                Log.w(TAG, "Could not create WebRTC answer: ${e.javaClass.simpleName}")
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type,
                    outgoing = false, reason = e.message?.take(140) ?: "Could not start secure media")
            }
        }
    }

    fun rejectIncoming() {
        val current = _session.value ?: return
        dismissIncomingCallNotification()
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.REJECT, current.type)
        logCall(current, if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.DECLINED)
        teardown()
        _session.value = null
    }

    private fun handleAccept(signal: IncomingCallSignal) {
        val current = _session.value ?: return
        if (current.callId != signal.callId || !current.isOutgoing || !current.peerPubKeyHex.equals(signal.senderPubKeyHex, true)) return
        if (signal.payload["sdpType"] != "answer") {
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type,
                outgoing = true, reason = "Peer did not send a valid WebRTC answer")
            return
        }
        val answerSdp = signal.payload["sdp"].orEmpty()
        _session.value = current.copy(state = CallState.CONNECTING)
        _statusMessage.value = "Connecting secure media…"
        scope.launch {
            try {
                webRtcMedia.acceptAnswer(answerSdp)
                flushBufferedIce(current.peerPubKeyHex, current.callId)
                scheduleConnectTimeout()
            } catch (e: Exception) {
                Log.w(TAG, "Could not apply WebRTC answer: ${e.javaClass.simpleName}")
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type,
                    outgoing = true, reason = e.message?.take(140) ?: "Could not negotiate secure media")
            }
        }
    }

    private fun onLocalIceGenerated(candidate: IceCandidate) {
        val current = _session.value ?: return
        if (current.state == CallState.ENDED || current.state == CallState.IDLE) return
        val extra = JSONObject().apply {
            put("sdpMid", candidate.sdpMid ?: "")
            put("sdpMLineIndex", candidate.sdpMLineIndex)
            put("candidate", candidate.sdp)
        }
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.ICE, current.type, extra = extra)
    }

    private fun handleRemoteIce(signal: IncomingCallSignal) {
        val candidate = signal.payload["candidate"] ?: return
        val mid = signal.payload["sdpMid"]
        val lineIndex = signal.payload["sdpMLineIndex"]?.toIntOrNull() ?: return
        if (candidate.length > 4_096 || lineIndex !in 0..32) return
        val current = _session.value
        if (current != null && current.callId == signal.callId && current.peerPubKeyHex.equals(signal.senderPubKeyHex, true)) {
            if (!current.isOutgoing && current.state == CallState.INCOMING_RINGING) {
                bufferIce("${signal.senderPubKeyHex.lowercase()}:${signal.callId}", BufferedIce(mid, lineIndex, candidate))
            } else {
                webRtcMedia.addRemoteIceCandidate(mid, lineIndex, candidate)
            }
        } else if (vault.getContactByPubKey(signal.senderPubKeyHex) != null && !vault.isBlocked(signal.senderPubKeyHex)) {
            bufferIce("${signal.senderPubKeyHex.lowercase()}:${signal.callId}", BufferedIce(mid, lineIndex, candidate))
        }
    }

    private fun bufferIce(key: String, candidate: BufferedIce) {
        synchronized(earlyIceByCall) {
            val list = earlyIceByCall.getOrPut(key) { mutableListOf() }
            if (list.size < 256) list.add(candidate)
            while (earlyIceByCall.size > 64) earlyIceByCall.remove(earlyIceByCall.keys.first())
        }
    }

    private fun flushBufferedIce(peer: String, id: String) {
        val candidates = synchronized(earlyIceByCall) { earlyIceByCall.remove("${peer.lowercase()}:$id").orEmpty().toList() }
        candidates.forEach { webRtcMedia.addRemoteIceCandidate(it.mid, it.lineIndex, it.candidate) }
    }

    /**
     * Callee-side ringing expiry. Without this, a lost caller END/cancel signal left the
     * incoming-call screen ringing indefinitely with no way to recover except force kill.
     */
    private fun scheduleIncomingRingTimeout(callId: String) {
        incomingRingTimeoutJob?.cancel()
        incomingRingTimeoutJob = scope.launch {
            delay(INCOMING_RING_TIMEOUT_MS)
            val current = _session.value
            if (current != null && current.callId == callId && current.state == CallState.INCOMING_RINGING) {
                _statusMessage.value = "Missed call"
                finishCall(CallOutcome.MISSED, current.peerPubKeyHex, current.peerName, current.type,
                    outgoing = false, reason = "Missed call")
            }
        }
    }

    private fun handleWebRtcConnectionState(state: PeerConnection.PeerConnectionState) {
        val current = _session.value ?: return
        when (state) {
            PeerConnection.PeerConnectionState.CONNECTED -> {
                if (current.state == CallState.ENDED || current.state == CallState.IDLE || current.state == CallState.ACTIVE) {
                    // A DISCONNECTED state that recovered: cancel the pending grace-period
                    // teardown instead of letting it kill a healthy reconnected call.
                    if (current.state == CallState.ACTIVE) disconnectGraceJob?.cancel()
                    return
                }
                running.set(true)
                ringTimeoutJob?.cancel()
                connectTimeoutJob?.cancel()
                disconnectGraceJob?.cancel()
                _session.value = current.copy(state = CallState.ACTIVE,
                    connectedAtMs = if (current.connectedAtMs > 0L) current.connectedAtMs else System.currentTimeMillis())
                _statusMessage.value = null
                SecureChatForegroundService.updateCallForeground(
                    context, active = true,
                    audio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
                    video = current.type == CallType.VIDEO && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                )
                configureAudioRoute(current.speakerOn)
                startTicker()
            }
            PeerConnection.PeerConnectionState.FAILED -> {
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type,
                    outgoing = current.isOutgoing, reason = "WebRTC could not find a usable media path. Check connectivity or configure TURN.")
            }
            PeerConnection.PeerConnectionState.DISCONNECTED -> {
                // Only fail when the media path stays broken past the grace window. The previous
                // 6-second kill fired even after ICE had already reconnected, because the session
                // object still read ACTIVE; the delayed job had no cancellation path at all.
                disconnectGraceJob?.cancel()
                disconnectGraceJob = scope.launch {
                    delay(DISCONNECT_GRACE_MS)
                    val latest = _session.value
                    if (latest?.callId == current.callId && latest.state == CallState.ACTIVE) {
                        // Ask WebRTC for the live connection state rather than trusting the stale
                        // session copy; a recovered link is CONNECTED again by now.
                        val liveState = webRtcMedia.currentConnectionState()
                        if (liveState == PeerConnection.PeerConnectionState.DISCONNECTED ||
                            liveState == PeerConnection.PeerConnectionState.FAILED) {
                            finishCall(CallOutcome.FAILED, latest.peerPubKeyHex, latest.peerName, latest.type,
                                outgoing = latest.isOutgoing, reason = "Media connection was lost")
                        }
                    }
                }
            }
            else -> Unit
        }
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive && running.get()) {
                val s = _session.value ?: break
                if (s.connectedAtMs > 0) {
                    _durationSeconds.value = (System.currentTimeMillis() - s.connectedAtMs) / 1000
                }
                delay(1000)
            }
        }
    }

    // ------------------------------------------------------------------
    // Controls
    // ------------------------------------------------------------------

    fun toggleMute() {
        val s = _session.value ?: return
        val muted = !s.muted
        webRtcMedia.setMicrophoneEnabled(!muted)
        _session.value = s.copy(muted = muted)
    }

    fun toggleSpeaker() {
        val s = _session.value ?: return
        val now = !s.speakerOn
        _session.value = s.copy(speakerOn = now)
        configureAudioRoute(now)
    }

    fun setVideoEnabled(enabled: Boolean) {
        val s = _session.value ?: return
        webRtcMedia.setCameraEnabled(enabled)
        _session.value = s.copy(videoEnabled = enabled)
    }

    fun switchCamera() {
        val current = _session.value ?: return
        if (current.type != CallType.VIDEO || !current.videoEnabled || current.state != CallState.ACTIVE) return
        webRtcMedia.switchCamera()
    }

    private fun configureAudioRoute(speakerOn: Boolean) {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = am.availableCommunicationDevices
                val target = devices.firstOrNull {
                    if (speakerOn) it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    else it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                }
                if (target != null) am.setCommunicationDevice(target)
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = speakerOn
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audio route change failed: ${e.message}")
        }
    }

    fun endCall() {
        val current = _session.value ?: return
        if (current.state == CallState.INCOMING_RINGING) {
            rejectIncoming()
            return
        }
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.END, current.type)
        finishActive(if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.CANCELED)
    }

    private fun finishActive(outcome: CallOutcome) {
        val current = _session.value ?: return
        dismissIncomingCallNotification()
        logCall(current, outcome)
        teardown()
        _session.value = current.copy(state = CallState.ENDED, error = _statusMessage.value)
        scope.launch {
            delay(1200)
            if (_session.value?.state == CallState.ENDED) {
                _session.value = null
                _durationSeconds.value = 0
                _statusMessage.value = null
            }
        }
    }

    private fun finishCall(
        outcome: CallOutcome,
        peerHex: String,
        peerName: String,
        type: CallType,
        outgoing: Boolean,
        reason: String? = null
    ) {
        val current = _session.value
        val entry = current ?: CallSession(
            callId = UUID.randomUUID().toString(),
            peerPubKeyHex = peerHex,
            peerName = peerName,
            type = type,
            isOutgoing = outgoing,
            state = CallState.ENDED
        )
        logCall(entry, outcome)
        if (reason != null) _statusMessage.value = reason
        teardown()
        _session.value = entry.copy(state = CallState.ENDED, error = reason ?: _statusMessage.value)
        scope.launch {
            delay(1400)
            if (_session.value?.state == CallState.ENDED) {
                _session.value = null
                _statusMessage.value = null
                _durationSeconds.value = 0
            }
        }
    }

    private fun logCall(session: CallSession, outcome: CallOutcome) {
        vault.addCallLog(
            CallLogEntry(
                id = UUID.randomUUID().toString(),
                peerPubKeyHex = session.peerPubKeyHex,
                peerName = session.peerName,
                type = session.type,
                outcome = outcome,
                timestampMs = System.currentTimeMillis(),
                durationSeconds = if (session.connectedAtMs > 0) (System.currentTimeMillis() - session.connectedAtMs) / 1000 else 0,
                isOutgoing = session.isOutgoing
            )
        )
    }

    private fun scheduleRingTimeout() {
        ringTimeoutJob?.cancel()
        ringTimeoutJob = scope.launch {
            delay(RING_TIMEOUT_MS)
            val current = _session.value
            if (current != null && current.state == CallState.OUTGOING_RINGING) {
                _statusMessage.value = "No answer"
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "No answer")
            }
        }
    }

    private fun scheduleConnectTimeout() {
        connectTimeoutJob?.cancel()
        connectTimeoutJob = scope.launch {
            delay(CONNECTING_TIMEOUT_MS)
            val current = _session.value
            if (current != null && current.state == CallState.CONNECTING) {
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = current.isOutgoing, reason = "Connection timed out")
            }
        }
    }

    /**
     * SDP can exceed public-message bus packet limits. Split it into bounded, independently
     * authenticated encrypted signaling packets; the receiving transport reassembles only after
     * validating the peer, call id, fragment bounds, and consistent fragment metadata.
     */
    private suspend fun sendSdpSignalAwait(
        peerHex: String,
        callId: String,
        signal: CallSignalType,
        type: CallType,
        sdpType: String,
        sdp: String
    ): String? {
        if (sdp.length !in 20..64_000 || !sdp.startsWith("v=0") ||
            !(sdp.contains("\nm=") || sdp.contains("\r\nm="))) return null
        val fragments = sdp.chunked(1_100)
        if (fragments.size !in 1..64) return null
        var lastRoute: String? = null
        // Fragments are authenticated and reassembled by index on the receiver, so they do not
        // need to be sent serially. A small bounded window avoids N round trips over WAN while
        // limiting relay burst size and allowing the receiver to assemble out-of-order arrivals.
        fragments.withIndex().toList().chunked(3).forEach { batch ->
            val routes = coroutineScope {
                batch.map { (index, fragment) ->
                    async(Dispatchers.IO) {
                        val extra = JSONObject()
                            .put("sdpType", sdpType)
                            .put("sdpFragmentIndex", index)
                            .put("sdpFragmentCount", fragments.size)
                            .put("sdpFragment", fragment)
                        sendSignalAwait(peerHex, callId, signal, type, extra = extra)
                    }
                }.awaitAll()
            }
            if (routes.any { it.isNullOrBlank() }) return null
            lastRoute = routes.lastOrNull { !it.isNullOrBlank() } ?: lastRoute
        }
        return lastRoute
    }

    private fun sendSignal(
        peerHex: String,
        callId: String,
        signal: CallSignalType,
        type: CallType,
        extra: JSONObject? = null
    ) {
        scope.launch { sendSignalAwait(peerHex, callId, signal, type, extra = extra) }
    }

    private suspend fun sendSignalAwait(
        peerHex: String,
        callId: String,
        signal: CallSignalType,
        type: CallType,
        extra: JSONObject? = null
    ): String? {
        val json = JSONObject().apply {
            put("type", "CALL_SIGNAL")
            put("callId", callId)
            put("signal", signal.name)
            put("callType", type.name)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("timestamp", System.currentTimeMillis())
            if (extra != null) {
                val keys = extra.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    put(key, extra.get(key))
                }
            }
        }
        // ICE candidates, END and REJECT are one-shot control packets on a best-effort public
        // bus. A single lost candidate could leave the media path half-negotiated (stuck on
        // "Connecting…"), so an undelivered signal is retried briefly before giving up.
        repeat(3) { attempt ->
            val route = signalSender(peerHex, json)
            if (route != null) return route
            if (attempt < 2) delay(300L * (attempt + 1))
        }
        return null
    }

    private fun teardown() {
        try { SecureChatForegroundService.updateCallForeground(context, active = false) } catch (_: Exception) {}
        running.set(false)
        webRtcMedia.closeCall()
        pendingOfferSdp = null
        synchronized(earlyIceByCall) { earlyIceByCall.clear() }
        ringTimeoutJob?.cancel()
        incomingRingTimeoutJob?.cancel()
        disconnectGraceJob?.cancel()
        connectTimeoutJob?.cancel()
        tickerJob?.cancel()
        tickerJob = null; ringTimeoutJob = null; incomingRingTimeoutJob = null
        disconnectGraceJob = null; connectTimeoutJob = null
        try {
            val am = audioManager
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.clearCommunicationDevice()
                else { @Suppress("DEPRECATION") am.isSpeakerphoneOn = false }
            }
        } catch (_: Exception) {}
    }

    fun currentPeerHex(): String? = _session.value?.peerPubKeyHex
}
