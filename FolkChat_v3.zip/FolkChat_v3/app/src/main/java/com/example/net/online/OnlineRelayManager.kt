package com.example.net.online

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import com.example.BuildConfig
import android.util.Base64
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.EncryptedVault
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.URI
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Online relay client. The relay forwards opaque encrypted envelopes and can still
 * observe public routing keys, timing, packet sizes, and connection metadata.
 *
 * Relay identity subscriptions are authenticated using a short-lived X25519
 * challenge from the relay, preventing a stranger from subscribing as this key.
 */
class OnlineRelayManager(
    private val context: Context,
    private val vault: EncryptedVault? = null
) {
    companion object {
        private const val TAG = "OnlineRelayManager"
        const val TOR_SOCKS_HOST = "127.0.0.1"
        const val TOR_SOCKS_PORT = 9050
        private const val ACK_TIMEOUT_MS = 7_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connectivityManager = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    @Volatile private var networkCallbackRegistered = false
    private var networkReconnectJob: kotlinx.coroutines.Job? = null

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = scheduleNetworkReconnect("network available")
        override fun onLost(network: Network) = scheduleNetworkReconnect("default network lost")
    }
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()
    data class IncomingEnvelope(val payload: ByteArray, val deliveryId: String?)

    private val _incomingPayloads = MutableSharedFlow<IncomingEnvelope>(extraBufferCapacity = 256)
    val incomingPayloads: SharedFlow<IncomingEnvelope> = _incomingPayloads.asSharedFlow()

    private var myPubKeyHex: String? = null
    private val webSocketRef = AtomicReference<WebSocket?>(null)
    private val pendingSends = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private var client: OkHttpClient? = null
    private var clientBuiltForTor: Boolean = false
    private var reconnectJob: kotlinx.coroutines.Job? = null
    @Volatile private var shouldRun = false
    @Volatile private var detectedTorSocksPort: Int = TOR_SOCKS_PORT

    /** Runtime setting takes precedence; the build-time URL lets a branded distribution
     * ship preconfigured without forcing users to paste the same relay address on every phone. */
    private fun relayUrl(): String = vault?.getSettings()?.relayUrl?.trim()
        ?.takeIf { it.isNotBlank() }
        ?: BuildConfig.FOLKCHAT_RELAY_URL.trim()

    val configuredRelayUrl: String get() = relayUrl()

    init {
        registerDefaultNetworkCallback()
    }

    private fun registerDefaultNetworkCallback() {
        val manager = connectivityManager ?: return
        if (networkCallbackRegistered) return
        try {
            manager.registerDefaultNetworkCallback(networkCallback)
            networkCallbackRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "Could not register default-network callback: ${e.message}")
        }
    }

    /** TCP/WebSocket sessions cannot be assumed to survive a Wi-Fi ↔ cellular handoff.
     * Debounce Android's network callbacks and establish a fresh authenticated relay socket. */
    private fun scheduleNetworkReconnect(reason: String) {
        if (!shouldRun) return
        synchronized(this) {
            networkReconnectJob?.cancel()
            networkReconnectJob = scope.launch {
                delay(900)
                if (!shouldRun) return@launch
                if (relayUrl().isBlank()) {
                    _isConnected.value = false
                    _lastError.value = "Internet relay not configured"
                    return@launch
                }
                Log.i(TAG, "Reconnecting relay after $reason")
                reconnectJob?.cancel()
                val old = webSocketRef.getAndSet(null)
                _isConnected.value = false
                failPendingSends()
                try { old?.close(1012, "network changed") } catch (_: Exception) {}
                connect()
            }
        }
    }
    private fun torEnabled(): Boolean = vault?.getSettings()?.torRoutingEnabled ?: false

    /** Probe Orbot's SOCKS listener on IO and remember the actual port. */
    fun isTorProxyReachable(): Boolean {
        for (port in 9050..9200) {
            try {
                Socket().use { socket ->
                    socket.tcpNoDelay = true
                    socket.soTimeout = 300
                    socket.connect(InetSocketAddress(TOR_SOCKS_HOST, port), 100)
                    socket.getOutputStream().write(byteArrayOf(0x05, 0x01, 0x00))
                    socket.getOutputStream().flush()
                    val response = ByteArray(2)
                    val input = socket.getInputStream()
                    var read = 0
                    while (read < response.size) {
                        val count = input.read(response, read, response.size - read)
                        if (count < 0) break
                        read += count
                    }
                    if (read == 2 && response[0] == 0x05.toByte() && response[1] == 0x00.toByte()) {
                        detectedTorSocksPort = port
                        return true
                    }
                }
            } catch (_: Exception) {
                // Closed ports and non-SOCKS services are not Orbot.
            }
        }
        return false
    }

    fun start(publicKey: ByteArray) {
        val pubHex = CryptoEngine.bytesToHex(publicKey).lowercase(Locale.ROOT)
        if (shouldRun && myPubKeyHex == pubHex && webSocketRef.get() != null) return
        stop()
        myPubKeyHex = pubHex
        shouldRun = true
        connect()
    }

    private fun buildClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .pingInterval(25, TimeUnit.SECONDS)
        if (torEnabled()) {
            builder.proxy(Proxy(Proxy.Type.SOCKS, InetSocketAddress(TOR_SOCKS_HOST, detectedTorSocksPort)))
        } else {
            builder.proxy(Proxy.NO_PROXY)
        }
        return builder.build()
    }

    private fun connect() {
        val url = relayUrl()
        if (url.isBlank()) {
            _isConnected.value = false
            _lastError.value = "Internet relay not configured"
            return
        }
        val isWss = url.startsWith("wss://", ignoreCase = true)
        val host = try { URI(url).host?.lowercase(Locale.ROOT) } catch (_: Exception) { null }
        val onionOverTor = url.startsWith("ws://", ignoreCase = true) && host?.endsWith(".onion") == true && torEnabled()
        if (!isWss && !onionOverTor) {
            _isConnected.value = false
            _lastError.value = "Use wss://; ws:// is allowed only for .onion relays while Tor is enabled"
            return
        }
        try {
            val wantTor = torEnabled()
            if (client == null || clientBuiltForTor != wantTor) {
                client = buildClient()
                clientBuiltForTor = wantTor
            }
            val c = client ?: buildClient().also { client = it; clientBuiltForTor = wantTor }
            _isConnected.value = false // not connected until challenge authentication succeeds
            _lastError.value = null
            webSocketRef.set(c.newWebSocket(Request.Builder().url(url).build(), RelayListener()))
            Log.i(TAG, "Connecting to relay${if (wantTor) " via Tor" else ""}")
        } catch (e: Exception) {
            _isConnected.value = false
            _lastError.value = "Relay connection failed: ${e.message}"
            scheduleReconnect()
        }
    }

    private inner class RelayListener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (webSocketRef.get() !== webSocket) {
                webSocket.close(1000, "stale connection")
                return
            }
            _isConnected.value = false
            val key = myPubKeyHex ?: run {
                webSocket.close(1008, "identity unavailable")
                return
            }
            if (!webSocket.send(JSONObject().put("type", "subscribe").put("key", key).toString())) {
                _lastError.value = "Could not start relay authentication"
                webSocket.close(1011, "send failed")
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (webSocketRef.get() !== webSocket) return
            try {
                val json = JSONObject(text)
                when (json.optString("type")) {
                    "challenge" -> authenticateChallenge(webSocket, json)
                    "subscribed" -> {
                        _isConnected.value = true
                        _lastError.value = null
                        Log.i(TAG, "Relay identity authenticated")
                    }
                    "envelope" -> {
                        val raw = Base64.decode(json.getString("payload"), Base64.NO_WRAP)
                        // Keep the durable mailbox entry until TransportCoordinator has
                        // authenticated and processed the envelope. ACKing here would lose
                        // messages if the app crashed after enqueueing but before vault save.
                        val hasConsumer = _incomingPayloads.subscriptionCount.value > 0
                        if (!hasConsumer) {
                            // Force a reconnect so the relay redelivers durable mailbox
                            // items once the app's transport collector is ready.
                            webSocket.close(1013, "inbound consumer unavailable")
                            return
                        }
                        val deliveryId = json.optString("deliveryId").takeIf { it.isNotBlank() }
                        if (!_incomingPayloads.tryEmit(IncomingEnvelope(raw, deliveryId))) {
                            // Don't ACK a dropped packet. Reconnect to drain the durable
                            // server mailbox in order rather than silently lose a message.
                            webSocket.close(1013, "inbound queue full")
                        }
                    }
                    "accepted" -> {
                        json.optString("requestId").takeIf { it.isNotBlank() }?.let { id ->
                            pendingSends.remove(id)?.complete(true)
                        }
                    }
                    "error" -> {
                        val requestId = json.optString("requestId")
                        if (requestId.isNotBlank()) pendingSends.remove(requestId)?.complete(false)
                        _lastError.value = json.optString("message", "Relay rejected a packet")
                    }
                    "ping" -> webSocket.send(JSONObject().put("type", "pong").toString())
                }
            } catch (e: Exception) {
                Log.w(TAG, "Bad relay frame: ${e.message}")
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (!webSocketRef.compareAndSet(webSocket, null)) return
            _isConnected.value = false
            _lastError.value = "Relay lost: ${t.message ?: "connection failure"}"
            failPendingSends()
            scheduleReconnect()
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (!webSocketRef.compareAndSet(webSocket, null)) return
            _isConnected.value = false
            failPendingSends()
            if (shouldRun) scheduleReconnect()
        }
    }

    private fun authenticateChallenge(webSocket: WebSocket, json: JSONObject) {
        try {
            val nonce = json.getString("nonce")
            val relayPublicHex = json.getString("serverPubKey").lowercase(Locale.ROOT)
            require(nonce.matches(Regex("^[0-9a-fA-F]{64}$")))
            require(relayPublicHex.matches(Regex("^[0-9a-f]{64}$")))
            val identity = vault?.getIdentityKeyPair() ?: throw IllegalStateException("Vault unavailable")
            val myKey = myPubKeyHex ?: throw IllegalStateException("Identity unavailable")
            require(identity.publicKeyHex.equals(myKey, ignoreCase = true))
            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, CryptoEngine.hexToBytes(relayPublicHex))
            require(shared.any { it != 0.toByte() })
            val proofInput = "FolkChat-Relay-Auth-v1|$nonce|$myKey".toByteArray(Charsets.UTF_8)
            val proof = CryptoEngine.bytesToHex(CryptoEngine.hmacSha256(shared, proofInput))
            val sent = webSocket.send(
                JSONObject().put("type", "authenticate").put("key", myKey)
                    .put("nonce", nonce).put("proof", proof).toString()
            )
            if (!sent) throw IllegalStateException("Relay authentication send failed")
        } catch (e: Exception) {
            _isConnected.value = false
            _lastError.value = "Relay authentication failed: ${e.message}"
            webSocket.close(1008, "authentication failed")
        }
    }

    /** ACK durable relay delivery only after the app's transport consumer has processed it. */
    fun acknowledgeDelivery(deliveryId: String) {
        if (deliveryId.isBlank() || deliveryId.length > 128) return
        webSocketRef.get()?.takeIf { _isConnected.value }?.send(
            JSONObject().put("type", "received").put("deliveryId", deliveryId).toString()
        )
    }

    private fun failPendingSends() {
        pendingSends.values.forEach { it.complete(false) }
        pendingSends.clear()
    }

    private fun scheduleReconnect() {
        if (!shouldRun) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(5_000)
            if (shouldRun && !_isConnected.value) connect()
        }
    }

    fun stop() {
        shouldRun = false
        reconnectJob?.cancel()
        synchronized(this) { networkReconnectJob?.cancel(); networkReconnectJob = null }
        failPendingSends()
        webSocketRef.getAndSet(null)?.close(1000, "client stop")
        _isConnected.value = false
    }

    fun restart() {
        stop()
        shouldRun = true
        client = null
        if (myPubKeyHex != null) connect()
    }

    /**
     * Send an opaque envelope and wait for a server-side acceptance response.
     * Chunks/call signals are not put into offline storage; ordinary messages and
     * receipt/control packets may be queued by the relay.
     */
    suspend fun sendEnvelope(
        recipientPubKeyHex: String,
        envelopeBytes: ByteArray,
        queueIfOffline: Boolean = true
    ): Boolean {
        val ws = webSocketRef.get()
        if (ws == null || !_isConnected.value) return false
        val requestId = UUID.randomUUID().toString()
        val completion = CompletableDeferred<Boolean>()
        pendingSends[requestId] = completion
        return try {
            val frame = JSONObject()
                .put("type", "envelope")
                .put("requestId", requestId)
                .put("to", recipientPubKeyHex.lowercase(Locale.ROOT).trim())
                .put("queueIfOffline", queueIfOffline)
                .put("payload", Base64.encodeToString(envelopeBytes, Base64.NO_WRAP))
            if (!ws.send(frame.toString())) {
                false
            } else {
                withTimeoutOrNull(ACK_TIMEOUT_MS) { completion.await() } ?: false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed sending envelope over relay: ${e.message}")
            false
        } finally {
            pendingSends.remove(requestId)
        }
    }
}
