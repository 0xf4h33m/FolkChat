package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CallType
import com.example.net.call.CallManager
import com.example.net.call.CallState
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import org.webrtc.EglBase
import com.example.ui.components.PeerAvatar
import com.example.ui.theme.CallControlSurface
import com.example.ui.theme.CallControlSurfaceActive
import com.example.ui.theme.CallStageBg
import com.example.ui.theme.CallStageBgDeep
import com.example.ui.theme.FolkError
import com.example.ui.theme.FolkErrorDark
import com.example.ui.theme.FolkOnboarding
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkSuccessDark

/**
 * Full-screen WhatsApp-style call overlay for the entire call lifecycle,
 * driven directly by the real [CallManager] state.
 */
@Composable
fun ActiveCallScreen(
    callManager: CallManager,
    onClose: () -> Unit,
    reduceMotion: Boolean = false
) {
    val session by callManager.session.collectAsState()
    val duration by callManager.durationSeconds.collectAsState()
    val localVideoTrack by callManager.localVideoTrack.collectAsState()
    val remoteVideoTrack by callManager.remoteVideoTrack.collectAsState()
    val statusMessage by callManager.statusMessage.collectAsState()

    val current = session ?: return

    val isIncoming = current.state == CallState.INCOMING_RINGING
    val isActive = current.state == CallState.ACTIVE
    val isEnded = current.state == CallState.ENDED
    // Render the remote stage from the actual incoming track. Local camera-off/permission
    // state must never hide the peer's video; an answer can be receive-only while still sending
    // audio, so lack of a local camera does not require the entire call UI to become audio-only.
    val isVideoLive = current.type == CallType.VIDEO && isActive && remoteVideoTrack != null

    // Resolve the peer's saved avatar (profile image flow) if we have one.
    val context = LocalContext.current
    val peerAvatarPath = remember(current.peerPubKeyHex) {
        try {
            (context.applicationContext as? com.example.SecureChatApp)
                ?.vault?.getContactByPubKey(current.peerPubKeyHex)?.avatarPath
        } catch (_: Exception) {
            null
        }
    }

    // Auto-dismiss overlay shortly after the engine clears the session.
    LaunchedEffect(session) {
        if (session == null) onClose()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(CallStageBg, CallStageBgDeep)))
    ) {
        if (!isVideoLive) {
            Box(
                modifier = Modifier
                    .size(320.dp)
                    .align(Alignment.TopCenter)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(CallControlSurfaceActive.copy(alpha = 0.26f), Color.Transparent)))
            )
            Box(
                modifier = Modifier
                    .size(250.dp)
                    .align(Alignment.BottomCenter)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(FolkSage.copy(alpha = 0.10f), Color.Transparent)))
            )
        }

        if (isVideoLive) {
            // SurfaceViewRenderer (the renderer provided by this WebRTC fork) keeps WebRTC video composable-friendly; never tunnel full-resolution
            // video through the text relay or JPEG-over-TCP prototype.
            if (remoteVideoTrack != null) {
                WebRtcTrackRenderer(
                    track = remoteVideoTrack,
                    eglContext = callManager.eglBaseContext,
                    mirror = false,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Connecting secure video…", color = FolkSage, fontSize = 13.sp)
                }
            }

            if (localVideoTrack != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .size(width = 104.dp, height = 148.dp)
                        .clip(RoundedCornerShape(16.dp))
                ) {
                    WebRtcTrackRenderer(
                        track = localVideoTrack,
                        eglContext = callManager.eglBaseContext,
                        mirror = true,
                        modifier = Modifier.fillMaxSize()
                    )
                    androidx.compose.material3.FilledIconButton(
                        onClick = { callManager.switchCamera() },
                        enabled = isActive && current.videoEnabled,
                        modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).size(32.dp),
                        colors = androidx.compose.material3.IconButtonDefaults.filledIconButtonColors(
                            containerColor = Color.Black.copy(alpha = 0.55f),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.Cached, contentDescription = "Switch front/rear camera", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 52.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(28.dp))

            if (!isVideoLive) {
                val ringing = current.state == CallState.OUTGOING_RINGING || current.state == CallState.INCOMING_RINGING
                val ringPulse = rememberInfiniteTransition(label = "call-ring-pulse")
                val avatarScale = ringPulse.animateFloat(
                    initialValue = 1f,
                    targetValue = if (ringing && !reduceMotion) 1.045f else 1f,
                    animationSpec = infiniteRepeatable(tween(900), repeatMode = RepeatMode.Reverse),
                    label = "avatar-scale"
                ).value
                Box(modifier = Modifier.graphicsLayer { scaleX = avatarScale; scaleY = avatarScale }) {
                    PeerAvatar(
                        name = current.peerName,
                        avatarPath = peerAvatarPath,
                        size = 128.dp
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            } else {
                Spacer(modifier = Modifier.height(8.dp))
            }

            Text(
                text = current.peerName,
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = when {
                    isEnded -> statusMessage ?: "Call ended"
                    isIncoming -> "Incoming ${if (current.type == CallType.VIDEO) "video" else "voice"} call"
                    current.state == CallState.OUTGOING_RINGING -> statusMessage ?: "Ringing…"
                    current.state == CallState.CONNECTING -> statusMessage ?: "Connecting…"
                    isActive -> formatActiveCallDuration(duration)
                    else -> ""
                },
                fontSize = 14.sp,
                color = FolkSage
            )

            if (isActive) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 13.dp, vertical = 6.dp)
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = FolkSuccessDark,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "End-to-end encrypted peer-to-peer",
                        fontSize = 11.sp,
                        color = FolkSage
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            if (isIncoming) {
                // WhatsApp-style incoming call controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CallControlButton(
                        icon = Icons.Default.CallEnd,
                        label = "Decline",
                        container = FolkErrorDark,
                        reduceMotion = reduceMotion,
                        onClick = { callManager.rejectIncoming(); onClose() }
                    )
                    CallControlButton(
                        icon = Icons.Default.Call,
                        label = "Accept",
                        container = FolkOnboarding,
                        reduceMotion = reduceMotion,
                        onClick = { callManager.acceptIncoming() }
                    )
                }
            } else if (isEnded) {
                CallControlButton(
                    icon = Icons.Default.CallEnd,
                    label = "Close",
                    container = CallControlSurface,
                    reduceMotion = reduceMotion,
                    onClick = { onClose() }
                )
            } else {
                // Outgoing ringing / connecting / active controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CallControlButton(
                        icon = if (current.muted) Icons.Default.MicOff else Icons.Default.Mic,
                        label = if (current.muted) "Unmute" else "Mute",
                        container = if (current.muted) CallControlSurfaceActive else CallControlSurface,
                        enabled = isActive,
                        reduceMotion = reduceMotion,
                        onClick = { callManager.toggleMute() }
                    )
                    CallControlButton(
                        icon = if (current.speakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        label = "Speaker",
                        container = if (current.speakerOn) CallControlSurfaceActive else CallControlSurface,
                        enabled = isActive,
                        reduceMotion = reduceMotion,
                        onClick = { callManager.toggleSpeaker() }
                    )
                    if (current.type == CallType.VIDEO) {
                        CallControlButton(
                            icon = if (current.videoEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            label = "Camera",
                            container = if (current.videoEnabled) CallControlSurfaceActive else CallControlSurface,
                            enabled = isActive,
                            reduceMotion = reduceMotion,
                            onClick = { callManager.setVideoEnabled(!current.videoEnabled) }
                        )
                    }
                    CallControlButton(
                        icon = Icons.Default.CallEnd,
                        label = "End",
                        container = FolkErrorDark,
                        reduceMotion = reduceMotion,
                        onClick = { callManager.endCall() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun WebRtcTrackRenderer(
    track: VideoTrack?,
    eglContext: EglBase.Context,
    mirror: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val renderer = remember(context, eglContext, mirror, track) {
        SurfaceViewRenderer(context).apply {
            init(eglContext, null)
            setEnableHardwareScaler(true)
            setMirror(mirror)
            setScalingType(org.webrtc.RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        }
    }
    DisposableEffect(track, renderer) {
        if (track != null) track.addSink(renderer)
        onDispose {
            if (track != null) track.removeSink(renderer)
            try { renderer.release() } catch (_: Exception) { }
        }
    }
    AndroidView(factory = { renderer }, modifier = modifier)
}

@Composable
private fun CallControlButton(
    icon: ImageVector,
    label: String,
    container: Color,
    enabled: Boolean = true,
    reduceMotion: Boolean = false,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && enabled && !reduceMotion) 0.92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "callControlPressScale"
    )
    val animatedContainer by animateColorAsState(
        targetValue = if (enabled) container else container.copy(alpha = 0.35f),
        animationSpec = androidx.compose.animation.core.tween(durationMillis = if (reduceMotion) 0 else 180),
        label = "callControlContainerColor"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(66.dp)
                .shadow(if (enabled) 7.dp else 0.dp, CircleShape, clip = false)
                .clip(CircleShape)
                .background(animatedContainer)
                .border(1.dp, Color.White.copy(alpha = if (enabled) 0.17f else 0.05f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            IconButton(
                onClick = onClick,
                enabled = enabled,
                interactionSource = interactionSource,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            ) {
                Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }
        Spacer(modifier = Modifier.height(9.dp))
        Text(label, fontSize = 11.sp, color = Color.White.copy(alpha = if (enabled) 0.9f else 0.46f), fontWeight = FontWeight.Medium)
    }
}

private fun formatActiveCallDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}
