package com.example.net.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.ParcelUuid
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.DiscoveredPeer
import com.example.net.framing.L1Framer
import com.example.net.link.Link
import com.example.net.link.LinkState
import com.example.net.link.LinkType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

class BleLink(
    override val id: String,
    override val peerId: String,
    override val type: LinkType = LinkType.BLE_GATT,
    private val sendAction: suspend (ByteArray) -> Boolean,
    private val disconnectAction: () -> Unit
) : Link {
    override var mtu: Int = 180

    private val _state = MutableStateFlow(LinkState.CONNECTED)
    override val state: StateFlow<LinkState> = _state.asStateFlow()

    private val _onFrame = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    override val onFrame: SharedFlow<ByteArray> = _onFrame.asSharedFlow()

    fun emitFrame(frame: ByteArray) {
        _onFrame.tryEmit(frame)
    }

    fun updateState(newState: LinkState) {
        _state.value = newState
    }

    override suspend fun send(frame: ByteArray): Boolean {
        if (_state.value != LinkState.CONNECTED) return false
        return sendAction(frame)
    }

    override fun disconnect() {
        _state.value = LinkState.DISCONNECTED
        disconnectAction()
    }
}

class BleManager(private val context: Context) {
    companion object {
        private const val TAG = "SecureChatBle"
        val SERVICE_UUID: UUID = UUID.fromString("00005C01-0000-1000-8000-00805F9B34FB")
        val RX_CHAR_UUID: UUID = UUID.fromString("00005C02-0000-1000-8000-00805F9B34FB")
        val TX_CHAR_UUID: UUID = UUID.fromString("00005C03-0000-1000-8000-00805F9B34FB")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val bluetoothManager: BluetoothManager? = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? get() = bluetoothManager?.adapter

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var gattServer: BluetoothGattServer? = null
    private var rotatingTagJob: Job? = null
    private val inboundFrameBudget = ConcurrentHashMap<String, Pair<Long, Int>>()

    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<Map<String, DiscoveredPeer>>(emptyMap())
    val discoveredPeers: StateFlow<Map<String, DiscoveredPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPayloads = MutableSharedFlow<ByteArray>(extraBufferCapacity = 64)
    val incomingPayloads: SharedFlow<ByteArray> = _incomingPayloads.asSharedFlow()

    private val activeClientGatts = ConcurrentHashMap<String, BluetoothGatt>()

    var myIdentityPubKey: ByteArray? = null

    @SuppressLint("MissingPermission")
    fun startAdvertising(identityPubKey: ByteArray) {
        myIdentityPubKey = identityPubKey
        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled) return

        advertiser = adapter.bluetoothLeAdvertiser ?: return

        val rotatingTag = CryptoEngine.computeRotatingTag(identityPubKey)
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
            .setConnectable(true)
            .setTimeout(0)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .build()

        val advertiseData = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .setIncludeTxPowerLevel(false)
            .addServiceUuid(ParcelUuid(SERVICE_UUID))
            .build()

        val scanResponse = AdvertiseData.Builder()
            .addServiceData(ParcelUuid(SERVICE_UUID), rotatingTag.copyOf(8))
            .build()

        try {
            rotatingTagJob?.cancel()
            advertiser?.stopAdvertising(advertiseCallback)
            advertiser?.startAdvertising(settings, advertiseData, scanResponse, advertiseCallback)
            startGattServer()
            // BLE scan-response data is static while an advertisement is active. Restart it
            // periodically so its rotating tag does not remain trackable for the process lifetime.
            rotatingTagJob = scope.launch {
                while (kotlinx.coroutines.currentCoroutineContext().isActive) {
                    delay(60_000L)
                    val identity = myIdentityPubKey ?: continue
                    if (!_isAdvertising.value) continue
                    val nextResponse = AdvertiseData.Builder()
                        .addServiceData(ParcelUuid(SERVICE_UUID), CryptoEngine.computeRotatingTag(identity).copyOf(8))
                        .build()
                    try {
                        advertiser?.stopAdvertising(advertiseCallback)
                        advertiser?.startAdvertising(settings, advertiseData, nextResponse, advertiseCallback)
                    } catch (e: Exception) {
                        Log.w(TAG, "Could not rotate BLE discovery tag: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start advertising: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopAdvertising() {
        rotatingTagJob?.cancel()
        rotatingTagJob = null
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            _isAdvertising.value = false
            stopGattServer()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping advertising: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun startScanning() {
        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled) return

        scanner = adapter.bluetoothLeScanner ?: return

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_BALANCED)
            .build()

        try {
            scanner?.startScan(listOf(filter), settings, scanCallback)
            _isScanning.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start scan: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScanning() {
        try {
            scanner?.stopScan(scanCallback)
            _isScanning.value = false
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping scan: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGattServer() {
        if (gattServer != null) return
        val manager = bluetoothManager ?: return

        gattServer = manager.openGattServer(context, gattServerCallback)?.apply {
            val service = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)

            val rxChar = BluetoothGattCharacteristic(
                RX_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
                BluetoothGattCharacteristic.PERMISSION_WRITE
            )

            val txChar = BluetoothGattCharacteristic(
                TX_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_READ
            )

            service.addCharacteristic(rxChar)
            service.addCharacteristic(txChar)
            addService(service)
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopGattServer() {
        gattServer?.close()
        gattServer = null
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            _isAdvertising.value = true
            Log.d(TAG, "BLE advertising started successfully with rotating tag")
        }

        override fun onStartFailure(errorCode: Int) {
            _isAdvertising.value = false
            Log.e(TAG, "BLE advertising failed with code: $errorCode")
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.let { handleScanResult(it) }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { handleScanResult(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "BLE scan failed with code: $errorCode")
            _isScanning.value = false
        }
    }

    private fun handleScanResult(result: ScanResult) {
        val record = result.scanRecord ?: return
        val serviceData = record.getServiceData(ParcelUuid(SERVICE_UUID)) ?: return
        val tagHex = CryptoEngine.bytesToHex(serviceData)
        val device = result.device

        val peer = DiscoveredPeer(
            id = device.address,
            displayName = "BLE Peer [${tagHex.take(6)}]",
            tagHex = tagHex,
            linkType = "BLE_GATT",
            rssi = result.rssi,
            lastSeenEpochMs = System.currentTimeMillis()
        )

        val current = _discoveredPeers.value.toMutableMap()
        current[device.address] = peer
        _discoveredPeers.value = current
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice?,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic?,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray?
        ) {
            val bytes = value
            val accepted = device != null && bytes != null && bytes.size in L1Framer.HEADER_SIZE..202 &&
                allowInboundFrame(device.address)
            if (responseNeeded && device != null) {
                try {
                    gattServer?.sendResponse(
                        device, requestId,
                        if (accepted) BluetoothGatt.GATT_SUCCESS else 0x11,
                        offset, null
                    )
                } catch (e: SecurityException) {
                    Log.e(TAG, "SecurityException sending GATT response: ${e.message}")
                }
            }
            if (!accepted || bytes == null) return
            val chunk = L1Framer.parseFrame(bytes) ?: return
            val fullPayload = L1Framer.ingestChunk(chunk)
            if (fullPayload != null) _incomingPayloads.tryEmit(fullPayload)
        }
    }

    /** Per-device write budget keeps an unauthenticated nearby radio from flooding reassembly. */
    private fun allowInboundFrame(deviceAddress: String): Boolean {
        val now = System.currentTimeMillis()
        var allowed = false
        inboundFrameBudget.compute(deviceAddress) { _, prior ->
            val state = if (prior == null || now - prior.first >= 10_000L) now to 1 else prior.first to (prior.second + 1)
            allowed = state.second <= 1024
            state
        }
        if (inboundFrameBudget.size > 256) {
            val cutoff = now - 60_000L
            inboundFrameBudget.entries.removeIf { it.value.first < cutoff }
        }
        return allowed
    }

    @SuppressLint("MissingPermission")
    suspend fun sendPayloadToDevice(deviceAddress: String, payload: ByteArray): Boolean = withContext(Dispatchers.IO) {
        val adapter = bluetoothAdapter ?: return@withContext false
        val device = try { adapter.getRemoteDevice(deviceAddress) } catch (_: Exception) { return@withContext false }
        val frames = try { L1Framer.slicePayload(payload, maxChunkPayloadSize = 180) }
            catch (e: Exception) { Log.w(TAG, "Payload exceeds BLE framing limits: ${e.message}"); return@withContext false }
        if (frames.isEmpty()) return@withContext false

        val result = CompletableDeferred<Boolean>()
        val pendingWrite = AtomicReference<CompletableDeferred<Boolean>?>(null)
        val gattRef = AtomicReference<BluetoothGatt?>(null)
        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    result.complete(false)
                    return
                }
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    if (gatt?.discoverServices() != true) result.complete(false)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED && !result.isCompleted) {
                    result.complete(false)
                }
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS || gatt == null) {
                    result.complete(false)
                    return
                }
                val rx = gatt.getService(SERVICE_UUID)?.getCharacteristic(RX_CHAR_UUID)
                if (rx == null) { result.complete(false); return }
                scope.launch {
                    for (frame in frames) {
                        if (result.isCompleted) return@launch
                        val writeDone = CompletableDeferred<Boolean>()
                        pendingWrite.set(writeDone)
                        rx.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                        rx.value = frame
                        val started = try { gatt.writeCharacteristic(rx) } catch (_: Exception) { false }
                        if (!started) {
                            pendingWrite.compareAndSet(writeDone, null)
                            result.complete(false)
                            return@launch
                        }
                        val succeeded = withTimeoutOrNull(4_000L) { writeDone.await() } ?: false
                        pendingWrite.compareAndSet(writeDone, null)
                        if (!succeeded) {
                            result.complete(false)
                            return@launch
                        }
                        delay(12L)
                    }
                    result.complete(true)
                }
            }

            override fun onCharacteristicWrite(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?, status: Int) {
                pendingWrite.get()?.complete(status == BluetoothGatt.GATT_SUCCESS)
            }
        }

        try {
            val gatt = device.connectGatt(context, false, callback) ?: return@withContext false
            gattRef.set(gatt)
            withTimeoutOrNull(60_000L) { result.await() } ?: false
        } catch (e: Exception) {
            Log.e(TAG, "Error sending payload over BLE: ${e.message}")
            false
        } finally {
            pendingWrite.getAndSet(null)?.complete(false)
            gattRef.getAndSet(null)?.let { gatt ->
                try { gatt.disconnect() } catch (_: Exception) {}
                try { gatt.close() } catch (_: Exception) {}
            }
        }
    }

    fun cleanUp() {
        stopAdvertising()
        stopScanning()
        activeClientGatts.values.forEach {
            try {
                it.disconnect()
                it.close()
            } catch (e: Exception) {
                // Ignore
            }
        }
        activeClientGatts.clear()
    }
}
