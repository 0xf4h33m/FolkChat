package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.crypto.CryptoEngine
import com.example.data.RoutingPolicy
import com.example.data.Contact
import com.example.service.SecureChatForegroundService
import com.example.ui.ChatViewModel
import com.example.ui.UiEventKind
import com.example.ui.components.AddContactDialog
import com.example.ui.components.ContactConfirmationDialog
import com.example.ui.components.ContactProfileDialog
import com.example.ui.components.LinkDiagnosticsDialog
import com.example.ui.components.MyCodeDialog
import com.example.ui.components.QrScannerDialog
import com.example.ui.screens.ActiveCallScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ChatLockScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.LockScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.AppFontChoice
import com.example.ui.theme.BubbleStyle
import com.example.ui.theme.ChatWallpaper
import com.example.ui.branding.AppEmblemStyle

/** BLE-connected foreground-service type is only started when the permissions needed
 * by the local-link transport are granted. Camera/microphone are optional to messaging. */
private fun hasMeshTransportPermissions(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val scan = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        val advertise = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
        val connect = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        scan && advertise && connect
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }
}

private fun startBestAvailableMessagingTransport(context: Context, viewModel: ChatViewModel) {
    if (hasMeshTransportPermissions(context)) viewModel.startBackgroundService()
    else viewModel.startInternetMessagingOnly()
}

class MainActivity : FragmentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Deep link: open a conversation straight from a notification.
        val openPeerKey = intent?.getStringExtra(SecureChatForegroundService.EXTRA_OPEN_PEER)
        if (!openPeerKey.isNullOrBlank()) {
            viewModel.openConversationByPubKey(openPeerKey)
        }

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val settings by viewModel.settings.collectAsState()
            val foregroundContact by viewModel.activeContact.collectAsState()
            val activeChatIsProtected = foregroundContact?.x25519PublicKeyHex?.lowercase()?.let { it in settings.lockedChatKeys } == true

            // Screenshot protection is also forced for an individually locked conversation,
            // even if the global screenshot preference has been turned off.
            LaunchedEffect(settings.screenshotProtection, activeChatIsProtected) {
                if (settings.screenshotProtection || activeChatIsProtected) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            MyApplicationTheme(
                themeMode = themeMode,
                accentPalette = AccentPalette.fromName(settings.accentPalette),
                fontScale = settings.chatFontScale,
                bubbleStyle = BubbleStyle.fromName(settings.bubbleStyle),
                chatWallpaper = ChatWallpaper.fromName(settings.chatWallpaper),
                fontChoice = AppFontChoice.fromName(settings.appFont)
            ) {
                val lockState = viewModel.appLock.locked.collectAsState().value
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .onPreviewKeyEvent { event ->
                            if (event.type == KeyEventType.KeyDown && (!settings.appLockEnabled || !lockState)) {
                                viewModel.appLock.onUserActivity()
                            }
                            false
                        }
                        .pointerInput(viewModel.appLock, settings.appLockEnabled, lockState) {
                            awaitPointerEventScope {
                                while (true) {
                                    awaitPointerEvent(PointerEventPass.Initial)
                                    if (!settings.appLockEnabled || !lockState) viewModel.appLock.onUserActivity()
                                }
                            }
                        },
                    color = MaterialTheme.colorScheme.background
                ) {
                    FolkChatAppContent(viewModel, this@MainActivity)
                }
            }
        }
    }
}

@Composable
fun FolkChatAppContent(viewModel: ChatViewModel, activity: FragmentActivity) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val contacts by viewModel.contacts.collectAsState()
    val allMessages by viewModel.allMessages.collectAsState()
    val activeContact by viewModel.activeContact.collectAsState()
    val activeMessages by viewModel.activeConversationMessages.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()
    val isServiceRunning by viewModel.isServiceRunning.collectAsState()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val routingPolicy by viewModel.routingPolicy.collectAsState()
    val typingPeers by viewModel.typingPeers.collectAsState()
    val callSession by viewModel.callManager.session.collectAsState()
    val isLocked by viewModel.appLock.locked.collectAsState()
    val unlockedChatKeys by viewModel.appLock.unlockedChatKeys.collectAsState()
    val chatUnlockFailure by viewModel.appLock.unlockFailure.collectAsState()

    var showMyCodeDialog by remember { mutableStateOf(false) }
    var showAddContactDialog by remember { mutableStateOf(false) }
    var showContactProfileContact by remember { mutableStateOf<Contact?>(null) }
    var showDiagnosticsDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var contactConfirmationCandidate by remember { mutableStateOf<Pair<String, String>?>(null) }
    var scannedPairingToken by remember { mutableStateOf<String?>(null) }

    // A connected call is a foreground hold: the user is actively engaged with
    // the peer, so the idle auto-lock countdown must not cover the call screen.
    LaunchedEffect(callSession != null) {
        viewModel.appLock.setForegroundHold(callSession != null)
    }

    // App-lock lifecycle wiring (auto-lock after backgrounding).
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> viewModel.appLock.onAppStopped(activity)
                Lifecycle.Event.ON_START -> viewModel.appLock.onAppResumed()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Permissions: Bluetooth, notifications, camera, microphone.
    val requiredPermissions = remember {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        list.add(Manifest.permission.CAMERA)
        list.add(Manifest.permission.RECORD_AUDIO)
        list
    }

    var hasRequestedPermissions by remember { mutableStateOf(false) }
    var permissionsGranted by remember {
        mutableStateOf(
            requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        permissionsGranted = requiredPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        // Camera and microphone unlock optional features; denying either must not disable
        // internet messaging. If Bluetooth/location grants are absent, run relay-only while
        // the UI is foreground rather than failing to start the transport at all.
        startBestAvailableMessagingTransport(context, viewModel)
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showQrScannerDialog = true
        else Toast.makeText(context, "Camera permission needed to scan QR codes", Toast.LENGTH_SHORT).show()
    }

    fun openQrScannerWithPermissionCheck() {
        val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (hasCamera) showQrScannerDialog = true else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    LaunchedEffect(Unit) {
        if (!permissionsGranted && !hasRequestedPermissions) {
            hasRequestedPermissions = true
            permissionLauncher.launch(requiredPermissions.toTypedArray())
        } else if (permissionsGranted) {
            // Permissions are often already granted on later app launches. Always restart
            // the relay/service instead of silently leaving the app without an internet socket.
            startBestAvailableMessagingTransport(context, viewModel)
        } else {
            // All-feature permission set is incomplete, but internet chat does not need
            // camera/microphone permission. Keep the relay alive while this screen is open.
            startBestAvailableMessagingTransport(context, viewModel)
        }
    }

    // App Lock overlay takes absolute priority — gates everything.
    if (settings.appLockEnabled && isLocked) {
        LockScreen(appLock = viewModel.appLock, activity = activity, onUnlocked = { viewModel.appLock.unlock() })
        return
    }

    // First-run onboarding ↔ main app, animated as a calm cross-fade.
    AnimatedContent(
        targetState = isOnboardingCompleted,
        transitionSpec = {
            fadeIn(tween(340)) togetherWith fadeOut(tween(220))
        },
        label = "onboardingTransition"
    ) { completed ->
    if (!completed) {
        WelcomeScreen(
            initialName = viewModel.displayName.collectAsState().value,
            emblemStyle = AppEmblemStyle.fromName(settings.appEmblem),
            reduceMotion = settings.reduceMotion,
            onStartWithName = { name -> viewModel.completeOnboardingWithName(name) }
        )
    } else {
        Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            if (!permissionsGranted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Some features need permissions",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Internet chat works with the relay. Bluetooth enables local links; camera & microphone enable scanning, calls and voice notes.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { permissionLauncher.launch(requiredPermissions.toTypedArray()) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(start = 6.dp)
                        ) {
                            Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            if (activeContact != null) {
                val activeChatKey = activeContact!!.x25519PublicKeyHex.lowercase()
                val activeChatIsLocked = viewModel.appLock.isChatLocked(activeChatKey)
                val activeChatIsUnlocked = activeChatKey in unlockedChatKeys

                // Snapshot failures that happen while THIS lock screen is shown; a
                // stale error from a previously opened locked chat never bleeds in.
                var chatLockScreenError by remember(activeContact) { mutableStateOf<String?>(null) }
                LaunchedEffect(chatUnlockFailure, activeChatKey) {
                    if (chatUnlockFailure != null) chatLockScreenError = chatUnlockFailure
                }

                if (activeChatIsLocked && !activeChatIsUnlocked) {
                    ChatLockScreen(
                        contactName = activeContact!!.displayName,
                        externalError = chatLockScreenError,
                        lockoutRemainingMs = viewModel.appLock.pinLockoutRemainingMs(),
                        onVerifyPin = { pin ->
                            val verified = viewModel.appLock.verifyPinWithoutUnlock(pin)
                            if (verified) {
                                viewModel.appLock.unlockChat(activeChatKey)
                                viewModel.onActiveChatUnlocked()
                            }
                            verified
                        },
                        onBack = { viewModel.selectContact(null) }
                    )
                } else ChatScreen(
                    contact = activeContact!!,
                    messages = activeMessages,
                    peers = discoveredPeers,
                    isInternetAvailable = isInternetAvailable,
                    onSendMessage = { text -> viewModel.sendMessage(text) },
                    onSendMessageWithMeta = { text, replyId, replyPreview, replySender ->
                        viewModel.sendMessage(text, replyId, replyPreview, replySender)
                    },
                    onDeleteMessage = { msgId -> viewModel.deleteMessageLocally(msgId) },
                    onEditMessage = { msgId, text -> viewModel.editMessage(msgId, text) },
                    onDeleteForEveryone = { msgId -> viewModel.deleteMessageForEveryone(msgId) },
                    onTogglePin = { msgId -> viewModel.togglePin(msgId) },
                    onToggleReaction = { msgId, emoji -> viewModel.toggleReaction(msgId, emoji) },
                    onResendMessage = { msgId -> viewModel.resendMessage(msgId) },
                    onSendAttachment = { attachment, caption -> viewModel.sendMediaAttachment(attachment, caption) },
                    onCancelTransfer = { msgId -> viewModel.cancelMediaTransfer(msgId) },
                    onRetryTransfer = { msgId -> viewModel.retryMediaTransfer(msgId) },
                    resolveLocalFile = { attachment -> viewModel.resolveMediaFile(attachment) },
                    onOpenContactProfile = { showContactProfileContact = activeContact },
                    onBack = { viewModel.selectContact(null) },
                    onStartCall = { contact, isVideo -> viewModel.startCall(contact, isVideo) },
                    // v2
                    contactsForForward = contacts,
                    onToggleStar = { msgId -> viewModel.toggleStar(msgId) },
                    onForward = { msgId, toKey -> viewModel.forwardMessage(msgId, toKey) },
                    onConsumeView = { msgId -> viewModel.consumeViewLimitedMedia(msgId) },
                    onSetDisappearTimer = { timer -> activeContact?.let { viewModel.setDisappearTimer(it, timer) } },
                    onTypingSignal = { viewModel.sendTypingSignal() },
                    isPeerTyping = viewModel.isPeerTyping(activeContact),
                    peerLastReadMs = activeContact?.peerLastReadMs ?: 0L,
                    readReceiptsEnabled = settings.readReceipts,
                    compactChat = settings.compactChat,
                    reduceMotion = settings.reduceMotion,
                    isChatLocked = activeChatIsLocked,
                    onLockChat = {
                        if (activeChatIsLocked) {
                            // A temporary relock; the setting remains protected until changed in Settings.
                            viewModel.appLock.relockChat(activeChatKey)
                        } else if (viewModel.appLock.setChatLocked(activeChatKey, true)) {
                            viewModel.refreshSettings()
                        } else {
                            Toast.makeText(context, "Set a 6-digit PIN in Settings before locking chats", Toast.LENGTH_LONG).show()
                        }
                    },
                    onExternalActivityLaunch = { viewModel.appLock.expectExternalActivityResult() },
                    onExternalActivityResult = { viewModel.appLock.externalActivityResultReturned() },
                    // The composition draft survives chat switches; IME typing
                    // also keeps the app-lock idle timer alive.
                    draft = viewModel.getConversationDraft(activeContact!!.x25519PublicKeyHex),
                    onDraftChange = { viewModel.saveConversationDraft(activeContact!!.x25519PublicKeyHex, it) },
                    onUserActivity = { viewModel.appLock.onUserActivity() },
                )
            } else {
                ConversationsScreen(
                    viewModel = viewModel,
                    onOpenMyCode = { showMyCodeDialog = true },
                    onOpenAddContact = { showAddContactDialog = true },
                    onOpenDiagnostics = { showDiagnosticsDialog = true },
                    onOpenContactProfile = { contact -> showContactProfileContact = contact }
                )
            }
        }

        // ------------------------------------------------------------------
        // Unified transient event surface: errors and confirmations emitted
        // by the ViewModel surface here instead of failing silently.
        // ------------------------------------------------------------------
        val uiEvent by viewModel.uiEvents.collectAsState()
        uiEvent?.let { event ->
            LaunchedEffect(event.id) {
                kotlinx.coroutines.delay(if (event.kind == UiEventKind.ERROR) 4200L else 2600L)
                viewModel.consumeUiEvent()
            }
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(start = 14.dp, end = 14.dp, bottom = 92.dp),
                shape = RoundedCornerShape(14.dp),
                containerColor = if (event.kind == UiEventKind.ERROR)
                    MaterialTheme.colorScheme.error
                else
                    MaterialTheme.colorScheme.inverseSurface,
                contentColor = if (event.kind == UiEventKind.ERROR)
                    MaterialTheme.colorScheme.onError
                else
                    MaterialTheme.colorScheme.inverseOnSurface,
                dismissAction = {
                    Text(
                        text = "OK",
                        color = if (event.kind == UiEventKind.ERROR)
                            MaterialTheme.colorScheme.onError
                        else
                            MaterialTheme.colorScheme.inverseOnSurface,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable { viewModel.consumeUiEvent() }
                            .padding(horizontal = 4.dp)
                    )
                }
            ) { Text(event.message, fontSize = 13.sp, lineHeight = 18.sp) }
        }
        }
    }
    } // end AnimatedContent(onboarding)

    // Live call overlay — driven entirely by the real CallManager.
    if (callSession != null) {
        ActiveCallScreen(
            callManager = viewModel.callManager,
            onClose = { /* session clears itself */ },
            reduceMotion = settings.reduceMotion
        )
    }

    if (showQrScannerDialog) {
        QrScannerDialog(
            onQrCodeDetected = { qrContent ->
                val pairingQr = CryptoEngine.parsePairingQrCode(qrContent)
                val parsed = pairingQr?.let { Pair(it.pubKeyHex, it.displayName) } ?: CryptoEngine.parseContactCode(qrContent)
                showQrScannerDialog = false
                scannedPairingToken = pairingQr?.tokenHex
                if (parsed != null) contactConfirmationCandidate = parsed
                else Toast.makeText(context, "This FolkChat QR is invalid or expired. Ask them to refresh it.", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showQrScannerDialog = false }
        )
    }

    if (contactConfirmationCandidate != null) {
        val candidate = contactConfirmationCandidate!!
        ContactConfirmationDialog(
            scannedPubKeyHex = candidate.first,
            initialDisplayName = candidate.second,
            isMutualPairing = scannedPairingToken != null,
            onConfirmAdd = { name, key ->
                val pairingWasRequested = scannedPairingToken != null
                val selectedPolicy = routingPolicy
                val contact = viewModel.confirmAddContact(key, name, scannedPairingToken)
                contactConfirmationCandidate = null
                scannedPairingToken = null
                if (contact == null) {
                    Toast.makeText(
                        context,
                        "This contact is blocked or its public key is invalid. Unblock the peer explicitly before adding again.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val toastText = when {
                        !pairingWasRequested -> "Added ${contact.displayName}. Compare the safety fingerprint before trusting this identity."
                        selectedPolicy == RoutingPolicy.FORCE_OFFLINE -> "Force Offline is enabled. Switch to Auto/Online while both devices are connected to finish mutual QR pairing."
                        else -> "Pairing request sent to ${contact.displayName}. Trust is confirmed when the encrypted ACK returns."
                    }
                    Toast.makeText(context, toastText, Toast.LENGTH_LONG).show()
                }
            },
            onDismiss = { contactConfirmationCandidate = null; scannedPairingToken = null }
        )
    }

    if (showContactProfileContact != null) {
        ContactProfileDialog(
            contact = showContactProfileContact!!,
            myPubKey = viewModel.identity.collectAsState().value.publicKey,
            onDeleteContact = {
                viewModel.deleteContact(showContactProfileContact!!.x25519PublicKeyHex)
                showContactProfileContact = null
            },
            onClearChat = {
                viewModel.clearChatHistory(showContactProfileContact!!.x25519PublicKeyHex)
                showContactProfileContact = null
                Toast.makeText(context, "Chat history deleted", Toast.LENGTH_SHORT).show()
            },
            onBlockContact = {
                viewModel.blockPeer(
                    showContactProfileContact!!.x25519PublicKeyHex,
                    showContactProfileContact!!.displayName
                )
                showContactProfileContact = null
                Toast.makeText(context, "Peer blocked", Toast.LENGTH_SHORT).show()
            },
            onMarkVerified = {
                val contact = showContactProfileContact!!
                viewModel.markContactVerified(contact.x25519PublicKeyHex)
                showContactProfileContact = contact.copy(isVerified = true)
                Toast.makeText(context, "Fingerprint marked as compared", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showContactProfileContact = null }
        )
    }

    if (showMyCodeDialog) {
        MyCodeDialog(
            identity = viewModel.identity.collectAsState().value,
            displayName = viewModel.displayName.collectAsState().value,
            onUpdateName = { newName -> viewModel.updateDisplayName(newName) },
            onPairingChallenge = { token, expiry -> viewModel.activatePairingChallenge(token, expiry) },
            onClearPairingChallenge = { token -> viewModel.clearPairingChallenge(token) },
            reduceMotion = settings.reduceMotion,
            onDismiss = { viewModel.clearPairingChallenge(); showMyCodeDialog = false }
        )
    }

    if (showAddContactDialog) {
        AddContactDialog(
            onAddContact = { code, name -> viewModel.addContact(code, name) },
            onOpenQrScanner = { openQrScannerWithPermissionCheck() },
            onDismiss = { showAddContactDialog = false }
        )
    }

    if (showDiagnosticsDialog) {
        LinkDiagnosticsDialog(
            peers = discoveredPeers,
            isServiceRunning = isServiceRunning,
            onToggleService = { enable ->
                if (enable) viewModel.startBackgroundService() else viewModel.stopBackgroundService()
            },
            onFlushOutbox = { viewModel.triggerOutboxFlush() },
            onAddManualIp = { ip ->
                viewModel.registerManualPeer(ip)
                Toast.makeText(context, "Direct link registered to $ip", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showDiagnosticsDialog = false }
        )
    }
}
