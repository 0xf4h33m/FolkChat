package com.example.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.crypto.KeyPairBytes
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.io.FileOutputStream

class EncryptedVault(private val context: Context) {
    companion object {
        private const val TAG = "EncryptedVault"
        private const val KEYSTORE_ALIAS = "FolkChatVaultWrappingKeyV2"
        private const val LEGACY_KEY_ALIAS = "SecureChatMasterKey"
        private const val VAULT_FILENAME = "vault_v1.enc"
        private const val WRAPPED_KEY_FILENAME = "vault_v1.key"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val GCM_TAG_BITS = 128
        private const val STORAGE_PREFS = "folkchat_privacy_preferences"
        private const val KEEP_LOCAL_DATA_KEY = "keep_local_data"

        /** New installs use session-only data by default. Existing vaults are preserved on upgrade. */
        fun shouldPersistDeviceData(context: Context): Boolean =
            context.getSharedPreferences(STORAGE_PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEEP_LOCAL_DATA_KEY, File(context.filesDir, VAULT_FILENAME).exists())

        /** Persistent files live in filesDir only after consent; session media is kept in cacheDir. */
        fun dataRootFor(context: Context): File = if (shouldPersistDeviceData(context)) {
            context.filesDir
        } else {
            File(context.cacheDir, "folkchat_session")
        }
    }

    @Volatile private var deviceStorageEnabled: Boolean = shouldPersistDeviceData(context)

    private var cachedIdentity: KeyPairBytes? = null
    private var myDisplayName: String = "Alice"
    private var appThemeMode: String = "CLASSIC_LIGHT"
    private var onboardingCompleted: Boolean = false
    private var settings: AppSettings = AppSettings()
    private val contactsMap = mutableMapOf<String, Contact>()
    private val groupsMap = mutableMapOf<String, GroupConversation>()
    private val messagesList = mutableListOf<ChatMessage>()
    private val outboxList = mutableListOf<ChatMessage>()
    private val messageRequestsMap = mutableMapOf<String, MessageRequest>()
    private val callLogs = mutableListOf<CallLogEntry>()
    private val blockedPeers = mutableMapOf<String, String>()   // pubKeyHex -> displayName
    private val readCursors = mutableMapOf<String, Long>()      // conversation pubKeyHex -> last read timestamp
    // pubKeyHex -> (claimedName, verifiedAtMs). Peers authenticated by the QR pairing
    // handshake but not yet accepted as contacts by the local user.
    private val pairingVerifiedPeers = mutableMapOf<String, Pair<String, Long>>()
    private var myAvatarPath: String? = null
    private var routingPolicyName: String = "AUTO_FALLBACK"

    // Ephemeral QR pairing challenge: deliberately kept only in memory, never written to the vault.
    private data class ActivePairingChallenge(
        val tokenHex: String,
        val expiresAtMs: Long,
        var acceptedSenderPubKeyHex: String? = null,
        var acceptedRequestId: String? = null
    )
    @Volatile private var activePairingChallenge: ActivePairingChallenge? = null

    @Volatile private var cachedMasterKey: ByteArray? = null
    @Volatile private var vaultLoadFailed: Boolean = false
    @Volatile private var migratingLegacyVault: Boolean = false

    private val masterKey: ByteArray
        get() = synchronized(this) {
            cachedMasterKey ?: getOrCreateMasterKey().also { cachedMasterKey = it }
        }

    init {
        loadVault()
        // Do not mutate an unreadable vault, initialize a replacement identity, or purge
        // records based on partially parsed state. getIdentityKeyPair() also fails closed.
        if (!vaultLoadFailed) {
            purgeExpiredDisappearingMessages()
            purgeGifMediaAttachments()
            ensureDefaultSelfContact()
            // Session copies are no longer authoritative after a successful durable save. At this
            // point the previous process (and its open transfer handles) has exited.
            if (deviceStorageEnabled) {
                try { File(context.cacheDir, "folkchat_session").deleteRecursively() } catch (_: Exception) { }
            }
        }
    }

    /** Whether the user has explicitly enabled durable on-device persistence. */
    fun isDeviceStorageEnabled(): Boolean = deviceStorageEnabled

    /** Root used for avatars/media: app-private durable files only after consent, otherwise cache. */
    fun dataRoot(): File = if (deviceStorageEnabled) context.filesDir else File(context.cacheDir, "folkchat_session")

    /**
     * Explicit opt-in: promote session-only files, rewrite their references, and write the encrypted
     * vault once. A fresh install does not create a vault/key file before this action.
     */
    @Synchronized
    fun enableDeviceStorageAndSave(onStorageRootChanged: () -> Unit = {}): Boolean {
        if (deviceStorageEnabled) return true
        val prefs = context.getSharedPreferences(STORAGE_PREFS, Context.MODE_PRIVATE)
        if (!prefs.edit().putBoolean(KEEP_LOCAL_DATA_KEY, true).commit()) return false
        deviceStorageEnabled = true
        var promotedPaths: Map<String, String> = emptyMap()
        return try {
            // Switch the transfer manager before promoting files. Existing cache-backed receives
            // remain open and relocate after verification; new transfers write to the durable root.
            onStorageRootChanged()
            promotedPaths = promoteSessionFiles()
            rewriteStoredPaths(promotedPaths)
            if (saveVault()) {
                // Keep cache originals during this process: a media transfer may still hold an open
                // file there. They are safe to clean on a later startup after active handles are gone.
                true
            } else {
                rollbackSessionPromotion(promotedPaths)
                deviceStorageEnabled = false
                prefs.edit().putBoolean(KEEP_LOCAL_DATA_KEY, false).commit()
                onStorageRootChanged()
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Could not enable local persistence: ${e.message}")
            rollbackSessionPromotion(promotedPaths)
            deviceStorageEnabled = false
            prefs.edit().putBoolean(KEEP_LOCAL_DATA_KEY, false).commit()
            try { onStorageRootChanged() } catch (_: Exception) { }
            false
        }
    }

    /** Copy temporary media/avatar files to durable app-private storage on user opt-in. */
    private fun promoteSessionFiles(): Map<String, String> {
        val sessionRoot = File(context.cacheDir, "folkchat_session")
        val pathMap = mutableMapOf<String, String>()
        for (child in listOf("avatars", "media")) {
            val sourceRoot = File(sessionRoot, child)
            if (!sourceRoot.exists()) continue
            val destinationRoot = File(context.filesDir, child)
            sourceRoot.walkTopDown().forEach { source ->
                val relative = source.relativeTo(sourceRoot)
                val destination = File(destinationRoot, relative.path)
                if (source.isDirectory) {
                    if (!destination.exists() && !destination.mkdirs()) {
                        throw java.io.IOException("Could not create ${destination.name} directory")
                    }
                } else {
                    destination.parentFile?.let { if (!it.exists() && !it.mkdirs()) throw java.io.IOException("Could not create media directory") }
                    source.copyTo(destination, overwrite = true)
                    pathMap[source.canonicalPath] = destination.canonicalPath
                }
            }
        }
        return pathMap
    }

    /** Restore in-memory paths and remove copies if the explicit save transaction fails. */
    private fun rollbackSessionPromotion(pathMap: Map<String, String>) {
        if (pathMap.isEmpty()) return
        rewriteStoredPaths(pathMap.entries.associate { (source, destination) -> destination to source })
        pathMap.values.forEach { path ->
            try { File(path).delete() } catch (_: Exception) { }
        }
    }

    private fun rewriteStoredPaths(pathMap: Map<String, String>) {
        if (pathMap.isEmpty()) return
        fun movedPath(path: String?): String? {
            if (path.isNullOrBlank()) return path
            return try { pathMap[File(path).canonicalPath] ?: path } catch (_: Exception) { path }
        }
        myAvatarPath = movedPath(myAvatarPath)
        synchronized(contactsMap) {
            contactsMap.toMap().forEach { (key, contact) ->
                val next = movedPath(contact.avatarPath)
                if (next != contact.avatarPath) contactsMap[key] = contact.copy(avatarPath = next)
            }
        }
        fun moveMessage(message: ChatMessage): ChatMessage {
            val attachment = message.attachment ?: return message
            val nextPath = movedPath(attachment.localPath)
            return if (nextPath != attachment.localPath) message.copy(attachment = attachment.copy(localPath = nextPath)) else message
        }
        synchronized(messagesList) {
            for (index in messagesList.indices) messagesList[index] = moveMessage(messagesList[index])
        }
        synchronized(outboxList) {
            for (index in outboxList.indices) outboxList[index] = moveMessage(outboxList[index])
        }
    }

    private fun ensureDefaultSelfContact() {
        val identity = getIdentityKeyPair()
        if (contactsMap.isEmpty()) {
            val selfContact = Contact(
                id = "self_notes",
                displayName = "Saved Notes (Self-Test)",
                x25519PublicKeyHex = identity.publicKeyHex.lowercase(),
                isVerified = true
            )
            contactsMap[selfContact.x25519PublicKeyHex] = selfContact
            saveVault()
        }
    }

    fun isOnboardingCompleted(): Boolean = onboardingCompleted

    fun setOnboardingCompleted(completed: Boolean) {
        onboardingCompleted = completed
        saveVault()
    }

    fun getThemeMode(): String = appThemeMode

    fun setThemeMode(mode: String) {
        appThemeMode = mode
        saveVault()
    }

    // ---------------------------------------------------------------------
    // App settings
    // ---------------------------------------------------------------------
    fun getSettings(): AppSettings = settings

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settings = transform(settings)
        saveVault()
    }

    /** Store a salted PBKDF2-HMAC-SHA-256 PIN verifier in the encrypted vault. */
    fun setPin(pin: String) {
        require(pin.length == 6 && pin.all { it.isDigit() }) { "PIN must be exactly six digits" }
        val salt = ByteArray(16).apply { SecureRandom().nextBytes(this) }
        val saltHex = CryptoEngine.bytesToHex(salt)
        settings = settings.copy(
            pinHash = hashPin(pin, saltHex),
            pinSalt = saltHex,
            pinFailedAttempts = 0,
            pinLockoutUntilMs = 0L
        )
        saveVault()
    }

    /** Returns false without deriving a hash during a lockout; persists escalating delays. */
    fun verifyPin(pin: String): Boolean {
        if (settings.pinHash.isEmpty() || settings.pinSalt.isEmpty()) return false
        val now = System.currentTimeMillis()
        if (now < settings.pinLockoutUntilMs) return false
        if (pin.length != 6 || !pin.all { it.isDigit() }) {
            recordPinFailure(now)
            return false
        }
        val expected = settings.pinHash
        // Derive the modern verifier once and reuse that result for the successful migration.
        // The old path derived PBKDF2 twice on every correct PIN, adding visible latency without
        // improving security because the same salt and candidate PIN were used both times.
        val candidateHash = if (expected.startsWith("pbkdf2-sha256$")) hashPin(pin, settings.pinSalt) else null
        val ok = if (candidateHash != null) {
            MessageDigest.isEqual(
                expected.substringAfter('$').substringAfter('$').toByteArray(Charsets.US_ASCII),
                candidateHash.substringAfter('$').substringAfter('$').toByteArray(Charsets.US_ASCII)
            )
        } else {
            // Legacy verifier is retained only for a successful one-time upgrade.
            MessageDigest.isEqual(legacyHashPin(pin, settings.pinSalt).toByteArray(Charsets.US_ASCII), expected.toByteArray(Charsets.US_ASCII))
        }
        if (ok) {
            settings = settings.copy(
                pinHash = candidateHash ?: hashPin(pin, settings.pinSalt),
                pinFailedAttempts = 0,
                pinLockoutUntilMs = 0L
            )
            saveVault()
            return true
        }
        recordPinFailure(now)
        return false
    }

    fun pinLockoutRemainingMs(): Long = (settings.pinLockoutUntilMs - System.currentTimeMillis()).coerceAtLeast(0L)

    private fun recordPinFailure(now: Long) {
        val attempts = (settings.pinFailedAttempts + 1).coerceAtMost(30)
        val lockoutMs = if (attempts < 5) 0L else {
            (30_000L shl (attempts - 5).coerceIn(0, 7)).coerceAtMost(3_600_000L)
        }
        settings = settings.copy(
            pinFailedAttempts = attempts,
            pinLockoutUntilMs = if (lockoutMs > 0L) now + lockoutMs else settings.pinLockoutUntilMs
        )
        saveVault()
    }

    private fun hashPin(pin: String, saltHex: String): String {
        val salt = CryptoEngine.hexToBytes(saltHex)
        val spec = PBEKeySpec(pin.toCharArray(), salt, 210_000, 256)
        return try {
            val derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            "pbkdf2-sha256$210000$" + CryptoEngine.bytesToHex(derived)
        } finally {
            spec.clearPassword()
        }
    }

    private fun legacyHashPin(pin: String, saltHex: String): String {
        var material = (saltHex + ":" + pin).toByteArray()
        repeat(20_000) {
            material = CryptoEngine.hkdfSha256(
                material,
                salt = saltHex.toByteArray(),
                info = "folkchat-pin".toByteArray(),
                length = 32
            )
        }
        return CryptoEngine.bytesToHex(material)
    }

    fun clearPin() {
        settings = settings.copy(pinHash = "", pinSalt = "", pinFailedAttempts = 0, pinLockoutUntilMs = 0L)
        saveVault()
    }


    // ---------------------------------------------------------------------
    // Call history
    // ---------------------------------------------------------------------
    fun getCallLogs(): List<CallLogEntry> = synchronized(callLogs) {
        callLogs.sortedByDescending { it.timestampMs }
    }

    fun addCallLog(entry: CallLogEntry) {
        synchronized(callLogs) {
            if (callLogs.none { it.id == entry.id }) callLogs.add(entry)
        }
        saveVault()
    }

    fun clearCallLogs() {
        synchronized(callLogs) { callLogs.clear() }
        saveVault()
    }

    // ---------------------------------------------------------------------
    // Identity / contacts
    // ---------------------------------------------------------------------
    fun getIdentityKeyPair(): KeyPairBytes {
        cachedIdentity?.let { return it }
        check(!vaultLoadFailed) { "Existing vault is unreadable; refusing to create a replacement identity" }
        val newPair = CryptoEngine.generateX25519KeyPair()
        cachedIdentity = newPair
        saveVault()
        return newPair
    }

    fun getDisplayName(): String = myDisplayName

    fun setDisplayName(name: String) {
        myDisplayName = name.trim()
        saveVault()
    }

    fun getContacts(): List<Contact> = synchronized(contactsMap) { contactsMap.values.toList() }

    fun getGroups(): List<GroupConversation> = synchronized(groupsMap) {
        groupsMap.values.sortedByDescending { it.updatedAtMs }
    }

    fun getGroupById(groupId: String): GroupConversation? = synchronized(groupsMap) {
        groupsMap[groupId.lowercase().trim()]
    }

    /**
     * Persist a bounded group membership snapshot. Existing groups cannot be silently taken over
     * by another creator; membership changes must come from the original creator.
     */
    fun addOrUpdateGroup(group: GroupConversation): Boolean {
        val id = group.id.lowercase().trim()
        val creator = group.createdByPubKeyHex.lowercase().trim()
        val members = group.memberPubKeyHexes.map { it.lowercase().trim() }.distinct()
        if (!id.matches(Regex("^[0-9a-f]{64}$")) ||
            !creator.matches(Regex("^[0-9a-f]{64}$")) ||
            members.size !in 2..64 ||
            members.any { !it.matches(Regex("^[0-9a-f]{64}$")) } ||
            creator !in members || group.name.isBlank() || group.name.length > 80) return false

        synchronized(groupsMap) {
            val existing = groupsMap[id]
            if (existing != null && !existing.createdByPubKeyHex.equals(creator, ignoreCase = true)) return false
            if (existing != null && group.updatedAtMs < existing.updatedAtMs) return false
            groupsMap[id] = group.copy(
                id = id,
                name = group.name.trim(),
                memberPubKeyHexes = members,
                createdByPubKeyHex = creator
            )
        }
        saveVault()
        return true
    }

    fun deleteGroup(groupId: String) {
        val key = groupId.lowercase().trim()
        synchronized(groupsMap) { groupsMap.remove(key) }
        clearAllMessagesForContact(key)
        saveVault()
    }

    fun addOrUpdateContact(contact: Contact) {
        synchronized(contactsMap) {
            contactsMap[contact.x25519PublicKeyHex.lowercase()] = contact.copy(
                x25519PublicKeyHex = contact.x25519PublicKeyHex.lowercase()
            )
        }
        saveVault()
    }

    fun deleteContact(pubKeyHex: String) {
        val key = pubKeyHex.lowercase().trim()
        if (!key.matches(Regex("^[0-9a-f]{64}$"))) return
        synchronized(contactsMap) {
            contactsMap.remove(key)
        }
        saveVault()
    }

    fun getContactByPubKey(pubKeyHex: String): Contact? = synchronized(contactsMap) {
        contactsMap[pubKeyHex.lowercase().trim()]
    }

    /** Activate a short-lived pairing QR challenge. It is intentionally not persisted. */
    fun activatePairingChallenge(tokenHex: String, expiresAtMs: Long) {
        val token = tokenHex.lowercase().trim()
        require(token.matches(Regex("^[0-9a-f]{64}$"))) { "Invalid pairing token" }
        require(expiresAtMs > System.currentTimeMillis() && expiresAtMs <= System.currentTimeMillis() + 3 * 60_000L) {
            "Pairing challenge expiry is invalid"
        }
        synchronized(this) {
            activePairingChallenge = ActivePairingChallenge(token, expiresAtMs)
        }
    }

    fun clearPairingChallenge(tokenHex: String? = null) {
        synchronized(this) {
            val active = activePairingChallenge
            if (tokenHex == null || active?.tokenHex == tokenHex.lowercase().trim()) {
                activePairingChallenge = null
            }
        }
    }

    /**
     * Consume a QR bearer token once for one authenticated peer/request. Retransmission of that
     * exact request is idempotent so a lost ACK can be retried; other peers/requests are rejected.
     */
    fun consumePairingChallenge(tokenHex: String, senderPubKeyHex: String, requestId: String): Boolean {
        val token = tokenHex.lowercase().trim()
        val sender = senderPubKeyHex.lowercase().trim()
        if (!token.matches(Regex("^[0-9a-f]{64}$")) ||
            !sender.matches(Regex("^[0-9a-f]{64}$")) || requestId.length !in 16..80) return false
        synchronized(this) {
            val active = activePairingChallenge ?: return false
            if (active.expiresAtMs <= System.currentTimeMillis()) {
                activePairingChallenge = null
                return false
            }
            if (!MessageDigest.isEqual(CryptoEngine.hexToBytes(active.tokenHex), CryptoEngine.hexToBytes(token))) return false
            if (active.acceptedSenderPubKeyHex == null && active.acceptedRequestId == null) {
                active.acceptedSenderPubKeyHex = sender
                active.acceptedRequestId = requestId
                return true
            }
            return active.acceptedSenderPubKeyHex == sender && active.acceptedRequestId == requestId
        }
    }

    fun getMessageRequests(): List<MessageRequest> = synchronized(messageRequestsMap) {
        messageRequestsMap.values.sortedByDescending { it.timestampMs }
    }

    fun addOrUpdateMessageRequest(req: MessageRequest) {
        synchronized(messageRequestsMap) {
            messageRequestsMap[req.senderPubKeyHex.lowercase()] = req.copy(
                senderPubKeyHex = req.senderPubKeyHex.lowercase()
            )
        }
        saveVault()
    }

    /**
     * A peer that completed the mutual QR pairing handshake but is NOT yet an accepted contact.
     * Their first message still lands in Message Requests; accepting it creates a verified contact.
     */
    fun markPairingVerifiedPeer(pubKeyHex: String, claimedDisplayName: String) {
        val key = pubKeyHex.lowercase().trim()
        if (!key.matches(Regex("^[0-9a-f]{64}$"))) return
        val name = claimedDisplayName.trim().take(80).ifBlank { "Peer ${key.take(6)}" }
        synchronized(pairingVerifiedPeers) { pairingVerifiedPeers[key] = Pair(name, System.currentTimeMillis()) }
        saveVault()
    }

    fun isPairingVerifiedPeer(pubKeyHex: String): Boolean {
        val key = pubKeyHex.lowercase().trim()
        val entry = synchronized(pairingVerifiedPeers) { pairingVerifiedPeers[key] } ?: return false
        // Verification is only meaningful while the pairing handshake is recent.
        return System.currentTimeMillis() - entry.second < 24L * 60 * 60 * 1000L
    }

    /** Claimed display name from the authenticated QR pairing request, if any. */
    fun getPairingVerifiedPeerName(pubKeyHex: String): String? {
        val key = pubKeyHex.lowercase().trim()
        val entry = synchronized(pairingVerifiedPeers) { pairingVerifiedPeers[key] } ?: return null
        if (System.currentTimeMillis() - entry.second >= 24L * 60 * 60 * 1000L) return null
        return entry.first
    }

    /**
     * Recent QR-authenticated peers may send the first message before the user accepts them.
     * Returning their keys lets the relay listen for that first message without auto-accepting
     * the peer as a contact. Expired pairing records are deliberately excluded.
     */
    fun getPairingVerifiedPeerPubKeys(): Set<String> {
        val cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        return synchronized(pairingVerifiedPeers) {
            pairingVerifiedPeers.entries
                .filter { (key, value) -> key.matches(Regex("^[0-9a-f]{64}$")) && value.second >= cutoff }
                .map { it.key }
                .toSet()
        }
    }

    fun acceptMessageRequest(senderPubKeyHex: String, displayName: String): Contact {
        val cleanPubKey = senderPubKeyHex.lowercase().trim()
        // A request born from a verified QR pairing becomes a verified contact automatically;
        // the pairing handshake already proved possession of the advertised X25519 identity.
        val pairingVerified = isPairingVerifiedPeer(cleanPubKey)
        val pairingName = getPairingVerifiedPeerName(cleanPubKey)
        val contact = Contact(
            id = java.util.UUID.randomUUID().toString(),
            displayName = (displayName.ifBlank { pairingName.orEmpty() }).ifBlank { "Peer " + cleanPubKey.take(6) },
            x25519PublicKeyHex = cleanPubKey,
            isVerified = pairingVerified
        )
        synchronized(contactsMap) {
            contactsMap[cleanPubKey] = contact
        }
        synchronized(messageRequestsMap) {
            messageRequestsMap.remove(cleanPubKey)
        }
        if (pairingVerified) synchronized(pairingVerifiedPeers) { pairingVerifiedPeers.remove(cleanPubKey) }
        saveVault()
        return contact
    }

    fun declineMessageRequest(senderPubKeyHex: String) {
        val cleanPubKey = senderPubKeyHex.lowercase().trim()
        synchronized(messageRequestsMap) {
            messageRequestsMap.remove(cleanPubKey)
        }
        clearAllMessagesForContact(cleanPubKey)
        saveVault()
    }

    // ---------------------------------------------------------------------
    // Blocked peers (privacy-first persistent block list)
    // ---------------------------------------------------------------------
    fun blockPeer(pubKeyHex: String, displayName: String) {
        val key = pubKeyHex.lowercase().trim()
        if (key.isEmpty()) return
        synchronized(blockedPeers) { blockedPeers[key] = displayName.ifBlank { "Peer ${key.take(6)}" } }
        // Blocking also removes any pending message request from that peer.
        synchronized(messageRequestsMap) { messageRequestsMap.remove(key) }
        saveVault()
    }

    fun unblockPeer(pubKeyHex: String) {
        synchronized(blockedPeers) { blockedPeers.remove(pubKeyHex.lowercase().trim()) }
        saveVault()
    }

    fun isBlocked(pubKeyHex: String): Boolean =
        synchronized(blockedPeers) { blockedPeers.containsKey(pubKeyHex.lowercase().trim()) }

    fun getBlockedPeers(): List<Pair<String, String>> =
        synchronized(blockedPeers) { blockedPeers.map { Pair(it.key, it.value) } }

    // ---------------------------------------------------------------------
    // Read cursors & unread counts
    // ---------------------------------------------------------------------
    fun markConversationRead(peerPubKeyHex: String) {
        // The same lock object saveVault() uses while iterating the cursors: an unsynchronized
        // put racing that iteration threw ConcurrentModificationException inside saveVault(),
        // which aborted the snapshot and silently dropped every change since the last save.
        synchronized(readCursors) {
            readCursors[peerPubKeyHex.lowercase().trim()] = System.currentTimeMillis()
        }
        saveVault()
    }

    fun getReadCursor(peerPubKeyHex: String): Long = synchronized(readCursors) {
        readCursors[peerPubKeyHex.lowercase().trim()] ?: 0L
    }

    fun getUnreadCount(peerPubKeyHex: String): Int {
        val key = peerPubKeyHex.lowercase().trim()
        val cursor = synchronized(readCursors) { readCursors[key] } ?: 0L
        return synchronized(messagesList) {
            messagesList.count {
                !it.isOutgoing && !it.isDeleted && it.systemEvent == null &&
                    it.timestampMs > cursor &&
                    it.conversationPeerPubKeyHex.equals(key, ignoreCase = true)
            }
        }
    }

    // ---------------------------------------------------------------------
    // Starred messages
    // ---------------------------------------------------------------------
    fun getStarredMessages(): List<ChatMessage> = synchronized(messagesList) {
        messagesList.filter { it.isStarred && !it.isDeleted }.sortedByDescending { it.timestampMs }
    }

    fun setStarred(messageId: String, starred: Boolean) {
        updateMessage(messageId) { it.copy(isStarred = starred) }
    }

    // ---------------------------------------------------------------------
    // Disappearing messages (enforced locally per conversation timer)
    // ---------------------------------------------------------------------
    fun purgeExpiredDisappearingMessages() {
        val now = System.currentTimeMillis()
        val timerPolicies = synchronized(contactsMap) {
            contactsMap.values.associate {
                it.x25519PublicKeyHex.lowercase() to (it.disappearAfterSec to it.disappearAfterSetAtMs)
            }
        }
        val expired: List<ChatMessage>
        synchronized(messagesList) {
            expired = messagesList.filter { m ->
                val policy = timerPolicies[m.conversationPeerPubKeyHex.lowercase()] ?: (0 to Long.MAX_VALUE)
                val (seconds, enabledAtMs) = policy
                seconds > 0 && m.timestampMs >= enabledAtMs && !m.isDeleted &&
                    now - m.timestampMs > (seconds * 1000L)
            }
            if (expired.isNotEmpty()) messagesList.removeAll(expired.toSet())
        }
        if (expired.isNotEmpty()) {
            val expiredIds = expired.map { it.id }.toSet()
            synchronized(outboxList) { outboxList.removeAll { it.id in expiredIds } }
            expired.forEach { deleteManagedMedia(it.attachment?.localPath) }
            saveVault()
        }
    }

    /**
     * Removes legacy GIF attachments from FolkChat's private media directory and marks their
     * vault records unavailable. This deliberately never walks shared/external storage and never
     * deletes files owned by Gallery, Downloads, or other applications.
     */
    fun purgeGifMediaAttachments(): Int {
        if (vaultLoadFailed) return 0
        val mediaRoot = try { File(dataRoot(), "media").canonicalFile } catch (_: Exception) { return 0 }
        var deleted = 0
        var changed = false
        synchronized(messagesList) {
            for (index in messagesList.indices) {
                val message = messagesList[index]
                val attachment = message.attachment ?: continue
                val recordedGif = attachment.mimeType.equals("image/gif", ignoreCase = true) ||
                    attachment.fileName.endsWith(".gif", ignoreCase = true)
                val path = attachment.localPath
                val localFile = try { path?.let { File(it).canonicalFile } } catch (_: Exception) { null }
                val signatureGif = localFile != null && localFile.parentFile == mediaRoot && localFile.isFile &&
                    try { localFile.inputStream().use { input ->
                        val header = ByteArray(6)
                        val read = input.read(header)
                        val isGif = read == 6 && (String(header, Charsets.US_ASCII) == "GIF87a" || String(header, Charsets.US_ASCII) == "GIF89a")
                        header.fill(0)
                        isGif
                    } } catch (_: Exception) { false }
                if (!recordedGif && !signatureGif) continue
                if (localFile != null && localFile.parentFile == mediaRoot && localFile.isFile && localFile.delete()) deleted++
                messagesList[index] = message.copy(attachment = attachment.copy(
                    localPath = null,
                    transferState = TransferState.FAILED,
                    progress = 0f,
                    error = "GIF media was removed from FolkChat"
                ))
                changed = true
            }
        }
        // Also clean orphaned .gif files left by earlier versions, restricted to direct children
        // of FolkChat's own files/media directory.
        try {
            mediaRoot.listFiles()?.filter { it.isFile }?.forEach { file ->
                try {
                    if (file.canonicalFile.parentFile != mediaRoot) return@forEach
                    val extensionMatch = file.name.endsWith(".gif", ignoreCase = true)
                    val signatureMatch = if (!extensionMatch && file.length() >= 6L) {
                        file.inputStream().use { input ->
                            val header = ByteArray(6)
                            val read = input.read(header)
                            val matched = read == 6 && (String(header, Charsets.US_ASCII) == "GIF87a" || String(header, Charsets.US_ASCII) == "GIF89a")
                            header.fill(0)
                            matched
                        }
                    } else false
                    if ((extensionMatch || signatureMatch) && file.delete()) deleted++
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
        if (changed) saveVault()
        return deleted
    }

    /** Deletes only app-managed media files directly beneath files/media. */
    fun deleteManagedMedia(path: String?) {
        if (path.isNullOrBlank()) return
        try {
            val mediaRoot = File(dataRoot(), "media").canonicalFile
            val target = File(path).canonicalFile
            if (target.parentFile == mediaRoot && target.isFile) target.delete()
        } catch (e: Exception) {
            Log.w(TAG, "Could not delete managed media file: ${e.message}")
        }
    }

    // ---------------------------------------------------------------------
    // Avatars (profile image flow)
    // ---------------------------------------------------------------------
    fun saveAvatarImage(bytes: ByteArray): String {
        val dir = File(dataRoot(), "avatars")
        if (!dir.exists()) dir.mkdirs()
        val f = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
        f.writeBytes(bytes)
        myAvatarPath = f.absolutePath
        saveVault()
        return f.absolutePath
    }

    fun getMyAvatarPath(): String? = myAvatarPath

    /** Removes the local profile avatar; never deletes files outside FolkChat's avatar directory. */
    fun clearMyAvatar() {
        val oldPath = myAvatarPath
        myAvatarPath = null
        if (!oldPath.isNullOrBlank()) {
            try {
                val target = File(oldPath).canonicalFile
                val avatarRoot = File(dataRoot(), "avatars").canonicalFile
                if (target.parentFile == avatarRoot && target.isFile && target.name.startsWith("avatar_")) target.delete()
            } catch (_: Exception) { }
        }
        saveVault()
    }

    fun setContactAvatar(pubKeyHex: String, path: String?) {
        val key = pubKeyHex.lowercase().trim()
        var oldPath: String? = null
        synchronized(contactsMap) {
            contactsMap[key]?.let {
                oldPath = it.avatarPath
                contactsMap[key] = it.copy(avatarPath = path)
            }
        }
        if (oldPath != null && oldPath != path) {
            try {
                val old = File(oldPath!!).canonicalFile
                val avatarRoot = File(dataRoot(), "avatars").canonicalFile
                if (old.parentFile == avatarRoot && old.isFile && old.name.startsWith("peer_")) old.delete()
            } catch (_: Exception) { }
        }
        saveVault()
    }

    fun copyAvatarForContact(pubKeyHex: String, sourcePath: String): String? {
        return try {
            val src = File(sourcePath)
            if (!src.exists()) return null
            val dir = File(dataRoot(), "avatars")
            if (!dir.exists()) dir.mkdirs()
            val dst = File(dir, "peer_${pubKeyHex.take(12)}_${System.currentTimeMillis()}.jpg")
            src.copyTo(dst, overwrite = true)
            setContactAvatar(pubKeyHex, dst.absolutePath)
            dst.absolutePath
        } catch (e: Exception) {
            Log.w(TAG, "Failed to copy avatar: ${e.message}")
            null
        }
    }

    // ---------------------------------------------------------------------
    // Routing policy persistence
    // ---------------------------------------------------------------------
    fun getRoutingPolicyName(): String = routingPolicyName

    fun setRoutingPolicyName(name: String) {
        routingPolicyName = name
        saveVault()
    }

    // ---------------------------------------------------------------------
    // Messages
    // ---------------------------------------------------------------------
    fun getMessagesForConversation(peerPubKeyHex: String): List<ChatMessage> {
        return synchronized(messagesList) {
            messagesList.filter { it.conversationPeerPubKeyHex.equals(peerPubKeyHex, ignoreCase = true) }
        }
    }

    fun getAllMessages(): List<ChatMessage> = synchronized(messagesList) { messagesList.toList() }

    fun getMessageById(messageId: String): ChatMessage? = synchronized(messagesList) {
        messagesList.firstOrNull { it.id == messageId }
    }

    fun saveMessage(message: ChatMessage) {
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == message.id }
            if (idx >= 0) messagesList[idx] = message else messagesList.add(message)
        }
        synchronized(outboxList) {
            outboxList.removeAll { it.id == message.id }
            if (message.isOutgoing && message.groupId == null && message.attachment == null && (message.status == MessageStatus.QUEUED || message.status == MessageStatus.SENDING)) {
                outboxList.add(message)
            }
        }
        saveVault()
    }

    /** Applies an arbitrary mutation to a stored message and persists it. */
    fun updateMessage(messageId: String, transform: (ChatMessage) -> ChatMessage): ChatMessage? {
        var updated: ChatMessage? = null
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == messageId }
            if (idx >= 0) {
                updated = transform(messagesList[idx])
                messagesList[idx] = updated!!
            }
        }
        val result = updated
        if (result != null) {
            // Keep the outbox copy in sync with any mutation. Previously an edit to a still-
            // QUEUED message updated only the UI copy: the outbox kept sending the stale
            // pre-edit text while the sender's screen showed the new one.
            synchronized(outboxList) {
                val oi = outboxList.indexOfFirst { it.id == messageId }
                if (oi >= 0) {
                    val eligible = result.isOutgoing && result.groupId == null && result.attachment == null &&
                        (result.status == MessageStatus.QUEUED || result.status == MessageStatus.SENDING)
                    if (eligible) outboxList[oi] = result else outboxList.removeAt(oi)
                }
            }
        }
        saveVault()
        return result
    }

    fun updateMessageStatus(messageId: String, newStatus: MessageStatus) {
        var updated: ChatMessage? = null
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == messageId }
            if (idx >= 0) {
                val current = messagesList[idx]
                messagesList[idx] = current.copy(status = newStatus)
                updated = messagesList[idx]
            }
        }
        // Lock order is messagesList -> outboxList everywhere (matching saveMessage);
        // the previous nested acquisition here was the inverse order, an AB-BA deadlock
        // that could permanently freeze every vault write under load.
        val snapshot = updated
        synchronized(outboxList) {
            if (newStatus == MessageStatus.DELIVERED || newStatus == MessageStatus.FAILED) {
                outboxList.removeAll { it.id == messageId }
            } else if (snapshot != null && snapshot.isOutgoing && snapshot.attachment == null) {
                outboxList.removeAll { it.id == messageId }
                outboxList.add(snapshot)
            }
        }
        saveVault()
    }

    fun updateMessageStatusAndRoute(messageId: String, newStatus: MessageStatus, routeUsed: String) {
        var updated: ChatMessage? = null
        synchronized(messagesList) {
            val idx = messagesList.indexOfFirst { it.id == messageId }
            if (idx >= 0) {
                val current = messagesList[idx]
                // Record the attempt time for both dispatch outcomes. Without the QUEUED case,
                // a permanently unreachable peer caused the 2-second outbox worker to re-seal
                // and re-dispatch the same message forever, burning battery and relay rate limits.
                val attemptedAt = if (newStatus == MessageStatus.SENDING || newStatus == MessageStatus.QUEUED)
                    System.currentTimeMillis() else current.lastAttemptAtMs
                messagesList[idx] = current.copy(status = newStatus, routeUsed = routeUsed, lastAttemptAtMs = attemptedAt)
                updated = messagesList[idx]
            }
        }
        val snapshot = updated
        synchronized(outboxList) {
            outboxList.removeAll { it.id == messageId }
            if (snapshot != null && snapshot.isOutgoing && snapshot.attachment == null &&
                (newStatus == MessageStatus.QUEUED || newStatus == MessageStatus.SENDING)) {
                outboxList.add(snapshot)
            }
        }
        saveVault()
    }

    fun deleteMessage(messageId: String) {
        getMessageById(messageId)?.attachment?.localPath?.let(::deleteManagedMedia)
        synchronized(messagesList) {
            messagesList.removeAll { it.id == messageId }
        }
        synchronized(outboxList) {
            outboxList.removeAll { it.id == messageId }
        }
        saveVault()
    }

    fun clearAllMessagesForContact(peerPubKeyHex: String) {
        val removed = synchronized(messagesList) {
            val selected = messagesList.filter { it.conversationPeerPubKeyHex.equals(peerPubKeyHex, ignoreCase = true) }
            messagesList.removeAll(selected.toSet())
            selected
        }
        removed.forEach { deleteManagedMedia(it.attachment?.localPath) }
        synchronized(outboxList) {
            outboxList.removeAll { it.conversationPeerPubKeyHex.equals(peerPubKeyHex, ignoreCase = true) }
        }
        saveVault()
    }

    fun getQueuedOutbox(): List<ChatMessage> {
        val now = System.currentTimeMillis()
        return synchronized(outboxList) {
            outboxList.filter { msg ->
                // An ONLINE_RELAY send is retried only after the relay itself reports
                // failure. A positive relay acknowledgement means the encrypted packet
                // is durably queued until the recipient processes it; resending every
                // 15 seconds previously filled the mailbox with duplicate envelopes.
                //
                // A QUEUED (never-delivered) message is also throttled to one attempt per
                // 8 seconds; without this the worker re-sealed and re-broadcast the same
                // ciphertext over all transports every 2 seconds while the peer was simply
                // offline, wasting battery and public-relay rate limits.
                (msg.status == MessageStatus.QUEUED &&
                    (msg.lastAttemptAtMs == 0L || now - msg.lastAttemptAtMs >= 8_000L)) ||
                    (msg.status == MessageStatus.SENDING && msg.routeUsed != "ONLINE_RELAY" &&
                        now - msg.lastAttemptAtMs >= 15_000L)
            }
        }
    }

    /**
     * The vault data key is random per installation and is stored only as an AES-GCM
     * wrapped blob. The wrapping key never leaves Android Keystore. There is deliberately
     * no hard-coded fallback: if Keystore material is unavailable, persistence fails closed.
     */
    private fun getOrCreateMasterKey(): ByteArray {
        val wrappingKey = getOrCreateWrappingKey()
        val wrappedFile = File(context.filesDir, WRAPPED_KEY_FILENAME)
        if (wrappedFile.exists()) {
            val wrapped = wrappedFile.readBytes()
            require(wrapped.size >= 12 + 16) { "Wrapped vault key is truncated" }
            val nonce = wrapped.copyOfRange(0, 12)
            val cipherText = wrapped.copyOfRange(12, wrapped.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, wrappingKey, GCMParameterSpec(GCM_TAG_BITS, nonce))
            return cipher.doFinal(cipherText).also {
                require(it.size == 32) { "Invalid vault data key size" }
            }
        }

        // Do not silently replace a missing key when an existing vault is present.
        val vaultFile = File(context.filesDir, VAULT_FILENAME)
        check(!vaultFile.exists()) { "Vault key is missing; refusing to replace existing vault" }
        val randomKey = ByteArray(32).apply { SecureRandom().nextBytes(this) }
        writeWrappedMasterKey(randomKey, wrappingKey)
        return randomKey
    }

    private fun getOrCreateWrappingKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
        keyStore.load(null)
        val existing = keyStore.getKey(KEYSTORE_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun writeWrappedMasterKey(dataKey: ByteArray, wrappingKey: SecretKey = getOrCreateWrappingKey()) {
        val nonce = ByteArray(12).apply { SecureRandom().nextBytes(this) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, wrappingKey, GCMParameterSpec(GCM_TAG_BITS, nonce))
        val encrypted = cipher.doFinal(dataKey)
        val bytes = nonce + encrypted
        writeAtomically(File(context.filesDir, WRAPPED_KEY_FILENAME), bytes)
    }

    /** Key derivation used only to migrate already-installed legacy vaults. */
    private fun legacyMasterKey(): ByteArray = CryptoEngine.hkdfSha256(
        LEGACY_KEY_ALIAS.toByteArray(),
        salt = "SC_VAULT_SALT".toByteArray(),
        length = 32
    )

    /** A crash-safe same-directory replacement; the previous vault survives failed writes. */
    private fun writeAtomically(target: File, bytes: ByteArray) {
        val temp = File(target.parentFile, target.name + ".tmp")
        FileOutputStream(temp).use { out ->
            out.write(bytes)
            out.fd.sync()
        }
        if (!temp.renameTo(target)) {
            temp.delete()
            throw java.io.IOException("Atomic replacement failed for ${target.name}")
        }
    }

    @Synchronized
    private fun saveVault(): Boolean {
        // Never overwrite a vault that could not be read. A failed load is not a new install.
        if (vaultLoadFailed) {
            Log.e(TAG, "Vault is unreadable; preserving original file and refusing to save")
            return false
        }
        // New installations stay in RAM/cache until the user explicitly opts into device saving.
        if (!deviceStorageEnabled) return true
        return try {
            val root = JSONObject()
            cachedIdentity?.let {
                root.put("x25519_priv", it.privateKeyHex)
                root.put("x25519_pub", it.publicKeyHex)
            }
            root.put("display_name", myDisplayName)
            root.put("theme_mode", appThemeMode)
            root.put("onboarding_completed", onboardingCompleted)
            root.put("routing_policy", routingPolicyName)
            root.put("verification_schema", 1)
            myAvatarPath?.let { root.put("my_avatar_path", it) }
            root.put("settings", settingsToJson(settings))

            val blockedObj = JSONObject()
            synchronized(blockedPeers) {
                for ((k, v) in blockedPeers) blockedObj.put(k, v)
            }
            root.put("blocked_peers", blockedObj)

            val cursorsObj = JSONObject()
            synchronized(readCursors) {
                for ((k, v) in readCursors) cursorsObj.put(k, v)
            }
            root.put("read_cursors", cursorsObj)

            val contactsArray = JSONArray()
            synchronized(contactsMap) {
                for (c in contactsMap.values) {
                    val obj = JSONObject()
                    obj.put("id", c.id)
                    obj.put("name", c.displayName)
                    obj.put("pubKey", c.x25519PublicKeyHex)
                    obj.put("verified", c.isVerified)
                    obj.put("lastSeen", c.lastSeenEpochMs)
                    obj.put("statusText", c.statusText)
                    c.avatarPath?.let { obj.put("avatarPath", it) }
                    obj.put("archived", c.isArchived)
                    obj.put("muted", c.isMuted)
                    obj.put("disappearAfterSec", c.disappearAfterSec)
                    obj.put("peerLastReadMs", c.peerLastReadMs)
                    obj.put("disappearAfterSetAtMs", c.disappearAfterSetAtMs)
                    obj.put("disappearTimerUpdatedAtMs", c.disappearTimerUpdatedAtMs)
                    obj.put("profileUpdatedAtMs", c.profileUpdatedAtMs)
                    contactsArray.put(obj)
                }
            }
            root.put("contacts", contactsArray)

            val groupsArray = JSONArray()
            synchronized(groupsMap) {
                for (g in groupsMap.values) {
                    groupsArray.put(JSONObject().apply {
                        put("id", g.id)
                        put("name", g.name)
                        put("members", JSONArray(g.memberPubKeyHexes))
                        put("createdBy", g.createdByPubKeyHex)
                        put("createdAtMs", g.createdAtMs)
                        put("updatedAtMs", g.updatedAtMs)
                    })
                }
            }
            root.put("groups", groupsArray)

            val messagesArray = JSONArray()
            synchronized(messagesList) {
                for (m in messagesList) {
                    messagesArray.put(messageToJson(m))
                }
            }
            root.put("messages", messagesArray)

            val requestsArray = JSONArray()
            synchronized(messageRequestsMap) {
                for (r in messageRequestsMap.values) {
                    val obj = JSONObject()
                    obj.put("senderPubKey", r.senderPubKeyHex)
                    obj.put("senderName", r.senderDisplayName)
                    obj.put("latestMsg", r.latestMessageText)
                    obj.put("timestamp", r.timestampMs)
                    obj.put("count", r.messageCount)
                    requestsArray.put(obj)
                }
            }
            root.put("message_requests", requestsArray)

            val pairingVerifiedArray = JSONArray()
            synchronized(pairingVerifiedPeers) {
                for ((key, value) in pairingVerifiedPeers) {
                    if (System.currentTimeMillis() - value.second < 24L * 60 * 60 * 1000L) {
                        pairingVerifiedArray.put(JSONObject().apply {
                            put("pubKey", key)
                            put("name", value.first)
                            put("verifiedAt", value.second)
                        })
                    }
                }
            }
            root.put("pairing_verified", pairingVerifiedArray)

            val callsArray = JSONArray()
            synchronized(callLogs) {
                for (c in callLogs) {
                    val obj = JSONObject()
                    obj.put("id", c.id)
                    obj.put("peerKey", c.peerPubKeyHex)
                    obj.put("peerName", c.peerName)
                    obj.put("type", c.type.name)
                    obj.put("outcome", c.outcome.name)
                    obj.put("timestamp", c.timestampMs)
                    obj.put("duration", c.durationSeconds)
                    obj.put("isOutgoing", c.isOutgoing)
                    callsArray.put(obj)
                }
            }
            root.put("call_logs", callsArray)

            val jsonBytes = root.toString().toByteArray(Charsets.UTF_8)
            val nonce = ByteArray(12).apply { SecureRandom().nextBytes(this) }
            val encrypted = CryptoEngine.encryptChaCha20Poly1305(masterKey, nonce, jsonBytes)

            val file = File(context.filesDir, VAULT_FILENAME)
            writeAtomically(file, nonce + encrypted)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save encrypted vault: ${e.message}")
            false
        }
    }

    private fun messageToJson(m: ChatMessage): JSONObject {
        val obj = JSONObject()
        obj.put("id", m.id)
        obj.put("convPeer", m.conversationPeerPubKeyHex)
        obj.put("sender", m.senderPubKeyHex)
        obj.put("recipient", m.recipientPubKeyHex)
        obj.put("content", m.content)
        obj.put("timestamp", m.timestampMs)
        obj.put("status", m.status.name)
        obj.put("isOutgoing", m.isOutgoing)
        obj.put("routeUsed", m.routeUsed)
        m.replyToId?.let { obj.put("replyToId", it) }
        m.replyToPreview?.let { obj.put("replyToPreview", it) }
        m.replyToSender?.let { obj.put("replyToSender", it) }
        if (m.reactions.isNotEmpty()) {
            val reactionsObj = JSONObject()
            for ((emoji, senders) in m.reactions) {
                reactionsObj.put(emoji, JSONArray(senders))
            }
            obj.put("reactions", reactionsObj)
        }
        obj.put("isEdited", m.isEdited)
        obj.put("editedAtMs", m.editedAtMs)
        obj.put("deletedAtMs", m.deletedAtMs)
        obj.put("isPinned", m.isPinned)
        obj.put("pinUpdatedAtMs", m.pinUpdatedAtMs)
        obj.put("reactionUpdatedAtMs", m.reactionUpdatedAtMs)
        obj.put("isStarred", m.isStarred)
        obj.put("lastAttemptAtMs", m.lastAttemptAtMs)
        m.systemEvent?.let { obj.put("systemEvent", it) }
        m.groupId?.let { obj.put("groupId", it) }
        m.senderDisplayName?.let { obj.put("senderDisplayName", it.take(80)) }
        if (m.deliveryPeerPubKeyHexes.isNotEmpty()) obj.put("deliveryPeers", JSONArray(m.deliveryPeerPubKeyHexes.sorted()))
        m.attachment?.let { obj.put("attachment", attachmentToJson(it)) }
        return obj
    }

    private fun attachmentToJson(a: MediaAttachment): JSONObject {
        val obj = JSONObject()
        obj.put("id", a.id)
        obj.put("kind", a.kind.name)
        obj.put("fileName", a.fileName)
        obj.put("mimeType", a.mimeType)
        obj.put("sizeBytes", a.sizeBytes)
        obj.put("durationMs", a.durationMs)
        obj.put("width", a.width)
        obj.put("height", a.height)
        a.sha256Hex?.let { obj.put("sha256Hex", it) }
        a.localPath?.let { obj.put("localPath", it) }
        obj.put("transferState", a.transferState.name)
        obj.put("progress", a.progress.toDouble())
        obj.put("viewLimit", a.viewLimit)
        obj.put("viewsUsed", a.viewsUsed)
        a.error?.let { obj.put("error", it) }
        return obj
    }

    private fun attachmentFromJson(obj: JSONObject): MediaAttachment {
        return MediaAttachment(
            id = obj.getString("id"),
            kind = try { MediaKind.valueOf(obj.getString("kind")) } catch (e: Exception) { MediaKind.DOCUMENT },
            fileName = obj.optString("fileName", "file"),
            mimeType = obj.optString("mimeType", "application/octet-stream"),
            sizeBytes = obj.optLong("sizeBytes", 0L),
            durationMs = obj.optLong("durationMs", 0L),
            width = obj.optInt("width", 0),
            height = obj.optInt("height", 0),
            sha256Hex = if (obj.has("sha256Hex")) obj.optString("sha256Hex").takeIf { it.matches(Regex("^[0-9a-fA-F]{64}$")) } else null,
            localPath = if (obj.has("localPath")) obj.getString("localPath") else null,
            transferState = try { TransferState.valueOf(obj.optString("transferState", "PENDING")) } catch (e: Exception) { TransferState.PENDING },
            progress = obj.optDouble("progress", 0.0).toFloat(),
            viewLimit = obj.optInt("viewLimit", 0),
            viewsUsed = obj.optInt("viewsUsed", 0),
            error = if (obj.has("error")) obj.optString("error") else null
        )
    }

    private fun settingsToJson(s: AppSettings): JSONObject {
        return JSONObject().apply {
            put("appLockEnabled", s.appLockEnabled)
            put("biometricEnabled", s.biometricEnabled)
            put("pinHash", s.pinHash)
            put("pinSalt", s.pinSalt)
            put("pinFailedAttempts", s.pinFailedAttempts)
            put("pinLockoutUntilMs", s.pinLockoutUntilMs)
            put("autoLockMillis", s.autoLockMillis)
            put("lockedChatKeys", JSONArray().apply { s.lockedChatKeys.map { it.lowercase() }.distinct().sorted().forEach { put(it) } })
            put("notificationPreviewMode", s.notificationPreviewMode.name)
            put("mediaAutoDownload", s.mediaAutoDownload.name)
            put("readReceipts", s.readReceipts)
            put("typingIndicators", s.typingIndicators)
            put("screenshotProtection", s.screenshotProtection)
            put("compactChat", s.compactChat)
            put("outgoingBubbleEmphasis", s.outgoingBubbleEmphasis)
            put("notificationSound", s.notificationSound)
            put("notificationVibrate", s.notificationVibrate)
            put("torRoutingEnabled", s.torRoutingEnabled)
            put("relayUrl", s.relayUrl)
            put("shareProfilePhoto", s.shareProfilePhoto)
            put("reduceMotion", s.reduceMotion)
            put("callDataSaver", s.callDataSaver)
            put("callRelayOnly", s.callRelayOnly)
            put("callIceServers", s.callIceServers)
            put("callTurnUsername", s.callTurnUsername)
            put("callTurnCredential", s.callTurnCredential)
            put("autoDownloadVoice", s.autoDownloadVoice)
            put("autoDownloadVideo", s.autoDownloadVideo)
            put("clearTemporaryFilesOnExit", s.clearTemporaryFilesOnExit)
            put("accentPalette", s.accentPalette.take(32))
            put("chatFontScale", s.chatFontScale.coerceIn(0.8f, 1.4f))
            put("bubbleStyle", s.bubbleStyle.take(32))
            put("chatWallpaper", s.chatWallpaper.take(32))
            put("appFont", s.appFont.take(32))
            put("appEmblem", s.appEmblem.take(32))
            put("appIconVariant", s.appIconVariant.take(32))
            put("hapticFeedback", s.hapticFeedback)
        }
    }

    private fun settingsFromJson(obj: JSONObject): AppSettings {
        return AppSettings(
            appLockEnabled = obj.optBoolean("appLockEnabled", false),
            biometricEnabled = obj.optBoolean("biometricEnabled", true),
            pinHash = obj.optString("pinHash", ""),
            pinSalt = obj.optString("pinSalt", ""),
            pinFailedAttempts = obj.optInt("pinFailedAttempts", 0).coerceIn(0, 30),
            pinLockoutUntilMs = obj.optLong("pinLockoutUntilMs", 0L).coerceAtLeast(0L),
            autoLockMillis = obj.optLong("autoLockMillis", 60_000L),
            lockedChatKeys = obj.optJSONArray("lockedChatKeys")?.let { arr ->
                buildSet {
                    for (i in 0 until arr.length()) {
                        val key = arr.optString(i).trim().lowercase()
                        if (key.matches(Regex("[0-9a-f]{64,128}"))) add(key)
                    }
                }
            } ?: emptySet(),
            notificationPreviewMode = try { NotificationPreviewMode.valueOf(obj.optString("notificationPreviewMode", "HIDDEN")) } catch (e: Exception) { NotificationPreviewMode.HIDDEN },
            mediaAutoDownload = try { MediaAutoDownload.valueOf(obj.optString("mediaAutoDownload", "WIFI_OR_LAN")) } catch (e: Exception) { MediaAutoDownload.WIFI_OR_LAN },
            readReceipts = obj.optBoolean("readReceipts", true),
            typingIndicators = obj.optBoolean("typingIndicators", true),
            screenshotProtection = obj.optBoolean("screenshotProtection", true),
            compactChat = obj.optBoolean("compactChat", false),
            outgoingBubbleEmphasis = obj.optBoolean("outgoingBubbleEmphasis", true),
            notificationSound = obj.optBoolean("notificationSound", true),
            notificationVibrate = obj.optBoolean("notificationVibrate", true),
            torRoutingEnabled = obj.optBoolean("torRoutingEnabled", false),
            relayUrl = obj.optString("relayUrl", ""),
            shareProfilePhoto = obj.optBoolean("shareProfilePhoto", false),
            reduceMotion = obj.optBoolean("reduceMotion", false),
            callDataSaver = obj.optBoolean("callDataSaver", false),
            callRelayOnly = obj.optBoolean("callRelayOnly", false),
            callIceServers = obj.optString("callIceServers", "").take(2048),
            callTurnUsername = obj.optString("callTurnUsername", "").take(256),
            callTurnCredential = obj.optString("callTurnCredential", "").take(512),
            autoDownloadVoice = obj.optBoolean("autoDownloadVoice", false),
            autoDownloadVideo = obj.optBoolean("autoDownloadVideo", false),
            clearTemporaryFilesOnExit = obj.optBoolean("clearTemporaryFilesOnExit", true),
            accentPalette = obj.optString("accentPalette", "FOREST")
                .trim().uppercase().take(32).ifBlank { "FOREST" },
            chatFontScale = runCatching { obj.optDouble("chatFontScale", 1.0).toFloat() }
                .getOrDefault(1.0f).coerceIn(0.8f, 1.4f),
            bubbleStyle = obj.optString("bubbleStyle", "CLASSIC")
                .trim().uppercase().take(32).ifBlank { "CLASSIC" },
            chatWallpaper = obj.optString("chatWallpaper", "NONE")
                .trim().uppercase().take(32).ifBlank { "NONE" },
            appFont = obj.optString("appFont", "SYSTEM")
                .trim().uppercase().take(32).ifBlank { "SYSTEM" },
            appEmblem = obj.optString("appEmblem", "FOLK")
                .trim().uppercase().take(32).ifBlank { "FOLK" },
            appIconVariant = obj.optString("appIconVariant", "FOREST")
                .trim().uppercase().take(32).ifBlank { "FOREST" },
            hapticFeedback = obj.optBoolean("hapticFeedback", true)
        )
    }

    @Synchronized
    private fun loadVault() {
        val file = File(context.filesDir, VAULT_FILENAME)
        if (!file.exists()) return

        try {
            val bytes = file.readBytes()
            require(bytes.size >= 12 + 16) { "Vault file is truncated" }
            val nonce = bytes.copyOfRange(0, 12)
            val ciphertext = bytes.copyOfRange(12, bytes.size)
            val wrappedKeyFile = File(context.filesDir, WRAPPED_KEY_FILENAME)
            val decrypted = if (wrappedKeyFile.exists()) {
                try {
                    CryptoEngine.decryptChaCha20Poly1305(masterKey, nonce, ciphertext)
                } catch (newFormatError: Exception) {
                    // Recover an interrupted legacy migration: the wrapped key may have
                    // been atomically replaced just before the encrypted vault was replaced.
                    // Legacy material is accepted only if authenticated decryption and full
                    // JSON parsing succeed; the file is then re-encrypted with a new random key.
                    try {
                        CryptoEngine.decryptChaCha20Poly1305(legacyMasterKey(), nonce, ciphertext).also {
                            migratingLegacyVault = true
                        }
                    } catch (_: Exception) {
                        throw newFormatError
                    }
                }
            } else {
                // Upgrade old installations only after successfully decrypting and parsing
                // the legacy file. No fallback is used for new vaults.
                migratingLegacyVault = true
                CryptoEngine.decryptChaCha20Poly1305(legacyMasterKey(), nonce, ciphertext)
            }
            val root = JSONObject(String(decrypted, Charsets.UTF_8))
            val verificationSchema = root.optInt("verification_schema", 0)

            if (root.has("x25519_priv") && root.has("x25519_pub")) {
                val priv = CryptoEngine.hexToBytes(root.getString("x25519_priv"))
                val pub = CryptoEngine.hexToBytes(root.getString("x25519_pub"))
                cachedIdentity = KeyPairBytes(priv, pub)
            }
            if (root.has("display_name")) {
                myDisplayName = root.getString("display_name")
            }
            if (root.has("theme_mode")) {
                appThemeMode = root.getString("theme_mode")
            }
            if (root.has("routing_policy")) {
                routingPolicyName = root.optString("routing_policy", "AUTO_FALLBACK")
            }
            if (root.has("my_avatar_path")) {
                myAvatarPath = root.getString("my_avatar_path")
            }
            if (root.has("onboarding_completed")) {
                onboardingCompleted = root.getBoolean("onboarding_completed")
            }
            if (root.has("settings")) {
                settings = settingsFromJson(root.getJSONObject("settings"))
            }

            if (root.has("blocked_peers")) {
                val bObj = root.getJSONObject("blocked_peers")
                for (k in bObj.keys()) {
                    blockedPeers[k.lowercase()] = bObj.optString(k, "Peer")
                }
            }

            if (root.has("read_cursors")) {
                val cObj = root.getJSONObject("read_cursors")
                for (k in cObj.keys()) {
                    readCursors[k.lowercase()] = cObj.optLong(k, 0L)
                }
            }

            if (root.has("contacts")) {
                val arr = root.getJSONArray("contacts")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val contactId = obj.getString("id")
                    val c = Contact(
                        id = contactId,
                        displayName = obj.getString("name"),
                        x25519PublicKeyHex = obj.getString("pubKey"),
                        // Old releases marked every added contact verified without fingerprint comparison.
                        isVerified = contactId == "self_notes" || (verificationSchema >= 1 && obj.optBoolean("verified", false)),
                        lastSeenEpochMs = obj.optLong("lastSeen", 0L),
                        statusText = obj.optString("statusText", ""),
                        avatarPath = if (obj.has("avatarPath")) obj.getString("avatarPath") else null,
                        isArchived = obj.optBoolean("archived", false),
                        isMuted = obj.optBoolean("muted", false),
                        disappearAfterSec = obj.optInt("disappearAfterSec", 0),
                        peerLastReadMs = obj.optLong("peerLastReadMs", 0L),
                        disappearAfterSetAtMs = obj.optLong("disappearAfterSetAtMs", 0L),
                        disappearTimerUpdatedAtMs = obj.optLong("disappearTimerUpdatedAtMs", 0L),
                        profileUpdatedAtMs = if (verificationSchema >= 1) obj.optLong("profileUpdatedAtMs", 0L) else 0L
                    )
                    contactsMap[c.x25519PublicKeyHex] = c
                }
            }

            if (root.has("groups")) {
                val arr = root.getJSONArray("groups")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val membersArray = obj.optJSONArray("members") ?: JSONArray()
                    val members = (0 until membersArray.length()).map { membersArray.optString(it).lowercase() }
                    val group = GroupConversation(
                        id = obj.optString("id").lowercase(),
                        name = obj.optString("name", "Group"),
                        memberPubKeyHexes = members,
                        createdByPubKeyHex = obj.optString("createdBy").lowercase(),
                        createdAtMs = obj.optLong("createdAtMs", System.currentTimeMillis()),
                        updatedAtMs = obj.optLong("updatedAtMs", obj.optLong("createdAtMs", System.currentTimeMillis()))
                    )
                    val key = group.id
                    if (key.matches(Regex("^[0-9a-f]{64}$")) && group.memberPubKeyHexes.size in 2..64 &&
                        group.createdByPubKeyHex in group.memberPubKeyHexes && group.memberPubKeyHexes.all { it.matches(Regex("^[0-9a-f]{64}$")) }) {
                        groupsMap[key] = group
                    }
                }
            }

            if (root.has("messages")) {
                val arr = root.getJSONArray("messages")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val status = try {
                        MessageStatus.valueOf(obj.getString("status"))
                    } catch (e: Exception) {
                        MessageStatus.DELIVERED
                    }
                    val routeUsed = if (obj.has("routeUsed")) obj.getString("routeUsed") else "AUTO"

                    val reactions = mutableMapOf<String, List<String>>()
                    if (obj.has("reactions")) {
                        val rObj = obj.getJSONObject("reactions")
                        for (emoji in rObj.keys()) {
                            val sendersArr = rObj.getJSONArray(emoji)
                            val senders = mutableListOf<String>()
                            for (j in 0 until sendersArr.length()) senders.add(sendersArr.getString(j))
                            reactions[emoji] = senders
                        }
                    }

                    val attachment = if (obj.has("attachment")) attachmentFromJson(obj.getJSONObject("attachment")) else null

                    val m = ChatMessage(
                        id = obj.getString("id"),
                        conversationPeerPubKeyHex = obj.getString("convPeer"),
                        senderPubKeyHex = obj.getString("sender"),
                        recipientPubKeyHex = obj.getString("recipient"),
                        content = obj.getString("content"),
                        timestampMs = obj.getLong("timestamp"),
                        status = status,
                        isOutgoing = obj.getBoolean("isOutgoing"),
                        routeUsed = routeUsed,
                        replyToId = if (obj.has("replyToId")) obj.getString("replyToId") else null,
                        replyToPreview = if (obj.has("replyToPreview")) obj.getString("replyToPreview") else null,
                        replyToSender = if (obj.has("replyToSender")) obj.getString("replyToSender") else null,
                        reactions = reactions,
                        isEdited = obj.optBoolean("isEdited", false),
                        editedAtMs = obj.optLong("editedAtMs", 0L),
                        deletedAtMs = obj.optLong("deletedAtMs", 0L),
                        isPinned = obj.optBoolean("isPinned", false),
                        pinUpdatedAtMs = obj.optLong("pinUpdatedAtMs", 0L),
                        reactionUpdatedAtMs = obj.optLong("reactionUpdatedAtMs", 0L),
                        isStarred = obj.optBoolean("isStarred", false),
                        lastAttemptAtMs = obj.optLong("lastAttemptAtMs", 0L),
                        systemEvent = if (obj.has("systemEvent")) obj.getString("systemEvent") else null,
                        groupId = if (obj.has("groupId")) obj.optString("groupId").takeIf { it.matches(Regex("^[0-9a-fA-F]{64}$")) }?.lowercase() else null,
                        deliveryPeerPubKeyHexes = obj.optJSONArray("deliveryPeers")?.let { deliveryArr ->
                            buildSet {
                                for (j in 0 until deliveryArr.length()) {
                                    val key = deliveryArr.optString(j).lowercase()
                                    if (key.matches(Regex("^[0-9a-f]{64}$"))) add(key)
                                }
                            }
                        } ?: emptySet(),
                        attachment = attachment,
                        senderDisplayName = obj.optString("senderDisplayName").takeIf { it.isNotBlank() }?.take(80)
                    )
                    messagesList.add(m)
                    if (m.isOutgoing && m.groupId == null && m.attachment == null &&
                        (status == MessageStatus.QUEUED || status == MessageStatus.SENDING)) {
                        outboxList.add(m)
                    }
                }
            }

            if (root.has("message_requests")) {
                val arr = root.getJSONArray("message_requests")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val r = MessageRequest(
                        senderPubKeyHex = obj.getString("senderPubKey"),
                        senderDisplayName = obj.optString("senderName", "Unknown Peer"),
                        latestMessageText = obj.optString("latestMsg", ""),
                        timestampMs = obj.optLong("timestamp", System.currentTimeMillis()),
                        messageCount = obj.optInt("count", 1)
                    )
                    messageRequestsMap[r.senderPubKeyHex.lowercase()] = r
                }
            }

            if (root.has("pairing_verified")) {
                val arr = root.getJSONArray("pairing_verified")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val key = obj.optString("pubKey").lowercase().trim()
                    val verifiedAt = obj.optLong("verifiedAt", 0L)
                    if (key.matches(Regex("^[0-9a-f]{64}$")) &&
                        System.currentTimeMillis() - verifiedAt < 24L * 60 * 60 * 1000L) {
                        pairingVerifiedPeers[key] = Pair(obj.optString("name", "Peer ${key.take(6)}").take(80), verifiedAt)
                    }
                }
            }

            if (root.has("call_logs")) {
                val arr = root.getJSONArray("call_logs")
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val c = CallLogEntry(
                        id = obj.getString("id"),
                        peerPubKeyHex = obj.getString("peerKey"),
                        peerName = obj.optString("peerName", "Unknown"),
                        type = try { CallType.valueOf(obj.getString("type")) } catch (e: Exception) { CallType.VOICE },
                        outcome = try { CallOutcome.valueOf(obj.getString("outcome")) } catch (e: Exception) { CallOutcome.FAILED },
                        timestampMs = obj.getLong("timestamp"),
                        durationSeconds = obj.optLong("duration", 0L),
                        isOutgoing = obj.optBoolean("isOutgoing", true)
                    )
                    callLogs.add(c)
                }
            }

            if (migratingLegacyVault) {
                // Only now, after the entire legacy JSON was parsed, rotate to a fresh
                // random data key and wrap it with this device's Android Keystore key.
                cachedMasterKey = ByteArray(32).apply { SecureRandom().nextBytes(this) }
                writeWrappedMasterKey(cachedMasterKey!!)
                migratingLegacyVault = false
                saveVault()
            }
        } catch (e: Exception) {
            vaultLoadFailed = true
            migratingLegacyVault = false
            Log.e(TAG, "Failed to load encrypted vault; original data will be preserved: ${e.message}")
        }
    }
}
