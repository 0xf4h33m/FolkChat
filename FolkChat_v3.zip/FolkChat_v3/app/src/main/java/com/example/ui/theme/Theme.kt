package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp


/** Shared shape language: soft, composed surfaces without changing the brand palette. */
private val FolkShapes = Shapes(
    extraSmall = RoundedCornerShape(9.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(17.dp),
    large = RoundedCornerShape(23.dp),
    extraLarge = RoundedCornerShape(29.dp)
)

enum class AppThemeMode {
    CLASSIC_LIGHT,
    /** Cool, low-glare blue-gray surfaces. */
    MIST_LIGHT,
    /** Warm paper-like cream surfaces. */
    PAPER_LIGHT,
    /** Soft rose-tinted light surfaces. */
    ROSE_LIGHT,
    DEEP_DARK,
    /** Pure-black power-saving dark mode for AMOLED panels. */
    AMOLED_BLACK,
    SYSTEM;

    companion object {
        fun fromName(name: String?): AppThemeMode =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: CLASSIC_LIGHT
    }
}

/** Selectable brand tints; only re-tints brand slots, neutrals stay theme-owned. */
enum class AccentPalette(
    val label: String,
    val light: AccentTint,
    val dark: AccentTint
) {
    FOREST("Forest", ForestAccentLight, ForestAccentDark),
    EMERALD("Emerald", EmeraldAccentLight, EmeraldAccentDark),
    OCEAN("Ocean", OceanAccentLight, OceanAccentDark),
    DUSK("Dusk", DuskAccentLight, DuskAccentDark),
    SUNSET("Sunset", SunsetAccentLight, SunsetAccentDark),
    ROSE("Rose", RoseAccentLight, RoseAccentDark),
    AMETHYST("Amethyst", AmethystAccentLight, AmethystAccentDark),
    GRAPHITE("Graphite", GraphiteAccentLight, GraphiteAccentDark);

    companion object {
        fun fromName(name: String?): AccentPalette =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: FOREST
    }
}

/**
 * Extended chat + app surface palette. Every screen (bubbles, calls, QR,
 * lock, dialogs) consumes these tokens so the palette is identical everywhere.
 */
data class CustomChatColors(
    val outgoingBubbleBg: Color,
    val outgoingBubbleBorder: Color,
    val outgoingText: Color,
    val outgoingMeta: Color,
    val incomingBubbleBg: Color,
    val incomingBubbleBorder: Color,
    val incomingText: Color,
    val incomingMeta: Color,
    val statusSuccess: Color,
    val statusWarning: Color,
    val statusError: Color,
    val presenceOnline: Color,
    val presenceAway: Color,
    val cardElevated: Color,
    val searchField: Color,
    val topBar: Color,
    val textMuted: Color,
    val primaryBrand: Color,
    val sageAccent: Color,
    val borderSubtle: Color,
    val scrim: Color
)

/** Per-user appearance choices consumed by chat rendering. */
data class ChatCustomization(
    val bubbleStyle: BubbleStyle = BubbleStyle.CLASSIC,
    val chatWallpaper: ChatWallpaper = ChatWallpaper.NONE,
    val fontScale: Float = 1.0f
)

val LocalChatColors = staticCompositionLocalOf {
    CustomChatColors(
        outgoingBubbleBg = LightOutgoingBubble,
        outgoingBubbleBorder = LightOutgoingBubbleBorder,
        outgoingText = LightOutgoingText,
        outgoingMeta = LightOutgoingMeta,
        incomingBubbleBg = LightIncomingBubble,
        incomingBubbleBorder = LightIncomingBubbleBorder,
        incomingText = LightIncomingText,
        incomingMeta = LightIncomingMeta,
        statusSuccess = FolkSuccess,
        statusWarning = FolkWarning,
        statusError = FolkError,
        presenceOnline = FolkSuccess,
        presenceAway = FolkWarning,
        cardElevated = LightSurfaceElevated,
        searchField = LightSurfaceSearch,
        topBar = LightTopBar,
        textMuted = LightTextMuted,
        primaryBrand = FolkForestGreen,
        sageAccent = FolkSage,
        borderSubtle = LightOutline,
        scrim = Color(0x66000000)
    )
}

val LocalChatCustomization = staticCompositionLocalOf { ChatCustomization() }

private fun lightScheme(accent: AccentTint) = lightColorScheme(
    primary = accent.primary,
    onPrimary = accent.onPrimary,
    primaryContainer = accent.primaryContainer,
    onPrimaryContainer = accent.onPrimaryContainer,
    secondary = FolkSage,
    onSecondary = FolkDeepForest,
    secondaryContainer = accent.primaryContainer,
    onSecondaryContainer = accent.onPrimaryContainer,
    tertiary = FolkSuccess,
    onTertiary = Color.White,
    error = FolkError,
    onError = Color.White,
    background = FolkWarmIvory,
    onBackground = FolkTextPrimary,
    surface = FolkWarmIvory,
    onSurface = FolkTextPrimary,
    surfaceVariant = FolkLightSage,
    onSurfaceVariant = FolkTextSecondary,
    surfaceTint = accent.primary,
    inverseSurface = FolkDeepForest,
    inverseOnSurface = FolkWarmIvory,
    outline = FolkBorderSubtle,
    outlineVariant = LightOutlineSubtle,
    scrim = Color(0x66000000)
)

private fun darkScheme(accent: AccentTint, amoled: Boolean) = darkColorScheme(
    primary = accent.primary,
    onPrimary = accent.onPrimary,
    primaryContainer = accent.primaryContainer,
    onPrimaryContainer = accent.onPrimaryContainer,
    secondary = accent.primary,
    onSecondary = accent.onPrimary,
    secondaryContainer = accent.primaryContainer,
    onSecondaryContainer = accent.onPrimaryContainer,
    tertiary = FolkSuccessDark,
    onTertiary = Color(0xFF0F1E19),
    error = FolkErrorDark,
    onError = Color(0xFF0F1E19),
    background = if (amoled) AmoledBg else DarkBg,
    onBackground = DarkTextPrimaryClean,
    surface = if (amoled) AmoledSurface else DarkSurfaceClean,
    onSurface = DarkTextPrimaryClean,
    surfaceVariant = if (amoled) AmoledSurfaceElevated else DarkSurfaceElevatedClean,
    onSurfaceVariant = DarkTextSecondaryClean,
    surfaceTint = accent.primary,
    inverseSurface = Color(0xFFE8F2EC),
    inverseOnSurface = FolkDeepForest,
    outline = if (amoled) AmoledOutline else DarkOutlineClean,
    outlineVariant = if (amoled) Color(0xFF16201A) else Color(0xFF223E34),
    scrim = if (amoled) Color(0xFF000000) else Color(0x99000000)
)

private fun chatColors(
    isDark: Boolean,
    amoled: Boolean,
    accent: AccentPalette
): CustomChatColors {
    val tint = if (isDark) accent.dark else accent.light
    return if (isDark) {
        CustomChatColors(
            outgoingBubbleBg = tint.outgoingBubbleBg,
            outgoingBubbleBorder = tint.outgoingBubbleBorder,
            outgoingText = tint.outgoingText,
            outgoingMeta = tint.outgoingMeta,
            incomingBubbleBg = if (amoled) AmoledSurfaceElevated else DarkIncomingBubbleClean,
            incomingBubbleBorder = if (amoled) AmoledOutline else DarkIncomingBubbleBorderClean,
            incomingText = DarkIncomingTextClean,
            incomingMeta = DarkIncomingMetaClean,
            statusSuccess = FolkSuccessDark,
            statusWarning = FolkWarningDark,
            statusError = FolkErrorDark,
            presenceOnline = FolkSuccessDark,
            presenceAway = FolkWarningDark,
            cardElevated = if (amoled) AmoledSurfaceElevated else DarkSurfaceElevatedClean,
            searchField = if (amoled) AmoledSurfaceSearch else DarkSurfaceSearch,
            topBar = if (amoled) AmoledTopBar else DarkTopBar,
            textMuted = DarkTextMutedClean,
            primaryBrand = tint.primary,
            sageAccent = tint.primary,
            borderSubtle = if (amoled) AmoledOutline else DarkOutlineClean,
            scrim = if (amoled) Color(0xE6000000) else Color(0xB3000000)
        )
    } else {
        CustomChatColors(
            outgoingBubbleBg = tint.outgoingBubbleBg,
            outgoingBubbleBorder = tint.outgoingBubbleBorder,
            outgoingText = tint.outgoingText,
            outgoingMeta = tint.outgoingMeta,
            incomingBubbleBg = LightIncomingBubble,
            incomingBubbleBorder = LightIncomingBubbleBorder,
            incomingText = LightIncomingText,
            incomingMeta = LightIncomingMeta,
            statusSuccess = FolkSuccess,
            statusWarning = FolkWarning,
            statusError = FolkError,
            presenceOnline = FolkSuccess,
            presenceAway = FolkWarning,
            cardElevated = LightSurfaceElevated,
            searchField = LightSurfaceSearch,
            topBar = LightTopBar,
            textMuted = LightTextMuted,
            primaryBrand = tint.primary,
            sageAccent = FolkSage,
            borderSubtle = LightOutline,
            scrim = Color(0x66000000)
        )
    }
}

/**
 * Root theme. In addition to the classic light/dark/system modes, the app
 * supports an AMOLED pure-black dark mode, eight accent palettes, an
 * accessibility font scale, bubble silhouettes and chat wallpapers. All
 * extra parameters default to the historic Folk behavior so existing call
 * sites keep compiling and the app looks identical before customization.
 */
@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode = AppThemeMode.DEEP_DARK,
    accentPalette: AccentPalette = AccentPalette.FOREST,
    fontScale: Float = 1.0f,
    bubbleStyle: BubbleStyle = BubbleStyle.CLASSIC,
    chatWallpaper: ChatWallpaper = ChatWallpaper.NONE,
    fontChoice: AppFontChoice = AppFontChoice.SYSTEM,
    content: @Composable () -> Unit,
) {
    val isDark = when (themeMode) {
        AppThemeMode.CLASSIC_LIGHT, AppThemeMode.MIST_LIGHT, AppThemeMode.PAPER_LIGHT, AppThemeMode.ROSE_LIGHT -> false
        AppThemeMode.DEEP_DARK, AppThemeMode.AMOLED_BLACK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val isAmoled = themeMode == AppThemeMode.AMOLED_BLACK

    val safeAccent = AccentPalette.fromName(accentPalette.name)
    val tint = if (isDark) safeAccent.dark else safeAccent.light
    val baseScheme = if (isDark) darkScheme(tint, isAmoled) else lightScheme(tint)
    val colorScheme = when (themeMode) {
        AppThemeMode.MIST_LIGHT -> baseScheme.copy(
            background = Color(0xFFEAF1F5),
            surface = Color(0xFFF7FAFC),
            surfaceVariant = Color(0xFFDDE8EF),
            outline = Color(0xFFB8CAD5),
            outlineVariant = Color(0xFFD0DDE4)
        )
        AppThemeMode.PAPER_LIGHT -> baseScheme.copy(
            background = Color(0xFFF4EFE5),
            surface = Color(0xFFFFFBF3),
            surfaceVariant = Color(0xFFE9E0D2),
            outline = Color(0xFFCFC2AF),
            outlineVariant = Color(0xFFE0D6C8)
        )
        AppThemeMode.ROSE_LIGHT -> baseScheme.copy(
            background = Color(0xFFFFF0F4),
            surface = Color(0xFFFFFAFB),
            surfaceVariant = Color(0xFFF6DDE5),
            outline = Color(0xFFD9B6C2),
            outlineVariant = Color(0xFFEAD0D9)
        )
        else -> baseScheme
    }
    val resolvedChatColors = chatColors(isDark, isAmoled, safeAccent)
    val safeScale = fontScale.coerceIn(0.8f, 1.4f)
    val resolvedFamily = fontFamilyFor(AppFontChoice.fromName(fontChoice.name))

    CompositionLocalProvider(
        LocalChatColors provides resolvedChatColors,
        LocalChatCustomization provides ChatCustomization(
            bubbleStyle = BubbleStyle.fromName(bubbleStyle.name),
            chatWallpaper = ChatWallpaper.fromName(chatWallpaper.name),
            fontScale = safeScale
        )
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = when {
                safeScale == 1.0f && resolvedFamily == FontFamily.SansSerif -> Typography
                safeScale == 1.0f -> typographyWith(resolvedFamily)
                else -> scaledTypography(safeScale, resolvedFamily)
            },
            shapes = FolkShapes,
            content = content
        )
    }
}
