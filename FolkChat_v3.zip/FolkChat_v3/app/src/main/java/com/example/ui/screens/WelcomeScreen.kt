package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.branding.AppEmblemStyle
import com.example.ui.branding.FolkEmblem
import com.example.ui.theme.LocalChatColors

private const val MAX_NAME_LENGTH = 32

/**
 * First-run welcome: one calm screen instead of a wizard. The emblem breathes,
 * elements stagger in, and a single field + button complete onboarding.
 * Everything else (permissions, relays, pairing) waits until it is needed.
 */
@Composable
fun WelcomeScreen(
    initialName: String = "",
    emblemStyle: AppEmblemStyle = AppEmblemStyle.FOLK,
    reduceMotion: Boolean = false,
    onStartWithName: (String) -> Unit
) {
    var enteredName by remember { mutableStateOf(initialName) }
    val focusManager = LocalFocusManager.current
    val chatColors = LocalChatColors.current

    // Staggered entrance for a composed, confident first frame.
    val emblemAppear = remember { Animatable(0f) }
    val titleAppear = remember { Animatable(0f) }
    val fieldAppear = remember { Animatable(0f) }
    val actionAppear = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (reduceMotion) {
            emblemAppear.snapTo(1f); titleAppear.snapTo(1f)
            fieldAppear.snapTo(1f); actionAppear.snapTo(1f)
        } else {
            emblemAppear.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
            titleAppear.animateTo(1f, tween(420, delayMillis = 120, easing = FastOutSlowInEasing))
            fieldAppear.animateTo(1f, tween(420, delayMillis = 240, easing = FastOutSlowInEasing))
            actionAppear.animateTo(1f, tween(420, delayMillis = 360, easing = FastOutSlowInEasing))
        }
    }

    val trimmed = enteredName.trim()
    val isTooLong = enteredName.length > MAX_NAME_LENGTH
    val isValid = trimmed.isNotEmpty() && !isTooLong

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Ambient organic accents, calm and low-contrast.
            Box(
                modifier = Modifier
                    .size(330.dp)
                    .align(Alignment.TopEnd)
                    .graphicsLayer { alpha = 0.6f * titleAppear.value }
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(270.dp)
                    .align(Alignment.BottomStart)
                    .graphicsLayer { alpha = 0.55f * actionAppear.value }
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                chatColors.sageAccent.copy(alpha = 0.28f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 26.dp, vertical = 18.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                FolkEmblem(
                    style = emblemStyle,
                    size = 132.dp,
                    breathing = true,
                    reduceMotion = reduceMotion
                )

                Spacer(modifier = Modifier.height(30.dp))

                Text(
                    text = "Welcome to FolkChat",
                    fontSize = 29.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = (-0.6).sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .graphicsLayer {
                            alpha = titleAppear.value
                            translationY = (1f - titleAppear.value) * 18f
                        }
                        .testTag("welcome_title")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Private. Simple. Yours.",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = chatColors.primaryBrand,
                    letterSpacing = 1.1.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.graphicsLayer {
                        alpha = titleAppear.value
                        translationY = (1f - titleAppear.value) * 14f
                    }
                )

                Spacer(modifier = Modifier.height(34.dp))

                OutlinedTextField(
                    value = enteredName,
                    onValueChange = {
                        if (it.length <= MAX_NAME_LENGTH + 5) enteredName = it
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 460.dp)
                        .graphicsLayer {
                            alpha = fieldAppear.value
                            translationY = (1f - fieldAppear.value) * 16f
                        }
                        .testTag("welcome_name_input"),
                    label = { Text("Your name") },
                    placeholder = { Text("What should we call you?") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = if (isValid) ImeAction.Done else ImeAction.Default
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (isValid) {
                                focusManager.clearFocus()
                                onStartWithName(trimmed)
                            }
                        }
                    ),
                    isError = isTooLong,
                    supportingText = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isTooLong) "Name must be $MAX_NAME_LENGTH characters or fewer"
                                else "Visible only to contacts you approve",
                                fontSize = 12.sp,
                                color = if (isTooLong) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${enteredName.length}/$MAX_NAME_LENGTH",
                                fontSize = 12.sp,
                                color = if (isTooLong) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    shape = RoundedCornerShape(17.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = chatColors.primaryBrand,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                Spacer(modifier = Modifier.height(22.dp))

                Button(
                    onClick = {
                        if (isValid) {
                            focusManager.clearFocus()
                            onStartWithName(trimmed)
                        }
                    },
                    enabled = isValid,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 460.dp)
                        .height(56.dp)
                        .shadow(
                            elevation = if (isValid) 6.dp else 0.dp,
                            shape = RoundedCornerShape(28.dp),
                            ambientColor = chatColors.primaryBrand.copy(alpha = 0.28f)
                        )
                        .graphicsLayer {
                            alpha = 0.55f + 0.45f * actionAppear.value
                            translationY = (1f - actionAppear.value) * 14f
                        }
                        .testTag("welcome_lets_start_button"),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = chatColors.primaryBrand,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        disabledContainerColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Let's start",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.2.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.graphicsLayer { alpha = 0.85f * actionAppear.value }
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "End-to-end encrypted · No phone number · No cloud account",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
