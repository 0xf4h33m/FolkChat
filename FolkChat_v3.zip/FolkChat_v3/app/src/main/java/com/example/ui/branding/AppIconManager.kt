package com.example.ui.branding

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Home-screen launcher icon variants. Each variant maps to a manifest
 * activity-alias carrying its own adaptive icon; exactly one alias is enabled
 * at a time. MainActivity itself keeps no launcher intent-filter, so the
 * enabled alias is the single entry point.
 */
enum class AppIconVariant(
    val label: String,
    val description: String,
    /** Manifest alias suffix; the full component is <packageName>.<aliasName>. */
    val aliasName: String
) {
    FOREST("FolkChat · Original", "The real FolkChat logo and brand identity", "LauncherForest"),
    OCEAN("Deep Ocean", "Calm waves on a deep blue tile", "LauncherOcean"),
    SUNSET("Warm Sunset", "A warm sun over rolling hills", "LauncherSunset"),
    MONO("Graphite", "Minimal monochrome bubble", "LauncherMono"),
    CALCULATOR("Calculator", "Calculator-style launcher icon disguise", "LauncherCalculator"),
    NOTES("Notes", "Notes-style launcher icon disguise", "LauncherNotes"),
    CALENDAR("Calendar", "Calendar-style launcher icon disguise", "LauncherCalendar"),
    WEATHER("Weather", "Weather-style launcher icon disguise", "LauncherWeather"),
    CLOCK("Clock", "Clock-style launcher icon disguise", "LauncherClock"),
    FILES("Files", "Files-style launcher icon disguise", "LauncherFiles");

    companion object {
        fun fromName(name: String?): AppIconVariant =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: FOREST
    }
}

/**
 * Switches the home-screen launcher icon between the manifest aliases.
 * The new alias is always enabled BEFORE the old one is disabled, so there is
 * never a moment with zero launcher entry points (which would hide the app).
 * All operations use DONT_KILL_APP so a running conversation is not restarted.
 */
class AppIconManager(private val context: Context) {

    private fun componentName(variant: AppIconVariant): ComponentName =
        ComponentName(context, "${context.packageName}.${variant.aliasName}")

    private fun isAliasEnabled(variant: AppIconVariant): Boolean = try {
        context.packageManager.getComponentEnabledSetting(componentName(variant)) !=
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    } catch (e: Exception) {
        // Unknown component (e.g. a flavor without aliases): treat as not switchable.
        false
    }

    /**
     * Defensive recovery: if every launcher alias is disabled (corrupt state,
     * restored backup from another device), re-enable the default so the app
     * can never become unreachable from the home screen.
     */
    fun ensureLauncherAvailable() {
        try {
            val anyEnabled = AppIconVariant.entries.any { isAliasEnabled(it) }
            if (!anyEnabled) {
                setLauncherVariant(AppIconVariant.FOREST)
            }
        } catch (_: Exception) {
            // Never let branding housekeeping crash startup.
        }
    }

    /** Reads the icon Android's PackageManager currently exposes, including across app restarts. */
    fun activeVariant(): AppIconVariant =
        AppIconVariant.entries.firstOrNull { isAliasEnabled(it) } ?: AppIconVariant.FOREST

    /**
     * Applies [variant] as the active launcher icon. Returns true when the
     * switch was performed, false when it failed (component resolution error)
     * or the variant was already active — callers can report either safely.
     */
    fun setLauncherVariant(variant: AppIconVariant): Boolean {
        return try {
            val pm = context.packageManager
            // Enable the target first: no zero-launcher window, at worst a brief
            // double entry that the launcher reconciles on its next refresh.
            pm.setComponentEnabledSetting(
                componentName(variant),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            AppIconVariant.entries
                .filter { it != variant }
                .forEach { other ->
                    pm.setComponentEnabledSetting(
                        componentName(other),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                }
            true
        } catch (e: Exception) {
            false
        }
    }
}
