# QR Pairing and Direct-Link Trust Model

## Intended user flow

1. User B opens **My QR**. FolkChat creates a random 256-bit token with a short expiry and listens only on topics derived from that token while the QR screen remains open.
2. User A scans B's QR, reviews the key fingerprint and confirms. A records B as pending/unverified and sends a recipient-encrypted `PAIR_REQUEST` containing the one-time token and a request ID.
3. B accepts only the active token, within its expiry, from one authenticated sender/request pair. The exact same request may be retried idempotently to recover a lost ACK; a different sender/request cannot reuse the token.
4. B remembers the scanner as a **pairing-verified peer** (24h TTL) and replies with a recipient-encrypted `PAIR_ACK` containing the same token and request ID. B does *not* silently create a contact: the scanner's first message arrives in **Message Requests**, and accepting that request promotes the pairing-verified peer into a verified contact. Re-pairing with an already-known contact only upgrades its trust level.
5. A verifies the ACK's authenticated sender key and matching request/token before marking B verified. A then announces its own profile (display name + wire-budget avatar) and requests B's profile, so both sides converge on avatars as soon as B accepts the request; direct-link delivery becomes eligible once both sides hold a verified contact.

## Direct transfer trust

- Wi-Fi/BLE discovery, IP addresses and ports are untrusted routing hints, not identity.
- Before framed payloads are accepted on a TCP direct link, the client proves it owns its long-term X25519 private key; the server checks that the presented identity belongs to a verified, unblocked contact and returns an authenticated response proof. The client pins the expected contact key.
- All application messages remain end-to-end encrypted independently of the direct TCP handshake. The handshake is an additional endpoint-authentication gate, not a substitute for the message encryption.
- Unverified or blocked contacts cannot establish an accepted direct TCP session.

## Firewall limitation

This code does **not** add an operating-system firewall rule or trust a raw IP address. On ordinary Android, an app cannot open arbitrary OS firewall exceptions without privileged/root access or implementing an explicit VPN service. Trusting the IP itself would be weaker: DHCP, NAT, spoofing and address changes mean an IP is not a stable device identity. FolkChat instead allows a direct route only when the connection authenticates to the expected verified key.

## Styling

The pairing surfaces use Compose Material 3 cards, a bundled (offline) Lottie pulse, spring-based entrance motion and elevation. Reduce Motion suppresses the Lottie animation and skips the animated entrance. No remote animation resources are downloaded.

## Verification boundary

Pure Kotlin crypto/handshake smoke tests were run for: a trusted identity succeeds, a non-allowlisted identity is rejected, a QR code round-trips correctly, and expired QR codes are rejected. A complete Android build and cross-network device test still require Gradle/Android SDK tooling and two physical devices. Mutual QR pairing currently needs the public token-scoped inbox or a configured private relay; `Force Offline` will not silently use WAN.
