# FolkChat — messaging, media, and call fixes

This source update targets the reported first-contact, encrypted media transfer, viewer, WebRTC video, and typography problems.

## Messaging requests and QR pairing

- Relay subscriptions now include recently QR-authenticated peers and message-request senders, not only accepted contacts.
- Pairing and request transitions refresh subscriptions immediately rather than waiting for the periodic reconciliation pass.
- An incoming stranger remains a **Message Request** until accepted; receiving a first message does not silently create an accepted contact.

## Media transfer

- The sender derives plaintext size and SHA-256 from the actual selected file and updates the outgoing attachment metadata before publishing the transfer envelope.
- The public-host encrypted download retries up to three times after transient truncation/disconnects. Actual streamed byte counts—not a possibly absent or inaccurate HTTP `Content-Length`—are used for the file-size assertion.
- AES-GCM authentication and SHA-256 checks remain required before a downloaded file is finalized. Transfer window increased modestly to improve throughput.

## Media viewer

- Images and videos open in a full-window viewer; image gestures support pinch/pan, double-tap reset, and explicit zoom controls up to 5×.
- Video viewers add zoom controls and retain Android playback/seek controls. View-once/view-twice content uses a shared close handler to avoid consuming multiple views from duplicate dismiss events.

## Calls

- Video-call rendering uses `TextureViewRenderer` to avoid common `SurfaceView` z-order issues in Compose overlays.
- Remote video visibility is driven by the actual incoming video track rather than the local camera state. Camera permission therefore controls camera sending; an answerer can still receive video when their own camera is unavailable.
- Added a front/rear camera switch control. WebRTC still needs compatible ICE connectivity; STUN alone does not guarantee calls through every NAT/carrier. A properly configured reachable TURN service may be necessary.

## Typography

- Typeface choices are limited to supported, metric-friendlier families instead of monospaced/cursive choices that distort chat layouts.
- Font size, line-height, letter spacing, and Android font padding are handled consistently across the app's Material 3 type scale.

## Verification limits

- Resource XML can be parsed and the source archive checked locally.
- A full Android Gradle build and two-device connectivity test still need to be run in an environment with the Android SDK and the Gradle distribution available. Static source checks do not prove runtime behavior across every Android version, network, relay, camera, codec, or OEM.
