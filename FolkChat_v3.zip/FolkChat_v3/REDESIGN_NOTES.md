# FolkChat redesign and reliability notes

This source update brings the main messaging flow closer to the supplied FolkChat mockup: forest/sage surfaces, a lighter chat hub, compact Chats / Calls / People / Settings navigation, a unified new-conversation menu, an explicit group-creation flow, animated voice recording feedback, and a local in-app file preview.

## Included in this update

- **Group text conversations:** persisted group membership, encrypted client-side fan-out (a separately encrypted envelope for each member), creator-authenticated membership snapshots, per-member delivery receipts, sender labels, and guardrails that keep synthetic group IDs out of direct-contact routing. Groups support text messages; group file fan-out and group calls are not enabled yet.
- **File transfer reliability:** up to six chunks in flight, receiver acknowledgements for each chunk, bounded retransmission, safe duplicate handling, receiver-side byte-count and SHA-256 checks, and a final receipt before the sender is marked delivered. Transfer progress continues to update during the send.
- **In-app previews:** image, video, PDF, and common text/code files can be previewed locally; large PDFs/text files are intentionally bounded to reduce memory pressure. Other file types can be opened with another Android app.
- **Call-screen correction:** CameraX `Preview` is now bound to the `PreviewView` surface provider, fixing the missing local self-preview. The camera analysis stream is throttled to avoid overwhelming the existing socket media path.
- **Voice feedback:** the recording state now pulses and shows an animated waveform/timer instead of leaving the microphone interaction visually static.

## Networking reality and setup

FolkChat can transport end-to-end encrypted message envelopes and file chunks over the existing online WebSocket relay, **but a public relay must first be deployed and configured**. Set `FOLKCHAT_RELAY_URL` to a reachable `wss://…/ws` endpoint when building, or enter the same relay URL on both devices in Settings. The relay server is under `relay-server/`; see `WAN_RELAY_SETUP.md`. The relay must remain reachable and both peers must be online while a file is actively transferring: chunk data is intentionally not queued for offline delivery.

**WAN call reachability is network-dependent.** Current call media uses WebRTC with ICE and default STUN servers. Some NAT/firewall combinations still require valid TURN credentials configured in Settings → Calls & media transport. Successful WAN calling must be verified on real devices and different networks.

Group messages currently fan out to each group member individually, so every participant must be a configured contact of the sender to create the group. Membership changes, group message history synchronization, group media, and group calling are not included.

## Verification performed

- Relay JavaScript syntax checks (`node --check`) and the relay's Node test suite can run without Android tooling.
- The Android application was **not built or run on devices in this environment** because the Android SDK and standard Gradle wrapper JAR/distribution are not available here, and the environment cannot resolve external hosts to download them. This bundle includes a bootstrap `gradlew` script for internet-connected build machines. A successful relay test is not proof of Android compilation or real-device WAN behavior; use Android Studio or the included wrapper-restoration setup, then test with two physical devices and a deployed relay.
