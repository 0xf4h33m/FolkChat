# FolkChat networking and reliability update

## Changed in this pass

- Public chat/call signaling now returns after the first public relay accepts a packet; redundant relay publishes continue in the background instead of making every message wait for the slowest relay.
- Automatic routing prefers a recently discovered local path when present and otherwise chooses WAN, avoiding repeated futile LAN attempts between devices on different Wi-Fi networks.
- Public file transfer reuses HTTP client/connection pools, uses bounded 16 MiB encrypted segments with three uploads in flight, retries bounded transient GET failures, and safely follows only approved HTTPS redirects, addressing the repeated 302 failure. WAN relay routes prefer encrypted blob transfer for files above 8 MiB instead of serializing thousands of ACKed chat packets. Direct-transfer progress writes are throttled so every small chunk does not rewrite the full encrypted vault.
- View-once/view-twice counters are incremented from the latest synchronized vault state; receipts target the original sender and the sender applies cumulative, monotonic view counters capped at the configured limit.
- Attachment-picker failures now surface the actual bounded error message; cancellation propagates instead of being converted to transfer failure. The picker checks app storage and has a 100 GiB app-level ceiling.
- GIF search/library/device picker integration has been removed. Startup cleanup removes only GIF attachments and orphan GIF files under FolkChat's private `files/media` directory. It never deletes shared-storage GIFs or files owned by other apps.
- WebRTC camera defaults are reduced to 640x360 at 20 FPS (320x240 at 12 FPS in data-saver mode) to reduce encoding cost on slower devices and poor networks. Call rendering uses TextureViewRenderer to avoid SurfaceView z-order/Compose overlap that can leave local or remote video looking frozen, and SDP fragments are sent in bounded parallel batches rather than one WAN round-trip at a time.
- Settings are presented as a category index; tapping a category opens that category's settings detail page, with animated navigation and BackHandler support.

## Important limits

The 100 GiB value is a client-side ceiling, not a promise that a public temporary file host will retain or accept a file that large. A segmented transfer requires many upload/download requests and may fail when a host throttles, expires, rejects or deletes blobs. The current implementation can retry segments within an active transfer but does not persist a resumable manifest across process restarts.

HTTP redirects are allowed only over HTTPS to `0x0.st`, `tmpfiles.org`, or a `*.tmpfiles.org` hostname. Hosts outside that allowlist fail closed rather than risking an unsafe redirect. Provider-specific redirect changes may require updating the allowlist. Retryable responses include 408, 425, 429, 500, 502, 503 and 504, with bounded attempts.

WAN WebRTC calling still depends on ICE reachability; some NAT/firewall combinations require valid TURN credentials. Lower capture resolution/FPS can reduce latency but cannot substitute for network quality, TURN relay capacity, or device tests.

## Verification caveat

This environment lacks the Android SDK and a functioning Gradle wrapper/bootstrap, so a complete Android build and two-physical-device WAN/LAN tests cannot be claimed. Verify transfer integrity, view receipts, redirect paths and camera negotiation using two devices before distributing an APK.
