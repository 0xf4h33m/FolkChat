# FolkChat v3 — Bug Fix Release Notes

This pass fixes the issues reported across networking, calling, media, QR pairing and profile
sync. Every change is in the app layer; the relay-server protocol is unchanged (its test suite
still passes: 4/4).

> **Audit pass 2 (full-source sweep):** every networking, call, media, crypto, vault, UI and
> relay-server file was re-read end-to-end. Eight additional defects were found and fixed
> (including an app-freezing deadlock and a silent data-loss race), and two reliability
> features were added — see sections 7-9 below.

## 1. QR pairing now lands in Message Requests (not the inbox)

**Symptom:** User A scans User B's QR code and sends a message — it appeared directly in B's
inbox, bypassing the Requests tab.

**Root cause:** When B's phone received the authenticated `PAIR_REQUEST`, it silently created a
verified contact for A. Every later message therefore looked like it came from a known contact
and went straight to the inbox.

**Fix (`TransportCoordinator.handleQrPairingRequest`):** B now records A as a
*pairing-verified peer* (persisted in the vault, 24-hour validity) instead of a contact. A's
first message arrives as a **Message Request**. When B taps **Accept**, the request is promoted
into a contact that is already marked verified (the QR handshake proved A's identity), and both
sides immediately exchange profile snapshots. Re-pairing with an existing contact still just
upgrades its trust level.

## 2. Profile pictures now display

**Root causes:**
- The QR scanner never *announced* its own profile to the QR owner — B's phone had no path to
  ever learn A's name/avatar. Fixed in `handleQrPairingAck`: after mutual verification, A sends
  a full `PROFILE_UPDATE` (display name + wire-budget avatar) in addition to the existing
  profile request.
- The contact profile dialog and call-history rows rendered placeholder initials even when a
  real avatar file was stored. Both now use the shared `PeerAvatar` component with
  `contact.avatarPath`.

## 3. Calls: stability and "stuck" states

- **Stuck ringing on the callee:** a lost caller END signal used to ring forever. The callee now
  has its own 50-second ring timeout that logs the call as *Missed*.
- **Stuck "Connecting secure video…":** if the callee answered without camera permission, the
  call now completes as audio instead of hanging, and the caller's screen only switches to the
  video stage when a remote video track actually exists (previously an audio-connected call
  displayed "Connecting secure video…" forever).
- **Calls dropped during brief network blips:** the WebRTC `DISCONNECTED` kill window grew from
  6s to 12s, the grace job is cancelled when the link recovers, and the final decision consults
  the live connection state instead of a stale session copy (a reconnected call can no longer
  be killed by its own recovery timer).
- **Lost signaling packets:** call signals (ICE candidates, END, REJECT) are now retried up to
  3 times with backoff instead of fire-and-forget, and the connect timeout is 30s (TURN-heavy
  paths need the room).
- All new timeout jobs are cancelled on teardown/answer, so no stray coroutine can end a later
  call.

## 4. View-once / media

- Incoming view-once media that had not finished downloading rendered **nothing** — there was no
  way to fetch it. The bubble now renders the progress/Download UI until the transfer completes,
  then seals.
- The "Wi-Fi only" auto-download rule now checks the *actual active network* (Wi-Fi/Ethernet vs
  cellular) instead of assuming relay/public-topic links are metered. Media sent through the
  relay while you are on Wi-Fi auto-downloads again, and cellular users can enable it via
  Settings → Media auto-download → Always.

## 5. Networking / data-transfer stability

- **Outbox hot loop:** messages that could not be delivered were re-sealed and re-broadcast over
  every transport every 2 seconds while the peer was offline. Attempts are now throttled (8s for
  queued messages, 15s retained for in-flight ones), which also protects public-relay rate
  limits.
- **Stale direct peers:** discovered Wi-Fi/BLE peers now expire from the routing table
  (~20-25s without a beacon) instead of being preferred forever at their dead IP.
- **TCP server restarts:** the listen socket binds with `SO_REUSEADDR` and retries, so
  restarting the foreground link service no longer silently kills local Wi-Fi transport
  (BindException on a TIME_WAIT port).
- **Manual direct links ("register IP") actually work now:** manually registered endpoints are
  matched by the direct-Wi-Fi route and are probed even when the relay is preferred; the socket
  handshake still independently authenticates the peer identity. Manual entries use the
  reserved zero-timestamp marker so they neither expire nor hijack WAN routing.

## 6. Misc logic fixes

- Typing indicators are now tracked per peer (one peer's timeout no longer clears every
  conversation's indicator).
- Message requests created from a QR-paired sender use the pairing-authenticated display name
  as the fallback.

## 7. Full-source audit pass: additional defects fixed

**Vault save corruption race (data loss).** `EncryptedVault.readCursors` was mutated
(`markConversationRead`) from the UI thread with **no lock** while background coroutines
constantly called `saveVault()`, which iterates the same map under `synchronized(readCursors)`.
A concurrent put during that iteration threw `ConcurrentModificationException` inside
`saveVault()`, which aborted the snapshot and **silently dropped every change since the last
successful save** (messages, settings, contacts). All three cursor access points
(`markConversationRead`, `getReadCursor`, `getUnreadCount`) now synchronize on the same lock
object the snapshot uses. This was the most likely root cause of intermittent "my messages /
settings disappeared" instability.

**Duplicate message dispatch.** `flushOutbox()` could run twice concurrently — the immediate
flush launched by every new outgoing message races the 2-second outbox worker. Both reads saw
the same QUEUED list before either updated status, so the same message was sealed and
dispatched twice (duplicate envelopes over the public relays, wasted rate-limit budget and
battery). Flushes are now serialized by a mutex.

**Incoming media stuck after accepting a message request.** Media that arrived from a
not-yet-accepted sender was stored as FAILED ("Accept this contact request before
downloading"), but the Download button only appeared for errors containing "tap Download".
After accepting the request there was no re-delivery and no retry path — the media was
permanently stuck. Every FAILED incoming attachment is now retryable: the tap invokes the
normal download pipeline, which re-validates the contact and consent itself, so showing the
button is always safe.

**Silent chunk drops during busy periods.** When more than 4 simultaneous incoming transfers
were active, additional chunks were dropped *silently*: the sender exhausted retries and
failed with a generic error while the receiver's UI showed nothing. The receiving message is
now marked FAILED with "Too many simultaneous downloads — retry when other transfers finish".

**Jumpy transfer progress.** Incoming progress was checkpointed to the (encrypted, full
snapshot) vault only every 32 chunks, so typical 48 KB-chunk transfers jumped 0% → 50% → 100%
and small files showed 0% until completion. Progress now persists every 8 chunks or at a 4%
progress delta (tracked per transfer), which also throttles small BLE chunks correctly.

**Relay-server acknowledgement cost.** `handleReceived` scanned **every** registered mailbox
key to acknowledge one delivery — O(total keys) CPU per ACK on a busy relay. It now performs a
direct map lookup. (Relay protocol unchanged; test suite 4/4.)

**Vault AB-BA deadlock (app freeze).** `updateMessageStatus` and
`updateMessageStatusAndRoute` acquired `outboxList` and then *nested* an acquisition of
`messagesList` inside it, while `saveMessage`/`updateMessage` acquire the same two locks in
the opposite order. Under load (an incoming delivery receipt racing a new outgoing message)
both threads could block forever, freezing every subsequent vault operation — another
intermittent "the app just hangs" root cause. All vault mutation paths now use one
consistent lock order (`messagesList` → `outboxList`, never nested inversely).

**Edits to queued messages sent stale text.** `updateMessage` mutated the stored message but
left the outbox's copy untouched, so editing a message that was still QUEUED sent the
*pre-edit* text to the peer while the sender's screen showed the new one. `updateMessage`
now synchronizes the outbox copy (and drops it when the message is no longer
dispatch-eligible).

## 8. New: resend failed messages

A FAILED outgoing text message had **no** recovery path: the outbox only re-dispatches
QUEUED/eligible-SENDING messages, so a message that failed while the peer was unreachable
stayed failed forever. Now:

- the failed status tick on the message bubble is tap-to-resend, and
- the long-press menu offers **Resend** for failed text messages.

Resend requeues the message and clears its retry throttle so it dispatches immediately.

## 9. New: live queue indicator

The connection status strip on the Chats screen now shows how many messages are waiting in
the encrypted outbox, e.g. "Offline · 3 messages queued" or "Online · Sending 2 queued
messages". Previously there was no visible feedback that messages written while offline were
safely stored and would leave on the next connection.

## 10. Pass 3: UI customization, error surfacing and edge-case hardening

**New customization system** (see `UI_CUSTOMIZATION.md` for the full guide):

- Four theme modes: Light, Deep Dark, **AMOLED pure black** (new), System.
- Eight accent palettes (Forest, Emerald, Ocean, Dusk, Sunset, Rose, Amethyst, Graphite)
  that re-tint outgoing bubbles and brand controls app-wide, live.
- Accessibility text size XS→XL that scales the entire type scale, with chat bubbles
  leading.
- Three bubble silhouettes (Classic tails, Modern rounded, Soft squircle) and three chat
  wallpapers (Solid, Gentle wash, Folk dots).
- Chat density (compact) and outgoing-bubble emphasis toggles are now exposed in
  Settings → Appearance (they existed in the vault but were unreachable).
- The Appearance section shows a **live mini conversation preview** that reflects every
  choice instantly.

**Unified error surfacing.** Silent failure paths now surface through a snackbar event bus
(`ChatViewModel.uiEvents` + root snackbar host): forward-message when the source file is
gone, resend requeue failures, profile-photo save/compress failures, and appearance-setting
vault errors all produce a visible message instead of nothing.

**Voice messages.** The player now has a real `OnErrorListener`, distinct
"Preparing…/Not available" states, and tappable-failure feedback — previously a damaged
recording left a dead play button with zero feedback. The recorder: a zero-length or
unfinalized recording (send tapped too fast / storage pressure) now deletes the temp file
and tells the user instead of silently vanishing.

**Accent coherence.** Chat media/voice UI elements (transfer cards, video placeholder,
voice player, send/mic button) now use the theme's brand tokens instead of hardcoded
forest green, so selecting e.g. Ocean re-tints them too.

**Typing indicator.** "typing…" is now an animated three-dot indicator in both the chat
header and the conversation list (static dots when Reduce motion is enabled).

**Defensive parsing.** All new persisted appearance values are clamped/validated on load
(unknown enum names fall back to defaults, font scale coerced to 0.8–1.4, strings capped),
so a corrupted or hand-edited vault can never crash the UI. Theme-mode parsing switched
from `valueOf` (throws) to a fallback resolver.

**Compile-safety fix caught in review.** The wallpaper branch originally mixed `Color` and
`Brush` in a single `when` passed to `Modifier.background(...)`, which cannot resolve
against either overload; it now builds a uniform `Brush` (solid two-stop gradient for the
Solid canvas).

## Files changed

- `app/src/main/java/com/example/data/EncryptedVault.kt`
- `app/src/main/java/com/example/net/transport/TransportCoordinator.kt`
- `app/src/main/java/com/example/net/media/MediaTransferManager.kt`
- `app/src/main/java/com/example/net/call/CallManager.kt`
- `app/src/main/java/com/example/net/call/WebRtcMediaEngine.kt`
- `app/src/main/java/com/example/net/socket/SocketManager.kt`
- `app/src/main/java/com/example/ui/ChatViewModel.kt`
- `app/src/main/java/com/example/ui/screens/ChatScreen.kt`
- `app/src/main/java/com/example/ui/screens/CallScreen.kt`
- `app/src/main/java/com/example/ui/screens/ConversationsScreen.kt`
- `app/src/main/java/com/example/ui/screens/SettingsScreen.kt`
- `app/src/main/java/com/example/ui/components/Common.kt`
- `app/src/main/java/com/example/ui/components/ProfileDialog.kt`
- `app/src/main/java/com/example/ui/theme/Theme.kt`
- `app/src/main/java/com/example/ui/theme/Color.kt`
- `app/src/main/java/com/example/ui/theme/Type.kt`
- `app/src/main/java/com/example/MainActivity.kt`
- `app/src/main/java/com/example/data/Models.kt`
- `relay-server/src/server.js` (internal performance fix only; protocol unchanged)
- `QR_PAIRING_AND_DIRECT_TRUST.md` (flow documentation)
- `UI_CUSTOMIZATION.md` (new — appearance features guide)

## Verification notes

- Relay-server test suite: `node --test` → 4 pass / 0 fail.
- All modified Kotlin files pass brace/paren balance and were diffed line-by-line against the
  original archive. A full compile still requires Gradle + Android SDK (`./gradlew
  assembleDebug`) on a build machine, plus two physical devices for cross-network QA of
  pairing, calls and media handoff.

## 11. App Lock / Chat Lock deep fix pass (v3 "stability & customization" update)

**App-lock timer used wall-clock time (the reported "timer issue").** Idle measurement was
based on `System.currentTimeMillis()`. NTP sync, time-zone travel or a manual clock edit
made the auto-lock fire instantly (clock jumped forward) or never (clock jumped backward).
All idle tracking now uses monotonic `SystemClock.elapsedRealtime()`. The persisted PIN
lockout deadline intentionally stays wall-clock so it survives process restarts.

**Auto-lock no longer interrupts active use.** Two new activity sources feed the idle
timer: (1) typing in the message composer (soft-keyboard composition never reached the
root pointer pipeline, so a long message could lock the app mid-typing), and (2) a live
call — a connected call session now places a *foreground hold* on the idle countdown, so
a 30 s auto-lock can no longer cover a video call screen. Backgrounding still re-locks
exactly as configured.

**Live lockout countdown.** The "Too many attempts — retry in Ns" text used to freeze at
the value captured when the failure happened. Both the App-Lock gate and the per-chat
lock gate now tick every second until the lockout expires.

**Stale chat-unlock errors.** Opening a locked chat could show the failure message from a
*previously* opened locked chat. The error shown on the chat lock screen is now snapshotted
per contact (failures that occur while that screen is visible), and switching chats starts
clean.

**Chat lock parity.** The chat lock screen now uses the same haptic numeric keypad, animated
PIN dots and error shake as the app-level gate, instead of a bare text field.

**Hardening details.** `setAutoLockMillis` is clamped to 0…60 min and no longer schedules a
pointless re-lock while already locked; `setEnabled` no longer arms a stray timer; the
auto-lock runnable is foreground-hold aware; `clearUnlockFailure()` exists for consumers.

**Launcher-alias safety.** The app icon is now switchable via manifest activity-aliases.
Recovery logic at startup guarantees at least one launcher alias is enabled (corrupt or
restored component state can never make the app unreachable), and switching enables the
new alias before disabling the old one so there is never a zero-entry-point window.

## 12. Customization & UX additions in this pass

- **6 font families** (2 bundled, subset to Latin-1): Default (Roboto), Friendly (Carlito),
  Classic (Times-style serif), Modern serif (Noto Serif), Mono, Script — live "Aa" previews.
- **7 chat wallpapers** including an animated Aurora (static under reduce-motion), fine
  grid, warm paper and bloom.
- **5 in-app emblem styles** and **4 home-screen launcher icon variants** (activity-alias
  based; launcher redraws on its own schedule).
- **New Welcome flow**: one calm screen (emblem, name, start) replacing the two-step wizard.
- **Drafts**: unsent text survives switching conversations (memory-only per session).
- **Animations**: staggered entrances (welcome, lock gates), fresh-message rise+fade,
  `animateItem` placement animations in chat and conversation lists, error shake, calm
  cross-fade between onboarding and the main app.
- **New settings**: haptic feedback toggle, 10-minute auto-lock option, font/emblem/icon
  pickers, wallpaper set expansion.

Files added in this pass: `ui/branding/Emblems.kt`, `ui/branding/AppIconManager.kt`,
`res/font/*` (4 subset TTFs), `res/drawable/emblem_*.xml` (5 vectors),
`res/drawable/ic_launcher_{ocean,sunset,mono}_fg.xml`, adaptive + legacy launcher icon
resources, `FONTS_LICENSES.md`.

Verification for this pass: brace/paren balance re-checked on all 16 edited Kotlin files
(template-aware checker), all XML resources parsed, relay-server tests 4/4
(`node --test`), zip integrity + file-set diff against the original archive (nothing cut).
