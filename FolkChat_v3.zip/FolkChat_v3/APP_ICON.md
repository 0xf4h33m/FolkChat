# FolkChat app icon options

The app's default in-app emblem and original launcher icon use the supplied transparent FolkChat speech-bubble logo (`app/src/main/res/drawable/app_logo.webp`). The original identity remains available as **FolkChat · Original** in Settings → Appearance → App icon.

## Available launcher choices

- **FolkChat · Original** — the real FolkChat mark.
- **Deep Ocean** — blue visual theme.
- **Warm Sunset** — warm gradient-inspired mark.
- **Graphite** — monochrome mark.
- **Calculator**, **Notes**, **Calendar**, **Weather**, **Clock**, and **Files** — optional launcher-label/icon disguises.

Android exposes these through `activity-alias` entry points. FolkChat enables the selected alias and disables the others; launcher apps can take a moment to refresh cached icons. Some launchers may display duplicate entries briefly while the change propagates.

## Privacy limitation

A decoy launcher icon changes the home-screen appearance only. It does **not** rename the app's package, hide it from Android Settings or app-management tools, conceal network traffic or notifications from all observers, or guarantee anonymity. Use device-level privacy controls and consider who can access the unlocked device. The feature is not a security boundary.

## Updating the art

- Adaptive launcher art is in `app/src/main/res/mipmap-anydpi-v26/`.
- Legacy/vector launcher art is in `app/src/main/res/mipmap-anydpi/`.
- Disguise foreground vectors are in `app/src/main/res/drawable/ic_disguise_*.xml`.
- The default in-app logo is `app/src/main/res/drawable/app_logo.webp`.
