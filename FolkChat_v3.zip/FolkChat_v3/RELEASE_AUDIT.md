# FolkChat v3 source consolidation and release audit

## Scope

This package consolidates the latest QR-pairing/direct-trust source with the reliability update and the full WAN redesign. Files were compared from the supplied source archives; the QR-pairing source contains the reliability tree's code files and adds the QR pairing protocol, direct peer handshake, local Lottie resource, tests, and documentation. Non-source `.aistudio` planning/media artifacts were excluded from the release package. The removed Tenor/GIF browsing feature is intentional: the old service and search UI are absent, while cleanup only targets legacy GIFs/orphaned files inside FolkChat's own private storage.

## Included feature areas

- Jetpack Compose / Material 3 redesign, light/dark/system themes, profile/settings screens, spring motion, bundled Lottie pairing pulse, and Reduce Motion handling.
- Encrypted local vault, X25519 identity keys, authenticated/encrypted message envelopes, safety fingerprints, app lock, chat lock, and privacy settings.
- LAN Wi-Fi and Bluetooth LE transport; auto / force-offline / force-online routing; optional self-hosted WebSocket relay; public WAN message fallback across the configured ntfy-compatible relay pool.
- Per-relay authenticated encryption wrappers, retry/deduplication and transport timeouts. Public relays still expose metadata and may throttle/drop packets; the relay pool is not an anonymity system.
- Local encryption for WAN attachments, bounded acknowledged chunk transfer for supported local routes, encrypted public blob upload fallback, 16 MiB authenticated segments for public files above 64 MiB, integrity checks, retry behavior, and a client-side configured maximum of 100 GiB. Public file hosts usually impose lower practical limits, so that ceiling is not a promise of provider acceptance.
- In-app image/video/PDF/text/code viewing; view-once/view-twice counters and sender-directed receipts; video playback stops when its viewer closes; public-host redirects are constrained to approved HTTPS hosts.
- WebRTC audio/video calling and call UI. Real-world call setup can require a reachable TURN server and credentials; those are not bundled.
- Group text conversations with per-member encrypted fan-out, membership state, receipts and sender labels. Group media upload and group calls remain unsupported.
- Profile/avatar sync, transfer-progress persistence throttling, timeout cleanup, app-private media storage, and Android FileProvider path restrictions.
- QR pairing uses short-lived one-time `fc2` tokens, encrypted request/ack confirmation, and does not mark the scanner-side contact trusted until the matching authenticated ACK. Direct TCP checks identity possession and the verified/unblocked contact allow-list; IP addresses are only route hints.
- Self-hosted relay deployment files, test sources, Android resources, build scripts, setup/security notes, and project-local debug signing key for local debug builds.

## Additional fixes from the second audit pass (2026-10-16)

- Hex decoding now rejects odd-length and non-hex input instead of silently ignoring a trailing nibble; hex encoding uses a direct lookup table.
- X25519 rejects all-zero shared secrets and malformed key lengths. Message encryption/decryption clears temporary DH secrets, derived symmetric keys, and ephemeral private-key byte arrays in `finally` blocks. Authenticated packet processing also clears temporary auth keys, tags, canonical JSON bytes, outbound plaintext buffers, and the temporary inbound decrypted wire buffer after JSON parsing.
- Bounded L1 frame-count arithmetic uses `Long`, concurrent session creation reserves slots under a shared lock, and conflicting chunk metadata no longer evicts an otherwise-valid in-flight reassembly session.
- Adding a contact no longer silently removes an explicit block. Invalid/blocked QR contacts are rejected with a user-visible message, and re-adding an existing public key preserves its existing avatar/chat settings instead of replacing the contact record. Malformed optional pairing tokens are rejected rather than downgraded to ordinary contact additions. Contact deletion normalizes/validates the public-key hex.
- Relay environment integers are validated with bounded defaults. Malformed numeric retention configuration can no longer become `NaN` and trigger unintended mailbox expiry. Legacy plaintext mailbox migration now requires a valid mailbox schema; malformed JSON is rejected and preserved instead of being migrated to an empty queue.
- QR contact parsing now safely handles malformed percent-encoding and strips ISO control characters from displayed contact names, preventing scanner crashes and multiline label spoofing. Regression tests were added for these cases, conflicting frame metadata, strict hex parsing, AEAD tampering, positive discovery epoch intervals, malformed mailbox stores, and invalid relay numeric settings.

## Verification performed on this packaged tree

- Source archive comparison against the supplied reliability and full-WAN archives.
- All 12 Android XML resource/manifest files parsed successfully.
- All 3 JSON files parsed successfully, including the bundled Lottie animation.
- Shell syntax checked for the Gradle bootstrap and build/restore scripts.
- Relay-server JavaScript and test files pass `node --check`. The auth and mailbox-storage tests passed (4 tests) using a temporary minimal `ws` module stub only to load the server module for storage-only tests. This did **not** exercise actual WebSocket integration, which still requires installing the declared `ws` package.
- The standalone L1 framer compiled with the available Kotlin compiler and passed smoke tests for shuffled reassembly, CRC rejection, and frame-count bounds. The actual crypto, direct-handshake, and framing source files also compiled together against the locally available Bouncy Castle JAR and passed standalone smoke tests for X25519 agreement, AEAD round-trip/tamper rejection, strict hex, QR expiry/round-trip, and allowlisted vs rejected direct peers, relay-wrapper host/tamper rejection, malformed-QR safety, and reassembly survival after conflicting frame metadata.
- XML resources and JSON resources were parsed again after the second-pass changes. Shell scripts pass `bash -n`.
- Regression test sources now cover crypto hex parsing/tampering, direct-peer handshakes, framing, and relay configuration/legacy-store validation. The standalone smoke tests above are not a substitute for the Android/JUnit test task; Android/JUnit tests were not executed because the Android/Gradle dependency classpath is unavailable here.
- Source/test inventory checked; unit test sources include crypto, framing, relay-packet cipher, QR pairing, and direct-handshake tests, plus a Robolectric/unit example and an instrumented Android test.
- A SHA-256 source manifest is included. The final ZIP is checked with `unzip -t` and its contents re-listed.

## Verification not performed

A full Gradle/Android APK build and test suite were **not** run in this environment: the Android SDK and system Gradle are not installed, the standard wrapper JAR/Gradle distribution are not cached, and network name resolution is unavailable here. The included `gradlew` bootstrap can restore standard wrapper files on a machine with internet; an Android SDK Platform matching the configured compile SDK and dependencies must also be available. Real-device two-phone tests for WAN delivery, NAT traversal, BLE/Wi-Fi fallback, QR pairing, calls, and large files are still required before calling this production-ready.

## Important operational limits

- No signed APK is included; this is source code. Release signing files/secrets are not included.
- The root `debug.keystore` is for local development only and must never sign a production release.
- Completed media is still plaintext inside FolkChat's app-private media directory (not file-level encrypted at rest).
- Public relay/file-host services have their own rate limits, retention policies, and availability; successful relay publication is not the same as a recipient delivery receipt.
- QR pairing requires an internet delivery path in this version; Force Offline mode will not silently use WAN for pairing.
- Direct WebRTC can expose a peer's public IP to the other peer; relay-only media requires a real TURN deployment and valid credentials.
