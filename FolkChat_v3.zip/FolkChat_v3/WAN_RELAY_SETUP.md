# Optional self-hosted FolkChat WAN relay

FolkChat now has a built-in, no-configuration public WAN fallback for messaging and file transfer. This guide is optional: use it only if you prefer to operate your own relay instead of depending on the public ntfy-compatible relay pool and temporary file hosts. Self-hosting needs a public server/domain and TLS; no such infrastructure is required for the built-in fallback.

## 1. Requirements

Use an always-on Linux host/VPS with Docker Compose and OpenSSL, a domain/subdomain whose DNS A/AAAA record points to that host, and inbound TCP ports 80 and 443 open. Caddy is included and obtains/renews TLS certificates automatically. Do not expose the relay's plain port 8080 publicly.

## 2. Deploy the relay once

From the server, copy the repository and run:

```bash
cd FolkChat_v3/relay-server
./deploy.sh relay.your-domain.com
```

The script creates a mode-0600 `.env`, generates a random 256-bit mailbox-encryption secret, starts the relay and Caddy, and checks `https://relay.your-domain.com/healthz`. It keeps the same secret across redeployments; **back up `relay-server/.env` securely**. Losing `MAILBOX_ENCRYPTION_KEY` makes the queued offline-mailbox database unreadable, so the relay refuses to overwrite it. The app's end-to-end keys are separate from this relay-storage key.

Queued envelopes are stored only as end-to-end ciphertext, while the mailbox snapshot is additionally encrypted at rest with AES-256-GCM. Offline queued messages expire after seven days by default. The server still sees source/destination routing public keys, delivery timing, ciphertext sizes and traffic volume; it cannot decrypt the message/file payload.

Check the health endpoint:

```bash
curl -fsS https://relay.your-domain.com/healthz
```

The client endpoint is `wss://relay.your-domain.com/ws`.

## 3. Build an APK with your own relay address (optional)

On the build machine, from the Android project root:

```bash
./scripts/build-wan-release.sh wss://relay.your-domain.com/ws
```

This script checks the public health endpoint first and embeds the exact WSS address in `BuildConfig.FOLKCHAT_RELAY_URL` before running the release build. If the endpoint is not live, it refuses to produce an APK that falsely appears WAN-ready. Install that same APK on the devices; **end users do not need to fill in Settings → Relay server**. A manual per-device URL remains available for developers testing a separate relay, but is not part of normal setup.

This source bundle includes a bootstrap `gradlew`; on an internet-connected build machine it restores the standard wrapper on first use. Android SDK Platform and dependency availability are still required to compile the APK.

## 4. Verify with two physical devices

1. Add each other's FolkChat identity and compare the identity fingerprint through a trusted separate channel.
2. Keep phone A on cellular and phone B on Wi-Fi. Send a text, image, and large document in both directions.
3. Switch one connected phone from Wi-Fi to cellular, wait for authenticated reconnect, and send again.
4. Close the recipient app, send a normal text, then reopen it and confirm queued delivery.
5. For an interrupted media transfer, check progress, acknowledgement, retry, and final SHA-256 verification. Large-file transfer resume after a process restart is not implemented.

## 5. Network scope

- When configured, the self-hosted relay has priority for end-to-end encrypted message/control packets and supported chunk transfers.
- If it is unset or unavailable, the app falls back to pairwise-secret ntfy topics and temporary file hosting. See `PUBLIC_WAN_TRANSPORT.md` for the privacy model and service limits.
- The self-hosted relay does not queue media chunks while the recipient is offline; recipient must be online/accept the transfer. Its ordinary message mailbox has bounded retention.
- Call signaling can use the relay, while voice/video media uses WebRTC with ICE/STUN. Some networks require a TURN server; configure its URLs and credentials in the encrypted in-app settings. The relay does not itself relay call media.
- Bluetooth/Wi-Fi local routes remain available when devices can reach each other locally.

## FolkChat v3 UI and transfer behavior

- The conversation hub uses the sage/forest theme from the UI showcase, with Chats, Calls, People, and Settings navigation, a new-conversation/group menu, and group conversation tiles.
- Group chats are encrypted client-side fan-out: text and supported message controls are sent separately to each member. Group file attachments and group calls are not implemented in this version.
- File transfers use a bounded window of receiver-acknowledged chunks, retry each missing chunk, and verify the completed file's SHA-256 digest before the sender shows delivery success. A Retry still restarts the transfer; durable byte-offset resume after an app/process restart is not implemented.
- Received images, videos, PDFs, and bounded text/code files open in FolkChat's in-app viewer. Unsupported types can be opened using another installed app.
- Voice-message recording now has a live timer, pulsing microphone/recording indicator, and animated waveform bars. The local video preview is bound to CameraX's `PreviewView`.

## What is and is not global

- **Text messages:** use the self-hosted relay if configured; otherwise, compact end-to-end encrypted packets go through the public no-config transport, subject to public-service cache and rate limits.
- **Photo/video/document/voice-note bytes:** on the public route, each file is AES-GCM encrypted locally and uploaded as an opaque temporary blob after the receiver accepts. The decryption key is sent inside a separate end-to-end encrypted envelope. If interrupted, retry is available; durable partial-file resume is not yet implemented.
- **Voice/video calls:** the current media transport is LAN/private-network oriented. The WebSocket relay is not a TURN/WebRTC media server. Cross-country calls need a separate WebRTC + STUN/TURN implementation/deployment.

Never assume WAN works just because Android says “Mobile data on”; use the two-phone delivery tests above. A self-hosted relay can see routing identifiers, packet sizes and timing. Public services can see source IPs, topic activity, transfer size and retention metadata; message contents and uploaded file blobs are encrypted client-side, but providers can still block or drop traffic. The self-hosted service must be maintained and monitored like any internet-facing service.
