# FolkChat v3 — Private. Simple. Yours.

FolkChat is an Android messenger with a local X25519 identity, encrypted vault storage, authenticated message envelopes, and ChaCha20-Poly1305 protected message contents. It supports local Wi-Fi, Bluetooth LE, an optional self-hosted WebSocket relay, and a built-in no-configuration public WAN fallback. The public fallback uses pairwise-secret ntfy topics (host-scoped on community relays) for small end-to-end encrypted packets and short-lived public file hosts for client-side AES-GCM encrypted file blobs. Community-relay copies receive an additional host-specific AES-GCM wrapper. Public providers can observe connection metadata, size and timing; they cannot decrypt the actual message/file contents from relay data alone, but FolkChat does not claim perfect anonymity or to hide all metadata.

> **WAN messaging/files without per-phone setup:** in Auto or online routing mode, if the configured private relay is unavailable or unset and local routes cannot deliver, FolkChat publishes through a three-service ntfy-compatible relay pool (`ntfy.sh`, `ntfy.envs.net`, and `ntfy.adminforge.de`). Community-relay copies use host-specific topics and randomized AES-GCM wrappers; delivery is accepted when at least one provider accepts the packet, but that is not a recipient receipt. For accepted file transfers, the sender encrypts the file locally with AES-GCM, uploads only ciphertext to `0x0.st` (with `tmpfiles.org` as a limited-size fallback), then sends the recipient the URL and decryption key inside the existing end-to-end authenticated packet. No API key, server URL, account or user-supplied backend configuration is required. Public services have quotas, retention rules and no FolkChat delivery SLA; the receiver must be online to accept/download the file, and retry may be needed if a provider rate-limits traffic.

> **Protocol compatibility:** the hardened packet format requires the authenticated envelope protocol on both devices. Older versions that send unsigned envelopes are rejected rather than silently accepted as authenticated messages. Back up the app's exportable information before testing a development build, and do not delete the old installation until you have confirmed migration on a test device.

## Cross-country/mobile-data setup

The built-in public WAN fallback requires no custom configuration. See [`PUBLIC_WAN_TRANSPORT.md`](PUBLIC_WAN_TRANSPORT.md) for the privacy model, service limitations and two-device validation. [`WAN_RELAY_SETUP.md`](WAN_RELAY_SETUP.md) documents the optional self-hosted relay for users who prefer infrastructure they operate themselves.

## Run locally

**Prerequisite:** [Android Studio](https://developer.android.com/studio) with the Android SDK and a compatible JDK.

1. Open this directory in Android Studio and sync the Gradle project. This source bundle includes a bootstrap `gradlew`: on a connected Linux/macOS environment, run `./gradlew --version` once to restore the standard Gradle wrapper files, or run `bash scripts/restore-gradle-wrapper.sh`. The bootstrap requires internet access to download the configured Gradle distribution. On Windows, use Android Studio or run the restore script from Git Bash/WSL.
2. Install Android SDK Platform 36 (and the requested build tools) through Android Studio's SDK Manager. The app cannot compile with only a JDK.
3. The included root `debug.keystore` is for local debug builds only. Release signing requires your own `my-upload-key.jks` (or `KEYSTORE_PATH`) plus `STORE_PASSWORD` and `KEY_PASSWORD`; these secrets are intentionally not included. Never use the debug key to sign a release.
4. Run on an emulator or physical Android device. LAN and WAN calls use WebRTC ICE; default STUN helps discover direct paths, but some networks require valid TURN server credentials in Settings. Calls are intentionally disabled in Tor privacy mode.

## Features

### Messaging
- Text chat with replies, reactions, edit/delete, pin, star, copy, and forwarding.
- Typing indicators and read receipts with privacy controls.
- Per-chat disappearing-message settings. The selected policy applies to messages created after the policy change, not older messages.
- Archived/muted chats, unread counters, request inbox for unknown senders, and block list.
- Authenticated control messages with replay/staleness checks for edits, deletes, pins, reactions, typing, timer updates, profiles, and call signals.

### Media
- Photo, video, voice-note, and document transfers through bounded, receiver-acknowledged chunks. On WAN relay routes, files above 8 MiB use client-side encrypted blobs; files larger than 64 MiB are split into independently authenticated 16 MiB encrypted segments. FolkChat's client ceiling is 100 GiB, but providers may impose much lower upload/retention limits; very large transfers must be tested on real networks.
- SHA-256 validation and AES-GCM tag verification happen before a downloaded public-route file is finalized. Auto-download preferences are applied before starting incoming transfers; incomplete transfers are closed and removed after timeout.
- The media directory is restricted to app-private files and the FileProvider exposes only that directory.
- The relay stores only end-to-end encrypted message envelopes; its offline mailbox snapshot is AES-256-GCM encrypted at rest and queued envelopes expire after seven days by default. The relay still sees routing keys, timing, size and queue metadata.
- **Current limitation:** completed media is still stored as plaintext inside the app-private media directory. App-private storage limits access by other ordinary apps, but this is not file-level encryption at rest. Do not treat media-at-rest encryption as implemented.

### Calls
- WebRTC audio/video media uses ICE-negotiated paths and DTLS-SRTP encryption. End-to-end authenticated call signaling is carried through FolkChat transport.
- Default STUN servers help discover direct paths. Networks with restrictive NAT/firewalls may still require user-configured TURN servers and credentials in Settings → Calls & media transport.
- Calls are disabled while Tor privacy mode is enabled. Validate local camera preview, remote video, renegotiation, Wi-Fi changes, NAT traversal and audio routing on real devices before release.

### Privacy and security
- **Vault:** random 256-bit data key wrapped by an Android Keystore AES-GCM key; the vault itself is authenticated-encrypted. Legacy vault migration occurs only after successful authenticated decryption and parsing. Vault replacement uses a synced temporary file and atomic rename; a failed load refuses to overwrite the original file or generate a replacement identity.
- **App lock:** salted PBKDF2-HMAC-SHA-256 PIN verifier (210,000 iterations), escalating persisted retry delays, cold-start gating, background/inactivity re-checks, optional system biometric, and screenshot protection enabled by default.
- **Chat lock:** lock individual conversations from the chat menu or **Settings → Security center → Chat lock**. Each locked chat asks for the app PIN, never marks messages read until unlock, hides message previews/timestamps/status from the chat list, and suppresses sender/content in message notifications. Per-chat unlock grants are memory-only and clear on app background/process restart/app lock. This is an in-app access gate over the globally encrypted vault, not a separate per-chat encryption key.
- **Identity:** incoming envelopes prove possession of the claimed sender's X25519 private key through a key-agreement-derived HMAC. Old contacts are marked unverified after migration; users must compare fingerprints out of band before marking a contact verified.
- **Safety numbers:** longer fingerprint display than the previous release. A fingerprint is only meaningful when compared with the peer through a trusted separate channel.
- **Backups:** Android cloud backup/device transfer are explicitly excluded.
- **Tor:** off by default, with a SOCKS5 availability probe and fail-closed routing when Tor mode is enabled. Relay URLs should use `wss://`; plain `ws://` is only allowed for `.onion` services with the explicit Tor route. Calls and local broadcast discovery are disabled in Tor privacy mode.

### Networking
- Routing policy: auto, forced offline mesh, or forced online. In Auto mode a configured/authenticated private relay and reachable local routes retain priority; when those fail, the built-in public WAN fallback carries compact end-to-end encrypted packets. Forced-offline mode disables the public internet route.
- The optional self-hosted relay is included under `relay-server/` for deployments that want to operate their own infrastructure. It requires a Node.js 20+ public host (or Docker), persistent storage, public DNS and TLS termination. See `WAN_RELAY_SETUP.md`. With no private relay configured, the public fallback is used automatically; mobile data alone still cannot create a direct peer-to-peer route through carrier NAT/firewalls.
- Wi-Fi socket transport uses read timeouts, a connection cap, bounded length-prefixed frames, and multiple-frame reads per connection.
- Bluetooth GATT writes await connection/write completion rather than reporting success before a write finishes. Authenticated packet acceptance is still a separate step from a local transport write.
- Delivery state becomes delivered only after an authenticated recipient receipt. A local TCP/Bluetooth transport acknowledgement alone is not treated as delivery.
- Manual Wi-Fi peer entries are not used for contact-directed delivery until the endpoint can be explicitly bound to a verified contact; this prevents one manually configured peer from matching every contact.

### Design
- **Warm Sage Light is the new-install default**: warm ivory canvases, sage surfaces, forest-green actions, rounded conversation tiles, a privacy highlight card, and refined profile/settings panels. Deep Forest Dark, System and **AMOLED pure-black** modes are also available.
- **Deep appearance customization** (Settings → Appearance, with a live preview): eight accent palettes (Forest, Emerald, Ocean, Dusk, Sunset, Rose, Amethyst, Graphite), **six font families** (two bundled, see `FONTS_LICENSES.md`), accessibility text size XS→XL, three bubble silhouettes, **seven chat wallpapers** (incl. animated Aurora), **five in-app emblem styles**, **four home-screen launcher icon variants**, haptic-feedback toggle, compact chat density and outgoing-bubble emphasis. All choices persist in the encrypted vault and apply live app-wide. See `UI_CUSTOMIZATION.md`.
- **App Lock that never gets in your way**: monotonic-clock auto-lock (immune to NTP/time-zone jumps), typing- and call-aware idle tracking so the lock never fires mid-message or mid-call, live lockout countdown, per-chat PIN gates with the same haptic keypad, and launcher-alias icon switching with guaranteed-safe component handling.

## Important known limitations before production

- There is no full Room database migration yet. The encrypted JSON vault remains a single snapshot file; frequently changing state can still cause noticeable work on large histories, although media checkpoints and retry loops have been reduced.
- Media files are not encrypted individually at rest (see above).
- Text message encryption still uses the current long-term identity-based envelope scheme; there is no Double Ratchet for text, so text forward secrecy and post-compromise recovery are not provided.
- The private relay is not metadata-blind. The public ntfy relay pool uses high-entropy pairwise topics derived from contacts' X25519 shared secret, with host-specific topics and extra wrappers on community relays. Providers still see connecting IPs (unless tunneled), topic activity, timing, size and temporarily cached ciphertext; community operators may log traffic. Temporary file hosts see upload/download IPs, ciphertext sizes and retention metadata. Client-side encryption protects file contents; it does not hide all metadata or guarantee service availability/deletion.
- Bluetooth bonding is not required by a dedicated pairing workflow yet. Packet authentication does not make the radio link confidential by itself.
- Full Android Gradle build, device-level migration, Tor/Orbot integration, background-call, media transfer on multiple routes, relay deployment, and multi-device interoperability tests are required before a release. A source review is not a substitute for those tests.
- The no-configuration WAN path depends on third-party service availability, quotas and retention. It is best-effort, not a managed production service. Some WAN calls still need reachable TURN infrastructure; default public STUN cannot guarantee connectivity through every NAT/firewall.

## Technology

Kotlin · Jetpack Compose · Material 3 · BouncyCastle (X25519, ChaCha20-Poly1305, HKDF, HMAC, Ed25519 primitives) · CameraX · Coil · OkHttp · AndroidX Biometric · minSdk 24 / targetSdk 36.

## UI redesign

The primary screens now share a premium Folk Forest visual system: warm ivory backgrounds, pale sage panels, deep forest actions, consistent rounded shapes, clearer spacing, a custom brand header, a privacy overview card, rounded chat-list tiles, a pill-style bottom bar, a softer message composer, and outlined profile/settings cards. Existing screen callbacks and ViewModel actions remain connected rather than using static mockup content.

## Media picker and privacy cleanup

The media picker supports photos, video, and documents; GIF search and GIF sending have been removed to reduce external dependencies and animated-media processing. On startup, FolkChat removes legacy GIF attachments from its private `files/media` directory and marks those attachment records unavailable. Cleanup is intentionally limited to files owned by FolkChat and does not delete GIFs from Gallery, Downloads, or other apps. The existing FolkChat emblem and launcher artwork are unchanged.

## Reliability update

- Public relay publishes return after the first relay accepts the packet; redundant publishes continue in the background with a bounded timeout.
- Auto routing only trusts a peer discovered recently and matched by its rotating contact tag. Untimestamped manual endpoints are not used to route every contact's traffic.
- Public blob downloads and uploads follow only explicitly allowlisted HTTPS redirects and retry a bounded set of transient HTTP/network failures.
- View-once/view-twice receipts are sent to the original sender and the received view count is bounded to the configured limit.
- Transfer progress persistence is throttled to avoid encrypting/writing the entire vault for every network buffer callback.
- Full Android build and two-device tests remain required before release.

## QR pairing and direct-link trust

- The displayed identity QR is an expiring `fc2` pairing QR with a cryptographically random, one-time token. The device only subscribes to its token-derived inbox while the QR is displayed; no global pairing topic is used.
- The scanner sends a recipient-encrypted, authenticated `PAIR_REQUEST`. The device showing the QR accepts that token for one sender/request ID only, adds that sender as verified, and returns a recipient-encrypted `PAIR_ACK`. The scanner marks the contact verified only after the matching acknowledgement arrives. Retries of the same request are idempotent; the same token cannot be reused for a different sender/request.
- Legacy `sc1` public-key codes still add a contact, but do not auto-mark it verified.
- Direct TCP uses a mutual X25519 proof-of-possession handshake tied to the expected contact public key. Discovered IP/port values are just ephemeral route hints; an IP address is never considered identity, and the receiver rejects direct sockets from unverified/blocked peers before accepting framed payloads.
- First-contact profile/avatar exchange waits for the authenticated pairing ACK; scanning a QR alone does not immediately authorize profile exchange from the scanning device.
- Android apps cannot add a contact IP to the OS firewall without root or a dedicated VPN/firewall service. FolkChat therefore enforces an application-level public-key allow-list rather than dangerously trusting an IP address (which can change, be shared by NAT, or be spoofed).
- Pairing UI uses Jetpack Compose + Material 3 cards, a local bundled Lottie animation, spring-based QR entrance motion, and elevation/soft shadows. Reduce Motion suppresses the Lottie animation and skips the animated entrance.
- Pairing currently requires a working internet delivery path (public token-scoped ntfy inbox or a configured private relay). `Force Offline` is respected and will not silently send the pairing challenge through public WAN. Local direct transfers are preferred after both sides have completed pairing.
