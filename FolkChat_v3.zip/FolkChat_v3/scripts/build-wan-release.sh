#!/usr/bin/env bash
set -euo pipefail

RELAY_URL="${1:-${FOLKCHAT_RELAY_URL:-}}"
if [[ -z "$RELAY_URL" ]]; then
  echo "Usage: FOLKCHAT_RELAY_URL=wss://relay.your-domain.com/ws ./scripts/build-wan-release.sh" >&2
  exit 2
fi
if [[ ! "$RELAY_URL" =~ ^wss://[^/]+/ws$ ]]; then
  echo "Relay URL must be a public TLS WebSocket URL in the form wss://HOST/ws." >&2
  exit 2
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ORIGIN="${RELAY_URL#wss://}"
ORIGIN="${ORIGIN%/ws}"
HEALTH_URL="https://${ORIGIN}/healthz"

command -v curl >/dev/null 2>&1 || { echo "curl is required to verify the relay endpoint." >&2; exit 1; }
echo "Verifying public relay before embedding it into the APK..."
if ! curl --fail --silent --show-error --max-time 8 "$HEALTH_URL"; then
  echo "Relay health check failed. Refusing to create a release that looks WAN-ready but is not." >&2
  exit 1
fi
printf '\n'

if [[ ! -x "$ROOT/gradlew" ]]; then
  echo "Gradle wrapper is missing. Run bash scripts/restore-gradle-wrapper.sh in the project root, then retry." >&2
  exit 1
fi

cd "$ROOT"
export FOLKCHAT_RELAY_URL="$RELAY_URL"
./gradlew :app:assembleRelease
APK="$ROOT/app/build/outputs/apk/release/app-release.apk"
if [[ -f "$APK" ]]; then
  printf '\nWAN-preconfigured APK: %s\n' "$APK"
  printf 'Relay embedded: %s\n' "$RELAY_URL"
  echo "Install this APK on devices; end users do not need to enter a relay URL in Settings."
else
  echo "Gradle completed, but expected APK was not found at: $APK" >&2
  exit 1
fi
