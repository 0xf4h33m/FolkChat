#!/usr/bin/env bash
# The source archive this project came from omitted gradlew and gradle-wrapper.jar.
# Run this once on Linux/macOS to regenerate the standard wrapper files for the
# exact Gradle version declared in gradle/wrapper/gradle-wrapper.properties.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROPERTIES="$ROOT/gradle/wrapper/gradle-wrapper.properties"
RAW_URL="$(sed -n 's/^distributionUrl=//p' "$PROPERTIES" | head -n 1)"
URL="${RAW_URL//\\:/:}"
if [[ -z "$URL" || "$URL" != https://services.gradle.org/distributions/* ]]; then
  echo "Refusing unexpected Gradle distribution URL: $URL" >&2
  exit 1
fi
ZIP_NAME="$(basename "$URL")"
VERSION="${ZIP_NAME%-bin.zip}"
if [[ "$VERSION" == "$ZIP_NAME" ]]; then
  VERSION="${ZIP_NAME%-all.zip}"
fi
if [[ ! "$VERSION" =~ ^gradle-[0-9][0-9A-Za-z.-]*$ ]]; then
  echo "Could not parse Gradle version from $URL" >&2
  exit 1
fi

GRADLE_USER_HOME="${GRADLE_USER_HOME:-$HOME/.gradle}"
BOOTSTRAP_ROOT="$GRADLE_USER_HOME/folkchat-bootstrap"
GRADLE_HOME="$BOOTSTRAP_ROOT/$VERSION"
GRADLE_BIN="$GRADLE_HOME/bin/gradle"

if [[ ! -x "$GRADLE_BIN" ]]; then
  command -v unzip >/dev/null 2>&1 || { echo "Please install unzip first." >&2; exit 1; }
  TMP_DIR="$(mktemp -d)"
  trap 'rm -rf "$TMP_DIR"' EXIT
  ZIP_PATH="$TMP_DIR/$ZIP_NAME"
  if command -v curl >/dev/null 2>&1; then
    curl --fail --location --retry 2 --connect-timeout 15 "$URL" --output "$ZIP_PATH"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$ZIP_PATH" "$URL"
  else
    echo "Install curl or wget to download Gradle." >&2
    exit 1
  fi
  mkdir -p "$BOOTSTRAP_ROOT"
  unzip -q "$ZIP_PATH" -d "$TMP_DIR"
  rm -rf "$GRADLE_HOME"
  mv "$TMP_DIR/$VERSION" "$GRADLE_HOME"
fi

# Generate the wrapper from a temporary empty project so the Android SDK is not
# needed just to restore gradlew/gradlew.bat/the wrapper JAR.
TMP_PROJECT="$(mktemp -d)"
trap 'rm -rf "${TMP_DIR:-}" "$TMP_PROJECT"' EXIT
printf '// temporary Gradle wrapper bootstrap project\n' > "$TMP_PROJECT/build.gradle"
"$GRADLE_BIN" --no-daemon --offline -p "$TMP_PROJECT" wrapper --gradle-version "${VERSION#gradle-}" --distribution-type bin
cp "$TMP_PROJECT/gradlew" "$ROOT/gradlew"
cp "$TMP_PROJECT/gradlew.bat" "$ROOT/gradlew.bat"
cp "$TMP_PROJECT/gradle/wrapper/gradle-wrapper.jar" "$ROOT/gradle/wrapper/gradle-wrapper.jar"
chmod +x "$ROOT/gradlew"
echo "Gradle wrapper restored. Now run: cd \"$ROOT\" && ./gradlew :app:assembleDebug"
