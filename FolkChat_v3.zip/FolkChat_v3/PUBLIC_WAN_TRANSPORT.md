# FolkChat public WAN transport (no configuration)

FolkChat can exchange messages and files between Android phones on different internet connections without a user-provided relay URL, API key, account, or custom configuration. Public transport is a best-effort fallback after private relay/local routes. It is **not** a promise of zero metadata, perfect anonymity, guaranteed delivery, or a substitute for real-device security testing.

## Message delivery across multiple relays

FolkChat sends the same already end-to-end-encrypted packet to three ntfy-compatible services in parallel:

- `ntfy.sh` — official ntfy service; retains the existing packet format for compatibility.
- `ntfy.envs.net` — community-operated ntfy instance.
- `ntfy.adminforge.de` — community-operated ntfy instance.

For each accepted contact, the app derives a high-entropy pairwise topic from the two devices' X25519 shared secret. The community relays use host-specific topics. Their packet copies are wrapped with AES-256-GCM using a host-specific key derived from the peers' X25519 shared secret and a fresh random nonce; this avoids exposing identical message-body bytes across those services. The receiver removes this outer wrapper locally, deduplicates copies by the hash of the original packet, then runs the normal recipient-bound decryption and authentication checks before touching chat state.

A relay operator sees ciphertext, the topic it serves, client IP addresses (unless the connection is tunneled), timing, approximate sizes and online/activity patterns. A relay cannot decrypt an app message from the packet alone or unwrap community-relay copies without a participating device's private identity key. An operator can still record, replay, censor, delay or delete packets; it may also correlate activity using timing/IP information. The ntfy project explicitly warns that community instance operators may log activity and that uptime is not guaranteed. See [ntfy's public instance list and warning](https://docs.ntfy.sh/integrations/) and [official privacy policy](https://docs.ntfy.sh/privacy/).

FolkChat's optional Tor mode uses an existing Orbot SOCKS listener at `127.0.0.1:9050` if enabled and available. It does not install Tor, and it is not enabled automatically. Tor can reduce direct exposure of the user's IP to the destination service, but does not make a compromised endpoint safe or eliminate all traffic-correlation risks.

## File transfer

1. The sender encrypts each file locally with AES-256-GCM and a fresh random key/nonce before upload.
2. Only ciphertext is uploaded to `0x0.st`; if that fails, the app attempts `tmpfiles.org` for files within its smaller size limit.
3. The original filename, file key, nonce and digest travel inside the authenticated end-to-end encrypted FolkChat packet, not in the upload URL. The public host can see the ciphertext size, request IPs, and timing, and can delete or retain blobs.
4. The receiver validates the AES-GCM tag, expected length and SHA-256 before finalizing the file and returning a receipt.

The file-host fallback is redundancy, not a multi-hop anonymity network. Hosts cannot read file contents without the key, but they can see IP/size/timing metadata. Temporary-host expiry/deletion is best effort and controlled by those providers. Completed files in the app's private media directory are not currently encrypted at rest.

## Limits and failure modes

- The relay pool considers the message queued when at least one provider accepts it. This is not a recipient-delivery receipt; the authenticated recipient receipt is the stronger delivery signal.
- Providers can rate-limit, change policy, go offline, or drop messages. Retry may be needed; no service-level guarantee exists.
- Public packets have a 3,500-character Base64 body cap. The outer wrapper adds overhead on community relays, so some near-limit messages may still fit only the official route.
- FolkChat has a 100 GiB client-side segmented-transfer ceiling, but public hosts may impose far lower limits and retention windows. Files above 8 MiB on WAN-relay routes use encrypted blobs; files above 64 MiB are segmented into 16 MiB ciphertext uploads. Segment retries work within the active transfer, but transfer manifests/offsets are not persisted for resuming after process death. The nominal app ceiling is not a guarantee that any provider will accept a transfer of that size.
- The receiver must accept/download before the temporary link expires if the file is not persisted elsewhere.
- Voice/video uses WebRTC media with ICE/STUN. Some NAT/firewall configurations require valid TURN credentials configured in Settings → Calls & media transport; public STUN alone cannot guarantee a path on every network.
- Forced-offline routing does not use these services. Tor mode fails closed for these requests if its local SOCKS proxy is unavailable.

## Validation before release

Install the same build on two physical Android phones on separate networks. Test message delivery while each relay is blocked in turn; verify a message is accepted when any one relay is available; test offline recipient replay/cache behavior, duplicate suppression, file acceptance/rejection, hashes, zero-byte files, rate limiting, network changes, and retry. Verify with packet capture/logging that no file plaintext or file keys are sent to public services. A source review cannot replace Android build, cryptographic review, and real-device integration tests.
