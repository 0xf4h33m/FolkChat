# FolkChat security hardening notes

This note describes changes present in this source snapshot and items that remain open. A static review is not a substitute for a signed Android build and end-to-end device testing.

## Changes in this snapshot

- Replaced deterministic new-install vault encryption key derivation with a random 256-bit data key wrapped by a device Android Keystore AES-GCM key. Removed the deterministic fallback for new installs.
- Added legacy vault migration after authenticated decryption and full JSON parsing. Vault/key files are written to same-directory temporary files, synced, and atomically replaced. An unreadable vault is preserved and never overwritten by a newly generated identity.
- Upgraded PIN verification to salted PBKDF2-HMAC-SHA-256 (210,000 iterations), persisted escalating retry lockouts, moved PIN verification to IO, and re-checks idle lock state on app resume. Fixed cold-start enforcement so an early resume cannot clear the lock before authentication. Screenshot protection defaults on.
- Added persistent per-chat lock controls in Security Settings and the chat overflow menu. Locked conversations use the rate-limited PIN verifier without unlocking the whole app, avoid marking messages read before unlock, hide list previews/timestamps/outgoing status, and suppress both sender and body in system notifications. Per-chat unlock grants are memory-only and clear on background, process start, or app-lock activation. The lock list is persisted in the encrypted vault by public-key rather than contact name.
- Added authenticated packet envelopes derived from X25519 shared-secret possession proofs, reject old unsigned envelope packets, constrain ownership of edit/delete/pin commands, limit stale/replayed control updates, and wait for authenticated recipient receipts before marking a text message delivered.
- Reset legacy contact-verification flags to unverified because earlier versions marked contacts verified without a fingerprint comparison. Fingerprints now display six four-digit groups, and marking verified is an explicit user action.
- Bounded TCP connections/timeouts, socket frame sizes/counts and L1 reassembly sessions; TCP receive handles multiple frames on one connection. Bluetooth sends wait for connection, service discovery and write callbacks.
- Bound media transfer IDs to safe characters, validate sender/contact/message ownership and chunk metadata, cap attachment size and chunk counts, scope in-progress transfers to the sender, ignore duplicate chunk overwrites, respect Never/Wi-Fi-only download settings, and expire incomplete streams. Full encrypted-vault checkpoints occur every 32 chunks instead of on every chunk.
- Added authenticated call setup, ephemeral X25519 media key agreement mixed with static identity DH, ChaCha20-Poly1305 frame protection and sequence/replay checks. Call socket acceptance is gated by call state, known contact, and private IPv4 source; calls and radio discovery are disabled in Tor privacy mode.
- Detects a local SOCKS5 listener on IO rather than assuming port 9050; restricts relay URLs and cleartext; removes a boot permission with no corresponding receiver; avoids duplicate service collectors; scopes camera/microphone foreground service types to active calls.
- Uses the warm sage/ivory theme as the new-install default, enables screenshot protection by default, narrows FileProvider paths to the private media directory, and makes release minification enabled.
- Adds the bundled authenticated WebSocket relay under `relay-server/`, with bounded encrypted offline mailboxes, durable writes, identity challenge authentication, and delivery acknowledgements. The Android client retains queued relay packets until the transport consumer finishes processing the envelope.
- Adds explicit in-chat voice recording errors and cleans up MediaRecorder/file resources if permission or recorder startup fails. The composer visibly toggles between microphone, send, stop, and save-edit actions.
- Fixes the attachment picker lifecycle so selecting a file does not cancel its IO copy, and adds explicit download/retry controls for incoming media that was not auto-downloaded.
- Updates documentation and settings copy so the relay is not falsely described as zero-knowledge and explains that cellular messaging needs a reachable deployed relay configured on both devices.

## UI polish in this snapshot

- Redesigned the home header, navigation bar, privacy highlight, request row, conversation tiles, chat composer, profile identity panel, and settings cards in the sage/ivory + forest-green visual system. Existing ViewModel-backed click handlers and controls are retained.

## Known limitations / release blockers

- The app lock and chat lock are UI access gates. The Android Keystore wrapping key is **not** bound to per-use biometric/PIN authentication; a running/compromised app process can still use the vault key. Chat lock does not add a separate cryptographic key per conversation. A full cryptographic unlock flow requires restructuring startup so encrypted vault data is not loaded until an authentication gate succeeds.
- Completed media is still plaintext at rest under the app-private `files/media` directory. Private storage is not the same as file-level encryption.
- Text messages do not have a Double Ratchet or independent per-message forward secrecy. Call media uses ephemeral DH, but the protocol still depends on successful, authenticated long-term identity agreement at setup.
- The relay still learns subscription/routing public keys, timing, volume and online state. Challenge authentication proves the connecting device controls the claimed identity key; it does not hide routing metadata or make the relay zero-knowledge.
- Discovery tags are rotating but derived from public identity material; someone who already knows a public key can correlate its predictable time-slot tags. No dedicated Bluetooth bonding/pairing flow is enforced.
- Storage remains a single encrypted JSON snapshot instead of Room/SQLite. The main-thread startup vault load and snapshot serialization can still cause latency with large histories. Checkpointing reduces transfer churn but is not a database migration.
- The media protocol is chunked and bounded but does not implement resumable partial transfers across app/process restarts.
- A corrupt/unreadable vault is preserved and writes fail closed, but a polished recovery/import screen is not yet implemented.
- Device-specific Android behavior remains unverified here: calls in background, permission transitions, Tor/Orbot routing, migration of legacy installs, Bluetooth GATT interoperability, and Android 15/16 foreground service restrictions must be tested on real devices.

## Protocol and compatibility

The authenticated envelope requires both sender and recipient to run the hardened protocol version. Unsigned messages from older builds are rejected. Test migration and two-device compatibility on non-production installs before replacing a daily-use build.

## Validation performed for this snapshot

- XML resources and manifest are parsed for well-formedness.
- The pure Kotlin L1 framing implementation is compiled and its bounded framing/reassembly behavior is exercised separately where possible.
- Relay JavaScript syntax checks passed. The X25519/HMAC challenge and mailbox-storage tests passed (4 tests total) with a temporary minimal `ws` module stub used only to load the server module for storage-only tests. Actual WebSocket networking was not exercised because the declared `ws` dependency is not installed.
- XML resources/manifest are well-formed. Targeted Kotlin compiler attempts reach dependency-resolution failures because Android/Compose/WebRTC/OkHttp/coroutine classes are unavailable; the full application has not been type-checked or built. Chat-lock, PIN-gate, list-preview masking, view-limited media counters, and notification-masking paths were reviewed in source; full UI behavior still requires an Android build/device test.
- A full Android Gradle build and emulator/device tests were **not** run in this environment because the Android SDK/system Gradle and the standard Gradle wrapper JAR/distribution are unavailable. This source bundle includes a `gradlew` bootstrap script that restores the standard wrapper on an internet-connected build machine.


## Media picker cleanup

- Removed the online GIF picker, local GIF picker, Tenor integration, API-key wiring, Coil GIF dependency and animated GIF decoder configuration.
- Attachments are checked by MIME/name and by the GIF file signature before acceptance.
- Startup cleanup is scoped to FolkChat's private `files/media` directory and vault entries; it does not delete files owned by other applications.
- Added animated feedback to the attachment error state and retained view-once/view-twice controls.

## WAN/mobile-data reliability update

- Added `FOLKCHAT_RELAY_URL` as an optional build-time default, with a saved per-device relay URL taking precedence. No invented public endpoint is embedded; deploy the included relay first.
- Added an Android default-network callback to the relay client. On Wi-Fi/cellular default-network changes it debounces callbacks, clears stale pending sends, closes the old WebSocket, and reconnects/authenticates over the current network.
- Fixed startup behavior so the background transport service is started again when permissions are already granted on app launch. Camera/microphone grants no longer block internet messaging: when Bluetooth/local-link permissions are missing, the app uses relay-only while the UI is foreground.
- Bumped app version to 2.0 / versionCode 2.
- A built-in no-configuration public WAN fallback now carries compact E2E packets and client-encrypted temporary file blobs; it remains best-effort and needs two-device cellular/Wi-Fi validation. Internet voice/video call media still needs WebRTC/ICE/STUN/TURN infrastructure.


## Multi-relay public WAN hardening

- Expanded public message transport from one ntfy endpoint to three independently operated ntfy-compatible services. Sends run concurrently and report route acceptance if at least one provider accepts the packet; this does not equate to recipient delivery.
- Preserved the official `ntfy.sh` topic/wire format for compatibility. Community relay topics are host-scoped and payloads receive fresh-nonce AES-256-GCM wrappers derived from the peers' X25519 shared secret. The receiver validates the wrapper tag, then deduplicates the inner sealed packet before existing app authentication/decryption.
- Rate-limits are tracked per relay, so one community service returning HTTP 429/503 does not disable the remaining providers. Relay subscriptions include the selected peer per topic to support unwrapping.
- Documented residual metadata leakage, provider trust/availability limits, and the fact that this is redundant relay delivery—not full traffic anonymity or an onion-routed multi-hop system. File contents remain client-side AES-GCM ciphertext sent to the primary temporary host with a second provider as failover.
- Verification limitation: run a full Android Gradle build and two-device integration tests after obtaining the Android SDK, Gradle wrapper and dependencies.


## Second audit pass — 2026-10-16

- Strictly validate hexadecimal text before decoding; previous even/odd-length edge cases could silently truncate malformed input. Contact QR parsing now handles malformed URI percent-encoding without throwing and removes control characters from displayed identity labels.
- Erase ephemeral X25519 private-key, DH shared-secret, AEAD key and packet-authentication key byte arrays as soon as the operation finishes. This reduces retention in managed memory but cannot guarantee zeroization of JVM/crypto-provider internal copies.
- Reject all-zero X25519 shared secrets at the common primitive boundary and require exact 32-byte key sizes.
- Ensure hostile or mistyped relay environment values cannot disable the connection cap or turn mailbox expiry into `NaN` behavior. Invalid optional pairing tokens are rejected rather than silently downgraded to a normal contact addition, and contradictory chunk metadata is rejected without evicting valid in-flight reassembly. Require structurally valid legacy mailbox snapshots before migration so malformed content is not rewritten as an empty store.
- Respect the blocked-peer list during contact/QR addition; the user must explicitly unblock a peer before re-adding. Preserve existing contact state when the same public key is added again.
- Standalone Kotlin crypto/handshake/framing smoke checks passed; full Android build, Android/JUnit suite and live WebSocket integration are still required. This pass does not establish production readiness.
