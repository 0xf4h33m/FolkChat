# FolkChat privacy and local-storage behavior

## Session-only mode on a fresh install

A fresh installation starts in **session-only storage**. Identity, contacts, messages, requests, and preferences are held in the app's running process and are not written to the encrypted vault until the user selects **Settings → Data → Save on this device** and confirms. App-managed temporary attachments and avatars use the cache directory in this mode; Android may evict cache files. Cache storage is still device storage, so this mode should be understood as *no durable chat-vault persistence*, not as “no bytes are ever written to storage.”

After confirmation, FolkChat copies session media into the app-private files directory, rewrites file references, and writes the current state to the encrypted vault. The vault uses a device-bound Android Keystore wrapping key. If that save fails, the app keeps the session copies and attempts to revert file references rather than discarding the originals.

## Upgrades from older versions

If a pre-existing encrypted vault is detected and no explicit storage preference exists, it is preserved and persistent saving remains enabled. This avoids silently abandoning existing chats or overwriting the user's previous storage choice during an upgrade.

## Other privacy defaults

- Profile-photo sharing defaults to off for new settings.
- Notification previews default to hidden for new settings.
- The profile screen allows photo sharing to be disabled and a local profile photo to be removed.
- The app-lock PIN verifier runs off the UI thread; PIN verification is rate-limited and uses PBKDF2-HMAC-SHA-256.
- Launcher disguise options are visual only. They do not make the app, device, peers, or network traffic anonymous.

## Threat-model boundary

Encrypted local storage helps protect the vault at rest, but it does not prevent someone using an already-unlocked device from viewing content. It also cannot conceal metadata visible to peers, the network operator, a relay, Android's package manager, or an observer with device-level/forensic access. Do not treat a pseudonym, hidden notification preview, decoy icon, Tor setting, or local PIN as a guarantee of anonymity.
