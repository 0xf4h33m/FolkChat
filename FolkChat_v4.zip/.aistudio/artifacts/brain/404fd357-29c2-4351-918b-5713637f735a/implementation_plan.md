# FolkChat: Complete UI/UX Redesign & Integration Plan

## Objective
Transform FolkChat into a premium, modern, professional peer-to-peer messaging application matching the FolkChat visual identity while preserving all existing peer-to-peer BLE/LAN networking, X25519 cryptography, local vault storage, and in-app camera QR code scanning functionality.

---

## 1. Design System & Palette
Establish the official FolkChat color palette in `Color.kt` and `Theme.kt`:
- **Primary Forest Green**: `#174A3A`
- **Deep Forest Green**: `#103D31`
- **Secondary Sage Green**: `#92AD96`
- **Light Sage Background**: `#E4EBDD`
- **Warm Ivory Surface**: `#F7F5EA`
- **Card Surface**: `#F0F0E4`
- **Muted Green-Gray**: `#71877A`
- **Primary Text**: `#18372E`
- **Secondary Text**: `#728277`
- **Subtle Borders**: `#D8E0D2`
- **Success Green**: `#378653`
- **Error Red**: `#B94D48`
- **Dark Mode Support**: Organic dark forest tones (`#0F1D18`, `#172922`, `#20382F`, `#2E4E42`) rather than pitch black.

---

## 2. Screen 1: First-Launch Welcome Onboarding Screen
- Create `WelcomeScreen.kt` featuring:
  - Warm ivory surface (`#F7F5EA`) with soft sage-green organic accent curves.
  - Prominent FolkChat logo (`app_logo.jpg`) with natural depth and soft shadows.
  - Heading: **"Welcome to FolkChat"**
  - Tagline: **"Private. Simple. Yours."**
  - Three core pillars:
    - **Zero Cloud**: Sovereign device-to-device communication without servers.
    - **True Privacy**: End-to-end encrypted with rotating cryptographic keys.
    - **Offline Mesh**: Outbox queueing with automatic BLE & LAN sync.
  - Prominent rounded Forest Green button: **"Let's Start →"** with ivory text.
  - Persisted completion flag in `EncryptedVault` so onboarding is only shown on initial launch.

---

## 3. Screen 2: Main Chats Screen & Multi-Tab Navigation
- **Top Bar**: FolkChat logo, clean typography, live link status indicator, interactive search, and quick QR actions.
- **Connection & Privacy Status Card**: Real-time peer status from `TransportCoordinator` ("DIRECT LINKS ACTIVE • X peer(s) in range" vs "BLE & LAN READY • Outbox queued until peers meet").
- **Interactive Search**: Real-time filtering across contacts and messages.
- **Conversation List**: Card surface styling, contact avatar/initials with nearby pulse dot, last message snippet, timestamp, unread badge.
- **Bottom Navigation Bar**:
  - **Chats**: Conversations and direct message threads.
  - **Calls**: Peer-to-peer audio & video call manager with active peer launcher.
  - **Contacts**: Contact list, QR code scanner launcher, safety number inspection.
  - **Settings**: Theme mode (Classic Folk Light, Deep Dark, System), profile name editor, QR code display, outbox queue flush, diagnostics.
- **Floating Action Button**: Forest Green FAB for quick contact pairing.

---

## 4. Screen 3: Direct Messaging (DM) Screen
- **Header**: Back button, contact avatar, connection status ("In Direct Link Range" vs "Offline (Queued)"), Voice & Video Call actions, options menu.
- **Queued Explanation Banner**: Honest, clear explanation of why messages are queued when peers are not in Bluetooth/Wi-Fi range.
- **Message Bubbles**:
  - **Outgoing**: Forest green (`#174A3A`) with ivory text (`#F7F5EA`), delivery status icons (clock for queued, double checks for delivered).
  - **Incoming**: Card surface (`#F0F0E4`) with dark primary text (`#18372E`), subtle sage tint.
- **Input Bar**: Rounded ivory container with sage border, attachment button, camera shortcut, voice note button, and circular Forest Green send button.

---

## 5. Peer-to-Peer Calling UI
- Create `CallDialog.kt` supporting audio & video call simulations over direct link with duration timer, mute/video toggles, and encryption badge.

---

## 6. Verification
- Verify build with `compile_applet`.
- Verify Robolectric tests with `./gradlew :app:testDebugUnitTest`.
