package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SecureChatApp
import com.example.crypto.CryptoEngine
import com.example.crypto.KeyPairBytes
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DiscoveredPeer
import com.example.service.SecureChatForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as SecureChatApp
    private val vault = app.vault
    private val transportCoordinator = app.transportCoordinator

    private val _identity = MutableStateFlow(vault.getIdentityKeyPair())
    val identity: StateFlow<KeyPairBytes> = _identity.asStateFlow()

    private val _displayName = MutableStateFlow(vault.getDisplayName())
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    private val _contacts = MutableStateFlow(vault.getContacts())
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()

    private val _allMessages = MutableStateFlow(vault.getAllMessages())
    val allMessages: StateFlow<List<ChatMessage>> = _allMessages.asStateFlow()

    private val _activeContact = MutableStateFlow<Contact?>(null)
    val activeContact: StateFlow<Contact?> = _activeContact.asStateFlow()

    val discoveredPeers: StateFlow<List<DiscoveredPeer>> = transportCoordinator.allDiscoveredPeers

    private val _themeMode = MutableStateFlow(
        try {
            com.example.ui.theme.AppThemeMode.valueOf(vault.getThemeMode())
        } catch (e: Exception) {
            com.example.ui.theme.AppThemeMode.CLASSIC_LIGHT
        }
    )
    val themeMode: StateFlow<com.example.ui.theme.AppThemeMode> = _themeMode.asStateFlow()

    private val _isOnboardingCompleted = MutableStateFlow(vault.isOnboardingCompleted())
    val isOnboardingCompleted: StateFlow<Boolean> = _isOnboardingCompleted.asStateFlow()

    fun completeOnboarding() {
        vault.setOnboardingCompleted(true)
        _isOnboardingCompleted.value = true
    }

    fun resetOnboarding() {
        vault.setOnboardingCompleted(false)
        _isOnboardingCompleted.value = false
    }

    private val _isServiceRunning = MutableStateFlow(true)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    val activeConversationMessages: StateFlow<List<ChatMessage>> = combine(
        _allMessages,
        _activeContact
    ) { messages, active ->
        if (active == null) emptyList()
        else messages.filter {
            it.conversationPeerPubKeyHex.equals(active.x25519PublicKeyHex, ignoreCase = true)
        }.sortedBy { it.timestampMs }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        // Start foreground service on initialization
        startBackgroundService()

        // Listen for new incoming messages from coordinator
        viewModelScope.launch {
            transportCoordinator.onNewMessageReceived.collect {
                refreshData()
            }
        }
    }

    fun refreshData() {
        _contacts.value = vault.getContacts()
        _allMessages.value = vault.getAllMessages()
        _displayName.value = vault.getDisplayName()
    }

    fun selectContact(contact: Contact?) {
        _activeContact.value = contact
    }

    fun sendMessage(text: String) {
        val active = _activeContact.value ?: return
        if (text.isBlank()) return

        transportCoordinator.queueMessage(active.x25519PublicKeyHex.lowercase().trim(), text.trim())
        refreshData()
    }

    fun addContact(codeOrPubKey: String, name: String): Boolean {
        val trimmed = codeOrPubKey.trim()
        val parsed = CryptoEngine.parseContactCode(trimmed)

        val (pubKeyHex, finalName) = if (parsed != null) {
            Pair(parsed.first.lowercase(), if (name.isNotBlank()) name.trim() else parsed.second)
        } else if (trimmed.length == 64 && trimmed.matches(Regex("^[0-9a-fA-F]+$"))) {
            Pair(trimmed.lowercase(), if (name.isNotBlank()) name.trim() else "Peer " + trimmed.take(6))
        } else {
            return false
        }

        val contact = Contact(
            id = UUID.randomUUID().toString(),
            displayName = finalName,
            x25519PublicKeyHex = pubKeyHex,
            isVerified = true
        )
        vault.addOrUpdateContact(contact)
        refreshData()
        return true
    }

    /**
     * Scans QR code and adds contact directly with the default username embedded in QR code.
     * Automatically opens their conversation.
     */
    fun addContactFromQrCode(qrContent: String): Contact? {
        val trimmed = qrContent.trim()
        val parsed = CryptoEngine.parseContactCode(trimmed)

        val (pubKeyHex, defaultName) = if (parsed != null) {
            Pair(parsed.first.lowercase(), parsed.second.ifBlank { "Peer " + parsed.first.take(6) })
        } else if (trimmed.length == 64 && trimmed.matches(Regex("^[0-9a-fA-F]+$"))) {
            Pair(trimmed.lowercase(), "Peer " + trimmed.take(6))
        } else {
            return null
        }

        val contact = Contact(
            id = UUID.randomUUID().toString(),
            displayName = defaultName,
            x25519PublicKeyHex = pubKeyHex,
            isVerified = true
        )
        vault.addOrUpdateContact(contact)
        refreshData()
        _activeContact.value = contact
        return contact
    }

    fun deleteContact(pubKeyHex: String) {
        vault.deleteContact(pubKeyHex)
        if (_activeContact.value?.x25519PublicKeyHex.equals(pubKeyHex, ignoreCase = true)) {
            _activeContact.value = null
        }
        refreshData()
    }

    fun deleteMessage(messageId: String) {
        vault.deleteMessage(messageId)
        refreshData()
    }

    fun clearChatHistory(contactPubKey: String) {
        vault.clearAllMessagesForContact(contactPubKey)
        refreshData()
    }

    fun updateDisplayName(name: String) {
        vault.setDisplayName(name)
        _displayName.value = name
    }

    fun startBackgroundService() {
        SecureChatForegroundService.start(getApplication())
        _isServiceRunning.value = true
    }

    fun stopBackgroundService() {
        SecureChatForegroundService.stop(getApplication())
        _isServiceRunning.value = false
    }

    fun triggerOutboxFlush() {
        viewModelScope.launch {
            transportCoordinator.flushOutbox()
            refreshData()
        }
    }

    fun registerManualPeer(ipAddress: String) {
        transportCoordinator.socketManager.registerPeerManually(ipAddress)
        triggerOutboxFlush()
    }

    fun setThemeMode(mode: com.example.ui.theme.AppThemeMode) {
        _themeMode.value = mode
        vault.setThemeMode(mode.name)
    }

    fun openSavedNotes() {
        val myPubKey = identity.value.publicKeyHex.lowercase()
        val existing = contacts.value.firstOrNull { it.x25519PublicKeyHex.equals(myPubKey, ignoreCase = true) }
        if (existing != null) {
            _activeContact.value = existing
        } else {
            val self = Contact(
                id = "self_notes",
                displayName = "Saved Notes (Self-Test)",
                x25519PublicKeyHex = myPubKey,
                isVerified = true
            )
            vault.addOrUpdateContact(self)
            refreshData()
            _activeContact.value = self
        }
    }
}
