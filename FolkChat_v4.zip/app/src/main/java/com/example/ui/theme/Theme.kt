package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppThemeMode {
    CLASSIC_LIGHT,
    DEEP_DARK,
    SYSTEM
}

data class CustomChatColors(
    val outgoingBubbleBg: Color,
    val outgoingBubbleBorder: Color,
    val outgoingText: Color,
    val incomingBubbleBg: Color,
    val incomingBubbleBorder: Color,
    val incomingText: Color,
    val statusSuccess: Color,
    val statusWarning: Color,
    val cardElevated: Color,
    val textMuted: Color,
    val primaryBrand: Color,
    val sageAccent: Color,
    val borderSubtle: Color
)

val LocalChatColors = staticCompositionLocalOf {
    CustomChatColors(
        outgoingBubbleBg = LightOutgoingBubble,
        outgoingBubbleBorder = LightOutgoingBubbleBorder,
        outgoingText = LightOutgoingText,
        incomingBubbleBg = LightIncomingBubble,
        incomingBubbleBorder = LightIncomingBubbleBorder,
        incomingText = LightIncomingText,
        statusSuccess = FolkSuccess,
        statusWarning = FolkWarning,
        cardElevated = LightSurfaceElevated,
        textMuted = LightTextMuted,
        primaryBrand = FolkForestGreen,
        sageAccent = FolkSage,
        borderSubtle = LightOutline
    )
}

private val FolkLightColorScheme = lightColorScheme(
    primary = FolkForestGreen,
    onPrimary = FolkWarmIvory,
    primaryContainer = FolkLightSage,
    onPrimaryContainer = FolkDeepForest,
    secondary = FolkSage,
    onSecondary = FolkDeepForest,
    secondaryContainer = FolkLightSage,
    onSecondaryContainer = FolkDeepForest,
    tertiary = FolkSuccess,
    onTertiary = Color.White,
    background = FolkWarmIvory,
    onBackground = FolkTextPrimary,
    surface = FolkCardSurface,
    onSurface = FolkTextPrimary,
    surfaceVariant = FolkLightSage,
    onSurfaceVariant = FolkTextSecondary,
    outline = FolkBorderSubtle,
    outlineVariant = Color(0xFFE2E9DC)
)

private val FolkDarkColorScheme = darkColorScheme(
    primary = FolkSage,
    onPrimary = FolkDeepForest,
    primaryContainer = Color(0xFF1B3B30),
    onPrimaryContainer = Color(0xFFD4E8DC),
    secondary = FolkSage,
    onSecondary = FolkDeepForest,
    secondaryContainer = Color(0xFF1B3B30),
    onSecondaryContainer = Color(0xFFD4E8DC),
    tertiary = Color(0xFF48BB78),
    onTertiary = Color.White,
    background = DarkBg,
    onBackground = DarkTextPrimaryClean,
    surface = DarkSurfaceClean,
    onSurface = DarkTextPrimaryClean,
    surfaceVariant = DarkSurfaceElevatedClean,
    onSurfaceVariant = DarkTextSecondaryClean,
    outline = DarkOutlineClean,
    outlineVariant = Color(0xFF223E34)
)

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode = AppThemeMode.CLASSIC_LIGHT,
    content: @Composable () -> Unit,
) {
    val isDark = when (themeMode) {
        AppThemeMode.CLASSIC_LIGHT -> false
        AppThemeMode.DEEP_DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) FolkDarkColorScheme else FolkLightColorScheme

    val chatColors = if (isDark) {
        CustomChatColors(
            outgoingBubbleBg = DarkOutgoingBubbleClean,
            outgoingBubbleBorder = DarkOutgoingBubbleBorderClean,
            outgoingText = DarkOutgoingTextClean,
            incomingBubbleBg = DarkIncomingBubbleClean,
            incomingBubbleBorder = DarkIncomingBubbleBorderClean,
            incomingText = DarkIncomingTextClean,
            statusSuccess = Color(0xFF48BB78),
            statusWarning = Color(0xFFED8936),
            cardElevated = DarkSurfaceElevatedClean,
            textMuted = DarkTextMutedClean,
            primaryBrand = FolkSage,
            sageAccent = FolkSage,
            borderSubtle = DarkOutlineClean
        )
    } else {
        CustomChatColors(
            outgoingBubbleBg = LightOutgoingBubble,
            outgoingBubbleBorder = LightOutgoingBubbleBorder,
            outgoingText = LightOutgoingText,
            incomingBubbleBg = LightIncomingBubble,
            incomingBubbleBorder = LightIncomingBubbleBorder,
            incomingText = LightIncomingText,
            statusSuccess = FolkSuccess,
            statusWarning = FolkWarning,
            cardElevated = LightSurfaceElevated,
            textMuted = LightTextMuted,
            primaryBrand = FolkForestGreen,
            sageAccent = FolkSage,
            borderSubtle = LightOutline
        )
    }

    CompositionLocalProvider(LocalChatColors provides chatColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
