package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// FolkChat Design System — Core Palette
// ==========================================

// Primary Brand Colors
val FolkForestGreen = Color(0xFF174A3A)      // Primary buttons, selected items, outgoing bubbles
val FolkDeepForest = Color(0xFF103D31)       // Headers, emphasis, dark accents
val FolkSage = Color(0xFF92AD96)             // Secondary sage green, badges, highlights
val FolkLightSage = Color(0xFFE4EBDD)        // Light sage tint background
val FolkWarmIvory = Color(0xFFF7F5EA)        // Warm ivory surfaces, app background, message area
val FolkCardSurface = Color(0xFFF0F0E4)      // Elevated cards, incoming message bubbles
val FolkMutedGreen = Color(0xFF71877A)       // Muted icons and secondary controls
val FolkTextPrimary = Color(0xFF18372E)      // Deep dark green-black for high legibility
val FolkTextSecondary = Color(0xFF728277)    // Readable neutral muted green text
val FolkBorderSubtle = Color(0xFFD8E0D2)     // Natural hairline dividers and card outlines
val FolkSuccess = Color(0xFF378653)          // Verified safety numbers, online links
val FolkError = Color(0xFFB94D48)            // Danger, disconnect, delete actions
val FolkWarning = Color(0xFFC97A2E)          // Outbox queued indicator, warnings

// ==========================================
// Light Theme Tokens (Classic Folk Light)
// ==========================================
val LightBg = FolkWarmIvory
val LightSurface = FolkCardSurface
val LightSurfaceElevated = Color(0xFFFAF8F2)
val LightOutline = FolkBorderSubtle
val LightOutlineSubtle = Color(0xFFEAEFE6)

val LightTextPrimary = FolkTextPrimary
val LightTextSecondary = FolkTextSecondary
val LightTextMuted = FolkMutedGreen

val LightOutgoingBubble = FolkForestGreen
val LightOutgoingBubbleBorder = FolkDeepForest
val LightOutgoingText = FolkWarmIvory

val LightIncomingBubble = FolkCardSurface
val LightIncomingBubbleBorder = FolkBorderSubtle
val LightIncomingText = FolkTextPrimary

// ==========================================
// Dark Theme Tokens (Deep Forest Dark)
// ==========================================
val DarkBg = Color(0xFF0F1E19)               // Rich dark forest background (not pure black)
val DarkSurfaceClean = Color(0xFF152922)     // Deep forest card surface
val DarkSurfaceElevatedClean = Color(0xFF1E3830) // Elevated cards and popups
val DarkOutlineClean = Color(0xFF28483D)     // Subtle borders in dark mode

val DarkTextPrimaryClean = Color(0xFFE8F2EC) // Off-white with gentle sage tint
val DarkTextSecondaryClean = Color(0xFFA5BDB0)
val DarkTextMutedClean = Color(0xFF7A9788)

val DarkOutgoingBubbleClean = Color(0xFF1B4E3E)
val DarkOutgoingBubbleBorderClean = Color(0xFF246350)
val DarkOutgoingTextClean = Color(0xFFF5FAF7)

val DarkIncomingBubbleClean = Color(0xFF19322A)
val DarkIncomingBubbleBorderClean = Color(0xFF244439)
val DarkIncomingTextClean = Color(0xFFE8F2EC)

// ==========================================
// Backward-Compatibility Aliases
// ==========================================
val ClassicNavy = FolkForestGreen
val ClassicNavyDark = FolkDeepForest
val ClassicNavyLight = FolkSage
val ClassicAccent = FolkForestGreen
val ClassicSuccess = FolkSuccess
val ClassicWarning = FolkWarning
val ClassicDanger = FolkError

val MutedBronze = FolkForestGreen
val MutedBronzeDim = FolkLightSage
val TitaniumSteel = FolkMutedGreen
val MutedSage = FolkSage
val MutedAmber = FolkWarning
val MutedCrimson = FolkError

val DarkBackground = DarkBg
val DarkSurface = DarkSurfaceClean
val DarkSurfaceVariant = DarkSurfaceClean
val DarkSurfaceElevated = DarkSurfaceElevatedClean
val DarkOutline = DarkOutlineClean

val TextPrimary = DarkTextPrimaryClean
val TextSecondary = DarkTextSecondaryClean
val TextMuted = DarkTextMutedClean
