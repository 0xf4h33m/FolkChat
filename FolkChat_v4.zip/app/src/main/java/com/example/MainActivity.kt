package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.Contact
import com.example.ui.ChatViewModel
import com.example.ui.components.AddContactDialog
import com.example.ui.components.CallDialog
import com.example.ui.components.ContactProfileDialog
import com.example.ui.components.LinkDiagnosticsDialog
import com.example.ui.components.MyCodeDialog
import com.example.ui.components.QrScannerDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.components.UserProfileDialog
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            MyApplicationTheme(themeMode = themeMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FolkChatAppContent(viewModel)
                }
            }
        }
    }
}

@Composable
fun FolkChatAppContent(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val identity by viewModel.identity.collectAsState()
    val displayName by viewModel.displayName.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val allMessages by viewModel.allMessages.collectAsState()
    val activeContact by viewModel.activeContact.collectAsState()
    val activeMessages by viewModel.activeConversationMessages.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()
    val isServiceRunning by viewModel.isServiceRunning.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsState()

    var showMyCodeDialog by remember { mutableStateOf(false) }
    var showAddContactDialog by remember { mutableStateOf(false) }
    var showUserProfileDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showContactProfileContact by remember { mutableStateOf<Contact?>(null) }
    var showDiagnosticsDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }

    // Direct P2P Call State
    var activeCallContact by remember { mutableStateOf<Contact?>(null) }
    var isCallVideo by remember { mutableStateOf(false) }

    // Bluetooth & Notification Permissions
    val requiredPermissions = remember {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        list
    }

    var hasRequestedPermissions by remember { mutableStateOf(false) }
    var permissionsGranted by remember {
        mutableStateOf(
            requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        permissionsGranted = results.values.all { it }
        if (permissionsGranted) {
            viewModel.startBackgroundService()
        }
    }

    // Camera permission for In-App QR Scanner
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            showQrScannerDialog = true
        } else {
            Toast.makeText(context, "Camera permission needed to scan QR codes", Toast.LENGTH_SHORT).show()
        }
    }

    fun openQrScannerWithPermissionCheck() {
        val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (hasCamera) {
            showQrScannerDialog = true
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    LaunchedEffect(Unit) {
        if (!permissionsGranted && !hasRequestedPermissions) {
            hasRequestedPermissions = true
            permissionLauncher.launch(requiredPermissions.toTypedArray())
        }
    }

    // If onboarding has not been completed, present Screen 1 (Welcome Screen)
    if (!isOnboardingCompleted) {
        WelcomeScreen(
            onStart = { viewModel.completeOnboarding() }
        )
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            if (!permissionsGranted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Offline Links Require Permissions",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Bluetooth & notifications allow discovering peers without internet.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { permissionLauncher.launch(requiredPermissions.toTypedArray()) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(start = 6.dp)
                        ) {
                            Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Screen routing
            if (activeContact != null) {
                ChatScreen(
                    contact = activeContact!!,
                    messages = activeMessages,
                    peers = discoveredPeers,
                    onSendMessage = { text -> viewModel.sendMessage(text) },
                    onDeleteMessage = { msgId -> viewModel.deleteMessage(msgId) },
                    onOpenContactProfile = { showContactProfileContact = activeContact },
                    onBack = { viewModel.selectContact(null) },
                    onStartCall = { contact, isVideo ->
                        activeCallContact = contact
                        isCallVideo = isVideo
                    }
                )
            } else {
                ConversationsScreen(
                    contacts = contacts,
                    messages = allMessages,
                    peers = discoveredPeers,
                    onSelectContact = { contact -> viewModel.selectContact(contact) },
                    onOpenContactProfile = { contact -> showContactProfileContact = contact },
                    onOpenSettings = { showSettingsDialog = true },
                    onOpenQrScanner = { openQrScannerWithPermissionCheck() },
                    onOpenMyCode = { showMyCodeDialog = true },
                    onOpenAddContact = { showAddContactDialog = true },
                    onOpenDiagnostics = { showDiagnosticsDialog = true },
                    onOpenSavedNotes = { viewModel.openSavedNotes() },
                    onStartCall = { contact, isVideo ->
                        activeCallContact = contact
                        isCallVideo = isVideo
                    }
                )
            }
        }
    }

    // Direct P2P Call Dialog
    if (activeCallContact != null) {
        CallDialog(
            contact = activeCallContact!!,
            isVideo = isCallVideo,
            onEndCall = { activeCallContact = null }
        )
    }

    // In-App Camera QR Scanner Modal
    if (showQrScannerDialog) {
        QrScannerDialog(
            onQrCodeDetected = { qrContent ->
                val addedContact = viewModel.addContactFromQrCode(qrContent)
                showQrScannerDialog = false
                if (addedContact != null) {
                    Toast.makeText(
                        context,
                        "Connected with ${addedContact.displayName}",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "Invalid FolkChat QR code format",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            onDismiss = { showQrScannerDialog = false }
        )
    }

    // Settings Dialog with Theme Picker & Outbox Info
    if (showSettingsDialog) {
        SettingsDialog(
            currentTheme = themeMode,
            onSelectTheme = { mode -> viewModel.setThemeMode(mode) },
            onOpenSavedNotes = { viewModel.openSavedNotes() },
            onDismiss = { showSettingsDialog = false }
        )
    }

    // User Profile Dialog
    if (showUserProfileDialog) {
        UserProfileDialog(
            identity = identity,
            displayName = displayName,
            onUpdateName = { newName -> viewModel.updateDisplayName(newName) },
            onDismiss = { showUserProfileDialog = false }
        )
    }

    // Contact Profile Dialog
    if (showContactProfileContact != null) {
        ContactProfileDialog(
            contact = showContactProfileContact!!,
            myPubKey = identity.publicKey,
            onDeleteContact = {
                viewModel.deleteContact(showContactProfileContact!!.x25519PublicKeyHex)
                showContactProfileContact = null
            },
            onClearChat = {
                viewModel.clearChatHistory(showContactProfileContact!!.x25519PublicKeyHex)
                showContactProfileContact = null
                Toast.makeText(context, "Chat history deleted", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showContactProfileContact = null }
        )
    }

    // My Code Dialog
    if (showMyCodeDialog) {
        MyCodeDialog(
            identity = identity,
            displayName = displayName,
            onUpdateName = { newName -> viewModel.updateDisplayName(newName) },
            onDismiss = { showMyCodeDialog = false }
        )
    }

    // Add Contact Dialog
    if (showAddContactDialog) {
        AddContactDialog(
            onAddContact = { code, name -> viewModel.addContact(code, name) },
            onOpenQrScanner = { openQrScannerWithPermissionCheck() },
            onDismiss = { showAddContactDialog = false }
        )
    }

    // Diagnostics Dialog
    if (showDiagnosticsDialog) {
        LinkDiagnosticsDialog(
            peers = discoveredPeers,
            isServiceRunning = isServiceRunning,
            onToggleService = { enable ->
                if (enable) viewModel.startBackgroundService() else viewModel.stopBackgroundService()
            },
            onFlushOutbox = { viewModel.triggerOutboxFlush() },
            onAddManualIp = { ip ->
                viewModel.registerManualPeer(ip)
                Toast.makeText(context, "Direct link registered to $ip", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showDiagnosticsDialog = false }
        )
    }
}
