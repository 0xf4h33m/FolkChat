package com.example.data

enum class MessageStatus {
    QUEUED,
    SENDING,
    DELIVERED,
    FAILED
}

enum class RoutingPolicy {
    AUTO_FALLBACK, // Tries Online Relay when internet is available; automatically falls back to Offline Mesh when offline
    FORCE_OFFLINE, // Air-gapped: Only direct BLE and Local Wi-Fi
    FORCE_ONLINE   // Cloud Relay Only
}

enum class ActiveRouteType(val title: String, val shortLabel: String, val description: String) {
    ONLINE_RELAY(
        title = "Online Secure Relay",
        shortLabel = "Online",
        description = "End-to-end encrypted packet routed across the internet via zero-knowledge relay."
    ),
    OFFLINE_DIRECT_WIFI(
        title = "Direct Wi-Fi Socket",
        shortLabel = "Wi-Fi P2P",
        description = "Air-gapped high-speed socket link on local subnet or Wi-Fi Direct."
    ),
    OFFLINE_BLE_MESH(
        title = "Bluetooth Low Energy Mesh",
        shortLabel = "BLE Mesh",
        description = "Radio proximity link operating with zero internet and zero local network."
    ),
    OFFLINE_STORE_AND_FORWARD(
        title = "Offline Store & Forward",
        shortLabel = "Queued",
        description = "Encrypted in local device vault; auto-dispatches the instant peer is in range or online restored."
    )
}

data class Contact(
    val id: String,
    val displayName: String,
    val x25519PublicKeyHex: String,
    val ed25519PublicKeyHex: String = "",
    val isVerified: Boolean = false,
    val addedAtEpochMs: Long = System.currentTimeMillis(),
    val lastSeenEpochMs: Long = 0L
) {
    val contactCode: String
        get() = "sc1:$x25519PublicKeyHex:$displayName"
}

data class ChatMessage(
    val id: String,
    val conversationPeerPubKeyHex: String,
    val senderPubKeyHex: String,
    val recipientPubKeyHex: String,
    val content: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.QUEUED,
    val isOutgoing: Boolean = true,
    val routeUsed: String = "AUTO"
)

data class DiscoveredPeer(
    val id: String,
    val displayName: String,
    val tagHex: String,
    val linkType: String,
    val rssi: Int = 0,
    val hostAddress: String? = null,
    val port: Int = 0,
    val lastSeenEpochMs: Long = System.currentTimeMillis()
)
