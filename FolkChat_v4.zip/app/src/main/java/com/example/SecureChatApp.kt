package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.EncryptedVault
import com.example.net.transport.TransportCoordinator

class SecureChatApp : Application() {
    companion object {
        const val CHANNEL_SERVICE_ID = "securechat_link_service"
        const val CHANNEL_MESSAGES_ID = "securechat_messages"

        lateinit var instance: SecureChatApp
            private set
    }

    lateinit var vault: EncryptedVault
        private set

    lateinit var transportCoordinator: TransportCoordinator
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        vault = EncryptedVault(this)
        transportCoordinator = TransportCoordinator(this, vault)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE_ID,
                "FolkChat Mesh Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps BLE and local link listening in background"
                setShowBadge(false)
            }

            val messagesChannel = NotificationChannel(
                CHANNEL_MESSAGES_ID,
                "FolkChat Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for incoming peer messages"
                enableVibration(true)
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(serviceChannel)
            notificationManager.createNotificationChannel(messagesChannel)
        }
    }
}
