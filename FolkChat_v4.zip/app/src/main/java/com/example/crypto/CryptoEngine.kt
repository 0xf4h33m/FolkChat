package com.example.crypto

import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.generators.Ed25519KeyPairGenerator
import org.bouncycastle.crypto.generators.HKDFBytesGenerator
import org.bouncycastle.crypto.generators.X25519KeyPairGenerator
import org.bouncycastle.crypto.macs.HMac
import org.bouncycastle.crypto.modes.ChaCha20Poly1305
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.Ed25519KeyGenerationParameters
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters
import org.bouncycastle.crypto.params.HKDFParameters
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.crypto.params.X25519KeyGenerationParameters
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import java.nio.ByteBuffer
import java.security.SecureRandom

data class KeyPairBytes(
    val privateKey: ByteArray,
    val publicKey: ByteArray
) {
    val privateKeyHex: String get() = CryptoEngine.bytesToHex(privateKey)
    val publicKeyHex: String get() = CryptoEngine.bytesToHex(publicKey)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is KeyPairBytes) return false
        return privateKey.contentEquals(other.privateKey) && publicKey.contentEquals(other.publicKey)
    }

    override fun hashCode(): Int = 31 * privateKey.contentHashCode() + publicKey.contentHashCode()
}

data class EncryptedEnvelope(
    val ephemeralPublicKey: ByteArray,
    val nonce: ByteArray,
    val ciphertext: ByteArray
) {
    fun toByteArray(): ByteArray {
        val buffer = ByteBuffer.allocate(ephemeralPublicKey.size + nonce.size + ciphertext.size)
        buffer.put(ephemeralPublicKey)
        buffer.put(nonce)
        buffer.put(ciphertext)
        return buffer.array()
    }

    companion object {
        fun fromByteArray(bytes: ByteArray): EncryptedEnvelope {
            require(bytes.size >= 32 + 12 + 16) { "Envelope too small: ${bytes.size}" }
            val ephPub = bytes.copyOfRange(0, 32)
            val nonce = bytes.copyOfRange(32, 44)
            val cipher = bytes.copyOfRange(44, bytes.size)
            return EncryptedEnvelope(ephPub, nonce, cipher)
        }
    }
}

object CryptoEngine {
    private val secureRandom = SecureRandom()

    fun generateX25519KeyPair(): KeyPairBytes {
        val gen = X25519KeyPairGenerator()
        gen.init(X25519KeyGenerationParameters(secureRandom))
        val pair = gen.generateKeyPair()
        val priv = (pair.private as X25519PrivateKeyParameters).encoded
        val pub = (pair.public as X25519PublicKeyParameters).encoded
        return KeyPairBytes(priv, pub)
    }

    fun generateEd25519KeyPair(): KeyPairBytes {
        val gen = Ed25519KeyPairGenerator()
        gen.init(Ed25519KeyGenerationParameters(secureRandom))
        val pair = gen.generateKeyPair()
        val priv = (pair.private as Ed25519PrivateKeyParameters).encoded
        val pub = (pair.public as Ed25519PublicKeyParameters).encoded
        return KeyPairBytes(priv, pub)
    }

    fun computeSharedSecret(myPrivateKey: ByteArray, peerPublicKey: ByteArray): ByteArray {
        val agreement = X25519Agreement()
        val privParams = X25519PrivateKeyParameters(myPrivateKey, 0)
        val pubParams = X25519PublicKeyParameters(peerPublicKey, 0)
        agreement.init(privParams)
        val secret = ByteArray(agreement.agreementSize)
        agreement.calculateAgreement(pubParams, secret, 0)
        return secret
    }

    fun hkdfSha256(ikm: ByteArray, salt: ByteArray? = null, info: ByteArray? = null, length: Int = 32): ByteArray {
        val hkdf = HKDFBytesGenerator(SHA256Digest())
        hkdf.init(HKDFParameters(ikm, salt, info))
        val output = ByteArray(length)
        hkdf.generateBytes(output, 0, length)
        return output
    }

    fun encryptChaCha20Poly1305(key: ByteArray, nonce: ByteArray, plaintext: ByteArray, associatedData: ByteArray? = null): ByteArray {
        require(key.size == 32) { "Key must be 32 bytes" }
        require(nonce.size == 12) { "Nonce must be 12 bytes" }
        val cipher = ChaCha20Poly1305()
        val params = AEADParameters(KeyParameter(key), 128, nonce, associatedData)
        cipher.init(true, params)
        val output = ByteArray(cipher.getOutputSize(plaintext.size))
        val len = cipher.processBytes(plaintext, 0, plaintext.size, output, 0)
        cipher.doFinal(output, len)
        return output
    }

    fun decryptChaCha20Poly1305(key: ByteArray, nonce: ByteArray, ciphertext: ByteArray, associatedData: ByteArray? = null): ByteArray {
        require(key.size == 32) { "Key must be 32 bytes" }
        require(nonce.size == 12) { "Nonce must be 12 bytes" }
        val cipher = ChaCha20Poly1305()
        val params = AEADParameters(KeyParameter(key), 128, nonce, associatedData)
        cipher.init(false, params)
        val output = ByteArray(cipher.getOutputSize(ciphertext.size))
        val len = cipher.processBytes(ciphertext, 0, ciphertext.size, output, 0)
        val finalLen = cipher.doFinal(output, len)
        return output.copyOf(len + finalLen)
    }

    fun encryptToPeer(recipientPublicKey: ByteArray, plaintext: ByteArray, senderStaticPrivKey: ByteArray? = null): EncryptedEnvelope {
        val ephemeralKeyPair = generateX25519KeyPair()
        val ecdhSecret = computeSharedSecret(ephemeralKeyPair.privateKey, recipientPublicKey)
        val symmetricKey = hkdfSha256(ecdhSecret, salt = "SecureChat-v1".toByteArray(), info = "message-key".toByteArray(), length = 32)
        val nonce = ByteArray(12).apply { secureRandom.nextBytes(this) }
        val ciphertext = encryptChaCha20Poly1305(symmetricKey, nonce, plaintext)
        return EncryptedEnvelope(ephemeralKeyPair.publicKey, nonce, ciphertext)
    }

    fun decryptFromPeer(myPrivateKey: ByteArray, envelope: EncryptedEnvelope): ByteArray {
        val ecdhSecret = computeSharedSecret(myPrivateKey, envelope.ephemeralPublicKey)
        val symmetricKey = hkdfSha256(ecdhSecret, salt = "SecureChat-v1".toByteArray(), info = "message-key".toByteArray(), length = 32)
        return decryptChaCha20Poly1305(symmetricKey, envelope.nonce, envelope.ciphertext)
    }

    /**
     * Computes a rotating 16-byte discovery tag that changes every 15 minutes (epoch slot).
     * Prevents static tracking of BLE beacons and network broadcasts.
     */
    fun computeRotatingTag(sharedSecretOrIdentity: ByteArray, epochSlot: Long = currentEpochSlot()): ByteArray {
        val hmac = HMac(SHA256Digest())
        hmac.init(KeyParameter(sharedSecretOrIdentity))
        val slotBytes = ByteBuffer.allocate(8).putLong(epochSlot).array()
        hmac.update(slotBytes, 0, slotBytes.size)
        val fullTag = ByteArray(hmac.macSize)
        hmac.doFinal(fullTag, 0)
        return fullTag.copyOf(16) // Truncate to 16 bytes for BLE payload efficiency
    }

    fun currentEpochSlot(epochIntervalSec: Long = 900L): Long {
        return (System.currentTimeMillis() / 1000L) / epochIntervalSec
    }

    /**
     * Computes safety number for mutual key verification (12 digits, format: 0000 0000 0000).
     */
    fun computeSafetyNumber(pubKey1: ByteArray, pubKey2: ByteArray): String {
        val sorted = if (bytesToHex(pubKey1) < bytesToHex(pubKey2)) {
            pubKey1 + pubKey2
        } else {
            pubKey2 + pubKey1
        }
        val digest = SHA256Digest()
        digest.update(sorted, 0, sorted.size)
        val hash = ByteArray(digest.digestSize)
        digest.doFinal(hash, 0)

        val num1 = (ByteBuffer.wrap(hash, 0, 4).int.toLong() and 0xFFFFFFFFL) % 10000
        val num2 = (ByteBuffer.wrap(hash, 4, 4).int.toLong() and 0xFFFFFFFFL) % 10000
        val num3 = (ByteBuffer.wrap(hash, 8, 4).int.toLong() and 0xFFFFFFFFL) % 10000

        return String.format("%04d %04d %04d", num1, num2, num3)
    }

    fun parseContactCode(code: String): Pair<String, String>? {
        val parts = code.trim().split(":")
        if (parts.size >= 3 && parts[0] == "sc1") {
            val pubKeyHex = parts[1]
            val name = parts.drop(2).joinToString(":")
            if (pubKeyHex.length == 64 && pubKeyHex.matches(Regex("^[0-9a-fA-F]+$"))) {
                return Pair(pubKeyHex.lowercase(), name)
            }
        }
        return null
    }

    fun bytesToHex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    fun hexToBytes(hex: String): ByteArray {
        val cleaned = hex.trim()
        val result = ByteArray(cleaned.length / 2)
        for (i in result.indices) {
            val index = i * 2
            result[i] = cleaned.substring(index, index + 2).toInt(16).toByte()
        }
        return result
    }
}
