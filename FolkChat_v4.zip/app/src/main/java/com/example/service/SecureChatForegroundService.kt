package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.SecureChatApp
import com.example.data.ChatMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SecureChatForegroundService : Service() {
    companion object {
        private const val NOTIFICATION_ID = 9001
        private const val MESSAGE_NOTIFICATION_BASE_ID = 10000

        const val ACTION_START = "com.example.securechat.START_SERVICE"
        const val ACTION_STOP = "com.example.securechat.STOP_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, SecureChatForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, SecureChatForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SecureChat:BackgroundLock")?.apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L) // 10 min chunks
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = createServiceNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val app = SecureChatApp.instance
        app.transportCoordinator.startTransports()

        // Listen for new messages to trigger heads-up notifications
        serviceScope.launch {
            app.transportCoordinator.onNewMessageReceived.collectLatest { msg ->
                showMessageNotification(msg)
            }
        }

        return START_STICKY
    }

    private fun createServiceNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, SecureChatApp.CHANNEL_SERVICE_ID)
            .setContentTitle("FolkChat Mesh Active")
            .setContentText("Listening for peer links over BLE & Wi-Fi Hotspot")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun showMessageNotification(msg: ChatMessage) {
        val app = SecureChatApp.instance
        val contacts = app.vault.getContacts()
        val senderContact = contacts.firstOrNull { it.x25519PublicKeyHex.equals(msg.senderPubKeyHex, ignoreCase = true) }
        val senderName = senderContact?.displayName ?: "Verified Contact"

        val pendingIntent = PendingIntent.getActivity(
            this,
            msg.id.hashCode(),
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Privacy feature: Option to hide preview or show encrypted notice
        val notification = NotificationCompat.Builder(this, SecureChatApp.CHANNEL_MESSAGES_ID)
            .setContentTitle(senderName)
            .setContentText(msg.content)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        notificationManager.notify(MESSAGE_NOTIFICATION_BASE_ID + (msg.id.hashCode() and 0x7FFF), notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            // Ignore
        }
    }
}
