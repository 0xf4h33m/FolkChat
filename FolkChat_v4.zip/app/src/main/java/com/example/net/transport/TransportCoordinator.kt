package com.example.net.transport

import android.content.Context
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptedEnvelope
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DiscoveredPeer
import com.example.data.EncryptedVault
import com.example.data.MessageStatus
import com.example.net.ble.BleManager
import com.example.net.socket.SocketManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

class TransportCoordinator(
    private val context: Context,
    val vault: EncryptedVault
) {
    companion object {
        private const val TAG = "TransportCoordinator"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val bleManager = BleManager(context)
    val socketManager = SocketManager(context)

    private val _allDiscoveredPeers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val allDiscoveredPeers: StateFlow<List<DiscoveredPeer>> = _allDiscoveredPeers.asStateFlow()

    private val _onNewMessageReceived = MutableSharedFlow<ChatMessage>(extraBufferCapacity = 64)
    val onNewMessageReceived: SharedFlow<ChatMessage> = _onNewMessageReceived.asSharedFlow()

    private var outboxWorkerJob: Job? = null

    init {
        // Observe peers from BLE and Socket
        scope.launch {
            bleManager.discoveredPeers.collectLatest { blePeers ->
                val socketPeers = socketManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }
        scope.launch {
            socketManager.discoveredPeers.collectLatest { socketPeers ->
                val blePeers = bleManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }

        // Listen for incoming payloads from BLE
        scope.launch {
            bleManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "BLE")
            }
        }

        // Listen for incoming payloads from Wi-Fi Socket
        scope.launch {
            socketManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "WIFI_SOCKET")
            }
        }

        startOutboxWorker()
    }

    private fun mergePeers(blePeers: Collection<DiscoveredPeer>, socketPeers: Collection<DiscoveredPeer>) {
        val list = mutableListOf<DiscoveredPeer>()
        list.addAll(blePeers)
        list.addAll(socketPeers)
        _allDiscoveredPeers.value = list.sortedByDescending { it.lastSeenEpochMs }
    }

    fun startTransports() {
        val identity = vault.getIdentityKeyPair()
        bleManager.startAdvertising(identity.publicKey)
        bleManager.startScanning()
        socketManager.start(identity.publicKey)
    }

    fun stopTransports() {
        bleManager.cleanUp()
        socketManager.stop()
    }

    private fun startOutboxWorker() {
        outboxWorkerJob = scope.launch {
            while (isActive) {
                flushOutbox()
                delay(2000)
            }
        }
    }

    suspend fun flushOutbox() {
        val queued = vault.getQueuedOutbox()
        if (queued.isEmpty()) return

        val peers = _allDiscoveredPeers.value
        val contacts = vault.getContacts().associateBy { it.x25519PublicKeyHex.lowercase() }

        val myIdentity = vault.getIdentityKeyPair()
        val myHex = myIdentity.publicKeyHex.lowercase()

        for (msg in queued) {
            val recipientHex = msg.recipientPubKeyHex.lowercase()

            // Self-loopback delivery (e.g. testing or note to self)
            if (recipientHex == myHex) {
                vault.updateMessageStatus(msg.id, MessageStatus.DELIVERED)
                val incomingCopy = msg.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    isOutgoing = false,
                    status = MessageStatus.DELIVERED
                )
                vault.saveMessage(incomingCopy)
                _onNewMessageReceived.tryEmit(incomingCopy)
                continue
            }

            val recipientContact = contacts[recipientHex] ?: continue

            // Determine if recipient is in range
            val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
            val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(recipientPubKeyBytes))

            // Match full 16-byte tag, or 8-byte BLE tag prefix, or manual link
            val peer = peers.firstOrNull { p ->
                p.tagHex.equals(expectedTag, ignoreCase = true) ||
                (p.tagHex.length >= 16 && expectedTag.startsWith(p.tagHex, ignoreCase = true)) ||
                (expectedTag.length >= 16 && p.tagHex.startsWith(expectedTag.take(16), ignoreCase = true)) ||
                (p.linkType == "WIFI_SOCKET" && p.tagHex == "manual")
            }

            if (peer != null) {
                vault.updateMessageStatus(msg.id, MessageStatus.SENDING)
                val success = dispatchMessageToPeer(msg, recipientPubKeyBytes, peer)
                if (success) {
                    vault.updateMessageStatus(msg.id, MessageStatus.DELIVERED)
                } else {
                    vault.updateMessageStatus(msg.id, MessageStatus.QUEUED)
                }
            }
        }
    }

    private suspend fun dispatchMessageToPeer(
        msg: ChatMessage,
        recipientPubKeyBytes: ByteArray,
        peer: DiscoveredPeer
    ): Boolean {
        return try {
            val payloadJson = JSONObject().apply {
                put("type", "CHAT_MSG")
                put("msgId", msg.id)
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("recipientPubKey", msg.recipientPubKeyHex)
                put("text", msg.content)
                put("timestamp", msg.timestampMs)
            }

            val envelope = CryptoEngine.encryptToPeer(
                recipientPublicKey = recipientPubKeyBytes,
                plaintext = payloadJson.toString().toByteArray(Charsets.UTF_8)
            )
            val wireBytes = envelope.toByteArray()

            if (peer.linkType == "WIFI_SOCKET" && peer.hostAddress != null && peer.port > 0) {
                socketManager.sendPayload(peer.hostAddress, peer.port, wireBytes)
            } else if (peer.linkType == "BLE_GATT") {
                bleManager.sendPayloadToDevice(peer.id, wireBytes)
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed dispatching message to peer: ${e.message}")
            false
        }
    }

    fun queueMessage(recipientPubKeyHex: String, text: String): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = text,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.QUEUED,
            isOutgoing = true
        )
        vault.saveMessage(msg)
        scope.launch { flushOutbox() }
        return msg
    }

    private fun handleIncomingRawPayload(rawPayload: ByteArray, linkName: String) {
        try {
            val myIdentity = vault.getIdentityKeyPair()
            val envelope = EncryptedEnvelope.fromByteArray(rawPayload)
            val decryptedBytes = CryptoEngine.decryptFromPeer(myIdentity.privateKey, envelope)
            val json = JSONObject(String(decryptedBytes, Charsets.UTF_8))

            val senderPubKey = json.getString("senderPubKey")
            val text = json.getString("text")
            val msgId = json.getString("msgId")
            val timestamp = json.getLong("timestamp")

            // Privacy rule: "Only people I have added can message me"
            val contacts = vault.getContacts()
            val isKnown = contacts.any { it.x25519PublicKeyHex.equals(senderPubKey, ignoreCase = true) }
            if (!isKnown) {
                Log.w(TAG, "Dropped message from unknown sender: $senderPubKey (Message request inbox off by default)")
                return
            }

            val incomingMessage = ChatMessage(
                id = msgId,
                conversationPeerPubKeyHex = senderPubKey,
                senderPubKeyHex = senderPubKey,
                recipientPubKeyHex = myIdentity.publicKeyHex,
                content = text,
                timestampMs = timestamp,
                status = MessageStatus.DELIVERED,
                isOutgoing = false
            )

            vault.saveMessage(incomingMessage)
            _onNewMessageReceived.tryEmit(incomingMessage)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt incoming payload from $linkName: ${e.message}")
        }
    }
}
