# FolkChat v2 app icon

The uploaded FolkChat emblem is wired into all Android launcher icon paths:

- `app/src/main/AndroidManifest.xml` references `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`.
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` and `ic_launcher_round.xml` use the adaptive foreground/background resources (Android 8.0+).
- Legacy launcher PNGs are present at mdpi, hdpi, xhdpi, xxhdpi, and xxxhdpi.
- The foreground logo and legacy bitmaps were generated from the provided transparent FolkChat emblem. The icon background is pale sage (`#BCC7B7`) for contrast and is shared by adaptive and legacy icons.
- `app_logo.webp` remains the in-app logo used by the welcome and conversation header screens.

After installing an APK built from this project, Android may cache the previous launcher icon. If it appears unchanged, uninstall the development build (only after backing up any local app data you need), reinstall the new build, or clear the launcher cache.
