package com.example.net.framing

import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.CRC32
import kotlin.random.Random

data class FrameChunk(
    val messageId: Long,
    val totalChunks: Int,
    val chunkIndex: Int,
    val data: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is FrameChunk) return false
        return messageId == other.messageId &&
                totalChunks == other.totalChunks &&
                chunkIndex == other.chunkIndex &&
                data.contentEquals(other.data)
    }

    override fun hashCode(): Int {
        var result = messageId.hashCode()
        result = 31 * result + totalChunks
        result = 31 * result + chunkIndex
        result = 31 * result + data.contentHashCode()
        return result
    }
}

object L1Framer {
    const val MAGIC: Int = 0x53434631 // "SCF1"
    const val HEADER_SIZE: Int = 4 + 8 + 2 + 2 + 2 + 4 // 22 bytes
    private const val MAX_PAYLOAD_PER_CHUNK: Int = 4096
    private const val MAX_ACTIVE_SESSIONS: Int = 4
    private const val MAX_TOTAL_CHUNKS: Int = 1024
    private const val MAX_FRAME_DATA_BYTES: Int = 4096
    private const val SESSION_TIMEOUT_MS: Long = 60_000L

    private class ReassemblySession(
        val messageId: Long,
        val totalChunks: Int,
        var createdAtMs: Long = System.currentTimeMillis()
    ) {
        val chunks = arrayOfNulls<ByteArray>(totalChunks)
        var receivedCount = 0

        fun isComplete(): Boolean = receivedCount == totalChunks

        fun assemble(): ByteArray {
            var totalLen = 0
            for (chunk in chunks) {
                totalLen += chunk?.size ?: 0
            }
            val result = ByteArray(totalLen)
            var offset = 0
            for (chunk in chunks) {
                if (chunk != null) {
                    System.arraycopy(chunk, 0, result, offset, chunk.size)
                    offset += chunk.size
                }
            }
            return result
        }
    }

    private val activeSessions = ConcurrentHashMap<Long, ReassemblySession>()

    fun slicePayload(payload: ByteArray, maxChunkPayloadSize: Int = 180, messageId: Long = Random.nextLong()): List<ByteArray> {
        require(maxChunkPayloadSize > 0) { "Chunk size must be > 0" }
        val effectivePayloadSize = maxChunkPayloadSize.coerceAtMost(MAX_PAYLOAD_PER_CHUNK)
        val totalChunks = if (payload.isEmpty()) 1 else (payload.size + effectivePayloadSize - 1) / effectivePayloadSize
        require(totalChunks in 1..MAX_TOTAL_CHUNKS) { "Payload needs too many frames" }

        val frames = mutableListOf<ByteArray>()
        var offset = 0
        for (i in 0 until totalChunks) {
            val length = if (payload.isEmpty()) 0 else (payload.size - offset).coerceAtMost(effectivePayloadSize)
            val chunkData = if (length > 0) payload.copyOfRange(offset, offset + length) else ByteArray(0)
            offset += length

            // Calculate CRC32 of payload data
            val crc = CRC32()
            crc.update(chunkData)
            val crcValue = crc.value.toInt()

            val buffer = ByteBuffer.allocate(HEADER_SIZE + chunkData.size)
            buffer.putInt(MAGIC)
            buffer.putLong(messageId)
            buffer.putShort(totalChunks.toShort())
            buffer.putShort(i.toShort())
            buffer.putShort(chunkData.size.toShort())
            buffer.putInt(crcValue)
            buffer.put(chunkData)

            frames.add(buffer.array())
        }
        return frames
    }

    fun parseFrame(frameBytes: ByteArray): FrameChunk? {
        if (frameBytes.size < HEADER_SIZE) return null
        val buffer = ByteBuffer.wrap(frameBytes)
        val magic = buffer.int
        if (magic != MAGIC) return null

        val messageId = buffer.long
        val totalChunks = buffer.short.toInt() and 0xFFFF
        val chunkIndex = buffer.short.toInt() and 0xFFFF
        val payloadLen = buffer.short.toInt() and 0xFFFF
        val expectedCrc = buffer.int

        if (totalChunks !in 1..MAX_TOTAL_CHUNKS || chunkIndex >= totalChunks) return null
        if (payloadLen > MAX_FRAME_DATA_BYTES || buffer.remaining() != payloadLen) return null

        val payload = ByteArray(payloadLen)
        buffer.get(payload)

        val crc = CRC32()
        crc.update(payload)
        if (crc.value.toInt() != expectedCrc) {
            return null // Corrupted frame
        }

        return FrameChunk(messageId, totalChunks, chunkIndex, payload)
    }

    fun ingestChunk(chunk: FrameChunk): ByteArray? {
        cleanupStaleSessions()
        if (chunk.totalChunks !in 1..MAX_TOTAL_CHUNKS || chunk.chunkIndex !in 0 until chunk.totalChunks ||
            chunk.data.size > MAX_FRAME_DATA_BYTES) return null

        val session = activeSessions[chunk.messageId] ?: run {
            if (activeSessions.size >= MAX_ACTIVE_SESSIONS) return null
            activeSessions.putIfAbsent(chunk.messageId, ReassemblySession(chunk.messageId, chunk.totalChunks))
                ?: activeSessions[chunk.messageId]
                ?: return null
        }
        if (session.totalChunks != chunk.totalChunks) {
            activeSessions.remove(chunk.messageId)
            return null
        }
        synchronized(session) {
            if (chunk.chunkIndex < session.totalChunks && session.chunks[chunk.chunkIndex] == null) {
                session.chunks[chunk.chunkIndex] = chunk.data
                session.receivedCount++
            }
            if (session.isComplete()) {
                activeSessions.remove(chunk.messageId)
                return session.assemble()
            }
        }
        return null
    }

    private fun cleanupStaleSessions() {
        val now = System.currentTimeMillis()
        val iterator = activeSessions.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.createdAtMs > SESSION_TIMEOUT_MS) {
                iterator.remove()
            }
        }
    }

    fun clearSessions() {
        activeSessions.clear()
    }
}
