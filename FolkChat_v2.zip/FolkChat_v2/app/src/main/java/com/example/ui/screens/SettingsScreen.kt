package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DisappearTimer
import com.example.data.MediaAutoDownload
import com.example.data.NotificationPreviewMode
import com.example.data.RoutingPolicy
import com.example.ui.ChatViewModel
import com.example.ui.components.ChangePinDialog
import com.example.ui.components.PeerAvatar
import com.example.ui.components.PinSetupDialog
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.LocalChatColors

/**
 * Settings hub: Security Center, Privacy, Notifications, Media, Network
 * (relay + Tor), Appearance and Data. All state flows from the ViewModel.
 */
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onOpenDiagnostics: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    val routingPolicy by viewModel.routingPolicy.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val networkTypeName by viewModel.networkTypeName.collectAsState()
    val relayConnected by viewModel.onlineRelay.isConnected.collectAsState()
    val relayError by viewModel.onlineRelay.lastError.collectAsState()
    val effectiveRelayUrl = viewModel.onlineRelay.configuredRelayUrl
    val themeMode by viewModel.themeMode.collectAsState()
    val blockedPeers by viewModel.blockedPeers.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val torProbe by viewModel.torProbeResult.collectAsState()
    val chatColors = LocalChatColors.current

    var showPinSetup by remember { mutableStateOf(false) }
    var showChangePin by remember { mutableStateOf(false) }
    var showBlocked by remember { mutableStateOf(false) }
    var showChatLockManager by remember { mutableStateOf(false) }
    var openChatLockManagerAfterPin by remember { mutableStateOf(false) }
    var showRelayEditor by remember { mutableStateOf(false) }
    var lockNotice by remember { mutableStateOf<String?>(null) }

    val appLock = viewModel.appLock
    val hasPin = appLock.hasPin()
    val canBiometric = appLock.canUseBiometric()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 2.dp)
        ) {
            Text(
                "Make FolkChat yours",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.4).sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Privacy, appearance and device controls",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        // ---------------------------------------------------------
        // Security Center
        // ---------------------------------------------------------
        SectionHeader("Security center")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(chatColors.cardElevated)
                .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(18.dp))
        ) {
            // App lock master row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (settings.appLockEnabled) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "App lock",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        when {
                            settings.appLockEnabled && hasPin -> "Locked with PIN" +
                                (if (settings.biometricEnabled && canBiometric) " + biometrics" else "")
                            settings.appLockEnabled -> "Locked with biometrics"
                            else -> "Require PIN or biometrics to open FolkChat"
                        },
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = settings.appLockEnabled,
                    onCheckedChange = { enabled ->
                        if (enabled) {
                            if (hasPin || canBiometric) {
                                appLock.setEnabled(true)
                                viewModel.refreshSettings()
                            } else {
                                // Guide the user to create a PIN first.
                                showPinSetup = true
                            }
                        } else {
                            appLock.setEnabled(false)
                            viewModel.refreshSettings()
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = MaterialTheme.colorScheme.primary,
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // PIN management
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (hasPin) showChangePin = true else showPinSetup = true
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Password,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        if (hasPin) "Change PIN" else "Set 6-digit PIN",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        if (hasPin) "Your unlock PIN is stored as a salted hash" else "Create an offline unlock PIN",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }

            // Per-conversation lock management
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (hasPin) {
                            showChatLockManager = true
                        } else {
                            openChatLockManagerAfterPin = true
                            showPinSetup = true
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Chat lock", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        if (settings.lockedChatKeys.isEmpty()) "Protect individual conversations with your PIN"
                        else "${settings.lockedChatKeys.size} conversation${if (settings.lockedChatKeys.size == 1) "" else "s"} protected · previews hidden",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }

            // Biometrics
            if (canBiometric) {
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Biometric unlock", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Fingerprint or face instead of the PIN", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = settings.biometricEnabled,
                        onCheckedChange = { enabled ->
                            appLock.setBiometricEnabled(enabled)
                            viewModel.refreshSettings()
                        },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Auto lock
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text("Auto-lock", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                Text("Lock FolkChat after this much inactivity", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AutoLockChip("Immediately", 0L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("30 s", 30_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("1 min", 60_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                    AutoLockChip("5 min", 300_000L, settings.autoLockMillis) {
                        appLock.setAutoLockMillis(it); viewModel.refreshSettings()
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Blocked peers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showBlocked = true }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Blocked peers", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        if (blockedPeers.isEmpty()) "No blocked peers" else "${blockedPeers.size} blocked",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
        }

        // ---------------------------------------------------------
        // Privacy
        // ---------------------------------------------------------
        SectionHeader("Privacy")
        SettingsCard {
            ToggleRow(
                icon = Icons.Default.RemoveRedEye,
                title = "Read receipts",
                subtitle = "Send ✓✓ when you read messages",
                checked = settings.readReceipts
            ) { enabled ->
                viewModel.updateSettings { it.copy(readReceipts = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Sync,
                title = "Typing indicators",
                subtitle = "Show when you are typing",
                checked = settings.typingIndicators
            ) { enabled ->
                viewModel.updateSettings { it.copy(typingIndicators = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Lock,
                title = "Block screenshots",
                subtitle = "Hide FolkChat content in the app switcher and block screen capture",
                checked = settings.screenshotProtection
            ) { enabled ->
                viewModel.updateSettings { it.copy(screenshotProtection = enabled) }
            }
        }

        // ---------------------------------------------------------
        // Notifications
        // ---------------------------------------------------------
        SectionHeader("Notifications")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Message previews", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("What notifications reveal about new messages", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Column {
                    RadioOption("Full preview", "Show sender and message text", settings.notificationPreviewMode == NotificationPreviewMode.FULL) {
                        viewModel.updateSettings { it.copy(notificationPreviewMode = NotificationPreviewMode.FULL) }
                    }
                    RadioOption("Sender only", "Show sender name, hide message text", settings.notificationPreviewMode == NotificationPreviewMode.SENDER_ONLY) {
                        viewModel.updateSettings { it.copy(notificationPreviewMode = NotificationPreviewMode.SENDER_ONLY) }
                    }
                    RadioOption("Hidden", "Only \"New message\"", settings.notificationPreviewMode == NotificationPreviewMode.HIDDEN) {
                        viewModel.updateSettings { it.copy(notificationPreviewMode = NotificationPreviewMode.HIDDEN) }
                    }
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Notifications,
                title = "Notification sound",
                subtitle = "Play the default notification sound",
                checked = settings.notificationSound
            ) { enabled ->
                viewModel.updateSettings { it.copy(notificationSound = enabled) }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)
            ToggleRow(
                icon = Icons.Default.Notifications,
                title = "Vibration",
                subtitle = "Vibrate for new messages and calls",
                checked = settings.notificationVibrate
            ) { enabled ->
                viewModel.updateSettings { it.copy(notificationVibrate = enabled) }
            }
        }

        // ---------------------------------------------------------
        // Media
        // ---------------------------------------------------------
        SectionHeader("Media")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-download media", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Incoming photos, videos and documents", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                RadioOption("Always", "Download on any connection", settings.mediaAutoDownload == MediaAutoDownload.ALWAYS) {
                    viewModel.updateSettings { it.copy(mediaAutoDownload = MediaAutoDownload.ALWAYS) }
                }
                RadioOption("Wi-Fi or LAN only", "Save mobile data", settings.mediaAutoDownload == MediaAutoDownload.WIFI_OR_LAN) {
                    viewModel.updateSettings { it.copy(mediaAutoDownload = MediaAutoDownload.WIFI_OR_LAN) }
                }
                RadioOption("Never", "Download manually per message", settings.mediaAutoDownload == MediaAutoDownload.NEVER) {
                    viewModel.updateSettings { it.copy(mediaAutoDownload = MediaAutoDownload.NEVER) }
                }
            }
        }

        // ---------------------------------------------------------
        // Network & Routing
        // ---------------------------------------------------------
        SectionHeader("Network & routing")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isInternetAvailable) Icons.Default.Cloud else Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Routing policy", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("$networkTypeName · persisted across restarts", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                RadioOption("Auto (recommended)", "Use relay if configured; otherwise local Wi-Fi/Bluetooth", routingPolicy == RoutingPolicy.AUTO_FALLBACK) {
                    viewModel.setRoutingPolicy(RoutingPolicy.AUTO_FALLBACK)
                }
                RadioOption("Force online relay", "Cloud relay only", routingPolicy == RoutingPolicy.FORCE_ONLINE) {
                    viewModel.setRoutingPolicy(RoutingPolicy.FORCE_ONLINE)
                }
                RadioOption("Force offline mesh", "Air-gapped: BLE & Wi-Fi only", routingPolicy == RoutingPolicy.FORCE_OFFLINE) {
                    viewModel.setRoutingPolicy(RoutingPolicy.FORCE_OFFLINE)
                }
            }
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Relay URL
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRelayEditor = true }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Radar, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Relay server", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        when {
                            effectiveRelayUrl.isBlank() -> "Not configured — internet chat unavailable"
                            relayConnected -> "Connected · mobile-data messaging ready"
                            !relayError.isNullOrBlank() -> relayError.orEmpty()
                            else -> "Connecting… tap to edit relay URL"
                        },
                        fontSize = 11.sp,
                        color = when {
                            relayConnected -> com.example.ui.theme.FolkSuccess
                            effectiveRelayUrl.isBlank() || !relayError.isNullOrBlank() -> com.example.ui.theme.FolkWarning
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            // Tor routing — OFF by default
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (settings.torRoutingEnabled) Icons.Default.VpnKey else Icons.Default.VpnKey,
                        contentDescription = null,
                        tint = if (settings.torRoutingEnabled) chatColors.presenceOnline else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Tor routing", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text(
                            if (settings.torRoutingEnabled) "Relay traffic tunnels through Orbot (Tor)" else "Off — connect to the relay directly",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = settings.torRoutingEnabled,
                        onCheckedChange = { enabled ->
                            viewModel.setTorRoutingEnabled(enabled)
                        },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
                if (settings.torRoutingEnabled) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        torProbe ?: "Checking for Orbot…",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = chatColors.borderSubtle)

            SettingsActionRow(Icons.Default.Sync, "Link diagnostics", "Mesh & transport status") { onOpenDiagnostics() }
        }

        // ---------------------------------------------------------
        // Appearance
        // ---------------------------------------------------------
        SectionHeader("Appearance")
        SettingsCard {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Brightness6, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Theme", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                        Text("Warm sage light, deep forest dark, or system theme", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip("Light", themeMode == AppThemeMode.CLASSIC_LIGHT) { viewModel.setThemeMode(AppThemeMode.CLASSIC_LIGHT) }
                    ThemeChip("Dark", themeMode == AppThemeMode.DEEP_DARK) { viewModel.setThemeMode(AppThemeMode.DEEP_DARK) }
                    ThemeChip("System", themeMode == AppThemeMode.SYSTEM) { viewModel.setThemeMode(AppThemeMode.SYSTEM) }
                }
            }
        }

        // ---------------------------------------------------------
        // Data
        // ---------------------------------------------------------
        SectionHeader("Data")
        SettingsCard {
            SettingsActionRow(Icons.Default.Bookmark, "Saved Notes", "Encrypted personal vault") { viewModel.openSavedNotes() }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            "FolkChat · Private messaging, by design.\nConnect by QR or public key · No phone number required.",
            fontSize = 11.sp,
            lineHeight = 16.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(modifier = Modifier.height(80.dp))
    }

    // ---------------- Dialogs ----------------

    if (showPinSetup) {
        PinSetupDialog(
            appLock = appLock,
            onDone = {
                showPinSetup = false
                if (openChatLockManagerAfterPin) {
                    openChatLockManagerAfterPin = false
                    showChatLockManager = true
                } else {
                    appLock.setEnabled(true)
                }
                viewModel.refreshSettings()
            },
            onDismiss = {
                showPinSetup = false
                openChatLockManagerAfterPin = false
            }
        )
    }

    if (showChangePin) {
        ChangePinDialog(
            appLock = appLock,
            onDone = {
                showChangePin = false
                viewModel.refreshSettings()
            },
            onDismiss = { showChangePin = false }
        )
    }

    if (showChatLockManager) {
        com.example.ui.components.ChatLockManagerDialog(
            contacts = contacts,
            lockedKeys = settings.lockedChatKeys,
            hasPin = appLock.hasPin(),
            onSetLocked = { contact, locked ->
                val changed = appLock.setChatLocked(contact.x25519PublicKeyHex, locked)
                viewModel.refreshSettings()
                changed
            },
            onDismiss = {
                showChatLockManager = false
                viewModel.refreshSettings()
            }
        )
    }

    if (showBlocked) {
        BlockedListDialog(
            blocked = blockedPeers,
            onUnblock = { key -> viewModel.unblockPeer(key) },
            onDismiss = { showBlocked = false }
        )
    }

    if (showRelayEditor) {
        RelayUrlDialog(
            initial = effectiveRelayUrl,
            onSave = { url ->
                viewModel.setRelayUrl(url)
                showRelayEditor = false
            },
            onDismiss = { showRelayEditor = false }
        )
    }

    lockNotice?.let {
        AlertDialog(
            onDismissRequest = { lockNotice = null },
            title = { Text("App lock") },
            text = { Text(it) },
            confirmButton = { TextButton(onClick = { lockNotice = null }) { Text("OK") } }
        )
    }
}

// ---------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------

@Composable
private fun SectionHeader(title: String) {
    Text(
        title,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 8.dp, top = 18.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    val chatColors = LocalChatColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(chatColors.cardElevated)
            .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(18.dp))
    ) {
        content()
    }
}

@Composable
private fun ToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary
            )
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun RadioOption(title: String, subtitle: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onSelect,
            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Column {
            Text(title, fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AutoLockChip(label: String, value: Long, current: Long, onSelect: (Long) -> Unit) {
    val selected = current == value
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onSelect(value) }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onSelect: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onSelect() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---------------------------------------------------------------------
// Dialogs
// ---------------------------------------------------------------------

@Composable
fun BlockedListDialog(
    blocked: List<Pair<String, String>>,
    onUnblock: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Blocked peers", fontWeight = FontWeight.SemiBold) },
        text = {
            if (blocked.isEmpty()) {
                Text(
                    "No blocked peers. Block someone from their profile or a message request.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    blocked.forEach { (key, name) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PeerAvatar(name = name, avatarPath = null, size = 36.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text("${key.take(16)}…", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { onUnblock(key) }) {
                                Text("Unblock", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun RelayUrlDialog(
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var url by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Relay server", fontWeight = FontWeight.SemiBold) },
        text = {
            Column {
                Text(
                    "Global chat needs a deployed public FolkChat relay. Use the same wss://YOUR_HOST/ws URL on both phones, even if they are in different countries. You can configure it here per phone, or set FOLKCHAT_RELAY_URL at build time for a preconfigured app. Message contents are encrypted, but the relay can observe routing identifiers, packet size and timing. Prefer TLS (wss://); use .onion only through Tor.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    singleLine = true,
                    placeholder = { Text("wss://your-host.example/ws") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(url.trim()) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
