package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.ui.security.AppLockManager
import com.example.ui.theme.CallStageBg
import com.example.ui.theme.CallStageBgDeep
import com.example.ui.theme.FolkErrorDark
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkWarmIvory

/**
 * Full-screen App Lock gate. Deep forest stage, 6-dot PIN indicator and a
 * native-feeling numeric keypad with haptics; auto biometric prompt on show.
 */
@Composable
fun LockScreen(
    appLock: AppLockManager,
    activity: FragmentActivity,
    onUnlocked: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var verifying by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current

    val hasPin = remember { appLock.hasPin() }
    val canBiometric = remember { appLock.settings().biometricEnabled && appLock.canUseBiometric() }

    fun tryBiometric() {
        val launched = appLock.authenticateWithBiometric(activity, onSuccess = onUnlocked)
        if (!launched) {
            errorText = "Biometric unavailable — enter your PIN"
        }
    }

    LaunchedEffect(Unit) {
        if (canBiometric) tryBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(CallStageBg, CallStageBgDeep))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Emblem
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(FolkSage.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Fingerprint,
                    contentDescription = null,
                    tint = FolkSage,
                    modifier = Modifier.size(34.dp)
                )
            }
            Spacer(modifier = Modifier.height(22.dp))
            Text(
                "FolkChat is locked",
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = FolkWarmIvory
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                if (hasPin) "Enter your 6-digit PIN" else "Confirm your identity to continue",
                fontSize = 13.sp,
                color = FolkSage
            )

            Spacer(modifier = Modifier.height(30.dp))

            // 6-dot PIN indicator
            PinDots(count = 6, filled = pin.length, isError = errorText != null)

            errorText?.let {
                Spacer(modifier = Modifier.height(10.dp))
                Text(it, color = FolkErrorDark, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(34.dp))

            if (hasPin) {
                NumericKeypad(
                    onDigit = { digit ->
                        if (!verifying && pin.length < 6) {
                            val enteredPin = pin + digit
                            pin = enteredPin
                            errorText = null
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            if (enteredPin.length == 6) {
                                verifying = true
                                scope.launch {
                                    val accepted = withContext(Dispatchers.IO) { appLock.verifyPin(enteredPin) }
                                    verifying = false
                                    if (accepted) {
                                        onUnlocked()
                                    } else {
                                        val remaining = appLock.settings().pinLockoutUntilMs - System.currentTimeMillis()
                                        errorText = if (remaining > 0L) "Too many attempts. Retry in ${((remaining + 999L) / 1000L)}s." else "Incorrect PIN. Try again."
                                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        pin = ""
                                    }
                                }
                            }
                        }
                    },
                    onBackspace = {
                        if (!verifying && pin.isNotEmpty()) pin = pin.dropLast(1)
                        errorText = null
                    },
                    showBiometric = canBiometric,
                    onBiometric = { tryBiometric() }
                )
            } else {
                // No PIN configured: only the biometric path remains.
                if (canBiometric) {
                    androidx.compose.material3.Button(
                        onClick = { tryBiometric() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = FolkSage,
                            contentColor = CallStageBgDeep
                        ),
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.padding(4.dp))
                        Text("Unlock with biometrics", fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    Text(
                        "No unlock method available.\nDisable App Lock from Settings after signing in.",
                        fontSize = 12.sp,
                        color = FolkSage,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

/** Row of six PIN dots; filled dots reveal entry progress. */
@Composable
fun PinDots(count: Int = 6, filled: Int, isError: Boolean = false) {
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        repeat(count) { i ->
            val active = i < filled
            val color = when {
                isError -> FolkErrorDark
                active -> FolkWarmIvory
                else -> FolkSage.copy(alpha = 0.35f)
            }
            Box(
                modifier = Modifier
                    .size(13.dp)
                    .clip(CircleShape)
                    .background(color)
            )
        }
    }
}

/**
 * Native-feeling numeric keypad, themed for the deep lock stage.
 * Bottom row: blank, 0, backspace (or biometric when available).
 */
@Composable
fun NumericKeypad(
    onDigit: (String) -> Unit,
    onBackspace: () -> Unit,
    showBiometric: Boolean = false,
    onBiometric: () -> Unit = {}
) {
    val haptics = LocalHapticFeedback.current
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9")
        ).forEach { rowKeys ->
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                rowKeys.forEach { key ->
                    KeypadKey(key = key) {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDigit(key)
                    }
                }
            }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(72.dp))
            KeypadKey(key = "0") {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onDigit("0")
            }
            Box(modifier = Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                if (showBiometric) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(FolkSage.copy(alpha = 0.16f))
                            .clickable { onBiometric() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Fingerprint,
                            contentDescription = "Unlock with biometrics",
                            tint = FolkSage,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                } else {
                    Icon(
                        Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Backspace",
                        tint = FolkSage,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .clickable {
                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onBackspace()
                            }
                            .padding(14.dp)
                    )
                }
            }
        }
        // When biometrics replaced the backspace slot, keep backspace accessible.
        if (showBiometric) {
            Icon(
                Icons.AutoMirrored.Filled.Backspace,
                contentDescription = "Backspace",
                tint = FolkSage.copy(alpha = 0.7f),
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onBackspace()
                    }
                    .padding(8.dp)
            )
        }
    }
}

@Composable
private fun KeypadKey(key: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(FolkSage.copy(alpha = 0.10f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            key,
            fontSize = 26.sp,
            fontWeight = FontWeight.Medium,
            color = FolkWarmIvory
        )
    }
}
