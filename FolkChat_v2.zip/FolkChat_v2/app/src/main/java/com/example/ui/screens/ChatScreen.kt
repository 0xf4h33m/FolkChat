package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.Gif
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shortcut
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.crypto.CryptoEngine
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DisappearTimer
import com.example.data.DiscoveredPeer
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import com.example.data.MessageStatus
import com.example.data.TransferState
import com.example.data.ViewLimit
import com.example.ui.components.PeerAvatar
import com.example.ui.components.formatChatDivider
import com.example.ui.theme.FolkError
import com.example.ui.theme.FolkForestGreen
import com.example.ui.theme.FolkSage
import com.example.ui.theme.FolkSuccess
import com.example.ui.theme.FolkWarning
import com.example.ui.theme.LocalChatColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val QUICK_REACTIONS = listOf("❤️", "👍", "😂", "😮", "😢", "🙏")

/** LazyColumn item model: day dividers interleaved with messages. */
private sealed interface ChatListItem {
    data class DayDivider(val label: String) : ChatListItem
    data class MessageItem(val message: ChatMessage) : ChatListItem
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    contact: Contact,
    messages: List<ChatMessage>,
    peers: List<DiscoveredPeer>,
    isInternetAvailable: Boolean = true,
    onSendMessage: (String) -> Unit,
    onSendMessageWithMeta: ((String, String?, String?, String?) -> Unit)? = null,
    onDeleteMessage: (String) -> Unit,
    onEditMessage: ((String, String) -> Unit)? = null,
    onDeleteForEveryone: ((String) -> Unit)? = null,
    onTogglePin: ((String) -> Unit)? = null,
    onToggleReaction: ((String, String) -> Unit)? = null,
    onSendAttachment: ((MediaAttachment, String) -> Unit)? = null,
    onCancelTransfer: ((String) -> Unit)? = null,
    onRetryTransfer: ((String) -> Unit)? = null,
    resolveLocalFile: ((MediaAttachment?) -> File?)? = null,
    onOpenContactProfile: () -> Unit,
    onBack: () -> Unit,
    onStartCall: ((Contact, Boolean) -> Unit)? = null,
    // v2 additions
    contactsForForward: List<Contact> = emptyList(),
    onToggleStar: ((String) -> Unit)? = null,
    onForward: ((String, String) -> Unit)? = null,
    onConsumeView: ((String) -> Unit)? = null,
    onSetDisappearTimer: ((DisappearTimer) -> Unit)? = null,
    onTypingSignal: (() -> Unit)? = null,
    isPeerTyping: Boolean = false,
    peerLastReadMs: Long = 0L,
    readReceiptsEnabled: Boolean = true,
    compactChat: Boolean = false,
    isChatLocked: Boolean = false,
    onLockChat: (() -> Unit)? = null,
    onExternalActivityLaunch: (() -> Unit)? = null,
    onExternalActivityResult: (() -> Unit)? = null,
    allowOnlineGifSearch: Boolean = true
) {
    BackHandler { onBack() }

    val chatColors = LocalChatColors.current
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    var showMenu by remember { mutableStateOf(false) }
    var showQueueInfoBanner by remember { mutableStateOf(false) }
    var showAttachSheet by remember { mutableStateOf(false) }
    var showGifPicker by remember { mutableStateOf(false) }
    var forwardTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var showDisappearSheet by remember { mutableStateOf(false) }
    var viewOnceTarget by remember { mutableStateOf<ChatMessage?>(null) }

    // Voice message recorder
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordPath by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var recordElapsedMs by remember { mutableLongStateOf(0L) }
    var recordTotalMs by remember { mutableLongStateOf(0L) }
    var voiceError by remember { mutableStateOf<String?>(null) }

    fun stopRecordingAndSend() {
        val rec = recorder ?: return
        voiceError = null
        val path = recordPath
        val elapsed = recordElapsedMs
        recorder = null
        recordPath = null
        recording = false
        recordElapsedMs = 0L
        try { rec.stop() } catch (_: Exception) {}
        try { rec.release() } catch (_: Exception) {}
        if (path != null) {
            val f = File(path)
            if (f.exists() && f.length() > 0L) {
                onSendAttachment?.invoke(
                    MediaAttachment(
                        id = UUID.randomUUID().toString(),
                        kind = MediaKind.VOICE,
                        fileName = f.name,
                        mimeType = "audio/mp4",
                        sizeBytes = f.length(),
                        durationMs = if (elapsed > 0) elapsed else recordTotalMs,
                        localPath = f.absolutePath,
                        transferState = TransferState.PENDING
                    ),
                    ""
                )
            }
        }
    }

    fun discardRecording() {
        val rec = recorder ?: return
        voiceError = null
        val path = recordPath
        recorder = null
        recordPath = null
        recording = false
        recordElapsedMs = 0L
        try { rec.stop() } catch (_: Exception) {}
        try { rec.release() } catch (_: Exception) {}
        path?.let { File(it).delete() }
    }

    fun startRecording() {
        if (recorder != null) return
        var createdRecorder: MediaRecorder? = null
        var createdPath: String? = null
        voiceError = null
        try {
            val dir = File(context.filesDir, "media").apply { mkdirs() }
            val path = File(dir, "voice_${UUID.randomUUID()}.m4a").absolutePath
            @Suppress("DEPRECATION")
            val rec = MediaRecorder()
            createdRecorder = rec
            createdPath = path
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(64_000)
            rec.setAudioSamplingRate(16_000)
            rec.setOutputFile(path)
            rec.setMaxDuration(300_000)
            rec.prepare()
            rec.start()
            recorder = rec
            recordPath = path
            recording = true
            recordElapsedMs = 0L
            recordTotalMs = 0L
        } catch (e: Exception) {
            try { createdRecorder?.release() } catch (_: Exception) {}
            createdPath?.let { File(it).delete() }
            recorder = null
            recordPath = null
            recording = false
            voiceError = "Couldn't start recording. Check microphone access and try again."
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        onExternalActivityResult?.invoke()
        if (granted) startRecording()
        else voiceError = "Microphone permission is required to record voice messages."
    }

    LaunchedEffect(recording) {
        if (recording) {
            val startedAt = System.currentTimeMillis()
            while (recording) {
                recordElapsedMs = System.currentTimeMillis() - startedAt
                recordTotalMs = recordElapsedMs
                delay(300)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            recorder?.let {
                try { it.stop() } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
        }
    }

    // Messaging tools state
    var replyTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var editTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var reactionTarget by remember { mutableStateOf<ChatMessage?>(null) }

    // Search state
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val focusManagerVal = focusManager

    val isSelf = contact.id == "self_notes"

    val isNearby = remember(peers, contact, isSelf) {
        if (isSelf) true
        else {
            try {
                val pubBytes = CryptoEngine.hexToBytes(contact.x25519PublicKeyHex)
                val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(pubBytes))
                peers.any { p ->
                    p.tagHex.equals(expectedTag, ignoreCase = true) ||
                        (p.tagHex.length >= 16 && expectedTag.startsWith(p.tagHex, ignoreCase = true)) ||
                        (expectedTag.length >= 16 && p.tagHex.startsWith(expectedTag.take(16), ignoreCase = true)) ||
                        (p.linkType == "WIFI_SOCKET" && p.tagHex == "manual")
                }
            } catch (e: Exception) {
                false
            }
        }
    }

    val hasQueuedMessages = remember(messages) {
        messages.any { it.status == MessageStatus.QUEUED }
    }

    val displayMessages = remember(messages, searchQuery) {
        if (searchQuery.isBlank()) messages
        else messages.filter {
            it.content.contains(searchQuery, ignoreCase = true) &&
                !it.isDeleted
        }
    }

    // Chat list items with day dividers between dates.
    val chatListItems = remember(displayMessages) {
        val out = mutableListOf<ChatListItem>()
        var lastDay = -1
        val cal = java.util.Calendar.getInstance()
        for (m in displayMessages) {
            cal.timeInMillis = m.timestampMs
            val day = cal.get(java.util.Calendar.DAY_OF_YEAR) + cal.get(java.util.Calendar.YEAR) * 1000
            if (day != lastDay) {
                out.add(ChatListItem.DayDivider(formatChatDivider(m.timestampMs)))
                lastDay = day
            }
            out.add(ChatListItem.MessageItem(m))
        }
        out
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LaunchedEffect(searchQuery) {
        if (searchQuery.isNotBlank() && displayMessages.isNotEmpty()) {
            listState.animateScrollToItem(0)
        }
    }

    LaunchedEffect(editTarget) {
        if (editTarget != null) {
            inputText = editTarget?.content ?: ""
        }
    }

    val submitMessage = {
        val text = inputText
        if (text.isNotBlank()) {
            if (editTarget != null) {
                onEditMessage?.invoke(editTarget!!.id, text)
                editTarget = null
            } else {
                val reply = replyTarget
                if (reply != null && onSendMessageWithMeta != null) {
                    onSendMessageWithMeta(
                        text,
                        reply.id,
                        reply.previewText,
                        if (reply.isOutgoing) "You"
                        else contact.displayName
                    )
                } else {
                    onSendMessage(text)
                }
                replyTarget = null
            }
            inputText = ""
        }
        focusManagerVal.clearFocus()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    if (searchOpen) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search in chat", fontSize = 14.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = chatColors.searchField,
                                unfocusedContainerColor = chatColors.searchField,
                                focusedBorderColor = chatColors.sageAccent,
                                unfocusedBorderColor = chatColors.borderSubtle
                            ),
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear search")
                                    }
                                }
                            }
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { onOpenContactProfile() }
                        ) {
                            PeerAvatar(
                                name = contact.displayName,
                                avatarPath = contact.avatarPath,
                                size = 40.dp,
                                isOnline = isNearby || isInternetAvailable,
                                showPresence = !isSelf
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    if (isSelf) "Saved Notes" else contact.displayName,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (isChatLocked) {
                                        Text(
                                            "PIN protected · re-locks on exit",
                                            fontSize = 11.sp,
                                            color = chatColors.presenceOnline,
                                            fontWeight = FontWeight.Medium
                                        )
                                    } else if (isPeerTyping) {
                                        Text(
                                            "typing…",
                                            fontSize = 11.sp,
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                            color = chatColors.presenceOnline,
                                            fontWeight = FontWeight.Medium
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when {
                                                        isSelf -> chatColors.presenceOnline
                                                        isNearby -> chatColors.presenceOnline
                                                        isInternetAvailable -> chatColors.presenceAway
                                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                    }
                                                )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = when {
                                                isSelf -> "Encrypted personal vault"
                                                isNearby -> "Online · direct mesh link"
                                                isInternetAvailable -> "Online · E2EE relay"
                                                else -> "Offline · messages queue"
                                            },
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (searchOpen) {
                            searchOpen = false
                            searchQuery = ""
                        } else onBack()
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    if (!isSelf) {
                        IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) searchQuery = "" }) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (onStartCall != null) {
                            IconButton(onClick = { onStartCall(contact, false) }) {
                                Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { onStartCall(contact, true) }) {
                                Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More Options", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("View profile & safety number") },
                                onClick = { showMenu = false; onOpenContactProfile() }
                            )
                            if (onLockChat != null && !isSelf) {
                                DropdownMenuItem(
                                    text = { Text(if (isChatLocked) "Lock this chat now" else "Lock this chat") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    onClick = { showMenu = false; onLockChat() }
                                )
                            }
                            if (!isSelf) {
                                DropdownMenuItem(
                                    text = { Text("Search messages") },
                                    onClick = { showMenu = false; searchOpen = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Disappearing messages") },
                                    onClick = { showMenu = false; showDisappearSheet = true }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Why messages are queued") },
                                onClick = { showMenu = false; showQueueInfoBanner = !showQueueInfoBanner }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = chatColors.topBar)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
        ) {
            AnimatedVisibility(
                visible = hasQueuedMessages || showQueueInfoBanner,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, FolkWarning.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = FolkWarning, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Message queued in encrypted local outbox. FolkChat will auto-deliver it over BLE/LAN as soon as this peer comes into range.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 15.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (searchOpen && searchQuery.isNotBlank()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "${displayMessages.size} match${if (displayMessages.size == 1) "" else "es"}",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            val pinnedMessages = remember(messages) { messages.filter { it.isPinned && !it.isDeleted } }

            if (pinnedMessages.isNotEmpty() && searchQuery.isBlank()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.PushPin,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = pinnedMessages.last().previewText,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (displayMessages.isEmpty() && searchQuery.isNotBlank()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No messages match \"$searchQuery\"",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = FolkSage, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Private conversation · Encrypted messages",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    items(chatListItems, key = { 
                        when (it) {
                            is ChatListItem.DayDivider -> "divider_${it.label}_${it.hashCode()}"
                            is ChatListItem.MessageItem -> it.message.id
                        }
                    }) { listItem ->
                        when (listItem) {
                            is ChatListItem.DayDivider -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = listItem.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(chatColors.searchField)
                                            .padding(horizontal = 10.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            is ChatListItem.MessageItem -> {
                                val message = listItem.message
                                if (message.isSystemEvent) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = message.systemEvent ?: "",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(chatColors.searchField)
                                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                        )
                                    }
                                } else {
                                    MessageBubble(
                                        message = message,
                                        highlight = searchQuery,
                                        isSelfNotes = isSelf,
                                        peerLastReadMs = peerLastReadMs,
                                        readReceiptsEnabled = readReceiptsEnabled,
                                        compact = compactChat,
                                        onReply = { replyTarget = message; editTarget = null },
                                        onEdit = { editTarget = message; replyTarget = null },
                                        onCopy = { clipboardManager.setText(AnnotatedString(message.previewText)) },
                                        onDeleteLocal = { onDeleteMessage(message.id) },
                                        onDeleteForAll = { onDeleteForEveryone?.invoke(message.id) ?: onDeleteMessage(message.id) },
                                        onPin = { onTogglePin?.invoke(message.id) },
                                        onStar = { onToggleStar?.invoke(message.id) },
                                        onForward = { forwardTarget = message },
                                        onReact = { emoji -> onToggleReaction?.invoke(message.id, emoji) },
                                        onPickReaction = { reactionTarget = message },
                                        onOpenViewOnce = { viewOnceTarget = message },
                                        resolveLocalFile = resolveLocalFile,
                                        onCancelTransfer = { onCancelTransfer?.invoke(message.id) },
                                        onRetryTransfer = { onRetryTransfer?.invoke(message.id) }
                                    )
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(8.dp)) }
                }
            }

            // Edit / reply context strip
            val contextMessage = editTarget ?: replyTarget
            AnimatedVisibility(visible = contextMessage != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (editTarget != null) Icons.Default.Edit else Icons.Default.Reply,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                if (editTarget != null) "Editing message"
                                else "Replying to ${contextMessage?.let { if (it.isOutgoing) "yourself" else contact.displayName }}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                contextMessage?.previewText.orEmpty(),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = {
                            if (editTarget != null) { editTarget = null; inputText = "" }
                            replyTarget = null
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            voiceError?.let { error ->
                Text(
                    text = error,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp
                )
            }

            AnimatedVisibility(visible = recording || recordElapsedMs > 0L) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = FolkError.copy(alpha = 0.12f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(FolkError)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recording voice message… ${formatDurationShort(recordElapsedMs)}",
                            fontSize = 12.sp,
                            color = FolkError,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            "Cancel",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.clickable { discardRecording() }.padding(4.dp)
                        )
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                color = chatColors.topBar,
                tonalElevation = 3.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isSelf && onSendAttachment != null) {
                        IconButton(onClick = { showAttachSheet = true }) {
                            Icon(
                                Icons.Default.AttachFile,
                                contentDescription = "Attach",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { 
                            inputText = it
                            if (it.isNotBlank()) onTypingSignal?.invoke()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTagCompat("chat_input_text_field"),
                        placeholder = {
                            Text(
                                when {
                                    editTarget != null -> "Edit message…"
                                    isSelf -> "Write a private note..."
                                    else -> "Message..."
                                },
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = chatColors.searchField,
                            unfocusedContainerColor = chatColors.searchField,
                            focusedBorderColor = chatColors.sageAccent,
                            unfocusedBorderColor = chatColors.borderSubtle
                        ),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    FilledIconButton(
                        onClick = {
                            if (recording) {
                                stopRecordingAndSend()
                            } else if (editTarget != null || inputText.isNotBlank()) {
                                submitMessage()
                            } else {
                                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                if (hasMic) startRecording() else {
                                    onExternalActivityLaunch?.invoke()
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = if (recording) FolkError else FolkForestGreen,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTagCompat("chat_send_button")
                    ) {
                        Icon(
                            imageVector = when {
                                recording -> Icons.Default.Stop
                                editTarget != null -> Icons.Default.Check
                                inputText.isNotBlank() -> Icons.AutoMirrored.Filled.Send
                                else -> Icons.Default.Mic
                            },
                            contentDescription = when {
                                recording -> "Stop and send voice message"
                                editTarget != null -> "Save edit"
                                inputText.isNotBlank() -> "Send message"
                                else -> "Record voice message"
                            },
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    if (showAttachSheet && onSendAttachment != null) {
        AttachmentSheet(
            onDismiss = { showAttachSheet = false },
            onExternalActivityLaunch = { onExternalActivityLaunch?.invoke() },
            onExternalActivityResult = { onExternalActivityResult?.invoke() },
            onBrowseGifLibrary = {
                showAttachSheet = false
                showGifPicker = true
            },
            onSend = { attachment ->
                onSendAttachment(attachment, inputText.trim())
                inputText = ""
                showAttachSheet = false
            }
        )
    }

    if (showGifPicker && onSendAttachment != null) {
        OnlineGifPickerSheet(
            allowOnlineGifSearch = allowOnlineGifSearch,
            onDismiss = { showGifPicker = false },
            onSend = { attachment ->
                onSendAttachment(attachment, inputText.trim())
                inputText = ""
                showGifPicker = false
            }
        )
    }

    reactionTarget?.let { target ->
        ReactionPickerSheet(
            onDismiss = { reactionTarget = null },
            onPick = { emoji ->
                onToggleReaction?.invoke(target.id, emoji)
                reactionTarget = null
            }
        )
    }

    // Forward picker
    forwardTarget?.let { target ->
        ForwardMessageDialog(
            contacts = contactsForForward.filter { it.id != "self_notes" },
            onForward = { targetContact ->
                onForward?.invoke(target.id, targetContact.x25519PublicKeyHex)
                forwardTarget = null
            },
            onDismiss = { forwardTarget = null }
        )
    }

    // View-once / view-twice media viewer
    viewOnceTarget?.let { target ->
        ViewOnceMediaDialog(
            message = target,
            resolveLocalFile = resolveLocalFile,
            onDismiss = {
                onConsumeView?.invoke(target.id)
                viewOnceTarget = null
            }
        )
    }

    // Disappearing messages timer picker
    if (showDisappearSheet) {
        DisappearTimerSheet(
            currentSeconds = contact.disappearAfterSec,
            onSelect = { timer ->
                onSetDisappearTimer?.invoke(timer)
                showDisappearSheet = false
            },
            onDismiss = { showDisappearSheet = false }
        )
    }
}

private fun Modifier.testTagCompat(tag: String): Modifier = this.then(
    Modifier.testTag(tag)
)

// ------------------------------------------------------------------
// Message bubble
// ------------------------------------------------------------------

@Composable
private fun MessageBubble(
    message: ChatMessage,
    highlight: String,
    isSelfNotes: Boolean,
    peerLastReadMs: Long = 0L,
    readReceiptsEnabled: Boolean = true,
    compact: Boolean = false,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onDeleteLocal: () -> Unit,
    onDeleteForAll: () -> Unit,
    onPin: () -> Unit,
    onStar: () -> Unit,
    onForward: () -> Unit,
    onReact: (String) -> Unit,
    onPickReaction: () -> Unit,
    onOpenViewOnce: () -> Unit,
    resolveLocalFile: ((MediaAttachment?) -> File?)?,
    onCancelTransfer: () -> Unit,
    onRetryTransfer: () -> Unit
) {
    val chatColors = LocalChatColors.current
    var showMenu by remember { mutableStateOf(false) }

    val isOutgoing = message.isOutgoing
    val alignment = if (isOutgoing) Alignment.End else Alignment.Start
    val bubbleBg = if (isOutgoing) chatColors.outgoingBubbleBg else chatColors.incomingBubbleBg
    val metaColor = if (isOutgoing) chatColors.outgoingMeta else chatColors.incomingMeta
    val contentColor = if (isOutgoing) chatColors.outgoingText else chatColors.incomingText

    val att = message.attachment
    val isViewLimited = att?.isViewLimited == true
    val isViewExpired = att?.isViewExpired == true
    // Incoming view-limited media that has not been opened yet renders sealed.
    val isSealedViewOnce = !isOutgoing && isViewLimited && !isViewExpired &&
        att?.transferState == TransferState.COMPLETED

    val timeFormatted = remember(message.timestampMs) {
        SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(message.timestampMs))
    }

    val hPad = if (compact) 10.dp else 13.dp
    val vPad = if (compact) 6.dp else 9.dp

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        if (message.isPinned && !message.isDeleted) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 2.dp)
            ) {
                Icon(Icons.Default.PushPin, contentDescription = "Pinned", tint = chatColors.textMuted, modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("Pinned", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (message.isStarred) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(Icons.Default.Star, contentDescription = "Starred", tint = chatColors.statusWarning, modifier = Modifier.size(11.dp))
                }
            }
        }

        Box {
            Card(
                shape = RoundedCornerShape(
                    topStart = 18.dp,
                    topEnd = 18.dp,
                    bottomStart = if (isOutgoing) 18.dp else 4.dp,
                    bottomEnd = if (isOutgoing) 4.dp else 18.dp
                ),
                colors = CardDefaults.cardColors(containerColor = bubbleBg),
                border = if (!isOutgoing) androidx.compose.foundation.BorderStroke(1.dp, chatColors.incomingBubbleBorder) else null,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .pointerInput(message.id) {
                        detectTapGestures(
                            onLongPress = { showMenu = true },
                            onTap = {
                                // Tap opens sealed view-once media; otherwise no-op.
                                if (isSealedViewOnce) onOpenViewOnce()
                            }
                        )
                    }
            ) {
                Column(modifier = Modifier.padding(horizontal = hPad, vertical = vPad)) {
                    message.replyToPreview?.let { replyPreview ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isOutgoing) chatColors.outgoingBubbleBorder.copy(alpha = 0.45f) else chatColors.searchField,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                Text(
                                    text = message.replyToSender ?: "",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isOutgoing) metaColor else MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = replyPreview,
                                    fontSize = 11.sp,
                                    color = if (isOutgoing) metaColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    if (message.isDeleted) {
                        Text(
                            text = "This message was deleted",
                            fontSize = 13.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = metaColor
                        )
                    } else if (isSealedViewOnce) {
                        // Sealed view-once media bubble
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isOutgoing) chatColors.outgoingBubbleBorder.copy(alpha = 0.4f) else chatColors.searchField)
                                .clickable { onOpenViewOnce() }
                                .padding(horizontal = 12.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                Icons.Default.Visibility,
                                contentDescription = null,
                                tint = if (isOutgoing) metaColor else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = when (att?.kind) {
                                        MediaKind.VIDEO -> "View-once video"
                                        else -> "View-once photo"
                                    },
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = contentColor
                                )
                                Text(
                                    text = "Tap to view · " + (att?.remainingViews ?: 1) + " of " + (att?.viewLimit ?: 1) + " views left",
                                    fontSize = 11.sp,
                                    color = metaColor
                                )
                            }
                        }
                    } else if (isViewLimited && isViewExpired) {
                        // Expired view-once: content destroyed on this device.
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = metaColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isOutgoing) "View-once media opened" else "Media expired after viewing",
                                fontSize = 12.sp,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                color = metaColor
                            )
                        }
                    } else {
                        if (message.attachment != null && (!isViewLimited || isOutgoing)) {
                            Box {
                                AttachmentContentView(
                                    attachment = message.attachment,
                                    resolveLocalFile = resolveLocalFile,
                                    isOutgoing = isOutgoing,
                                    onCancelTransfer = onCancelTransfer,
                                    onRetryTransfer = onRetryTransfer
                                )
                                if (isViewLimited && isOutgoing) {
                                    // Sender-side: badge over the local preview copy.
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(6.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(chatColors.scrim)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Visibility,
                                            contentDescription = null,
                                            tint = chatColors.outgoingText,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            " " + (att?.viewLimit ?: 1),
                                            fontSize = 10.sp,
                                            color = chatColors.outgoingText,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        if (message.content.isNotBlank()) {
                            if (highlight.isNotBlank() && message.content.contains(highlight, ignoreCase = true)) {
                                val annotated = remember(message.content, highlight) {
                                    buildAnnotatedHighlight(message.content, highlight)
                                }
                                Text(
                                    text = annotated,
                                    fontSize = 14.sp,
                                    color = contentColor,
                                    lineHeight = 19.sp
                                )
                            } else {
                                Text(
                                    text = message.content,
                                    fontSize = 14.sp,
                                    color = contentColor,
                                    lineHeight = 19.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (message.isStarred && !message.isPinned) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = "Starred",
                                tint = metaColor,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        if (message.isEdited && !message.isDeleted) {
                            Text("edited", fontSize = 9.sp, color = metaColor)
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = timeFormatted,
                            fontSize = 10.sp,
                            color = metaColor
                        )

                        if (isOutgoing && !isSelfNotes) {
                            Spacer(modifier = Modifier.width(4.dp))
                            val isRead = readReceiptsEnabled && peerLastReadMs > 0 &&
                                message.timestampMs <= peerLastReadMs
                            when (message.status) {
                                MessageStatus.QUEUED -> Icon(
                                    Icons.Default.AccessTime, "Queued",
                                    tint = metaColor, modifier = Modifier.size(12.dp)
                                )
                                MessageStatus.SENDING -> Icon(
                                    Icons.Default.Check, "Sending",
                                    tint = metaColor, modifier = Modifier.size(12.dp)
                                )
                                MessageStatus.DELIVERED -> Icon(
                                    Icons.Default.DoneAll,
                                    if (isRead) "Read" else "Delivered",
                                    tint = if (isRead) chatColors.statusSuccess else metaColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                MessageStatus.FAILED -> Icon(
                                    Icons.Default.ErrorOutline, "Failed",
                                    tint = chatColors.statusError, modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (message.reactions.isNotEmpty() && !message.isDeleted) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = 12.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
                        message.reactions.forEach { (emoji, senders) ->
                            Text(
                                text = "$emoji ${senders.size}",
                                fontSize = 11.sp,
                                color = if (senders.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onReact(emoji) }
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                if (!message.isDeleted) {
                    DropdownMenuItem(
                        text = { Text("Reply") },
                        leadingIcon = { Icon(Icons.Default.Reply, contentDescription = null) },
                        onClick = { onReply(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("React") },
                        leadingIcon = { Icon(Icons.Default.EmojiEmotions, contentDescription = null) },
                        onClick = { onPickReaction(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Forward") },
                        leadingIcon = { Icon(Icons.Default.Shortcut, contentDescription = null) },
                        onClick = { onForward(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(if (message.isStarred) "Unstar" else "Star") },
                        leadingIcon = { Icon(Icons.Default.Star, contentDescription = null) },
                        onClick = { onStar(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Copy") },
                        leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                        onClick = { onCopy(); showMenu = false }
                    )
                    if (isOutgoing && message.attachment == null && message.content.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = { onEdit(); showMenu = false }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (message.isPinned) "Unpin" else "Pin") },
                        leadingIcon = { Icon(Icons.Default.PushPin, contentDescription = null) },
                        onClick = { onPin(); showMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete for me", color = MaterialTheme.colorScheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                        onClick = { onDeleteLocal(); showMenu = false }
                    )
                    if (isOutgoing) {
                        DropdownMenuItem(
                            text = { Text("Delete for everyone", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = { onDeleteForAll(); showMenu = false }
                        )
                    }
                }
            }
        }
    }
}

private fun buildAnnotatedHighlight(text: String, query: String): AnnotatedString {
    val builder = AnnotatedString.Builder()
    var index = text.indexOf(query, ignoreCase = true)
    if (index < 0) {
        builder.append(text)
        return builder.toAnnotatedString()
    }
    var last = 0
    while (index >= 0) {
        builder.append(text.substring(last, index))
        builder.pushStyle(androidx.compose.ui.text.SpanStyle(background = FolkWarning.copy(alpha = 0.45f)))
        builder.append(text.substring(index, index + query.length))
        builder.pop()
        last = index + query.length
        index = text.indexOf(query, startIndex = last, ignoreCase = true)
    }
    builder.append(text.substring(last))
    return builder.toAnnotatedString()
}

// ------------------------------------------------------------------
// Attachments
// ------------------------------------------------------------------

@Composable
private fun AttachmentContentView(
    attachment: MediaAttachment,
    resolveLocalFile: ((MediaAttachment?) -> File?)?,
    isOutgoing: Boolean,
    onCancelTransfer: () -> Unit,
    onRetryTransfer: () -> Unit
) {
    val context = LocalContext.current
    val file = remember(attachment.localPath, attachment.transferState) {
        resolveLocalFile?.invoke(attachment)
    }

    when (attachment.transferState) {
        TransferState.PENDING, TransferState.IN_PROGRESS -> {
            Column(
                modifier = Modifier
                    .widthIn(min = 200.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isOutgoing) FolkSage.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant)
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "${if (isOutgoing) "Sending" else "Downloading"} ${(attachment.progress * 100).toInt()}%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCancelTransfer, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", modifier = Modifier.size(16.dp), tint = FolkError)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        attachment.fileName,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        TransferState.FAILED, TransferState.CANCELLED -> {
            Column(
                modifier = Modifier
                    .widthIn(min = 200.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(FolkError.copy(alpha = 0.12f))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = FolkError, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        attachment.error ?: "Transfer failed",
                        fontSize = 11.sp,
                        color = FolkError,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    val canManuallyDownload = !isOutgoing && (attachment.error?.contains("tap Download", ignoreCase = true) == true)
                    if (attachment.transferState == TransferState.CANCELLED || isOutgoing || canManuallyDownload) {
                        Text(
                            if (canManuallyDownload) "Download" else "Retry",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable { onRetryTransfer() }.padding(end = 14.dp)
                        )
                    }
                    Text(
                        "Cancel",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = FolkError,
                        modifier = Modifier.clickable { onCancelTransfer() }
                    )
                }
            }
        }
        TransferState.COMPLETED -> {
            when (attachment.kind) {
                MediaKind.IMAGE -> {
                    if (file != null) {
                        AsyncImage(
                            model = file,
                            contentDescription = attachment.fileName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .widthIn(max = 260.dp)
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        MediaUnavailableBox(attachment, "Image not downloaded")
                    }
                }
                MediaKind.VIDEO -> {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 260.dp)
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(FolkForestGreen.copy(alpha = 0.85f))
                    ) {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play video",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                attachment.fileName,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp)
                            )
                        }
                        if (file != null) {
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .clickable {
                                        try {
                                            val uri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                file
                                            )
                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(uri, attachment.mimeType)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Open video"))
                                        } catch (_: Exception) {
                                            // Fallback: no matching activity on device.
                                        }
                                    }
                            )
                        }
                    }
                }
                MediaKind.DOCUMENT -> {
                    Row(
                        modifier = Modifier
                            .widthIn(min = 230.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(10.dp)
                            .clickable(enabled = file != null) {
                                if (file != null) {
                                    try {
                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            file
                                        )
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, attachment.mimeType)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Open file"))
                                    } catch (_: Exception) {}
                                }
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FileCopy, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                attachment.fileName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                formatBytes(attachment.sizeBytes),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                MediaKind.VOICE -> VoiceNotePlayer(attachment, file, isOutgoing)
            }
        }
    }
}

@Composable
private fun MediaUnavailableBox(attachment: MediaAttachment, reason: String) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.widthIn(min = 180.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = FolkWarning, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("$reason — ${attachment.fileName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun VoiceNotePlayer(
    attachment: MediaAttachment,
    file: File?,
    isOutgoing: Boolean
) {
    var playing by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var progress by remember { mutableFloatStateOf(0f) }
    val sourcePath = file?.absolutePath ?: attachment.localPath
    val player = remember(sourcePath) {
        if (!sourcePath.isNullOrBlank() && File(sourcePath).exists()) MediaPlayer() else null
    }
    var prepared by remember(sourcePath) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    DisposableEffect(player) {
        onDispose {
            try { player?.release() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(player) {
        val p = player ?: return@LaunchedEffect
        if (!prepared) {
            try {
                p.setDataSource(sourcePath)
                p.setOnPreparedListener {
                    prepared = true
                    // Auto-play fixed: wait for explicit user tap.
                }
                p.setOnCompletionListener { playing = false; positionMs = 0L; progress = 0f }
                p.prepareAsync()
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(playing, player) {
        val p = player ?: return@LaunchedEffect
        while (playing) {
            try {
                positionMs = p.currentPosition.toLong()
                val total = p.duration
                progress = if (total > 0) positionMs.toFloat() / total.toFloat() else 0f
                if (!p.isPlaying) { playing = false; break }
            } catch (_: Exception) { break }
            delay(250)
        }
    }

    Row(
        modifier = Modifier
            .widthIn(min = 210.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (isOutgoing) FolkSage.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(FolkForestGreen)
                .clickable {
                    val p = player ?: return@clickable
                    try {
                        if (playing) { p.pause(); playing = false }
                        else { p.start(); playing = true }
                    } catch (_: Exception) {}
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (playing) "Pause" else "Play",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Voice message", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(4.dp)
                        .background(FolkForestGreen)
                )
            }
            Text(
                formatDurationShort(positionMs),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ------------------------------------------------------------------
// Attachment picker sheet
// ------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AttachmentSheet(
    onDismiss: () -> Unit,
    onExternalActivityLaunch: () -> Unit,
    onExternalActivityResult: () -> Unit,
    onBrowseGifLibrary: () -> Unit,
    onSend: (MediaAttachment) -> Unit
) {
    val context = LocalContext.current
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var viewLimit by remember { mutableStateOf(0) } // 0 normal, 1 once, 2 twice
    var isGif by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) { pendingUri = uri; isGif = false }
    }
    val gifPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) { pendingUri = uri; isGif = true }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) { pendingUri = uri; isGif = false }
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        onExternalActivityResult()
        if (uri != null) { pendingUri = uri; isGif = false }
    }

    var attachmentError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pendingUri) {
        val uri = pendingUri ?: return@LaunchedEffect
        attachmentError = null
        // Do not clear pendingUri before copying: changing the LaunchedEffect key
        // cancels the coroutine and used to abort selected-media copies mid-transfer.
        val attachment = withContext(Dispatchers.IO) { buildAttachmentFromUri(context, uri) }
        pendingUri = null
        if (attachment == null) {
            attachmentError = "Could not read this file. Choose it again or use a smaller file."
        } else {
            onSend(attachment.copy(viewLimit = viewLimit))
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(bottom = 20.dp)) {
            Text(
                "Share media",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            attachmentError?.let { error ->
                Text(
                    error,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    fontSize = 12.sp,
                    color = FolkError
                )
            }
            SheetRow(Icons.Default.PlayArrow, "Photo", "Send an image over the encrypted link") {
                onExternalActivityLaunch()
                imagePicker.launch(arrayOf("image/*"))
            }
            SheetRow(Icons.Default.Gif, "GIF library", "Search trending and worldwide GIFs") {
                onBrowseGifLibrary()
            }
            SheetRow(Icons.Default.Gif, "GIF from device", "Send a saved animated GIF") {
                onExternalActivityLaunch()
                gifPicker.launch(arrayOf("image/gif"))
            }
            SheetRow(Icons.Default.Videocam, "Video", "Stream a video file peer-to-peer") {
                onExternalActivityLaunch()
                videoPicker.launch(arrayOf("video/*"))
            }
            SheetRow(Icons.Default.FileCopy, "Document", "Any file of any size, sent in encrypted chunks") {
                onExternalActivityLaunch()
                docPicker.launch(arrayOf("*/*"))
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "Photo & video privacy",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ViewLimitChip("Normal", viewLimit == 0) { viewLimit = 0 }
                ViewLimitChip("View once", viewLimit == 1) { viewLimit = 1 }
                ViewLimitChip("View twice", viewLimit == 2) { viewLimit = 2 }
            }
            Text(
                if (viewLimit == 0) "Media stays in the chat"
                else "Media disappears after " + (if (viewLimit == 1) "one view" else "two views"),
                modifier = Modifier.padding(horizontal = 20.dp),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OnlineGifPickerSheet(
    allowOnlineGifSearch: Boolean,
    onDismiss: () -> Unit,
    onSend: (MediaAttachment) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<TenorGif>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var sendingId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val apiConfigured = TenorGifService.isConfigured()

    LaunchedEffect(query, allowOnlineGifSearch, apiConfigured) {
        if (!allowOnlineGifSearch || !apiConfigured) {
            results = emptyList()
            loading = false
            return@LaunchedEffect
        }
        if (query.isNotBlank()) delay(380)
        loading = true
        error = null
        try {
            results = if (query.isBlank()) TenorGifService.featured() else TenorGifService.search(query)
        } catch (failure: Exception) {
            results = emptyList()
            error = failure.message ?: "GIF search failed. Check your connection and try again."
        } finally {
            loading = false
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 460.dp, max = 680.dp)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("GIFs", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Find a reaction for every moment",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close GIF picker")
                }
            }

            if (allowOnlineGifSearch && apiConfigured) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp),
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    placeholder = { Text("Search GIFs worldwide…", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear GIF search")
                            }
                        }
                    }
                )
            }

            when {
                !allowOnlineGifSearch -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Online GIFs are paused", fontWeight = FontWeight.SemiBold)
                            Text(
                                "GIF search uses a direct secure connection to Tenor. It is paused while internet is unavailable or Tor/offline privacy routing is enabled, so it does not bypass your privacy route.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                !apiConfigured -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("Connect the GIF library", fontWeight = FontWeight.SemiBold)
                            Text(
                                "FolkChat uses Tenor for worldwide and trending GIF search. Add your own API key to your local Gradle properties, then rebuild the app.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "TENOR_API_KEY=your_key_here",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "Create a key in the Google Tenor API console. Restrict it to this Android app and set usage quotas.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                else -> {
                    if (loading) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(if (query.isBlank()) "Loading trending GIFs…" else "Searching GIFs…", fontSize = 12.sp)
                        }
                    }
                    error?.let { message ->
                        Text(
                            message,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                    if (!loading && error == null && results.isEmpty()) {
                        Text(
                            "No GIFs found. Try another search.",
                            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                    AnimatedVisibility(
                        visible = results.isNotEmpty() && !loading && error == null,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier.weight(1f)
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 4.dp, bottom = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            gridItems(results, key = { it.id }) { gif ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .animateContentSize()
                                        .clickable(enabled = sendingId == null) {
                                            sendingId = gif.id
                                            error = null
                                            scope.launch {
                                                try {
                                                    val attachment = TenorGifService.downloadAsAttachment(context, gif)
                                                    onSend(attachment)
                                                    onDismiss()
                                                } catch (failure: Exception) {
                                                    error = failure.message ?: "Could not download the selected GIF."
                                                    sendingId = null
                                                }
                                            }
                                        },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Box {
                                        AsyncImage(
                                            model = gif.previewUrl,
                                            contentDescription = gif.description,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxWidth().height(132.dp)
                                        )
                                        if (sendingId == gif.id) {
                                            Box(
                                                modifier = Modifier.fillMaxWidth().height(132.dp).background(Color.Black.copy(alpha = 0.48f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text(
                "GIFs powered by Tenor · Tap a GIF to send",
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                textAlign = TextAlign.Center,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ViewLimitChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SheetRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun buildAttachmentFromUri(context: android.content.Context, uri: Uri): MediaAttachment? {
    var partialCopy: File? = null
    return try {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val kind = when {
            mime.startsWith("image/") -> MediaKind.IMAGE
            mime.startsWith("video/") -> MediaKind.VIDEO
            mime.startsWith("audio/") -> MediaKind.VOICE
            else -> MediaKind.DOCUMENT
        }

        var displayName = "attachment"
        var size = 0L
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
            }
        }

        var width = 0
        var height = 0
        if (kind == MediaKind.IMAGE) {
            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, opts)
            }
            width = opts.outWidth
            height = opts.outHeight
        }

        val copyName = "${UUID.randomUUID()}_${displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")}"
        val dest = File(File(context.filesDir, "media"), copyName)
        partialCopy = dest
        dest.parentFile?.mkdirs()
        val copied = resolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var total = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > 2L * 1024 * 1024 * 1024) throw IllegalArgumentException("Attachment exceeds 2 GB")
                    output.write(buffer, 0, read)
                }
            }
            true
        } ?: false
        if (!copied || !dest.isFile) {
            dest.delete()
            return null
        }

        MediaAttachment(
            id = UUID.randomUUID().toString(),
            kind = kind,
            fileName = displayName,
            mimeType = mime,
            sizeBytes = dest.length(),
            width = width,
            height = height,
            localPath = dest.absolutePath,
            transferState = TransferState.PENDING,
            progress = 0f
        )
    } catch (_: Exception) {
        try { partialCopy?.delete() } catch (_: Exception) {}
        null
    }
}

// ------------------------------------------------------------------
// Reaction picker
// ------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReactionPickerSheet(
    onDismiss: () -> Unit,
    onPick: (String) -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            "React",
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            QUICK_REACTIONS.forEach { emoji ->
                Text(
                    text = emoji,
                    fontSize = 30.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { onPick(emoji) }
                        .padding(8.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
    }
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

private fun formatBytes(bytes: Long): String = when {
    bytes <= 0 -> "0 B"
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

private fun formatDurationShort(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}

// ---------------------------------------------------------------------
// v2: Forward / view-once viewer / disappearing timer sheet
// ---------------------------------------------------------------------

@Composable
private fun ForwardMessageDialog(
    contacts: List<Contact>,
    onForward: (Contact) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        title = { Text("Forward to", fontWeight = FontWeight.SemiBold) },
        text = {
            if (contacts.isEmpty()) {
                Text("Add more contacts to forward messages.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(
                    modifier = Modifier.height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(contacts, key = { it.x25519PublicKeyHex }) { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onForward(contact) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PeerAvatar(name = contact.displayName, avatarPath = contact.avatarPath, size = 38.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                contact.displayName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    )
}

/**
 * Full-screen viewer for view-once / view-twice media. Closing the viewer
 * consumes one view.
 */
@Composable
private fun ViewOnceMediaDialog(
    message: ChatMessage,
    resolveLocalFile: ((MediaAttachment?) -> File?)?,
    onDismiss: () -> Unit
) {
    val att = message.attachment ?: run { onDismiss(); return }
    val file = remember(att.localPath) { resolveLocalFile?.invoke(att) }
    val chatColors = LocalChatColors.current

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text("Close · " + (if (att.remainingViews > 1) "${att.remainingViews - 1} view left" else "this view is now gone"))
            }
        },
        title = {
            Text(
                "View once · " + (if (att.viewLimit == 2) "2 views" else "1 view"),
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp
            )
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    file != null && att.kind == MediaKind.IMAGE -> {
                        AsyncImage(
                            model = file,
                            contentDescription = "View once media",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(360.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                    file != null && att.kind == MediaKind.VIDEO -> {
                        val context = LocalContext.current
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(240.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(chatColors.scrim)
                                .clickable {
                                    try {
                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            file
                                        )
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, att.mimeType)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Open video"))
                                    } catch (_: Exception) {}
                                },
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play once",
                                tint = androidx.compose.ui.graphics.Color.White,
                                modifier = Modifier.size(52.dp)
                            )
                            Text("Tap to play · video will expire", fontSize = 12.sp, color = androidx.compose.ui.graphics.Color.White)
                        }
                    }
                    else -> {
                        Icon(
                            Icons.Default.VisibilityOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Media is no longer available on this device.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "After closing, this media can be viewed " +
                        (if (att.remainingViews - 1 > 0) "${att.remainingViews - 1} more time(s)" else "no more — it will be destroyed"),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DisappearTimerSheet(
    currentSeconds: Int,
    onSelect: (DisappearTimer) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(bottom = 28.dp)) {
            Text(
                "Disappearing messages",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "New messages vanish from both devices after the timer. Setting it here syncs to your peer.",
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            DisappearTimer.entries.forEach { timer ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(timer) }
                        .padding(horizontal = 20.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.RadioButton(
                        selected = currentSeconds == timer.seconds,
                        onClick = { onSelect(timer) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        timer.label,
                        fontSize = 14.sp,
                        fontWeight = if (currentSeconds == timer.seconds) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
