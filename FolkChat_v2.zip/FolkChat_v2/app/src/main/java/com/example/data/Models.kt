package com.example.data

enum class MessageStatus {
    QUEUED,
    SENDING,
    DELIVERED,
    FAILED
}

enum class RoutingPolicy {
    AUTO_FALLBACK, // Tries Online Relay when internet is available; automatically falls back to Offline Mesh when offline
    FORCE_OFFLINE, // Air-gapped: Only direct BLE and Local Wi-Fi
    FORCE_ONLINE   // Cloud Relay Only
}

enum class ActiveRouteType(val title: String, val shortLabel: String, val description: String) {
    ONLINE_RELAY(
        title = "Online Secure Relay",
        shortLabel = "Online",
        description = "Encrypted packet routed via relay; the relay can observe routing identifiers and timing metadata."
    ),
    OFFLINE_DIRECT_WIFI(
        title = "Direct Wi-Fi Socket",
        shortLabel = "Wi-Fi P2P",
        description = "Air-gapped high-speed socket link on local subnet or Wi-Fi Direct."
    ),
    OFFLINE_BLE_MESH(
        title = "Bluetooth Low Energy Mesh",
        shortLabel = "BLE Mesh",
        description = "Radio proximity link operating with zero internet and zero local network."
    ),
    OFFLINE_STORE_AND_FORWARD(
        title = "Offline Store & Forward",
        shortLabel = "Queued",
        description = "Encrypted in local device vault; auto-dispatches the instant peer is in range or online restored."
    )
}

/** The kind of media attached to a message. */
enum class MediaKind {
    IMAGE,
    VIDEO,
    DOCUMENT,
    VOICE
}

/** Lifecycle of a media attachment transfer. */
enum class TransferState {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    CANCELLED
}

/**
 * View-limited media policy (like WhatsApp view-once media).
 * 0 = normal persistent media, 1 = view once, 2 = view twice.
 */
enum class ViewLimit(val label: String) {
    NORMAL("Normal"),
    ONCE("View once"),
    TWICE("View twice");

    val limit: Int get() = when (this) {
        NORMAL -> 0
        ONCE -> 1
        TWICE -> 2
    }
}

/** Disappearing message timer options (Signal-style, enforced locally on both devices). */
enum class DisappearTimer(val seconds: Int, val label: String) {
    OFF(0, "Off"),
    THIRTY_SECONDS(30, "30 seconds"),
    FIVE_MINUTES(300, "5 minutes"),
    ONE_HOUR(3600, "1 hour"),
    ONE_DAY(86400, "24 hours"),
    ONE_WEEK(604800, "7 days");

    companion object {
        fun fromSeconds(seconds: Int): DisappearTimer =
            entries.firstOrNull { it.seconds == seconds } ?: OFF
    }
}

/** Derived presence of a peer, shown in chat headers and calls. */
enum class PresenceState(val label: String) {
    ONLINE_MESH("Online - Mesh"),
    ONLINE_RELAY("Online - Relay"),
    LAST_SEEN("Last seen"),
    OFFLINE("Offline")
}

data class Contact(
    val id: String,
    val displayName: String,
    val x25519PublicKeyHex: String,
    val ed25519PublicKeyHex: String = "",
    val isVerified: Boolean = false,
    val addedAtEpochMs: Long = System.currentTimeMillis(),
    val lastSeenEpochMs: Long = 0L,
    val statusText: String = "",
    // FolkChat v2 additions
    val avatarPath: String? = null,
    val isArchived: Boolean = false,
    val isMuted: Boolean = false,
    val disappearAfterSec: Int = 0,
    val peerLastReadMs: Long = 0L,
    /** Timer changes only apply to messages created at/after this point. */
    val disappearAfterSetAtMs: Long = 0L,
    /** Monotonic timer-sync guard against stale/replayed timer updates. */
    val disappearTimerUpdatedAtMs: Long = 0L,
    /** Rejects replayed/stale profile updates from the peer. */
    val profileUpdatedAtMs: Long = 0L
) {
    val contactCode: String
        get() = "sc1:$x25519PublicKeyHex:$displayName"

    /** True when the peer was seen very recently (mesh or any incoming traffic). */
    fun isOnlineNow(nowMs: Long = System.currentTimeMillis(), windowMs: Long = 60_000L): Boolean =
        lastSeenEpochMs > 0L && nowMs - lastSeenEpochMs < windowMs

    fun isSelf(myPubKeyHex: String): Boolean =
        id == "self_notes" || x25519PublicKeyHex.equals(myPubKeyHex, ignoreCase = true)
}

/**
 * Metadata for a media attachment carried inside a [ChatMessage].
 * The actual bytes live on disk (in [localPath]) once transfer completes.
 */
data class MediaAttachment(
    val id: String,
    val kind: MediaKind,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val localPath: String? = null,
    val transferState: TransferState = TransferState.PENDING,
    val progress: Float = 0f,
    val error: String? = null,
    // View-limited media (0 = normal, 1 = view once, 2 = view twice)
    val viewLimit: Int = 0,
    val viewsUsed: Int = 0
) {
    val isViewLimited: Boolean get() = viewLimit > 0
    val isViewExpired: Boolean get() = viewLimit > 0 && viewsUsed >= viewLimit
    val remainingViews: Int get() = if (viewLimit <= 0) Int.MAX_VALUE else (viewLimit - viewsUsed).coerceAtLeast(0)
}

data class ChatMessage(
    val id: String,
    val conversationPeerPubKeyHex: String,
    val senderPubKeyHex: String,
    val recipientPubKeyHex: String,
    val content: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.QUEUED,
    val isOutgoing: Boolean = true,
    val routeUsed: String = "AUTO",
    // Messaging tools
    val replyToId: String? = null,
    val replyToPreview: String? = null,
    val replyToSender: String? = null,
    val reactions: Map<String, List<String>> = emptyMap(),
    val isEdited: Boolean = false,
    val editedAtMs: Long = 0L,
    val deletedAtMs: Long = 0L,
    val isPinned: Boolean = false,
    /** Monotonic timestamp used to ignore replayed pin-state updates. */
    val pinUpdatedAtMs: Long = 0L,
    /** Monotonic timestamp used to ignore replayed reaction updates. */
    val reactionUpdatedAtMs: Long = 0L,
    val attachment: MediaAttachment? = null,
    // FolkChat v2 additions
    val isStarred: Boolean = false,
    /** Timestamp of the most recent transport attempt; prevents a hot outbox retry loop. */
    val lastAttemptAtMs: Long = 0L,
    /** Centered, non-bubble system event text (e.g. disappearing timer changes). */
    val systemEvent: String? = null
) {
    val isDeleted: Boolean get() = deletedAtMs > 0L
    val isSystemEvent: Boolean get() = systemEvent != null

    val previewText: String
        get() = when {
            isSystemEvent -> systemEvent ?: ""
            isDeleted -> "This message was deleted"
            attachment != null && content.isBlank() -> when {
                attachment.isViewExpired -> "Expired view-once media"
                attachment.isViewLimited -> "View-once ${attachment.kind.label}"
                else -> when (attachment.kind) {
                    MediaKind.IMAGE -> if (attachment.mimeType == "image/gif") "GIF" else "Photo"
                    MediaKind.VIDEO -> "Video"
                    MediaKind.DOCUMENT -> attachment.fileName
                    MediaKind.VOICE -> "Voice message"
                }
            }
            else -> content
        }
}

private val MediaKind.label: String
    get() = when (this) {
        MediaKind.IMAGE -> "photo"
        MediaKind.VIDEO -> "video"
        MediaKind.DOCUMENT -> "document"
        MediaKind.VOICE -> "voice note"
    }

data class DiscoveredPeer(
    val id: String,
    val displayName: String,
    val tagHex: String,
    val linkType: String,
    val rssi: Int = 0,
    val hostAddress: String? = null,
    val port: Int = 0,
    val lastSeenEpochMs: Long = System.currentTimeMillis()
)

data class MessageRequest(
    val senderPubKeyHex: String,
    val senderDisplayName: String,
    val latestMessageText: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val messageCount: Int = 1
)

enum class CallType { VOICE, VIDEO }

enum class CallOutcome {
    MISSED,
    DECLINED,
    COMPLETED,
    FAILED,
    CANCELED
}

data class CallLogEntry(
    val id: String,
    val peerPubKeyHex: String,
    val peerName: String,
    val type: CallType,
    val outcome: CallOutcome,
    val timestampMs: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0L,
    val isOutgoing: Boolean = true
)

enum class NotificationPreviewMode {
    FULL,        // Show sender + message content
    SENDER_ONLY, // Show sender name, hide content
    HIDDEN       // Show neither
}

enum class MediaAutoDownload {
    ALWAYS,
    WIFI_OR_LAN,
    NEVER
}

/** User-configurable privacy/security/app preferences, persisted in the vault. */
data class AppSettings(
    val appLockEnabled: Boolean = false,
    val biometricEnabled: Boolean = true,
    val pinHash: String = "",
    val pinSalt: String = "",
    val pinFailedAttempts: Int = 0,
    val pinLockoutUntilMs: Long = 0L,
    val autoLockMillis: Long = 60_000L,
    /** Normalized X25519 public keys for conversations requiring an extra PIN gate. */
    val lockedChatKeys: Set<String> = emptySet(),
    val notificationPreviewMode: NotificationPreviewMode = NotificationPreviewMode.FULL,
    val notificationSound: Boolean = true,
    val notificationVibrate: Boolean = true,
    val mediaAutoDownload: MediaAutoDownload = MediaAutoDownload.WIFI_OR_LAN,
    val readReceipts: Boolean = true,
    val typingIndicators: Boolean = true,
    val screenshotProtection: Boolean = true,
    val compactChat: Boolean = false,
    val outgoingBubbleEmphasis: Boolean = true,
    // Network
    val torRoutingEnabled: Boolean = false,   // Route relay traffic through Tor (Orbot SOCKS 127.0.0.1:9050). OFF by default.
    val relayUrl: String = ""                 // WebSocket relay URL (empty = offline-first); relay metadata remains visible.
)
