package com.example.ui.security

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.data.AppSettings
import com.example.data.EncryptedVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * App Lock: a real 6-digit PIN (salted + iterated hash in the encrypted vault) plus
 * optional system biometric (fingerprint / face) unlock, cold-start enforcement and
 * an idle auto-lock timer. Everything is driven by persisted settings in the vault —
 * nothing here is cosmetic.
 */
class AppLockManager(private val vault: EncryptedVault, private val context: Context) {

    private val _locked = MutableStateFlow(false)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()

    private val _unlockFailure = MutableStateFlow<String?>(null)
    val unlockFailure: StateFlow<String?> = _unlockFailure.asStateFlow()

    /** Chats unlocked only for the current foreground session. Never persisted. */
    private val _unlockedChatKeys = MutableStateFlow<Set<String>>(emptySet())
    val unlockedChatKeys: StateFlow<Set<String>> = _unlockedChatKeys.asStateFlow()

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var lastActivityAt = System.currentTimeMillis()
    @Volatile private var requireColdStartUnlock = false
    @Volatile private var externalActivityResultExpectedUntilMs = 0L
    private var pendingLock: Runnable? = null

    private var prompt: BiometricPrompt? = null

    fun settings(): AppSettings = vault.getSettings()

    val isAppLockEnabled: Boolean get() = vault.getSettings().appLockEnabled

    /** True when the user has configured a 6-digit PIN. */
    fun hasPin(): Boolean = vault.getSettings().pinHash.isNotBlank()

    /** True only when real biometrics are enrolled and usable (not merely hardware present). */
    fun canUseBiometric(): Boolean {
        val can = BiometricManager.from(context).canAuthenticate(BIOMETRIC_WEAK)
        return can == BiometricManager.BIOMETRIC_SUCCESS
    }

    /** True when any unlock method (usable biometric or device credential) exists. */
    fun canAuthenticate(): Boolean {
        val can = BiometricManager.from(context).canAuthenticate(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)
        return can == BiometricManager.BIOMETRIC_SUCCESS
    }

    /** True when any device credential (PIN/pattern/password) is enrolled on the device. */
    fun hasDeviceCredential(): Boolean {
        val can = BiometricManager.from(context).canAuthenticate(DEVICE_CREDENTIAL)
        return can == BiometricManager.BIOMETRIC_SUCCESS
    }

    /**
     * Cold-start enforcement: app lock must gate the app from the very first frame
     * after process death, not only after a background/foreground transition.
     */
    fun onAppCreated() {
        // Per-chat access grants are memory-only and never survive process death.
        relockAllChats()
        if (isAppLockEnabled) {
            _locked.value = true
            requireColdStartUnlock = true
            cancelAutoLock()
        }
    }

    fun lockNow() {
        if (!isAppLockEnabled) return
        requireColdStartUnlock = true
        _locked.value = true
        relockAllChats()
        cancelAutoLock()
    }

    fun unlock() {
        requireColdStartUnlock = false
        lastActivityAt = System.currentTimeMillis()
        _locked.value = false
        _unlockFailure.value = null
        scheduleAutoLock()
    }

    /** Called from app-level pointer events so auto-lock measures inactivity, not unlock age. */
    fun onUserActivity() {
        if (!isAppLockEnabled || _locked.value) return
        lastActivityAt = System.currentTimeMillis()
    }

    fun cancelAutoLock() {
        pendingLock?.let { handler.removeCallbacks(it) }
        pendingLock = null
    }

    private fun scheduleAutoLock() {
        cancelAutoLock()
        if (!isAppLockEnabled) return
        val idleLimit = vault.getSettings().autoLockMillis
        if (idleLimit <= 0L) return
        val r = object : Runnable {
            override fun run() {
                if (!isAppLockEnabled) {
                    pendingLock = null
                    return
                }
                val externalDeadline = externalActivityResultExpectedUntilMs
                if (System.currentTimeMillis() <= externalDeadline) {
                    handler.postDelayed(this, (externalDeadline - System.currentTimeMillis()).coerceAtLeast(100L).coerceAtMost(1_000L))
                    return
                }
                val remaining = idleLimit - (System.currentTimeMillis() - lastActivityAt)
                if (remaining <= 0L) {
                    _locked.value = true
                    relockAllChats()
                    pendingLock = null
                } else {
                    handler.postDelayed(this, remaining)
                }
            }
        }
        pendingLock = r
        val remaining = (idleLimit - (System.currentTimeMillis() - lastActivityAt)).coerceAtLeast(1L)
        handler.postDelayed(r, remaining)
    }

    fun onAppStopped(activity: Activity?) {
        // A picker/permission prompt is a foreground task started by FolkChat, not a user
        // backgrounding the conversation. Keep its state only while a result is expected.
        if (System.currentTimeMillis() <= externalActivityResultExpectedUntilMs) return
        relockAllChats()
        if (!isAppLockEnabled) return
        val delay = vault.getSettings().autoLockMillis
        if (delay <= 0L || System.currentTimeMillis() - lastActivityAt >= delay) {
            _locked.value = true
            cancelAutoLock()
        } else {
            // Keep a timer while backgrounded, but lifecycle re-check is still authoritative
            // if Android suspends this process and the callback never runs.
            scheduleAutoLock()
        }
    }

    fun onAppResumed() {
        if (System.currentTimeMillis() <= externalActivityResultExpectedUntilMs) return
        if (!isAppLockEnabled) {
            requireColdStartUnlock = false
            _locked.value = false
            return
        }
        // A new process must never clear the cold-start gate just because the idle timer
        // was initialized moments ago. Only a successful authentication clears this flag.
        if (requireColdStartUnlock) {
            _locked.value = true
            cancelAutoLock()
            return
        }
        val delay = vault.getSettings().autoLockMillis
        val idle = System.currentTimeMillis() - lastActivityAt
        if (delay <= 0L || idle >= delay) {
            _locked.value = true
            cancelAutoLock()
        } else {
            _locked.value = false
            scheduleAutoLock()
        }
    }

    // ------------------------------------------------------------------
    // PIN lifecycle: set / change / disable / verify
    // ------------------------------------------------------------------

    suspend fun setPin(pin: String): Boolean = withContext(Dispatchers.IO) {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return@withContext false
        vault.setPin(pin)
        true
    }

    fun clearPin() {
        vault.clearPin()
        vault.updateSettings { it.copy(appLockEnabled = false, lockedChatKeys = emptySet()) }
        _locked.value = false
        requireColdStartUnlock = false
        relockAllChats()
        cancelAutoLock()
    }

    suspend fun verifyPin(pin: String): Boolean {
        val ok = verifyPinWithoutUnlock(pin)
        if (ok) withContext(Dispatchers.Main.immediate) { unlock() }
        return ok
    }

    /** Verify the same rate-limited PIN without unlocking the entire app (for chat locks). */
    suspend fun verifyPinWithoutUnlock(pin: String): Boolean {
        val ok = withContext(Dispatchers.IO) { vault.verifyPin(pin) }
        if (ok) {
            _unlockFailure.value = null
        } else {
            val remaining = withContext(Dispatchers.IO) { vault.pinLockoutRemainingMs() }
            _unlockFailure.value = if (remaining > 0L) {
                "Too many attempts. Try again in ${((remaining + 999L) / 1000L)} seconds."
            } else {
                "Incorrect PIN. Try again."
            }
        }
        return ok
    }

    /** Mark an app-launched system picker/permission sheet as an expected short-lived return flow. */
    fun expectExternalActivityResult() {
        externalActivityResultExpectedUntilMs = System.currentTimeMillis() + 120_000L
    }

    /** Clear the temporary picker exemption as soon as its activity result is delivered. */
    fun externalActivityResultReturned() {
        val now = System.currentTimeMillis()
        // Keep a brief resume grace so ON_START ordering cannot re-lock before the result callback.
        externalActivityResultExpectedUntilMs = now + 1_500L
        lastActivityAt = now
        if (isAppLockEnabled && !_locked.value) scheduleAutoLock()
    }

    // ------------------------------------------------------------------
    // Per-chat locks. These use the rate-limited app PIN and are session-gated.
    // ------------------------------------------------------------------

    fun isChatLocked(pubKeyHex: String): Boolean {
        val key = normalizeChatKey(pubKeyHex) ?: return false
        return key in vault.getSettings().lockedChatKeys
    }

    fun isChatUnlocked(pubKeyHex: String): Boolean {
        val key = normalizeChatKey(pubKeyHex) ?: return false
        return key in _unlockedChatKeys.value
    }

    /** Requires a configured PIN, even if biometrics-only app lock is enabled. */
    fun setChatLocked(pubKeyHex: String, locked: Boolean): Boolean {
        val key = normalizeChatKey(pubKeyHex) ?: return false
        if (locked && !hasPin()) return false
        vault.updateSettings { current ->
            current.copy(
                lockedChatKeys = if (locked) current.lockedChatKeys + key else current.lockedChatKeys - key
            )
        }
        _unlockedChatKeys.value = _unlockedChatKeys.value - key
        return true
    }

    fun unlockChat(pubKeyHex: String) {
        val key = normalizeChatKey(pubKeyHex) ?: return
        if (isChatLocked(key)) _unlockedChatKeys.value = _unlockedChatKeys.value + key
    }

    fun relockChat(pubKeyHex: String) {
        val key = normalizeChatKey(pubKeyHex) ?: return
        _unlockedChatKeys.value = _unlockedChatKeys.value - key
    }

    fun relockAllChats() {
        _unlockedChatKeys.value = emptySet()
    }

    private fun normalizeChatKey(pubKeyHex: String): String? {
        val key = pubKeyHex.trim().lowercase()
        return key.takeIf { it.matches(Regex("[0-9a-f]{64}")) }
    }

    /** Launches the system biometric prompt when biometrics are actually enrolled. */
    fun authenticateWithBiometric(
        activity: FragmentActivity,
        title: String = "FolkChat is locked",
        subtitle: String = "Confirm it is you",
        onSuccess: () -> Unit
    ): Boolean {
        if (!canUseBiometric()) return false
        val executor = ContextCompat.getMainExecutor(activity)
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                _unlockFailure.value = null
                unlock()
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // User can still fall back to PIN; do not spam.
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON
                ) {
                    _unlockFailure.value = errString.toString()
                }
            }
        }
        val p = BiometricPrompt(activity, executor, cb)
        prompt = p
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BIOMETRIC_WEAK)
            .build()
        p.authenticate(info)
        return true
    }

    // ------------------------------------------------------------------
    // Settings mutations
    // ------------------------------------------------------------------

    /**
     * Enable / disable the whole app lock. Enabling requires that at least one
     * unlock method exists (a configured FolkChat PIN, or usable biometrics).
     * Returns false (and does not enable) when no unlock method would be available.
     */
    fun setEnabled(enabled: Boolean): Boolean {
        if (enabled && !hasPin() && !canUseBiometric()) {
            return false // refuse to lock the user out
        }
        vault.updateSettings { it.copy(appLockEnabled = enabled) }
        if (enabled) {
            requireColdStartUnlock = true
            lastActivityAt = System.currentTimeMillis()
            relockAllChats()
            _locked.value = true // engage immediately: the user just armed it
            scheduleAutoLock()
        } else {
            _locked.value = false
            relockAllChats()
            cancelAutoLock()
        }
        return true
    }

    fun setAutoLockMillis(millis: Long) {
        vault.updateSettings { it.copy(autoLockMillis = millis) }
        scheduleAutoLock()
    }

    fun setBiometricEnabled(enabled: Boolean) {
        vault.updateSettings { it.copy(biometricEnabled = enabled) }
    }

    /** Full disable: lock off + PIN cleared. */
    fun disableEverything() {
        vault.clearPin()
        vault.updateSettings { it.copy(appLockEnabled = false, lockedChatKeys = emptySet()) }
        _locked.value = false
        relockAllChats()
        cancelAutoLock()
    }

    fun invalidatePrompt() {
        prompt = null
    }
}
