package com.example.net.transport

import android.content.Context
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.crypto.EncryptedEnvelope
import com.example.data.ActiveRouteType
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DiscoveredPeer
import com.example.data.EncryptedVault
import com.example.data.MediaAutoDownload
import com.example.data.MediaKind
import com.example.data.MediaAttachment
import com.example.data.MessageRequest
import com.example.data.MessageStatus
import com.example.data.RoutingPolicy
import com.example.data.TransferState
import com.example.net.ble.BleManager
import com.example.net.call.CallSignalType
import com.example.net.call.IncomingCallSignal
import com.example.net.media.MediaTransferManager
import com.example.net.online.OnlineRelayManager
import com.example.net.routing.RoutingEngine
import com.example.net.socket.SocketManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

class TransportCoordinator(
    private val context: Context,
    val vault: EncryptedVault
) {
    companion object {
        private const val TAG = "TransportCoordinator"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val routingEngine = RoutingEngine(context)
    val onlineRelayManager = OnlineRelayManager(context, vault)
    val bleManager = BleManager(context)
    val socketManager = SocketManager(context)

    val mediaTransferManager = MediaTransferManager(
        vault = vault,
        mediaDir = File(context.filesDir, "media"),
        dispatcher = { recipient, json -> dispatchEncryptedJson(recipient, json) },
        onUpdated = { _onConversationUpdated.tryEmit(Unit) }
    )

    private val _allDiscoveredPeers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val allDiscoveredPeers: StateFlow<List<DiscoveredPeer>> = _allDiscoveredPeers.asStateFlow()

    private val _onNewMessageReceived = MutableSharedFlow<ChatMessage>(extraBufferCapacity = 64)
    val onNewMessageReceived: SharedFlow<ChatMessage> = _onNewMessageReceived.asSharedFlow()

    private val _onConversationUpdated = MutableSharedFlow<Unit>(extraBufferCapacity = 64)
    val onConversationUpdated: SharedFlow<Unit> = _onConversationUpdated.asSharedFlow()

    private val _onCallSignal = MutableSharedFlow<IncomingCallSignal>(extraBufferCapacity = 32)
    val onCallSignal: SharedFlow<IncomingCallSignal> = _onCallSignal.asSharedFlow()

    /** peerPubKeyHex -> isTyping events for live "typing…" indicators. */
    private val _onTypingUpdate = MutableSharedFlow<Pair<String, Boolean>>(extraBufferCapacity = 32)
    val onTypingUpdate: SharedFlow<Pair<String, Boolean>> = _onTypingUpdate.asSharedFlow()

    /** peerPubKeyHex of any peer that just produced traffic (presence refresh). */
    private val _onPresenceSeen = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val onPresenceSeen: SharedFlow<String> = _onPresenceSeen.asSharedFlow()

    private var outboxWorkerJob: Job? = null
    private val lastTypingAtByPeer = java.util.concurrent.ConcurrentHashMap<String, Long>()

    init {
        // Observe peers from BLE and Socket
        scope.launch {
            bleManager.discoveredPeers.collectLatest { blePeers ->
                val socketPeers = socketManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }
        scope.launch {
            socketManager.discoveredPeers.collectLatest { socketPeers ->
                val blePeers = bleManager.discoveredPeers.value
                mergePeers(blePeers.values, socketPeers.values)
            }
        }

        // Listen for incoming payloads from Online Relay
        scope.launch {
            // Use ordered collection here (not collectLatest): a new packet must not
            // cancel processing of a previous durable relay envelope. Acknowledge the
            // relay mailbox only after authenticated processing has returned.
            onlineRelayManager.incomingPayloads.collect { envelope ->
                try {
                    handleIncomingRawPayload(envelope.payload, "ONLINE_RELAY")
                } finally {
                    envelope.deliveryId?.let(onlineRelayManager::acknowledgeDelivery)
                }
            }
        }

        // Listen for incoming payloads from BLE
        scope.launch {
            bleManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "BLE")
            }
        }

        // Listen for incoming payloads from Wi-Fi Socket
        scope.launch {
            socketManager.incomingPayloads.collectLatest { rawPayload ->
                handleIncomingRawPayload(rawPayload, "WIFI_SOCKET")
            }
        }

        startOutboxWorker()
    }

    private fun mergePeers(blePeers: Collection<DiscoveredPeer>, socketPeers: Collection<DiscoveredPeer>) {
        val list = mutableListOf<DiscoveredPeer>()
        list.addAll(blePeers)
        list.addAll(socketPeers)
        _allDiscoveredPeers.value = list.sortedByDescending { it.lastSeenEpochMs }
    }

    /** Start internet messaging without Bluetooth/Wi-Fi discovery permissions.
     * This keeps cellular/WAN chat available when the user declines optional mesh permissions. */
    fun startOnlineRelayOnly() {
        bleManager.cleanUp()
        socketManager.stop()
        onlineRelayManager.start(vault.getIdentityKeyPair().publicKey)
    }

    fun startTransports() {
        val identity = vault.getIdentityKeyPair()
        onlineRelayManager.start(identity.publicKey)
        // Tor/high-privacy mode avoids local Wi-Fi beacons and BLE advertising, which
        // otherwise reveal proximity and a stable device presence outside the tunnel.
        if (!vault.getSettings().torRoutingEnabled) {
            bleManager.startAdvertising(identity.publicKey)
            bleManager.startScanning()
            socketManager.start(identity.publicKey)
        } else {
            bleManager.stopScanning()
            bleManager.stopAdvertising()
            socketManager.stop()
        }
    }

    fun restartPrivacyTransports() {
        stopTransports()
        startTransports()
    }

    fun stopTransports() {
        onlineRelayManager.stop()
        bleManager.cleanUp()
        socketManager.stop()
    }

    private fun startOutboxWorker() {
        outboxWorkerJob = scope.launch {
            while (isActive) {
                flushOutbox()
                delay(2000)
            }
        }
    }

    suspend fun flushOutbox() {
        val queued = vault.getQueuedOutbox()
        if (queued.isEmpty()) return

        for (msg in queued) {
            // Media messages are dispatched by the MediaTransferManager, not the text outbox.
            if (msg.attachment != null) continue

            val recipientHex = msg.recipientPubKeyHex.lowercase()

            // 1. Self-loopback delivery (e.g. Saved Notes or testing)
            if (recipientHex == vault.getIdentityKeyPair().publicKeyHex.lowercase()) {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.DELIVERED, "LOOPBACK")
                val incomingCopy = msg.copy(
                    id = UUID.randomUUID().toString(),
                    isOutgoing = false,
                    status = MessageStatus.DELIVERED,
                    routeUsed = "LOOPBACK"
                )
                vault.saveMessage(incomingCopy)
                _onNewMessageReceived.tryEmit(incomingCopy)
                continue
            }

            val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
            val json = buildChatJson(msg)
            val route = dispatchToPeer(recipientHex, recipientPubKeyBytes, json)
            if (route != null) {
                // Transport acceptance is not recipient delivery. Keep the message pending
                // until a signed peer receipt arrives; the outbox applies a bounded retry interval.
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.SENDING, route)
                _onConversationUpdated.tryEmit(Unit)
            } else {
                vault.updateMessageStatusAndRoute(msg.id, MessageStatus.QUEUED, "OFFLINE_QUEUED")
            }
        }
    }

    private fun buildChatJson(msg: ChatMessage): JSONObject {
        return JSONObject().apply {
            put("type", "CHAT_MSG")
            put("msgId", msg.id)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("recipientPubKey", msg.recipientPubKeyHex)
            put("text", msg.content)
            put("timestamp", msg.timestampMs)
            msg.replyToId?.let { put("replyToId", it) }
            msg.replyToPreview?.let { put("replyToPreview", it) }
            msg.replyToSender?.let { put("replyToSender", it) }
        }
    }

    /** Canonical JSON prevents serializer key order from changing the authenticated bytes. */
    private fun canonicalJson(value: Any?): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> value.keys().asSequence().toList().sorted().joinToString(",", "{", "}") { key ->
            JSONObject.quote(key) + ":" + canonicalJson(value.get(key))
        }
        is JSONArray -> (0 until value.length()).joinToString(",", "[", "]") { i -> canonicalJson(value.get(i)) }
        is String -> JSONObject.quote(value)
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }

    private fun peerAuthKey(sharedSecret: ByteArray, senderHex: String, recipientHex: String): ByteArray =
        CryptoEngine.hkdfSha256(
            sharedSecret,
            salt = "FolkChat-PacketAuth-v1".toByteArray(Charsets.UTF_8),
            info = "$senderHex|$recipientHex".toByteArray(Charsets.UTF_8),
            length = 32
        )

    private fun seal(recipientPubKeyBytes: ByteArray, json: JSONObject): ByteArray? {
        return try {
            require(recipientPubKeyBytes.size == 32) { "Recipient key must be 32 bytes" }
            val identity = vault.getIdentityKeyPair()
            val senderHex = identity.publicKeyHex.lowercase()
            val recipientHex = CryptoEngine.bytesToHex(recipientPubKeyBytes).lowercase()
            json.put("senderPubKey", senderHex)
            json.put("recipientPubKey", recipientHex)
            json.put("authVersion", 1)
            json.remove("authTag")

            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, recipientPubKeyBytes)
            require(shared.any { it != 0.toByte() }) { "Invalid peer shared secret" }
            val authKey = peerAuthKey(shared, senderHex, recipientHex)
            val canonical = canonicalJson(json).toByteArray(Charsets.UTF_8)
            json.put("authTag", CryptoEngine.bytesToHex(CryptoEngine.hmacSha256(authKey, canonical)))

            CryptoEngine.encryptToPeer(
                recipientPublicKey = recipientPubKeyBytes,
                plaintext = json.toString().toByteArray(Charsets.UTF_8)
            ).toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Failed authenticating/encrypting payload: ${e.message}")
            null
        }
    }

    /** Require proof that the sender possesses the long-term X25519 private key they claim. */
    private fun verifyAuthenticatedPayload(json: JSONObject): Boolean {
        return try {
            if (json.optInt("authVersion", 0) != 1) return false
            val identity = vault.getIdentityKeyPair()
            val senderHex = json.optString("senderPubKey").lowercase().trim()
            val recipientHex = json.optString("recipientPubKey").lowercase().trim()
            val tagHex = json.optString("authTag").lowercase().trim()
            if (senderHex.length != 64 || !senderHex.matches(Regex("^[0-9a-f]{64}$"))) return false
            if (recipientHex != identity.publicKeyHex.lowercase()) return false
            if (tagHex.length != 64 || !tagHex.matches(Regex("^[0-9a-f]{64}$"))) return false

            val tag = CryptoEngine.hexToBytes(tagHex)
            json.remove("authTag")
            val senderBytes = CryptoEngine.hexToBytes(senderHex)
            val shared = CryptoEngine.computeSharedSecret(identity.privateKey, senderBytes)
            if (shared.all { it == 0.toByte() }) return false
            val authKey = peerAuthKey(shared, senderHex, recipientHex)
            val expected = CryptoEngine.hmacSha256(authKey, canonicalJson(json).toByteArray(Charsets.UTF_8))
            MessageDigest.isEqual(expected, tag)
        } catch (e: Exception) {
            Log.w(TAG, "Rejected unauthenticated packet: ${e.message}")
            false
        }
    }

    private fun sendDeliveryReceipt(senderPubKeyHex: String, messageId: String, mediaTransferId: String? = null) {
        if (senderPubKeyHex.isBlank() || messageId.isBlank()) return
        scope.launch {
            val json = JSONObject().apply {
                put("type", if (mediaTransferId == null) "DELIVERY_RECEIPT" else "MEDIA_RECEIPT")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("msgId", messageId)
                mediaTransferId?.let { put("transferId", it) }
            }
            dispatchEncryptedJson(senderPubKeyHex, json)
        }
    }

    private fun handleDeliveryReceipt(senderPubKeyHex: String, json: JSONObject, isMediaReceipt: Boolean) {
        val msgId = json.optString("msgId")
        if (senderPubKeyHex.isBlank() || msgId.isBlank()) return
        val existing = vault.getMessageById(msgId) ?: return
        if (!existing.isOutgoing || !existing.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        if (isMediaReceipt) {
            val att = existing.attachment ?: return
            if (att.id != json.optString("transferId")) return
            vault.updateMessage(msgId) {
                it.copy(status = MessageStatus.DELIVERED, attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED, progress = 1f, error = null
                ))
            }
        } else {
            if (existing.attachment != null) return
            vault.updateMessageStatusAndRoute(msgId, MessageStatus.DELIVERED, "PEER_RECEIPT")
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun findWifiPeer(expectedTag: String): DiscoveredPeer? {
        return _allDiscoveredPeers.value.firstOrNull { peer ->
            peer.linkType == "WIFI_SOCKET" && peer.tagHex.length >= 16 &&
                expectedTag.startsWith(peer.tagHex, ignoreCase = true)
        }
    }

    /**
     * Encrypts and dispatches [json] to [recipientPubKeyHex] using the best available
     * route. Returns the route used, or null if the peer was unreachable.
     */
    suspend fun dispatchEncryptedJson(recipientPubKeyHex: String, json: JSONObject): String? {
        val recipientHex = recipientPubKeyHex.lowercase()
        val recipientPubKeyBytes = CryptoEngine.hexToBytes(recipientHex)
        return dispatchToPeer(recipientHex, recipientPubKeyBytes, json)
    }

    private suspend fun dispatchToPeer(recipientHex: String, recipientPubKeyBytes: ByteArray, json: JSONObject): String? {
        val myHex = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val wireBytes = seal(recipientPubKeyBytes, json) ?: return null

        // Self loopback
        if (recipientHex == myHex) {
            handleIncomingRawPayload(wireBytes, "LOOPBACK")
            return "LOOPBACK"
        }

        val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(recipientPubKeyBytes))
        val peers = _allDiscoveredPeers.value
        val policy = routingEngine.routingPolicy.value
        val preferred = routingEngine.resolveRoute(recipientHex, peers, expectedTag)

        // Attempt the preferred route first, then gracefully fall back to any other
        // usable link. Previously a single failed attempt (e.g. an unconfigured online
        // relay, or "internet up" hiding a reachable LAN peer) left the message stuck
        // in the outbox even though the peer was reachable on another transport.
        val order = LinkedHashSet<ActiveRouteType>()
        order.add(preferred)
        if (policy != RoutingPolicy.FORCE_ONLINE) {
            order.add(ActiveRouteType.OFFLINE_DIRECT_WIFI)
            order.add(ActiveRouteType.OFFLINE_BLE_MESH)
        }
        if (policy != RoutingPolicy.FORCE_OFFLINE) {
            order.add(ActiveRouteType.ONLINE_RELAY)
        }

        for (route in order) {
            val used = when (route) {
                ActiveRouteType.ONLINE_RELAY -> {
                    val packetType = json.optString("type", "CHAT_MSG").uppercase()
                    val queueIfOffline = packetType !in setOf("MEDIA_CHUNK", "CHAT_TYPING", "CALL_SIGNAL")
                    if (onlineRelayManager.sendEnvelope(recipientHex, wireBytes, queueIfOffline)) "ONLINE_RELAY" else null
                }
                ActiveRouteType.OFFLINE_DIRECT_WIFI -> {
                    val peer = findWifiPeer(expectedTag)
                    if (peer?.hostAddress != null && peer.port > 0 &&
                        socketManager.sendPayload(peer.hostAddress, peer.port, wireBytes)
                    ) "OFFLINE_DIRECT_WIFI" else null
                }
                ActiveRouteType.OFFLINE_BLE_MESH -> {
                    val peer = peers.firstOrNull {
                        it.linkType == "BLE_GATT" && it.tagHex.length >= 16 &&
                            expectedTag.startsWith(it.tagHex, ignoreCase = true)
                    }
                    if (peer != null && bleManager.sendPayloadToDevice(peer.id, wireBytes)) "OFFLINE_BLE_MESH" else null
                }
                ActiveRouteType.OFFLINE_STORE_AND_FORWARD -> null
            }
            if (used != null) return used
        }
        return null
    }

    fun queueMessage(recipientPubKeyHex: String, text: String): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = text,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.QUEUED,
            isOutgoing = true,
            routeUsed = "AUTO"
        )
        vault.saveMessage(msg)
        scope.launch { flushOutbox() }
        return msg
    }

    fun queueMediaMessage(
        recipientPubKeyHex: String,
        attachment: MediaAttachment,
        caption: String = ""
    ): ChatMessage {
        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = recipientPubKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = recipientPubKeyHex,
            content = caption,
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.SENDING,
            isOutgoing = true,
            routeUsed = "AUTO",
            attachment = attachment
        )
        vault.saveMessage(msg)
        mediaTransferManager.startTransfer(msg)
        _onConversationUpdated.tryEmit(Unit)
        return msg
    }

    private fun handleIncomingRawPayload(rawPayload: ByteArray, linkName: String) {
        try {
            val myIdentity = vault.getIdentityKeyPair()
            val envelope = EncryptedEnvelope.fromByteArray(rawPayload)
            val decryptedBytes = CryptoEngine.decryptFromPeer(myIdentity.privateKey, envelope)
            val json = JSONObject(String(decryptedBytes, Charsets.UTF_8))
            if (!verifyAuthenticatedPayload(json)) {
                Log.w(TAG, "Dropped unauthenticated packet received over $linkName")
                return
            }

            // Privacy-first block list: only authenticated sender identities are considered.
            val senderKey = json.optString("senderPubKey").lowercase().trim()
            if (vault.isBlocked(senderKey)) {
                Log.i(TAG, "Dropped payload from blocked peer ${senderKey.take(8)}")
                return
            }

            // Presence: any incoming traffic marks the sender as recently seen.
            if (senderKey.isNotEmpty() && senderKey != myIdentity.publicKeyHex.lowercase()) {
                touchContactPresence(senderKey)
            }

            when (json.optString("type", "CHAT_MSG")) {
                "CHAT_MSG" -> handleIncomingChat(json, linkName)
                "CHAT_EDIT" -> handleIncomingEdit(senderKey, json)
                "CHAT_DELETE" -> handleIncomingDelete(senderKey, json)
                "CHAT_REACTION" -> handleIncomingReaction(senderKey, json)
                "CHAT_PIN" -> handleIncomingPin(senderKey, json)
                "CHAT_TYPING" -> {
                    val timestamp = json.optLong("timestamp", 0L)
                    val now = System.currentTimeMillis()
                    if (timestamp in (now - 15_000L)..(now + 30_000L)) {
                        val previous = lastTypingAtByPeer[senderKey] ?: 0L
                        if (timestamp > previous) {
                            lastTypingAtByPeer[senderKey] = timestamp
                            _onTypingUpdate.tryEmit(Pair(senderKey, json.optBoolean("typing", true)))
                        }
                    }
                }
                "CHAT_READ" -> handleIncomingRead(senderKey, json)
                "CHAT_PRESENCE" -> _onPresenceSeen.tryEmit(senderKey)
                "PROFILE_UPDATE" -> handleIncomingProfileUpdate(senderKey, json)
                "ATTACHMENT_VIEWED" -> handleIncomingAttachmentViewed(senderKey, json)
                "DISAPPEAR_SYNC" -> handleIncomingDisappearSync(senderKey, json)
                "DELIVERY_RECEIPT" -> handleDeliveryReceipt(senderKey, json, false)
                "MEDIA_RECEIPT" -> handleDeliveryReceipt(senderKey, json, true)
                "MEDIA_ACCEPT" -> mediaTransferManager.onRemoteAccept(senderKey, json)
                "MEDIA_CHUNK" -> mediaTransferManager.handleIncomingChunk(json, linkName)
                "CALL_SIGNAL" -> handleIncomingCallSignal(json)
                else -> Log.w(TAG, "Unknown payload type: ${json.optString("type")}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt incoming payload from $linkName: ${e.message}")
        }
    }

    private fun touchContactPresence(senderPubKeyHex: String) {
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        if (System.currentTimeMillis() - contact.lastSeenEpochMs > 5_000L) {
            vault.addOrUpdateContact(contact.copy(lastSeenEpochMs = System.currentTimeMillis()))
        }
        _onPresenceSeen.tryEmit(senderPubKeyHex)
    }

    private fun handleIncomingChat(json: JSONObject, linkName: String) {
        val senderPubKey = json.getString("senderPubKey").lowercase()
        val msgId = json.getString("msgId")
        if (msgId.isBlank() || msgId.length > 128) return
        val alreadyStored = vault.getMessageById(msgId)
        if (alreadyStored != null) {
            if (alreadyStored.senderPubKeyHex.equals(senderPubKey, ignoreCase = true)) {
                val storedAttachment = alreadyStored.attachment
                if (storedAttachment == null) {
                    sendDeliveryReceipt(senderPubKey, msgId)
                } else if (!alreadyStored.isOutgoing && storedAttachment.transferState != TransferState.COMPLETED &&
                    vault.getContactByPubKey(senderPubKey) != null) {
                    val mode = vault.getSettings().mediaAutoDownload
                    val alreadyApproved = mediaTransferManager.isIncomingApproved(senderPubKey, storedAttachment.id)
                    val autoAllowed = mode == MediaAutoDownload.ALWAYS ||
                        (mode == MediaAutoDownload.WIFI_OR_LAN && linkName != "ONLINE_RELAY")
                    if (alreadyApproved || autoAllowed) {
                        if (mediaTransferManager.prepareIncoming(alreadyStored)) {
                            sendMediaAccept(senderPubKey, msgId, storedAttachment.id)
                        }
                    }
                }
            }
            return
        }
        val senderContact = vault.getContactByPubKey(senderPubKey)
        val senderDisplayName = senderContact?.displayName ?: json.optString("senderDisplayName", "").ifBlank {
            "Peer " + senderPubKey.take(6)
        }
        val text = json.optString("text", "")
        val timestamp = json.optLong("timestamp", System.currentTimeMillis()).coerceAtMost(System.currentTimeMillis() + 5 * 60_000L)
        val attachment = if (json.has("attachment")) parseAttachment(json.getJSONObject("attachment")) else null

        val incomingMessage = ChatMessage(
            id = msgId,
            conversationPeerPubKeyHex = senderPubKey,
            senderPubKeyHex = senderPubKey,
            recipientPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            content = text,
            timestampMs = timestamp,
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = linkName,
            replyToId = if (json.has("replyToId")) json.getString("replyToId") else null,
            replyToPreview = if (json.has("replyToPreview")) json.getString("replyToPreview") else null,
            replyToSender = if (json.has("replyToSender")) json.getString("replyToSender") else null,
            attachment = attachment
        )

        vault.saveMessage(incomingMessage)

        val isKnown = senderContact != null
        if (attachment != null) {
            val mode = vault.getSettings().mediaAutoDownload
            when {
                !isKnown -> vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = "Accept this contact request before downloading"
                    ))
                }
                mode == MediaAutoDownload.NEVER -> vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = "Auto-download is off — tap Download to get this file"
                    ))
                }
                mode == MediaAutoDownload.WIFI_OR_LAN && linkName == "ONLINE_RELAY" -> vault.updateMessage(msgId) {
                    it.copy(attachment = it.attachment?.copy(
                        transferState = TransferState.FAILED,
                        error = "Paused on mobile data — tap Download to get this file"
                    ))
                }
                else -> {
                    if (mediaTransferManager.prepareIncoming(incomingMessage)) {
                        sendMediaAccept(senderPubKey, msgId, attachment.id)
                    }
                }
            }
        }

        if (!isKnown) {
            val existingRequests = vault.getMessageRequests()
            val currentReq = existingRequests.firstOrNull { it.senderPubKeyHex.equals(senderPubKey, ignoreCase = true) }
            val newCount = (currentReq?.messageCount ?: 0) + 1
            val request = MessageRequest(
                senderPubKeyHex = senderPubKey,
                senderDisplayName = senderDisplayName,
                latestMessageText = incomingMessage.previewText,
                timestampMs = timestamp,
                messageCount = newCount
            )
            vault.addOrUpdateMessageRequest(request)
            Log.i(TAG, "Message request received from unknown peer: $senderDisplayName ($senderPubKey)")
        }

        if (attachment == null) sendDeliveryReceipt(senderPubKey, msgId)
        _onNewMessageReceived.tryEmit(incomingMessage)
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun sendMediaAccept(senderPubKeyHex: String, messageId: String, transferId: String) {
        scope.launch {
            dispatchEncryptedJson(senderPubKeyHex, JSONObject().apply {
                put("type", "MEDIA_ACCEPT")
                put("msgId", messageId)
                put("transferId", transferId)
            })
        }
    }

    private fun parseAttachment(obj: JSONObject): MediaAttachment {
        return MediaAttachment(
            id = obj.getString("id"),
            kind = try { MediaKind.valueOf(obj.getString("kind")) } catch (e: Exception) { MediaKind.DOCUMENT },
            fileName = obj.optString("fileName", "file"),
            mimeType = obj.optString("mimeType", "application/octet-stream"),
            sizeBytes = obj.optLong("sizeBytes", 0L),
            durationMs = obj.optLong("durationMs", 0L),
            width = obj.optInt("width", 0),
            height = obj.optInt("height", 0),
            viewLimit = obj.optInt("viewLimit", 0),
            transferState = TransferState.PENDING
        )
    }

    private fun handleIncomingEdit(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val newText = json.optString("text")
        val editAt = json.optLong("timestamp", System.currentTimeMillis())
        val target = vault.getMessageById(msgId) ?: return
        if (target.isOutgoing || !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        if (editAt < target.timestampMs || editAt > System.currentTimeMillis() + 5 * 60_000L) return
        if (target.isDeleted || editAt <= target.editedAtMs) return
        vault.updateMessage(msgId) {
            if (it.isOutgoing || !it.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || it.isDeleted || editAt <= it.editedAtMs) it
            else it.copy(content = newText.take(100_000), isEdited = true, editedAtMs = editAt)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingDelete(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val deletedAt = json.optLong("timestamp", System.currentTimeMillis())
        val target = vault.getMessageById(msgId) ?: return
        if (target.isOutgoing || !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        if (deletedAt < target.timestampMs || deletedAt > System.currentTimeMillis() + 5 * 60_000L) return
        if (target.deletedAtMs >= deletedAt) return
        target.attachment?.localPath?.let { path ->
            vault.deleteManagedMedia(path)
        }
        vault.updateMessage(msgId) {
            if (it.isOutgoing || !it.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || it.deletedAtMs >= deletedAt) it
            else it.copy(deletedAtMs = deletedAt, content = "", attachment = it.attachment?.copy(localPath = null))
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingReaction(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val emoji = json.optString("emoji")
        val add = json.optBoolean("add", true)
        val updatedAt = json.optLong("timestamp", 0L)
        if (emoji.isBlank() || emoji.length > 32 || updatedAt <= 0L || updatedAt > System.currentTimeMillis() + 5 * 60_000L) return
        val target = vault.getMessageById(msgId) ?: return
        if (updatedAt <= target.reactionUpdatedAtMs) return
        if (!target.conversationPeerPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) &&
            !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) &&
            !target.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        vault.updateMessage(msgId) { msg ->
            if (updatedAt <= msg.reactionUpdatedAtMs) return@updateMessage msg
            val map = msg.reactions.toMutableMap()
            val current = (map[emoji] ?: emptyList()).toMutableList()
            if (add) {
                if (!current.contains(senderPubKeyHex) && current.size < 100) current.add(senderPubKeyHex)
            } else current.remove(senderPubKeyHex)
            if (current.isEmpty()) map.remove(emoji) else map[emoji] = current
            msg.copy(reactions = map, reactionUpdatedAtMs = updatedAt)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingPin(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val target = vault.getMessageById(msgId) ?: return
        // A peer may synchronize pin state only for their own authored message; never mutate yours.
        val updatedAt = json.optLong("timestamp", 0L)
        if (updatedAt < target.timestampMs || updatedAt > System.currentTimeMillis() + 5 * 60_000L) return
        if (updatedAt <= target.pinUpdatedAtMs) return
        if (target.isOutgoing || !target.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        vault.updateMessage(msgId) {
            if (it.isOutgoing || !it.senderPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || updatedAt <= it.pinUpdatedAtMs) it
            else it.copy(isPinned = json.optBoolean("pinned", true), pinUpdatedAtMs = updatedAt)
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    private fun handleIncomingCallSignal(json: JSONObject) {
        val signalType = try { CallSignalType.valueOf(json.optString("signal")) } catch (_: Exception) { return }
        val callType = try { com.example.data.CallType.valueOf(json.optString("callType", "VOICE")) } catch (_: Exception) { return }
        val callId = json.optString("callId")
        if (!callId.matches(Regex("^[A-Za-z0-9_-]{1,64}$"))) return
        val signalTimestamp = json.optLong("timestamp", 0L)
        val now = System.currentTimeMillis()
        if (signalTimestamp <= now - 120_000L || signalTimestamp > now + 30_000L) return
        val signal = IncomingCallSignal(
            callId = callId,
            type = signalType,
            callType = callType,
            senderPubKeyHex = json.optString("senderPubKey"),
            senderDisplayName = json.optString("senderDisplayName", "Peer"),
            payload = buildMap {
                json.optString("host").takeIf { it.isNotBlank() }?.let { put("host", it) }
                json.optString("port").takeIf { it.isNotBlank() }?.let { put("port", it) }
            }
        )
        _onCallSignal.tryEmit(signal)
    }

    // ------------------------------------------------------------------
    // v2 protocol: read receipts / presence / profile / view-once / disappearing
    // ------------------------------------------------------------------

    /** Peer reports they have read everything up to lastReadMs in our conversation. */
    private fun handleIncomingRead(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val lastReadMs = json.optLong("lastReadMs", 0L)
        if (lastReadMs <= 0L) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        if (lastReadMs > contact.peerLastReadMs) {
            vault.addOrUpdateContact(contact.copy(peerLastReadMs = lastReadMs))
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Peer updated their profile (display name and/or avatar). */
    private fun handleIncomingProfileUpdate(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        val timestamp = json.optLong("timestamp", 0L)
        val now = System.currentTimeMillis()
        if (timestamp <= contact.profileUpdatedAtMs || timestamp <= 0L || timestamp > now + 5 * 60_000L || timestamp < now - 7L * 24 * 60 * 60 * 1000) return
        val newName = json.optString("displayName").trim().take(80)
        val updated = contact.copy(
            displayName = if (newName.isNotEmpty()) newName else contact.displayName,
            profileUpdatedAtMs = timestamp
        )
        vault.addOrUpdateContact(updated)

        val avatarB64 = json.optString("avatarBase64", "")
        if (avatarB64.isNotEmpty()) {
            try {
                val bytes = android.util.Base64.decode(avatarB64, android.util.Base64.NO_WRAP)
                if (bytes.isNotEmpty() && bytes.size < 512 * 1024) {
                    val dir = File(context.filesDir, "avatars")
                    if (!dir.exists()) dir.mkdirs()
                    val f = File(dir, "peer_${senderPubKeyHex.take(12)}.jpg")
                    f.writeBytes(bytes)
                    vault.setContactAvatar(senderPubKeyHex, f.absolutePath)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to store peer avatar: ${e.message}")
            }
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Recipient opened a view-limited attachment; increment and expire when spent. */
    private fun handleIncomingAttachmentViewed(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        if (msgId.isEmpty()) return
        val target = vault.getMessageById(msgId) ?: return
        if (!target.isOutgoing || !target.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true)) return
        vault.updateMessage(msgId) { m ->
            val att = m.attachment ?: return@updateMessage m
            if (att.viewLimit <= 0) return@updateMessage m
            val views = (json.optInt("viewsUsed", att.viewsUsed + 1)).coerceAtLeast(att.viewsUsed)
            m.copy(attachment = att.copy(viewsUsed = views))
        }
        // If the limit is now spent, wipe the local copy of the media.
        vault.getMessageById(msgId)?.attachment?.let { att ->
            if (att.viewLimit > 0 && att.viewsUsed >= att.viewLimit) {
                att.localPath?.let { path ->
                    vault.deleteManagedMedia(path)
                }
                vault.updateMessage(msgId) { m ->
                    m.copy(attachment = m.attachment?.copy(localPath = null))
                }
            }
        }
        _onConversationUpdated.tryEmit(Unit)
    }

    /** Peer changed the disappearing-message timer for our conversation. */
    private fun handleIncomingDisappearSync(senderPubKeyHex: String, json: JSONObject) {
        if (senderPubKeyHex.isEmpty()) return
        val contact = vault.getContactByPubKey(senderPubKeyHex) ?: return
        val seconds = json.optInt("seconds", 0)
        if (seconds !in setOf(0, 30, 300, 3600, 86400, 604800)) return
        val updatedAt = json.optLong("timestamp", 0L)
        val now = System.currentTimeMillis()
        if (updatedAt <= contact.disappearTimerUpdatedAtMs || updatedAt <= 0L ||
            updatedAt > now + 5 * 60_000L || updatedAt < now - 7L * 24 * 60 * 60 * 1000) return
        vault.addOrUpdateContact(contact.copy(
            disappearAfterSec = seconds,
            disappearAfterSetAtMs = updatedAt,
            disappearTimerUpdatedAtMs = updatedAt
        ))

        val label = com.example.data.DisappearTimer.fromSeconds(seconds).label
        val event = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = senderPubKeyHex,
            senderPubKeyHex = senderPubKeyHex,
            recipientPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            content = "",
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.DELIVERED,
            isOutgoing = false,
            routeUsed = "SYNC",
            systemEvent = "${contact.displayName} set disappearing messages to $label"
        )
        vault.saveMessage(event)
        vault.purgeExpiredDisappearingMessages()
        _onConversationUpdated.tryEmit(Unit)
    }
}
