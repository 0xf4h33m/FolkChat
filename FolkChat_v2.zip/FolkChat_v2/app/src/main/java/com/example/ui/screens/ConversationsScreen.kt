package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.crypto.CryptoEngine
import com.example.data.CallLogEntry
import com.example.data.CallOutcome
import com.example.data.CallType
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.MessageStatus
import com.example.ui.BottomTab
import com.example.ui.ChatViewModel
import com.example.ui.components.PeerAvatar
import com.example.ui.components.formatListTimestamp
import com.example.ui.components.initialsOf
import com.example.ui.theme.LocalChatColors
import java.io.File

/**
 * Main hub: Chats / Calls / People / Profile / Settings with a professional,
 * flat messenger layout driven entirely by the shared ViewModel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationsScreen(
    viewModel: ChatViewModel,
    onOpenMyCode: () -> Unit,
    onOpenAddContact: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenContactProfile: (Contact) -> Unit
) {
    val chatColors = LocalChatColors.current

    val contacts by viewModel.contacts.collectAsState()
    val allMessages by viewModel.allMessages.collectAsState()
    val peers by viewModel.discoveredPeers.collectAsState()
    val messageRequests by viewModel.messageRequests.collectAsState()
    val unreadCounts by viewModel.unreadCounts.collectAsState()
    val typingPeers by viewModel.typingPeers.collectAsState()
    val callLogs by viewModel.callLogs.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val routingPolicy by viewModel.routingPolicy.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val networkTypeName by viewModel.networkTypeName.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val displayName by viewModel.displayName.collectAsState()
    val identity by viewModel.identity.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()

    val tabIndex = when (selectedTab) {
        BottomTab.CHATS -> 0
        BottomTab.CALLS -> 1
        BottomTab.PEOPLE -> 2
        BottomTab.PROFILE -> 3
        BottomTab.SETTINGS -> 4
    }

    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showMessageRequestsDialog by remember { mutableStateOf(false) }

    LaunchedEffect(tabIndex) {
        if (tabIndex != 0) {
            isSearchActive = false
            searchQuery = ""
        }
    }

    val totalUnread = unreadCounts.values.sum()

    val myPubKey = identity.publicKeyHex.lowercase()

    fun isSelfContact(c: Contact) = c.isSelf(myPubKey)

    val (activeContacts, archivedContacts) = remember(contacts, myPubKey) {
        val nonSelf = contacts.filter { !isSelfContact(it) }
        nonSelf.partition { !it.isArchived }
    }

    val filteredActive = remember(activeContacts, searchQuery) {
        if (searchQuery.isBlank()) activeContacts
        else activeContacts.filter {
            it.displayName.contains(searchQuery, ignoreCase = true) ||
                it.x25519PublicKeyHex.contains(searchQuery, ignoreCase = true)
        }
    }
    val selfContact = contacts.firstOrNull { isSelfContact(it) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search", fontSize = 15.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(end = 8.dp)
                                .testTag("search_text_field"),
                            singleLine = true,
                            shape = RoundedCornerShape(22.dp),
                        )
                    } else if (tabIndex == 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.app_logo),
                                    contentDescription = "FolkChat logo",
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(11.dp))
                            Column {
                                Text(
                                    "FolkChat",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 21.sp,
                                    letterSpacing = (-0.55).sp
                                )
                                Text(
                                    "Private. Simple. Yours.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    } else {
                        Column {
                            Text(
                                when (tabIndex) {
                                    1 -> "Calls"
                                    2 -> "People"
                                    3 -> "Profile"
                                    else -> "Settings"
                                },
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 21.sp,
                                letterSpacing = (-0.45).sp
                            )
                            Text(
                                when (tabIndex) {
                                    1 -> "Your private conversations, by voice"
                                    2 -> "People you choose to connect with"
                                    3 -> "Your identity, your device"
                                    else -> "Privacy and app preferences"
                                },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    if (tabIndex == 0) {
                        if (isSearchActive) {
                            IconButton(onClick = {
                                searchQuery = ""
                                isSearchActive = false
                            }) {
                                Icon(Icons.Default.Close, contentDescription = "Close search")
                            }
                        } else {
                            IconButton(
                                onClick = { isSearchActive = true },
                                modifier = Modifier.testTag("open_search_button")
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Search")
                            }
                            IconButton(
                                onClick = { showMessageRequestsDialog = true },
                                modifier = Modifier.testTag("open_message_requests_top_button")
                            ) {
                                BadgedIcon(
                                    icon = Icons.Default.Shield,
                                    contentDescription = "Message requests",
                                    badgeCount = messageRequests.size
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = chatColors.topBar
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = chatColors.cardElevated,
                tonalElevation = 4.dp,
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 7.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(24.dp))
                    .testTag("bottom_navigation_bar")
            ) {
                BottomNavItem(
                    selected = tabIndex == 0,
                    onClick = { viewModel.setSelectedTab(BottomTab.CHATS) },
                    icon = {
                        if (totalUnread > 0) {
                            BadgedIcon(Icons.Default.ChatBubbleOutline, "Chats", totalUnread)
                        } else {
                            Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chats")
                        }
                    },
                    label = "Chats",
                    testTag = "nav_chats_tab"
                )
                BottomNavItem(tabIndex == 1, { viewModel.setSelectedTab(BottomTab.CALLS) }, { Icon(Icons.Default.Phone, contentDescription = "Calls") }, "Calls", "nav_calls_tab")
                BottomNavItem(tabIndex == 2, { viewModel.setSelectedTab(BottomTab.PEOPLE) }, { Icon(Icons.Default.People, contentDescription = "People") }, "People", "nav_people_tab")
                BottomNavItem(tabIndex == 3, { viewModel.setSelectedTab(BottomTab.PROFILE) }, { Icon(Icons.Default.Person, contentDescription = "Profile") }, "Profile", "nav_profile_tab")
                BottomNavItem(tabIndex == 4, { viewModel.setSelectedTab(BottomTab.SETTINGS) }, { Icon(Icons.Default.Settings, contentDescription = "Settings") }, "Settings", "nav_settings_tab")
            }
        },
        floatingActionButton = {
            if (tabIndex == 0 || tabIndex == 2) {
                FloatingActionButton(
                    onClick = onOpenAddContact,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.testTag("add_contact_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New conversation")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Slim professional link status strip
            LinkStatusStrip(
                isSimulatedOffline = viewModel.routingEngine.isSimulatedOffline(),
                isInternetAvailable = isInternetAvailable,
                peerCount = peers.size,
                onOpen = onOpenDiagnostics
            )

            when (tabIndex) {
                0 -> ChatsTab(
                    viewModel = viewModel,
                    activeContacts = filteredActive,
                    archivedContacts = archivedContacts,
                    selfContact = selfContact,
                    messages = allMessages,
                    messageRequests = messageRequests,
                    unreadCounts = unreadCounts,
                    typingPeers = typingPeers,
                    peers = peers,
                    myPubKey = myPubKey,
                    searchQuery = searchQuery,
                    onOpenRequests = { showMessageRequestsDialog = true },
                    onOpenContactProfile = onOpenContactProfile
                )
                1 -> CallsTab(
                    viewModel = viewModel,
                    contacts = activeContacts,
                    callLogs = callLogs
                )
                2 -> PeopleTab(
                    contacts = activeContacts,
                    peers = peers,
                    myPubKey = myPubKey,
                    onSelectContact = { viewModel.selectContact(it) },
                    onOpenContactProfile = onOpenContactProfile
                )
                3 -> ProfileScreen(
                    viewModel = viewModel,
                    onOpenMyCode = onOpenMyCode,
                    onOpenDiagnostics = onOpenDiagnostics
                )
                4 -> SettingsScreen(
                    viewModel = viewModel,
                    onOpenDiagnostics = onOpenDiagnostics
                )
            }
        }

        if (showMessageRequestsDialog) {
            com.example.ui.components.MessageRequestsDialog(
                requests = messageRequests,
                onAccept = { senderKey, displayName ->
                    showMessageRequestsDialog = false
                    viewModel.acceptMessageRequest(senderKey, displayName)
                },
                onDecline = { senderKey ->
                    viewModel.declineMessageRequest(senderKey)
                },
                onBlock = { senderKey, name ->
                    viewModel.blockPeer(senderKey, name)
                },
                onDismiss = { showMessageRequestsDialog = false },
            )
        }
    }
}

// ---------------------------------------------------------------------
// Bottom nav + badges
// ---------------------------------------------------------------------

@Composable
private fun RowScope.BottomNavItem(
    selected: Boolean,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    label: String,
    testTag: String
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = icon,
        label = { Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            indicatorColor = MaterialTheme.colorScheme.primary,
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        modifier = Modifier.testTag(testTag)
    )
}

@Composable
private fun BadgedIcon(
    icon: ImageVector,
    contentDescription: String,
    badgeCount: Int
) {
    if (badgeCount > 0) {
        androidx.compose.material3.BadgedBox(
            badge = {
                Badge { Text(badgeCount.toString()) }
            }
        ) {
            Icon(icon, contentDescription = contentDescription)
        }
    } else {
        Icon(icon, contentDescription = contentDescription)
    }
}

@Composable
private fun LinkStatusStrip(
    isSimulatedOffline: Boolean,
    isInternetAvailable: Boolean,
    peerCount: Int,
    onOpen: () -> Unit
) {
    val chatColors = LocalChatColors.current
    val (label, color) = when {
        isSimulatedOffline -> "Airgap mode · Offline P2P mesh only" to chatColors.statusWarning
        isInternetAvailable -> "Online · E2EE relay active" to chatColors.presenceOnline
        peerCount > 0 -> "Offline mesh active · $peerCount peer${if (peerCount > 1) "s" else ""} nearby" to chatColors.presenceOnline
        else -> "Offline · Outbox queued until peers meet" to chatColors.statusWarning
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(chatColors.searchField)
            .clickable { onOpen() }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Text(
            "ROUTING ›",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

// ---------------------------------------------------------------------
// Chats tab
// ---------------------------------------------------------------------

@Composable
private fun ChatsTab(
    viewModel: ChatViewModel,
    activeContacts: List<Contact>,
    archivedContacts: List<Contact>,
    selfContact: Contact?,
    messages: List<ChatMessage>,
    messageRequests: List<com.example.data.MessageRequest>,
    unreadCounts: Map<String, Int>,
    typingPeers: Set<String>,
    peers: List<com.example.data.DiscoveredPeer>,
    myPubKey: String,
    searchQuery: String,
    onOpenRequests: () -> Unit,
    onOpenContactProfile: (Contact) -> Unit
) {
    var showArchived by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp)
    ) {
        // Calm privacy highlight, followed by actionable requests when present.
        if (searchQuery.isBlank()) {
            item(key = "privacy_highlight") { PrivacyHighlightCard() }
        }
        if (messageRequests.isNotEmpty()) {
            item(key = "message_requests") {
                RequestsBanner(
                    count = messageRequests.size,
                    preview = messageRequests.firstOrNull()?.let { "${it.senderDisplayName}: ${it.latestMessageText}" },
                    onOpen = onOpenRequests
                )
            }
        }

        // Archived row
        if (archivedContacts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showArchived = !showArchived }
                        .background(MaterialTheme.colorScheme.background)
                        .padding(horizontal = 20.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Archive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(
                        "Archived",
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "${archivedContacts.size}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (archivedContacts.isNotEmpty() && showArchived) {
            items(archivedContacts, key = { "arch_${it.x25519PublicKeyHex}" }) { contact ->
                ConversationRow(
                    viewModel = viewModel,
                    contact = contact,
                    messages = messages,
                    peers = peers,
                    myPubKey = myPubKey,
                    unread = unreadCounts[contact.x25519PublicKeyHex.lowercase()] ?: 0,
                    isTyping = typingPeers.contains(contact.x25519PublicKeyHex.lowercase()),
                    isArchivedRow = true,
                    onOpenContactProfile = onOpenContactProfile
                )
            }
        }

        if (searchQuery.isBlank()) {
            item(key = "recent_chats_heading") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Recent conversations",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.15).sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        activeContacts.size.toString(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Saved notes pinned row (hidden while searching)
        if (selfContact != null && searchQuery.isBlank()) {
            item(key = "saved_notes") {
                ConversationRow(
                    viewModel = viewModel,
                    contact = selfContact,
                    messages = messages,
                    peers = peers,
                    myPubKey = myPubKey,
                    unread = 0,
                    isTyping = false,
                    isArchivedRow = false,
                    onOpenContactProfile = onOpenContactProfile
                )
            }
        }

        if (activeContacts.isEmpty() && archivedContacts.isEmpty()) {
            item {
                EmptyChatsState(
                    onOpenSavedNotes = { viewModel.openSavedNotes() }
                )
            }
        } else {
            items(activeContacts, key = { it.x25519PublicKeyHex }) { contact ->
                ConversationRow(
                    viewModel = viewModel,
                    contact = contact,
                    messages = messages,
                    peers = peers,
                    myPubKey = myPubKey,
                    unread = unreadCounts[contact.x25519PublicKeyHex.lowercase()] ?: 0,
                    isTyping = typingPeers.contains(contact.x25519PublicKeyHex.lowercase()),
                    isArchivedRow = false,
                    onOpenContactProfile = onOpenContactProfile
                )
            }
            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}


@Composable
private fun PrivacyHighlightCard() {
    val chatColors = LocalChatColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(horizontal = 15.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Shield,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "Your privacy comes first",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                "Encrypted messaging · Backups off by default",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
            Icons.Default.CheckCircle,
            contentDescription = "Privacy settings overview",
            tint = chatColors.presenceOnline,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun RequestsBanner(count: Int, preview: String?, onOpen: () -> Unit) {
    val chatColors = LocalChatColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(chatColors.cardElevated)
            .border(1.dp, chatColors.borderSubtle, RoundedCornerShape(18.dp))
            .clickable { onOpen() }
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("message_requests_banner"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Shield,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Message requests",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (count > 0) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 7.dp, vertical = 1.dp)
                    ) {
                        Text(
                            count.toString(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
            Text(
                preview ?: "Encrypted requests from new peers appear here",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            Icons.Default.Schedule,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun ConversationRow(
    viewModel: ChatViewModel,
    contact: Contact,
    messages: List<ChatMessage>,
    peers: List<com.example.data.DiscoveredPeer>,
    myPubKey: String,
    unread: Int,
    isTyping: Boolean,
    isArchivedRow: Boolean,
    onOpenContactProfile: (Contact) -> Unit
) {
    val chatColors = LocalChatColors.current
    val currentSettings by viewModel.settings.collectAsState()
    val isChatLocked = contact.x25519PublicKeyHex.lowercase() in currentSettings.lockedChatKeys
    var menuOpen by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmBlock by remember { mutableStateOf(false) }

    val isSelf = contact.isSelf(myPubKey)
    val lastMessage = remember(messages, contact) {
        messages
            .filter { it.conversationPeerPubKeyHex.equals(contact.x25519PublicKeyHex, ignoreCase = true) }
            .maxByOrNull { it.timestampMs }
    }

    val isNearby = remember(peers, contact, isSelf) {
        if (isSelf) true
        else {
            try {
                val pubBytes = CryptoEngine.hexToBytes(contact.x25519PublicKeyHex)
                val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(pubBytes))
                peers.any { p ->
                    p.tagHex.equals(expectedTag, ignoreCase = true) ||
                        (p.tagHex.length >= 16 && expectedTag.startsWith(p.tagHex, ignoreCase = true)) ||
                        (expectedTag.length >= 16 && p.tagHex.startsWith(expectedTag.take(16), ignoreCase = true)) ||
                        (p.linkType == "WIFI_SOCKET" && p.tagHex == "manual")
                }
            } catch (e: Exception) {
                false
            }
        }
    }

    val peerReadMs = contact.peerLastReadMs
    val isOnline = isSelf || isNearby || contact.isOnlineNow()

    Box {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 3.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (unread > 0) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.58f)
                    else chatColors.cardElevated
                )
                .clickable { viewModel.selectContact(contact) }
                .padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PeerAvatar(
                name = contact.displayName,
                avatarPath = contact.avatarPath,
                size = 54.dp,
                isOnline = isOnline,
                showPresence = !isSelf
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isSelf) "Saved Notes" else contact.displayName,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (isChatLocked) {
                            Spacer(modifier = Modifier.width(5.dp))
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = "Locked chat",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        if (contact.isMuted) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                Icons.Default.NotificationsOff,
                                contentDescription = "Muted",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    if (!isChatLocked && lastMessage != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = formatListTimestamp(lastMessage.timestampMs),
                            fontSize = 11.sp,
                            color = if (unread > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = if (unread > 0) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Typing indicator overrides preview
                    if (isTyping && !isChatLocked) {
                        Text(
                            "typing…",
                            fontSize = 13.sp,
                            fontStyle = FontStyle.Italic,
                            color = chatColors.presenceOnline,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        // Outgoing status ticks
                        if (!isChatLocked && lastMessage?.isOutgoing == true && !isSelf) {
                            val (icon, tint) = when {
                                lastMessage.status == MessageStatus.FAILED -> Icons.Default.Info to chatColors.statusError
                                lastMessage.status == MessageStatus.QUEUED -> Icons.Default.Schedule to chatColors.statusWarning
                                lastMessage.timestampMs <= peerReadMs && peerReadMs > 0 -> Icons.Default.DoneAll to chatColors.statusSuccess
                                else -> Icons.Default.Check to MaterialTheme.colorScheme.onSurfaceVariant
                            }
                            Icon(
                                icon,
                                contentDescription = null,
                                tint = tint,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                        }
                        Text(
                            text = if (isChatLocked) "Locked chat · tap to unlock" else lastMessage?.previewText
                                ?: (if (isSelf) "Notes to self, end-to-end encrypted" else "Tap to start a private conversation"),
                            fontSize = 13.sp,
                            color = if (lastMessage != null && !isChatLocked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (unread > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary)
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                unread.toString(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }
            }

            // Long-press actions
            Spacer(modifier = Modifier.width(4.dp))
            Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(30.dp)) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Conversation options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(16.dp)
                    )
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    if (!isSelf) {
                        DropdownMenuItem(
                            text = { Text("Voice call") },
                            leadingIcon = { Icon(Icons.Default.Call, null, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; viewModel.startCall(contact, false) }
                        )
                        DropdownMenuItem(
                            text = { Text("Video call") },
                            leadingIcon = { Icon(Icons.Default.Videocam, null, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; viewModel.startCall(contact, true) }
                        )
                        DropdownMenuItem(
                            text = { Text("View profile") },
                            leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; onOpenContactProfile(contact) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (contact.isArchived) "Unarchive" else "Archive") },
                            leadingIcon = { Icon(Icons.Default.Archive, null, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; viewModel.toggleArchive(contact) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (contact.isMuted) "Unmute notifications" else "Mute notifications") },
                            leadingIcon = { Icon(Icons.Default.NotificationsOff, null, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; viewModel.toggleMute(contact) }
                        )
                        DropdownMenuItem(
                            text = { Text("Clear chat", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp)) },
                            onClick = {
                                menuOpen = false
                                viewModel.clearChatHistory(contact.x25519PublicKeyHex)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete contact", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; confirmDelete = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Block", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Block, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; confirmBlock = true }
                        )
                    } else {
                        DropdownMenuItem(
                            text = { Text("Open notes") },
                            leadingIcon = { Icon(Icons.Default.Bookmark, null, modifier = Modifier.size(18.dp)) },
                            onClick = { menuOpen = false; viewModel.selectContact(contact) }
                        )
                    }
                }
            }
        }

        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Delete ${contact.displayName}?") },
                text = { Text("This removes the contact. Message history on your device stays until cleared separately.") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteContact(contact.x25519PublicKeyHex)
                        confirmDelete = false
                    }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
            )
        }
        if (confirmBlock) {
            AlertDialog(
                onDismissRequest = { confirmBlock = false },
                title = { Text("Block ${contact.displayName}?") },
                text = { Text("Blocked peers can no longer message or call you. You can unblock them later from Settings → Privacy.") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.blockPeer(contact.x25519PublicKeyHex, contact.displayName)
                        confirmBlock = false
                    }) { Text("Block", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { confirmBlock = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun EmptyChatsState(
    onOpenSavedNotes: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 56.dp)
    ) {
        Icon(
            Icons.Default.ChatBubbleOutline,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            "Your sovereign inbox",
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            "Scan a peer's QR code to establish an end-to-end encrypted link — no phone number, no server account.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 19.sp
        )
        Spacer(modifier = Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TextButton(onClick = onOpenSavedNotes) {
                Icon(Icons.Default.Bookmark, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Saved Notes")
            }
        }
    }
}

// ---------------------------------------------------------------------
// Calls tab (WhatsApp-style)
// ---------------------------------------------------------------------

@Composable
private fun CallsTab(
    viewModel: ChatViewModel,
    contacts: List<Contact>,
    callLogs: List<CallLogEntry>
) {
    val chatColors = LocalChatColors.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 6.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text(
                    "Recent",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        if (callLogs.isEmpty()) {
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp)
                ) {
                    Icon(
                        Icons.Default.Phone,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        "No calls yet",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Start an encrypted voice or video call from any chat",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(end = 16.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        "Clear history",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .clickable { viewModel.clearCallHistory() }
                            .padding(vertical = 4.dp)
                    )
                }
            }
            items(callLogs.take(50), key = { it.id }) { log ->
                CallLogRow(
                    log = log,
                    chatColors = chatColors,
                    onRedial = {
                        contacts.firstOrNull {
                            it.x25519PublicKeyHex.equals(log.peerPubKeyHex, ignoreCase = true)
                        }?.let { c -> viewModel.startCall(c, log.type == CallType.VIDEO) }
                    }
                )
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text(
                "Contacts",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
            )
        }

        if (contacts.isEmpty()) {
            item {
                Text(
                    "Add contacts to place direct peer-to-peer calls",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 20.dp)
                )
            }
        } else {
            items(contacts, key = { "call_${it.x25519PublicKeyHex}" }) { contact ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PeerAvatar(
                        name = contact.displayName,
                        avatarPath = contact.avatarPath,
                        size = 46.dp,
                        isOnline = contact.isOnlineNow(),
                        showPresence = true
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            contact.displayName,
                            fontWeight = FontWeight.Medium,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            if (contact.isOnlineNow()) "Online · direct link ready" else "Offline · will ring when in range",
                            fontSize = 12.sp,
                            color = if (contact.isOnlineNow()) chatColors.presenceOnline else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { viewModel.startCall(contact, false) }) {
                        Icon(Icons.Default.Call, contentDescription = "Voice call", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { viewModel.startCall(contact, true) }) {
                        Icon(Icons.Default.Videocam, contentDescription = "Video call", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}

@Composable
private fun CallLogRow(
    log: CallLogEntry,
    chatColors: com.example.ui.theme.CustomChatColors,
    onRedial: () -> Unit
) {
    val (outcomeColor, outcomeLabel) = when (log.outcome) {
        CallOutcome.COMPLETED -> chatColors.statusSuccess to "Completed"
        CallOutcome.MISSED -> chatColors.statusError to "Missed"
        CallOutcome.DECLINED -> chatColors.statusWarning to "Declined"
        CallOutcome.CANCELED -> MaterialTheme.colorScheme.onSurfaceVariant to "Cancelled"
        CallOutcome.FAILED -> chatColors.statusError to "Failed"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRedial() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PeerAvatar(name = log.peerName, avatarPath = null, size = 46.dp)
        Spacer(modifier = Modifier.width(14.dp))
        Icon(
            imageVector = if (log.isOutgoing) Icons.AutoMirrored.Filled.CallMade else Icons.AutoMirrored.Filled.CallReceived,
            contentDescription = null,
            tint = outcomeColor,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                log.peerName,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                buildString {
                    append(outcomeLabel)
                    if (log.durationSeconds > 0) append(" · ${formatCallDuration(log.durationSeconds)}")
                    append(" · ${formatListTimestamp(log.timestampMs)}")
                },
                fontSize = 12.sp,
                color = outcomeColor
            )
        }
        Icon(
            imageVector = if (log.type == CallType.VIDEO) Icons.Default.Videocam else Icons.Default.Call,
            contentDescription = "Call again",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
    }
}

fun formatCallDuration(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}

// ---------------------------------------------------------------------
// People tab
// ---------------------------------------------------------------------

@Composable
private fun PeopleTab(
    contacts: List<Contact>,
    peers: List<com.example.data.DiscoveredPeer>,
    myPubKey: String,
    onSelectContact: (Contact) -> Unit,
    onOpenContactProfile: (Contact) -> Unit
) {
    val chatColors = LocalChatColors.current

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Contacts · ${contacts.size}",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (contacts.isEmpty()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 64.dp)
            ) {
                Icon(
                    Icons.Default.People,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                    modifier = Modifier.size(52.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text("No contacts yet", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Scan a QR code or paste a public key to add your first peer",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(contacts, key = { it.x25519PublicKeyHex }) { contact ->
                    val isNearby = remember(peers, contact) {
                        try {
                            val pubBytes = CryptoEngine.hexToBytes(contact.x25519PublicKeyHex)
                            val expectedTag = CryptoEngine.bytesToHex(CryptoEngine.computeRotatingTag(pubBytes))
                            peers.any { p ->
                                p.tagHex.equals(expectedTag, ignoreCase = true) ||
                                    (p.tagHex.length >= 16 && expectedTag.startsWith(p.tagHex, ignoreCase = true)) ||
                                    (expectedTag.length >= 16 && p.tagHex.startsWith(expectedTag.take(16), ignoreCase = true))
                            }
                        } catch (e: Exception) {
                            false
                        }
                    }
                    val online = isNearby || contact.isOnlineNow()

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.background)
                            .clickable { onSelectContact(contact) }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PeerAvatar(
                            name = contact.displayName,
                            avatarPath = contact.avatarPath,
                            size = 48.dp,
                            isOnline = online,
                            showPresence = true
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                contact.displayName,
                                fontWeight = FontWeight.Medium,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                if (online) "Online" else formatPresenceShort(contact.lastSeenEpochMs),
                                fontSize = 12.sp,
                                color = if (online) chatColors.presenceOnline else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { onOpenContactProfile(contact) }) {
                            Icon(Icons.Default.Info, contentDescription = "Profile", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun formatPresenceShort(lastSeenMs: Long): String {
    return if (lastSeenMs <= 0L) "Offline"
    else "Last seen ${formatListTimestamp(lastSeenMs).lowercase()}"
}
