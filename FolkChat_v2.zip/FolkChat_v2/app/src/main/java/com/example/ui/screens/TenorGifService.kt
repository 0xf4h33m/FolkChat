package com.example.ui.screens

import android.content.Context
import android.net.Uri
import com.example.BuildConfig
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import com.example.data.TransferState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/** GIF discovery/download adapter for the Tenor v2 API. The API key is supplied at build time. */
internal object TenorGifService {
    private const val API_BASE = "https://tenor.googleapis.com/v2"
    private const val CLIENT_KEY = "folkchat_android"
    private const val MAX_GIF_BYTES = 15L * 1024L * 1024L

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .build()

    fun isConfigured(): Boolean = BuildConfig.TENOR_API_KEY.isNotBlank()

    suspend fun featured(): List<TenorGif> = withContext(Dispatchers.IO) {
        requireConfigured()
        val url = Uri.parse("$API_BASE/featured").buildUpon()
            .appendQueryParameter("key", BuildConfig.TENOR_API_KEY)
            .appendQueryParameter("client_key", CLIENT_KEY)
            .appendQueryParameter("limit", "24")
            .appendQueryParameter("media_filter", "tinygif,gif")
            .appendQueryParameter("contentfilter", "high")
            .appendQueryParameter("country", "PK")
            .appendQueryParameter("locale", "en_PK")
            .build().toString()
        requestResults(url)
    }

    suspend fun search(query: String): List<TenorGif> = withContext(Dispatchers.IO) {
        requireConfigured()
        val trimmed = query.trim()
        if (trimmed.isBlank()) return@withContext featured()
        val url = Uri.parse("$API_BASE/search").buildUpon()
            .appendQueryParameter("q", trimmed)
            .appendQueryParameter("key", BuildConfig.TENOR_API_KEY)
            .appendQueryParameter("client_key", CLIENT_KEY)
            .appendQueryParameter("limit", "24")
            .appendQueryParameter("media_filter", "tinygif,gif")
            .appendQueryParameter("contentfilter", "high")
            .appendQueryParameter("country", "PK")
            .appendQueryParameter("locale", "en_PK")
            .build().toString()
        requestResults(url)
    }

    private fun requireConfigured() {
        if (!isConfigured()) throw IllegalStateException("GIF search needs a Tenor API key. Add TENOR_API_KEY to Gradle properties and rebuild.")
    }

    private fun requestResults(url: String): List<TenorGif> {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "FolkChat/1.0 (Android)")
            .get()
            .build()
        return client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val code = response.code
                throw IOException(if (code == 401 || code == 403) "Tenor rejected the API key. Check the key and API restrictions." else "GIF search failed (HTTP $code). Try again.")
            }
            val json = JSONObject(response.body?.string() ?: "{}")
            val items = json.optJSONArray("results") ?: return emptyList()
            buildList {
                for (index in 0 until items.length()) {
                    val item = items.optJSONObject(index) ?: continue
                    val formats = item.optJSONObject("media_formats") ?: continue
                    val preview = formats.optJSONObject("tinygif")
                        ?: formats.optJSONObject("nanogif")
                        ?: formats.optJSONObject("mediumgif")
                        ?: formats.optJSONObject("gif")
                        ?: continue
                    val full = formats.optJSONObject("gif")
                        ?: formats.optJSONObject("mediumgif")
                        ?: formats.optJSONObject("tinygif")
                        ?: continue
                    val previewUrl = preview.optString("url").takeIf { isTenorHttpsUrl(it) } ?: continue
                    val fullUrl = full.optString("url").takeIf { isTenorHttpsUrl(it) } ?: continue
                    val dims = full.optJSONArray("dims")
                    add(
                        TenorGif(
                            id = item.optString("id", "tenor-$index"),
                            description = item.optString("content_description", "Animated GIF").ifBlank { "Animated GIF" },
                            previewUrl = previewUrl,
                            fullUrl = fullUrl,
                            width = dims?.optInt(0, 0) ?: 0,
                            height = dims?.optInt(1, 0) ?: 0
                        )
                    )
                }
            }
        }
    }

    suspend fun downloadAsAttachment(context: Context, gif: TenorGif): MediaAttachment = withContext(Dispatchers.IO) {
        if (!isTenorHttpsUrl(gif.fullUrl)) throw IOException("The selected GIF URL is not trusted.")
        val request = Request.Builder().url(gif.fullUrl).header("User-Agent", "FolkChat/1.0 (Android)").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Could not download this GIF (HTTP ${response.code}).")
            val body = response.body ?: throw IOException("The GIF response was empty.")
            val mime = body.contentType()?.toString()?.substringBefore(';')?.lowercase() ?: "image/gif"
            if (!mime.startsWith("image/")) throw IOException("Tenor did not return an image file.")
            if (body.contentLength() > MAX_GIF_BYTES) throw IOException("This GIF is larger than 15 MB. Choose a smaller one.")

            val mediaDir = File(context.filesDir, "media").apply { mkdirs() }
            val safeId = UUID.randomUUID().toString()
            val extension = when (mime) {
                "image/webp" -> "webp"
                "image/png" -> "png"
                else -> "gif"
            }
            val destination = File(mediaDir, "tenor_${safeId}.$extension")
            try {
                body.byteStream().use { input ->
                    destination.outputStream().use { output ->
                        val buffer = ByteArray(32 * 1024)
                        var total = 0L
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            total += count
                            if (total > MAX_GIF_BYTES) throw IOException("This GIF is larger than 15 MB. Choose a smaller one.")
                            output.write(buffer, 0, count)
                        }
                    }
                }
                if (!destination.isFile || destination.length() == 0L) throw IOException("The GIF download was empty.")
                MediaAttachment(
                    id = safeId,
                    kind = MediaKind.IMAGE,
                    fileName = "FolkChat_${safeId.take(8)}.$extension",
                    mimeType = mime,
                    sizeBytes = destination.length(),
                    width = gif.width,
                    height = gif.height,
                    localPath = destination.absolutePath,
                    transferState = TransferState.PENDING,
                    progress = 0f
                )
            } catch (error: Exception) {
                destination.delete()
                throw error
            }
        }
    }

    private fun isTenorHttpsUrl(value: String): Boolean {
        return try {
            val parsed = Uri.parse(value)
            parsed.scheme.equals("https", ignoreCase = true) &&
                parsed.host?.lowercase()?.let { it == "tenor.com" || it.endsWith(".tenor.com") } == true
        } catch (_: Exception) {
            false
        }
    }
}

internal data class TenorGif(
    val id: String,
    val description: String,
    val previewUrl: String,
    val fullUrl: String,
    val width: Int,
    val height: Int
)
