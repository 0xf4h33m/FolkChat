package com.example.net.media

import android.util.Base64
import android.util.Log
import com.example.crypto.CryptoEngine
import com.example.data.ChatMessage
import com.example.data.EncryptedVault
import com.example.data.MediaAttachment
import com.example.data.MediaKind
import com.example.data.MessageStatus
import com.example.data.TransferState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Transfers media attachments (images, videos, documents, voice notes) as
 * chunked, end-to-end encrypted envelopes over the existing P2P transport.
 *
 * Outgoing transfers report progress, can be cancelled and retried.
 * Incoming transfers are reassembled into the app's private media directory.
 */
class MediaTransferManager(
    private val vault: EncryptedVault,
    private val mediaDir: File,
    private val dispatcher: suspend (String, JSONObject) -> String?,
    private val onUpdated: () -> Unit
) {
    companion object {
        private const val TAG = "MediaTransfer"
        private const val CHUNK_SIZE_SOCKET = 48 * 1024
        private const val CHUNK_SIZE_BLE = 280
        private const val MAX_CHUNKS = 65_536
        private const val MAX_ACTIVE_INCOMING = 4
        private const val INCOMING_IDLE_TIMEOUT_MS = 10 * 60_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cancelled = ConcurrentHashMap.newKeySet<String>()
    private val activeTransfers = ConcurrentHashMap.newKeySet<String>()
    private val approvedIncoming = ConcurrentHashMap.newKeySet<String>()
    private val pendingAccepts = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private val preAcceptedTransfers = ConcurrentHashMap.newKeySet<String>()
    private val incomingStreams = mutableMapOf<String, IncomingTransfer>()
    private val mutex = Mutex()

    private class IncomingTransfer(
        val file: File,
        val randomAccess: RandomAccessFile,
        val totalChunks: Int,
        val chunkSize: Int,
        val claimedSize: Long,
        val messageId: String,
        val senderPubKeyHex: String,
        var lastUpdatedAtMs: Long = System.currentTimeMillis(),
        val receivedChunks: MutableSet<Int> = mutableSetOf()
    )

    init {
        mediaDir.mkdirs()
    }

    fun resolveLocalFile(attachment: MediaAttachment?): File? {
        val path = attachment?.localPath ?: return null
        val f = File(path)
        return if (f.exists()) f else null
    }

    /** Kick off (or resume) an outgoing media transfer for [message]. */
    fun startTransfer(message: ChatMessage, restart: Boolean = false) {
        val attachment = message.attachment ?: return
        message.recipientPubKeyHex.let { recipient ->
            if (!activeTransfers.add(attachment.id)) return
            if (restart) cancelled.remove(attachment.id)
            scope.launch {
                try { runOutgoing(message, recipient) }
                finally { activeTransfers.remove(attachment.id) }
            }
        }
    }

    /** Re-attempts a failed or cancelled transfer. */
    fun retry(messageId: String) {
        val message = vault.getMessageById(messageId) ?: return
        if (message.attachment == null) return
        if (!message.isOutgoing) {
            scope.launch { requestIncomingDownload(message) }
            return
        }
        val attachmentId = message.attachment.id
        cancelled.remove(attachmentId)
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.SENDING,
                attachment = it.attachment?.copy(
                    transferState = TransferState.PENDING,
                    progress = 0f,
                    error = null
                )
            )
        }
        onUpdated()
        startTransfer(vault.getMessageById(messageId) ?: message, restart = true)
    }

    /** Handle an authenticated MEDIA_ACCEPT from the recipient. */
    fun onRemoteAccept(senderPubKeyHex: String, json: JSONObject) {
        val msgId = json.optString("msgId")
        val transferId = json.optString("transferId")
        if (msgId.isBlank() || !isSafeTransferId(transferId)) return
        val message = vault.getMessageById(msgId) ?: return
        val attachment = message.attachment ?: return
        if (!message.isOutgoing || !message.recipientPubKeyHex.equals(senderPubKeyHex, ignoreCase = true) || attachment.id != transferId) return
        val key = incomingKey(senderPubKeyHex, transferId)
        val waiting = pendingAccepts[key]
        if (waiting != null) {
            waiting.complete(true)
        } else {
            // A recipient can accept after a previous send attempt timed out.
            preAcceptedTransfers.add(key)
            if (!activeTransfers.contains(attachment.id)) {
                vault.updateMessage(msgId) {
                    it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(
                        transferState = TransferState.PENDING, progress = 0f, error = null
                    ))
                }
                startTransfer(vault.getMessageById(msgId) ?: message, restart = true)
            }
        }
    }

    private suspend fun requestIncomingDownload(message: ChatMessage) {
        val attachment = message.attachment ?: return
        val sender = message.senderPubKeyHex.lowercase()
        if (vault.getContactByPubKey(sender) == null) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(
                    transferState = TransferState.FAILED,
                    error = "Accept this contact request before downloading"
                ))
            }
            onUpdated()
            return
        }
        val key = incomingKey(sender, attachment.id)
        approvedIncoming.add(key)
        vault.updateMessage(message.id) {
            it.copy(attachment = it.attachment?.copy(
                transferState = TransferState.IN_PROGRESS, progress = 0f, error = null
            ))
        }
        onUpdated()
        var sent = false
        repeat(3) { attempt ->
            if (!sent) {
                sent = dispatcher(sender, JSONObject().apply {
                    put("type", "MEDIA_ACCEPT")
                    put("msgId", message.id)
                    put("transferId", attachment.id)
                }) != null
                if (!sent && attempt < 2) delay(500L * (attempt + 1))
            }
        }
        if (!sent) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(
                    transferState = TransferState.FAILED,
                    error = "Could not reach sender — tap Download to retry"
                ))
            }
            onUpdated()
        }
    }

    fun cancel(messageId: String) {
        val message = vault.getMessageById(messageId) ?: return
        val attachment = message.attachment ?: return
        cancelled.add(attachment.id)
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.CANCELLED, error = "Cancelled")
            )
        }
        onUpdated()
    }

    private suspend fun runOutgoing(message: ChatMessage, recipientHex: String) {
        val attachment = message.attachment ?: return
        val sourceFile = resolveLocalFile(attachment)
        if (sourceFile == null || !sourceFile.exists()) {
            markFailed(message.id, attachment.id, "Local file missing")
            return
        }
        val acceptKey = incomingKey(recipientHex, attachment.id)
        val acceptance = CompletableDeferred<Boolean>()
        pendingAccepts[acceptKey] = acceptance
        val acceptedBeforeStart = preAcceptedTransfers.remove(acceptKey)
        try {
            val totalBytes = sourceFile.length()
            if (totalBytes < 0L || totalBytes > MAX_INCOMING_BYTES) {
                markFailed(message.id, attachment.id, "Files larger than 2 GB are not supported")
                return
            }
            var chunkSize = CHUNK_SIZE_SOCKET

            // Send metadata first. The recipient explicitly accepts before bytes flow;
            // this makes NEVER/Wi-Fi-only download preferences real rather than cosmetic.
            val route = dispatchWithRetry(recipientHex, buildChatEnvelope(message))
            if (route == null) {
                markFailed(message.id, attachment.id, "Peer unreachable — check the relay connection or retry")
                return
            }
            if (route == "OFFLINE_BLE_MESH") chunkSize = CHUNK_SIZE_BLE
            val accepted = acceptedBeforeStart || (withTimeoutOrNull(120_000L) { acceptance.await() } ?: false)
            if (!accepted) {
                markFailed(message.id, attachment.id, "Waiting for recipient to accept the download — tap Retry")
                return
            }
            if (isCancelled(attachment.id)) {
                markCancelled(message.id)
                return
            }

            vault.updateMessage(message.id) {
                it.copy(status = MessageStatus.SENDING, attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS))
            }
            onUpdated()

            RandomAccessFile(sourceFile, "r").use { raf ->
                val adjustedTotalLong = if (totalBytes == 0L) 1L else (totalBytes + chunkSize - 1L) / chunkSize.toLong()
                if (adjustedTotalLong !in 1..MAX_CHUNKS.toLong()) {
                    markFailed(message.id, attachment.id, "File is too large for this transport")
                    return
                }
                val adjustedTotal = adjustedTotalLong.toInt()
                val buffer = ByteArray(chunkSize)
                var index = 0
                var offset = 0L
                while (index < adjustedTotal) {
                    if (isCancelled(attachment.id)) {
                        markCancelled(message.id)
                        return
                    }
                    val read = if (totalBytes == 0L) 0 else {
                        raf.seek(offset)
                        raf.read(buffer, 0, minOf(chunkSize.toLong(), totalBytes - offset).toInt())
                    }
                    if (read < 0 || (read == 0 && totalBytes > 0L)) {
                        markFailed(message.id, attachment.id, "Could not read the selected file")
                        return
                    }
                    val dataB64 = Base64.encodeToString(if (read > 0) buffer.copyOf(read) else ByteArray(0), Base64.NO_WRAP)
                    val chunkJson = JSONObject().apply {
                        put("type", "MEDIA_CHUNK")
                        put("transferId", attachment.id)
                        put("msgId", message.id)
                        put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                        put("senderDisplayName", vault.getDisplayName())
                        put("recipientPubKey", recipientHex)
                        put("index", index)
                        put("total", adjustedTotal)
                        put("chunkSize", chunkSize)
                        put("data", dataB64)
                        put("timestamp", System.currentTimeMillis())
                    }
                    val chunkRoute = dispatchWithRetry(recipientHex, chunkJson)
                    if (chunkRoute == null) {
                        markFailed(message.id, attachment.id, "Transfer interrupted — tap Retry")
                        return
                    }
                    offset += read.coerceAtLeast(0)
                    index++
                    val progress = if (totalBytes <= 0L) 1f else (offset.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                    if (index % 8 == 0 || index >= adjustedTotal) {
                        vault.updateMessage(message.id) {
                            it.copy(attachment = it.attachment?.copy(progress = progress, transferState = TransferState.IN_PROGRESS))
                        }
                        onUpdated()
                    }
                }
            }

            vault.updateMessage(message.id) {
                it.copy(
                    status = MessageStatus.SENDING,
                    routeUsed = route,
                    lastAttemptAtMs = System.currentTimeMillis(),
                    attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = 1f)
                )
            }
            onUpdated()
        } catch (e: Exception) {
            Log.e(TAG, "Outgoing media transfer failed: ${e.message}")
            markFailed(message.id, attachment.id, e.message ?: "Transfer failed")
        } finally {
            pendingAccepts.remove(acceptKey, acceptance)
        }
    }

    private suspend fun dispatchWithRetry(recipientHex: String, json: JSONObject): String? {
        repeat(3) { attempt ->
            val route = dispatcher(recipientHex, JSONObject(json.toString()))
            if (route != null) return route
            if (attempt < 2) delay(350L * (attempt + 1))
        }
        return null
    }

    private fun incomingKey(senderPubKeyHex: String, transferId: String): String =
        "${senderPubKeyHex.lowercase()}_$transferId"

    private fun buildChatEnvelope(message: ChatMessage): JSONObject {
        val attachment = message.attachment
        return JSONObject().apply {
            put("type", "CHAT_MSG")
            put("msgId", message.id)
            put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
            put("senderDisplayName", vault.getDisplayName())
            put("recipientPubKey", message.recipientPubKeyHex)
            put("text", message.content)
            put("timestamp", message.timestampMs)
            message.replyToId?.let { put("replyToId", it) }
            message.replyToPreview?.let { put("replyToPreview", it) }
            message.replyToSender?.let { put("replyToSender", it) }
            if (attachment != null) {
                put("attachment", JSONObject().apply {
                    put("id", attachment.id)
                    put("kind", attachment.kind.name)
                    put("fileName", attachment.fileName)
                    put("mimeType", attachment.mimeType)
                    put("sizeBytes", attachment.sizeBytes)
                    put("durationMs", attachment.durationMs)
                    put("width", attachment.width)
                    put("height", attachment.height)
                    put("viewLimit", attachment.viewLimit)
                })
            }
        }
    }

    // ------------------------------------------------------------------
    // Incoming
    // ------------------------------------------------------------------

    fun isIncomingApproved(senderPubKeyHex: String, transferId: String): Boolean =
        approvedIncoming.contains(incomingKey(senderPubKeyHex, transferId))

    /** Called when a CHAT_MSG carrying an attachment arrives. Returns true if accepted. */
    fun prepareIncoming(message: ChatMessage, totalChunks: Int = -1): Boolean {
        val attachment = message.attachment ?: return false
        if (!isSafeTransferId(attachment.id) || attachment.sizeBytes < 0L || attachment.sizeBytes > MAX_INCOMING_BYTES) {
            vault.updateMessage(message.id) {
                it.copy(attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = "Invalid or oversized attachment"))
            }
            onUpdated()
            return false
        }
        // Accepting metadata also authorizes exactly this sender + transfer. This set is
        // checked on every chunk so a stranger cannot stream files before consent.
        approvedIncoming.add(incomingKey(message.senderPubKeyHex, attachment.id))
        return true
    }

    fun handleIncomingChunk(json: JSONObject, linkName: String) {
        val transferId = json.optString("transferId")
        val msgId = json.optString("msgId")
        val senderKey = json.optString("senderPubKey").lowercase()
        val index = json.optInt("index", -1)
        val total = json.optInt("total", -1)
        val chunkSize = json.optInt("chunkSize", CHUNK_SIZE_SOCKET)
        val dataB64 = json.optString("data")
        if (!isSafeTransferId(transferId) || msgId.isBlank() || msgId.length > 128 ||
            !senderKey.matches(Regex("^[0-9a-f]{64}$")) || index < 0 || total !in 1..MAX_CHUNKS ||
            chunkSize !in 1..CHUNK_SIZE_SOCKET) return
        // Scope local temp files and reassembly sessions to the authenticated sender as
        // well as attachment id; one contact must not collide with another's transfer.
        val streamKey = "${senderKey}_$transferId"

        val message = vault.getMessageById(msgId) ?: return
        val attachment = message.attachment ?: return
        if (message.isOutgoing || !message.senderPubKeyHex.equals(senderKey, ignoreCase = true) || attachment.id != transferId) return
        if (vault.getContactByPubKey(senderKey) == null) return // unknown peers cannot stream files before request acceptance
        if (attachment.sizeBytes < 0L || attachment.sizeBytes > MAX_INCOMING_BYTES) return

        // No file is written until the receiver's automatic policy or an explicit
        // Download tap has authorized this sender/transfer pair.
        if (!approvedIncoming.contains(streamKey)) return

        val bytes = try { Base64.decode(dataB64, Base64.NO_WRAP) } catch (_: Exception) { return }
        if (bytes.size > chunkSize) return
        val expectedTotal = maxOf(1L, (attachment.sizeBytes + chunkSize - 1L) / chunkSize.toLong())
        if (expectedTotal != total.toLong() || index >= total) return
        val expectedChunkBytes = if (index < total - 1) chunkSize else (attachment.sizeBytes - index.toLong() * chunkSize).coerceAtLeast(0L).toInt()
        if (bytes.size != expectedChunkBytes) return

        scope.launch {
            mutex.withLock {
                cleanupStaleTransfersLocked()
                var entry = incomingStreams[streamKey]
                if (entry == null) {
                    if (incomingStreams.size >= MAX_ACTIVE_INCOMING) return@withLock
                    val out = incomingFile(streamKey, attachment.fileName) ?: return@withLock
                    val opened = try {
                        RandomAccessFile(out, "rw").let { raf ->
                            raf.setLength(attachment.sizeBytes)
                            IncomingTransfer(out, raf, total, chunkSize, attachment.sizeBytes, msgId, senderKey)
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Cannot open incoming file safely: ${e.message}")
                        return@withLock
                    }
                    entry = opened
                    incomingStreams[streamKey] = opened
                }
                val idx = entry ?: return@withLock
                if (idx.messageId != msgId || !idx.senderPubKeyHex.equals(senderKey, ignoreCase = true)) return@withLock
                if (idx.totalChunks != total || idx.chunkSize != chunkSize || idx.claimedSize != attachment.sizeBytes) {
                    closeAndDeleteLocked(streamKey, idx)
                    markFailed(msgId, transferId, "Attachment metadata changed during transfer")
                    return@withLock
                }
                // A replayed chunk may be re-ACKed at transport level, but must never
                // overwrite already accepted bytes in a partially completed file.
                if (index in idx.receivedChunks) return@withLock
                try {
                    idx.randomAccess.seek(index.toLong() * chunkSize.toLong())
                    idx.randomAccess.write(bytes)
                    idx.receivedChunks.add(index)
                    idx.lastUpdatedAtMs = System.currentTimeMillis()
                    val progress = (idx.receivedChunks.size.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                    // Vault persistence is a full encrypted snapshot; checkpoint every 32
                    // chunks instead of encrypting and rewriting the complete vault per chunk.
                    if (idx.receivedChunks.size % 32 == 0 || idx.receivedChunks.size >= total) {
                        vault.updateMessage(msgId) {
                            it.copy(attachment = it.attachment?.copy(transferState = TransferState.IN_PROGRESS, progress = progress))
                        }
                    }
                    if (idx.receivedChunks.size >= total) {
                        finalize(streamKey, transferId, msgId, idx)
                    } else if (idx.receivedChunks.size % 4 == 0) onUpdated()
                } catch (e: Exception) {
                    Log.e(TAG, "Chunk write failed: ${e.message}")
                    closeAndDeleteLocked(streamKey, idx)
                    markFailed(msgId, transferId, "Invalid or incomplete transfer")
                }
            }
        }
    }

    private fun isSafeTransferId(value: String): Boolean =
        value.length in 1..64 && value.matches(Regex("^[A-Za-z0-9_-]+$"))

    private fun incomingFile(transferId: String, fileName: String): File? = try {
        if (!mediaDir.exists()) mediaDir.mkdirs()
        val root = mediaDir.canonicalFile
        val target = File(root, "${transferId}_${sanitize(fileName)}").canonicalFile
        if (target.parentFile != root) null else target
    } catch (_: Exception) { null }

    private fun cleanupStaleTransfersLocked() {
        val cutoff = System.currentTimeMillis() - INCOMING_IDLE_TIMEOUT_MS
        val stale = incomingStreams.filterValues { it.lastUpdatedAtMs < cutoff }.keys.toList()
        stale.forEach { id -> incomingStreams[id]?.let { closeAndDeleteLocked(id, it) } }
    }

    private fun closeAndDeleteLocked(id: String, entry: IncomingTransfer) {
        try { entry.randomAccess.close() } catch (_: Exception) {}
        try { entry.file.delete() } catch (_: Exception) {}
        incomingStreams.remove(id)
    }

    private fun finalize(streamKey: String, transferId: String, msgId: String, entry: IncomingTransfer) {
        val message = vault.getMessageById(msgId)
        if (message == null || !message.senderPubKeyHex.equals(entry.senderPubKeyHex, ignoreCase = true) ||
            message.attachment?.id != transferId || entry.file.length() != entry.claimedSize ||
            entry.receivedChunks.size != entry.totalChunks) {
            closeAndDeleteLocked(streamKey, entry)
            markFailed(msgId, transferId, "Attachment size verification failed")
            return
        }
        try { entry.randomAccess.fd.sync() } catch (_: Exception) {}
        try { entry.randomAccess.close() } catch (_: Exception) {}
        incomingStreams.remove(streamKey)
        approvedIncoming.remove(streamKey)
        vault.updateMessage(msgId) {
            it.copy(
                status = MessageStatus.DELIVERED,
                attachment = it.attachment?.copy(
                    transferState = TransferState.COMPLETED,
                    progress = 1f,
                    localPath = entry.file.absolutePath,
                    error = null
                )
            )
        }
        // The sender is not shown as delivered until all bytes arrive and size-check passes.
        scope.launch {
            dispatcher(message.senderPubKeyHex, JSONObject().apply {
                put("type", "MEDIA_RECEIPT")
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("msgId", msgId)
                put("transferId", transferId)
            })
        }
        onUpdated()
    }

    private fun markFailed(messageId: String, transferId: String, reason: String) {
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.FAILED, error = reason)
            )
        }
        onUpdated()
    }

    private fun markCancelled(messageId: String) {
        vault.updateMessage(messageId) {
            it.copy(
                status = MessageStatus.FAILED,
                attachment = it.attachment?.copy(transferState = TransferState.CANCELLED, error = "Cancelled")
            )
        }
        onUpdated()
    }

    private fun isCancelled(transferId: String): Boolean = cancelled.contains(transferId)

    private fun sanitize(name: String): String {
        val base = name.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (cleaned.isBlank()) "file" else cleaned.take(64)
    }

    fun registerLocalCopy(attachment: MediaAttachment): MediaAttachment {
        return attachment.copy(transferState = TransferState.COMPLETED, progress = 1f)
    }

    private val MAX_INCOMING_BYTES = 2L * 1024 * 1024 * 1024 // 2 GB — chunked transfer supports very large files
}
