package com.example.net.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.crypto.CryptoEngine
import com.example.data.CallLogEntry
import com.example.data.CallOutcome
import com.example.data.CallType
import com.example.data.Contact
import com.example.data.EncryptedVault
import com.example.service.SecureChatForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.nio.ByteBuffer
import java.util.LinkedHashSet
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

enum class CallState {
    IDLE,
    OUTGOING_RINGING,
    INCOMING_RINGING,
    CONNECTING,
    ACTIVE,
    ENDED
}

data class CallSession(
    val callId: String,
    val peerPubKeyHex: String,
    val peerName: String,
    val type: CallType,
    val isOutgoing: Boolean,
    val state: CallState,
    val startedAtMs: Long = System.currentTimeMillis(),
    val connectedAtMs: Long = 0L,
    val error: String? = null,
    val muted: Boolean = false,
    val speakerOn: Boolean = true,
    val videoEnabled: Boolean = false
)

/**
 * Peer-to-peer voice & video call engine.
 *
 * Signaling travels as end-to-end encrypted CALL_SIGNAL envelopes over the existing
 * FolkChat transport (Bluetooth / local Wi-Fi socket / relay). Once both parties agree,
 * a dedicated, full-duplex TCP media socket is established directly between the two
 * devices and carries live AudioRecord/AudioTrack PCM plus optional camera JPEG frames.
 *
 * Because media flows device-to-device (no TURN/relay media server is configured),
 * a call can only complete when both peers can reach each other on the same local
 * network. Otherwise the call fails gracefully and is recorded in call history.
 */
class CallManager(
    private val context: Context,
    private val vault: EncryptedVault,
    private val signalSender: suspend (String, JSONObject) -> String?
) {
    companion object {
        private const val TAG = "CallManager"
        const val CALL_PORT = 42426
        private const val SAMPLE_RATE = 16000
        private const val FRAME_SAMPLES = 320 // 20 ms @ 16 kHz
        private const val FRAME_BYTES = FRAME_SAMPLES * 2
        private const val AUDIO_FRAME = 0x01
        private const val VIDEO_FRAME = 0x02
        private const val RING_TIMEOUT_MS = 45_000L
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val HANDSHAKE_MAGIC = 0x46434831 // "FCH1"
        private const val HANDSHAKE_BYTES = 32
        private const val MAX_VIDEO_FRAME_BYTES = 1_900_000
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _session = MutableStateFlow<CallSession?>(null)
    val session: StateFlow<CallSession?> = _session.asStateFlow()

    private val _durationSeconds = MutableStateFlow(0L)
    val durationSeconds: StateFlow<Long> = _durationSeconds.asStateFlow()

    private val _remoteFrame = MutableStateFlow<Bitmap?>(null)
    val remoteFrame: StateFlow<Bitmap?> = _remoteFrame.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var mediaSocket: Socket? = null
    private var mediaOut: DataOutputStream? = null
    private var mediaIn: DataInputStream? = null
    @Volatile private var callMediaKey: ByteArray? = null
    private val mediaConnectionPending = AtomicBoolean(false)
    private val secureRandom = SecureRandom()
    private val sendFrameSequence = AtomicLong(0L)
    @Volatile private var lastReceivedFrameSequence: Long = 0L
    private val recentOfferIds = LinkedHashSet<String>()
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var audioManager: AudioManager? = null

    private var captureJob: Job? = null
    private var playbackJob: Job? = null
    private var tickerJob: Job? = null
    private var ringTimeoutJob: Job? = null

    private val running = AtomicBoolean(false)
    private val writeLock = Any()

    init {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        startServer()
    }

    private fun startServer() {
        scope.launch {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(CALL_PORT))
                serverSocket = ss
                while (isActive && !ss.isClosed) {
                    val client = ss.accept()
                    onIncomingMediaConnection(client)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Call server stopped: ${e.message}")
            }
        }
    }

    private fun onIncomingMediaConnection(socket: Socket) {
        val current = _session.value
        val remote = socket.inetAddress
        if (current == null || current.isOutgoing || current.state != CallState.CONNECTING ||
            remote !is Inet4Address || !(remote.isSiteLocalAddress || remote.isLinkLocalAddress) ||
            !vault.getContactByPubKey(current.peerPubKeyHex).let { it != null && !vault.isBlocked(current.peerPubKeyHex) }) {
            try { socket.close() } catch (_: Exception) {}
            return
        }
        adoptMediaSocket(socket, asInitiator = false)
    }

    // ------------------------------------------------------------------
    // Outgoing / incoming control
    // ------------------------------------------------------------------

    fun startOutgoing(contact: Contact, type: CallType) {
        if (vault.getSettings().torRoutingEnabled) {
            _statusMessage.value = "Calls are disabled while Tor privacy mode is enabled"
            return
        }
        if (contact.x25519PublicKeyHex.length != 64 || !contact.x25519PublicKeyHex.matches(Regex("^[0-9a-fA-F]{64}$"))) return
        if (_session.value != null && _session.value?.state != CallState.ENDED) return
        val callId = UUID.randomUUID().toString()
        val session = CallSession(
            callId = callId,
            peerPubKeyHex = contact.x25519PublicKeyHex,
            peerName = contact.displayName,
            type = type,
            isOutgoing = true,
            state = CallState.OUTGOING_RINGING,
            videoEnabled = type == CallType.VIDEO
        )
        _session.value = session
        _statusMessage.value = "Ringing…"
        sendSignal(contact.x25519PublicKeyHex, callId, CallSignalType.OFFER, type)
        scheduleRingTimeout()
    }

    fun onSignal(signal: IncomingCallSignal) {
        val sender = signal.senderPubKeyHex.lowercase()
        if (!sender.matches(Regex("^[0-9a-f]{64}$")) || sender == vault.getIdentityKeyPair().publicKeyHex.lowercase()) return
        val current = _session.value
        when (signal.type) {
            CallSignalType.OFFER -> handleOffer(signal)
            CallSignalType.RINGING -> {
                if (current != null && current.isOutgoing && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    _statusMessage.value = "Ringing…"
                }
            }
            CallSignalType.ACCEPT -> {
                if (current != null && current.isOutgoing && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    handleAccept(signal)
                }
            }
            CallSignalType.REJECT, CallSignalType.BUSY -> {
                if (current != null && current.isOutgoing && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    _statusMessage.value = if (signal.type == CallSignalType.BUSY) "Peer is busy" else "Call declined"
                    finishCall(CallOutcome.DECLINED, sender, current.peerName, current.type, outgoing = true)
                }
            }
            CallSignalType.END -> {
                if (current != null && current.callId == signal.callId && current.peerPubKeyHex.equals(sender, true)) {
                    val outcome = if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.CANCELED
                    finishActive(outcome)
                }
            }
            CallSignalType.ICE -> { /* Reserved for a future negotiated transport. */ }
        }
    }

    private fun handleOffer(signal: IncomingCallSignal) {
        val sender = signal.senderPubKeyHex.lowercase()
        if (!signal.callId.matches(Regex("^[A-Za-z0-9_-]{1,64}$"))) return
        val contact = vault.getContactByPubKey(sender)
        if (contact == null || vault.isBlocked(sender) || sender == vault.getIdentityKeyPair().publicKeyHex.lowercase()) {
            sendSignal(sender, signal.callId, CallSignalType.REJECT, signal.callType)
            return
        }
        synchronized(recentOfferIds) {
            if (!recentOfferIds.add("$sender:${signal.callId}")) return
            while (recentOfferIds.size > 256) recentOfferIds.remove(recentOfferIds.first())
        }
        if (vault.getSettings().torRoutingEnabled) {
            sendSignal(sender, signal.callId, CallSignalType.REJECT, signal.callType)
            return
        }
        val existing = _session.value
        if (existing != null && existing.state != CallState.ENDED) {
            if (existing.callId != signal.callId) {
                sendSignal(sender, signal.callId, CallSignalType.BUSY, signal.callType)
            }
            return
        }
        _session.value = CallSession(
            callId = signal.callId,
            peerPubKeyHex = sender,
            peerName = contact.displayName,
            type = signal.callType,
            isOutgoing = false,
            state = CallState.INCOMING_RINGING,
            videoEnabled = signal.callType == CallType.VIDEO
        )
        _statusMessage.value = "Incoming ${if (signal.callType == CallType.VIDEO) "video" else "voice"} call"
        sendSignal(sender, signal.callId, CallSignalType.RINGING, signal.callType)
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.notify(12000, buildIncomingCallNotification(signal.copy(senderDisplayName = contact.displayName)))
        } catch (_: Exception) {}
    }

    private fun buildIncomingCallNotification(signal: IncomingCallSignal): android.app.Notification {
        val pendingIntent = android.app.PendingIntent.getActivity(
            context,
            12000,
            android.content.Intent(context, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val label = if (signal.callType == CallType.VIDEO) "video" else "voice"
        return androidx.core.app.NotificationCompat.Builder(context, com.example.SecureChatApp.CHANNEL_CALLS_ID)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setContentTitle("Incoming $label call")
            .setContentText(signal.senderDisplayName)
            .setContentIntent(pendingIntent)
            .setCategory(androidx.core.app.NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setOngoing(true)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setDefaults(0)
            .build()
    }

    private fun dismissIncomingCallNotification() {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(12000)
        } catch (_: Exception) {}
    }

    fun acceptIncoming() {
        val current = _session.value ?: return
        if (current.state != CallState.INCOMING_RINGING) return
        if (vault.getSettings().torRoutingEnabled) {
            sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.REJECT, current.type)
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = false,
                reason = "Calls are disabled while Tor privacy mode is enabled")
            return
        }
        dismissIncomingCallNotification()
        val host = localIpAddress() ?: "0.0.0.0"
        _session.value = current.copy(state = CallState.CONNECTING)
        _statusMessage.value = "Connecting…"
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.ACCEPT, current.type, host = host)
        scheduleConnectTimeout()
    }

    fun rejectIncoming() {
        val current = _session.value ?: return
        dismissIncomingCallNotification()
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.REJECT, current.type)
        logCall(current, if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.DECLINED)
        teardown()
        _session.value = null
    }

    private fun handleAccept(signal: IncomingCallSignal) {
        val current = _session.value ?: return
        if (current.callId != signal.callId || !current.isOutgoing || !current.peerPubKeyHex.equals(signal.senderPubKeyHex, true)) return
        val host = signal.payload["host"]
        if (vault.getSettings().torRoutingEnabled) {
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true,
                reason = "Calls are disabled while Tor privacy mode is enabled")
            return
        }
        _session.value = current.copy(state = CallState.CONNECTING)
        _statusMessage.value = "Connecting…"
        scheduleConnectTimeout()
        if (host.isNullOrBlank() || !isPrivateLanIpv4(host)) {
            _statusMessage.value = "Peer did not provide a valid private LAN address"
            finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "Peer not reachable on local network")
            return
        }
        scope.launch {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(host, CALL_PORT), CONNECT_TIMEOUT_MS)
                adoptMediaSocket(socket, asInitiator = true)
            } catch (e: Exception) {
                Log.e(TAG, "Media connect failed: ${e.message}")
                _statusMessage.value = "Could not establish media link"
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "Media connection failed — peers must be on the same local network")
            }
        }
    }

    private fun adoptMediaSocket(socket: Socket, asInitiator: Boolean) {
        if (!mediaConnectionPending.compareAndSet(false, true)) {
            try { socket.close() } catch (_: Exception) {}
            return
        }
        scope.launch {
            var established = false
            var staticShared: ByteArray? = null
            var baseKey: ByteArray? = null
            var ephemeralPrivate: ByteArray? = null
            var ephemeralShared: ByteArray? = null
            var pendingSessionKey: ByteArray? = null
            try {
                socket.tcpNoDelay = true
                socket.soTimeout = 5_000
                val current = _session.value ?: throw IllegalStateException("No active call session")
                require(current.state == CallState.CONNECTING) { "Call is not connecting" }
                require(current.callId.matches(Regex("^[A-Za-z0-9_-]{1,64}$"))) { "Invalid call identifier" }
                val identity = vault.getIdentityKeyPair()
                val peerPub = CryptoEngine.hexToBytes(current.peerPubKeyHex)
                require(peerPub.size == 32) { "Invalid peer public key" }
                staticShared = CryptoEngine.computeSharedSecret(identity.privateKey, peerPub)
                require(staticShared!!.any { it != 0.toByte() }) { "Invalid peer key agreement" }
                val callId = current.callId
                val callIdBytes = callId.toByteArray(Charsets.UTF_8)
                baseKey = CryptoEngine.hkdfSha256(
                    staticShared!!,
                    salt = MessageDigest.getInstance("SHA-256").digest(callIdBytes),
                    info = "FolkChat-Call-Handshake-v2".toByteArray(Charsets.UTF_8),
                    length = 32
                )
                val input = DataInputStream(socket.getInputStream())
                val output = DataOutputStream(socket.getOutputStream())
                val nonceA: ByteArray
                val nonceB: ByteArray
                val ephemeralPublicA: ByteArray
                val ephemeralPublicB: ByteArray

                if (asInitiator) {
                    nonceA = ByteArray(HANDSHAKE_BYTES).apply { secureRandom.nextBytes(this) }
                    val ephemeral = CryptoEngine.generateX25519KeyPair()
                    ephemeralPrivate = ephemeral.privateKey
                    ephemeralPublicA = ephemeral.publicKey
                    val helloTranscript = "hello|$callId|${CryptoEngine.bytesToHex(nonceA)}|${CryptoEngine.bytesToHex(ephemeralPublicA)}"
                    output.writeInt(HANDSHAKE_MAGIC)
                    output.writeUTF(callId)
                    output.write(nonceA)
                    output.write(ephemeralPublicA)
                    output.write(CryptoEngine.hmacSha256(baseKey!!, helloTranscript.toByteArray(Charsets.UTF_8)))
                    output.flush()

                    nonceB = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    ephemeralPublicB = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    require(ephemeralPublicB.size == 32) { "Invalid ephemeral public key" }
                    val responderProof = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    ephemeralShared = CryptoEngine.computeSharedSecret(ephemeralPrivate!!, ephemeralPublicB)
                    require(ephemeralShared!!.any { it != 0.toByte() }) { "Invalid ephemeral key agreement" }
                    pendingSessionKey = deriveCallMediaKey(staticShared!!, ephemeralShared!!, callIdBytes, nonceA, nonceB, ephemeralPublicA, ephemeralPublicB)
                    val transcript = "$callId|${CryptoEngine.bytesToHex(nonceA)}|${CryptoEngine.bytesToHex(nonceB)}|${CryptoEngine.bytesToHex(ephemeralPublicA)}|${CryptoEngine.bytesToHex(ephemeralPublicB)}"
                    val expectedResponder = CryptoEngine.hmacSha256(pendingSessionKey!!, "responder|$transcript".toByteArray(Charsets.UTF_8))
                    require(MessageDigest.isEqual(responderProof, expectedResponder)) { "Peer failed media authentication" }
                    output.write(CryptoEngine.hmacSha256(pendingSessionKey!!, "initiator|$transcript".toByteArray(Charsets.UTF_8)))
                    output.flush()
                    val readyProof = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    val expectedReady = CryptoEngine.hmacSha256(pendingSessionKey!!, "ready|$transcript".toByteArray(Charsets.UTF_8))
                    require(MessageDigest.isEqual(readyProof, expectedReady)) { "Peer did not confirm the call key" }
                } else {
                    require(input.readInt() == HANDSHAKE_MAGIC) { "Invalid media handshake" }
                    require(input.readUTF() == callId) { "Call identifier mismatch" }
                    nonceA = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    ephemeralPublicA = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    require(ephemeralPublicA.size == 32) { "Invalid initiator ephemeral public key" }
                    val initiatorProof = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    val helloTranscript = "hello|$callId|${CryptoEngine.bytesToHex(nonceA)}|${CryptoEngine.bytesToHex(ephemeralPublicA)}"
                    val expectedHello = CryptoEngine.hmacSha256(baseKey!!, helloTranscript.toByteArray(Charsets.UTF_8))
                    require(MessageDigest.isEqual(initiatorProof, expectedHello)) { "Caller identity proof failed" }

                    nonceB = ByteArray(HANDSHAKE_BYTES).apply { secureRandom.nextBytes(this) }
                    val ephemeral = CryptoEngine.generateX25519KeyPair()
                    ephemeralPrivate = ephemeral.privateKey
                    ephemeralPublicB = ephemeral.publicKey
                    ephemeralShared = CryptoEngine.computeSharedSecret(ephemeralPrivate!!, ephemeralPublicA)
                    require(ephemeralShared!!.any { it != 0.toByte() }) { "Invalid ephemeral key agreement" }
                    pendingSessionKey = deriveCallMediaKey(staticShared!!, ephemeralShared!!, callIdBytes, nonceA, nonceB, ephemeralPublicA, ephemeralPublicB)
                    val transcript = "$callId|${CryptoEngine.bytesToHex(nonceA)}|${CryptoEngine.bytesToHex(nonceB)}|${CryptoEngine.bytesToHex(ephemeralPublicA)}|${CryptoEngine.bytesToHex(ephemeralPublicB)}"
                    output.write(nonceB)
                    output.write(ephemeralPublicB)
                    output.write(CryptoEngine.hmacSha256(pendingSessionKey!!, "responder|$transcript".toByteArray(Charsets.UTF_8)))
                    output.flush()
                    val confirmedInitiator = ByteArray(HANDSHAKE_BYTES).also(input::readFully)
                    val expectedInitiator = CryptoEngine.hmacSha256(pendingSessionKey!!, "initiator|$transcript".toByteArray(Charsets.UTF_8))
                    require(MessageDigest.isEqual(confirmedInitiator, expectedInitiator)) { "Caller failed key confirmation" }
                    output.write(CryptoEngine.hmacSha256(pendingSessionKey!!, "ready|$transcript".toByteArray(Charsets.UTF_8)))
                    output.flush()
                }

                socket.soTimeout = 0
                if (_session.value?.callId != callId || _session.value?.state != CallState.CONNECTING) {
                    throw IllegalStateException("Call ended during handshake")
                }
                mediaSocket = socket
                mediaOut = DataOutputStream(socket.getOutputStream())
                mediaIn = DataInputStream(socket.getInputStream())
                callMediaKey = pendingSessionKey
                pendingSessionKey = null // ownership moves to the active call
                sendFrameSequence.set(0L)
                lastReceivedFrameSequence = 0L
                ringTimeoutJob?.cancel()
                established = true
                startMedia()
            } catch (e: Exception) {
                Log.w(TAG, "Secure media handshake failed: ${e.message}")
                try { socket.close() } catch (_: Exception) {}
                mediaConnectionPending.set(false)
                if (asInitiator) {
                    val current = _session.value
                    if (current != null && current.state == CallState.CONNECTING) {
                        finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "Secure call handshake failed")
                    }
                }
            } finally {
                staticShared?.fill(0)
                baseKey?.fill(0)
                ephemeralPrivate?.fill(0)
                ephemeralShared?.fill(0)
                pendingSessionKey?.fill(0)
                if (!established) mediaConnectionPending.set(false)
            }
        }
    }

    /** Session keys mix the authenticated long-term secret with ephemeral X25519 DH.
     * Erasing ephemeral private/shared values after handshake provides forward secrecy
     * for captured call media, assuming device memory is not compromised during the call.
     */
    private fun deriveCallMediaKey(
        staticShared: ByteArray,
        ephemeralShared: ByteArray,
        callId: ByteArray,
        nonceA: ByteArray,
        nonceB: ByteArray,
        ephemeralPublicA: ByteArray,
        ephemeralPublicB: ByteArray
    ): ByteArray {
        val transcript = callId + nonceA + nonceB + ephemeralPublicA + ephemeralPublicB
        val salt = MessageDigest.getInstance("SHA-256").digest(transcript)
        return CryptoEngine.hkdfSha256(
            staticShared + ephemeralShared,
            salt = salt,
            info = "FolkChat-Call-Media-v2-FS".toByteArray(Charsets.UTF_8),
            length = 32
        )
    }

    private fun isPrivateLanIpv4(host: String): Boolean {
        if (!host.matches(Regex("^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$"))) return false
        return try {
            val addr = InetAddress.getByName(host) as? Inet4Address ?: return false
            !addr.isAnyLocalAddress && !addr.isLoopbackAddress && !addr.isMulticastAddress &&
                (addr.isSiteLocalAddress || addr.isLinkLocalAddress) &&
                host.split('.').all { part -> part.toIntOrNull()?.let { it in 0..255 } == true }
        } catch (_: Exception) { false }
    }

    private fun startMedia() {
        val current = _session.value ?: return
        if (running.getAndSet(true)) return
        _session.value = current.copy(state = CallState.ACTIVE, connectedAtMs = System.currentTimeMillis())
        _statusMessage.value = null
        val hasAudioPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val hasCameraPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        SecureChatForegroundService.updateCallForeground(
            context,
            active = true,
            audio = hasAudioPermission,
            video = current.type == CallType.VIDEO && hasCameraPermission
        )
        configureAudioRoute(current.speakerOn)
        startAudioPipeline()
        startTicker()
        // Send END eventually by caller; auto end handled by UI.

        val audioPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!audioPerm) {
            _statusMessage.value = "Microphone permission missing — you are muted"
        }
    }

    private fun startAudioPipeline() {
        try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val record = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, FRAME_BYTES * 4)
                )
                if (record.state == AudioRecord.STATE_INITIALIZED) {
                    audioRecord = record
                    record.startRecording()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord init failed: ${e.message}")
        }

        try {
            val minTrack = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minTrack, FRAME_BYTES * 8))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            audioTrack = track
            track.play()
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack init failed: ${e.message}")
        }

        captureJob = scope.launch {
            val buffer = ByteArray(FRAME_BYTES)
            while (isActive && running.get()) {
                val record = audioRecord ?: break
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0 && _session.value?.muted != true) {
                    sendFrame(AUDIO_FRAME, buffer, read)
                }
            }
        }

        playbackJob = scope.launch {
            while (isActive && running.get()) {
                try {
                    val length = mediaIn?.readInt() ?: break
                    if (length !in (12 + 16 + 9)..(MAX_VIDEO_FRAME_BYTES + 12 + 16 + 9)) break
                    val packet = ByteArray(length)
                    mediaIn?.readFully(packet)
                    val key = callMediaKey ?: break
                    val nonce = packet.copyOfRange(0, 12)
                    val ciphertext = packet.copyOfRange(12, packet.size)
                    val aad = (_session.value?.callId ?: break).toByteArray(Charsets.UTF_8)
                    val plaintext = try { CryptoEngine.decryptChaCha20Poly1305(key, nonce, ciphertext, aad) }
                    catch (_: Exception) { break }
                    if (plaintext.size < 9) break
                    val sequence = ByteBuffer.wrap(plaintext, 0, 8).long
                    if (sequence <= lastReceivedFrameSequence) continue
                    lastReceivedFrameSequence = sequence
                    val type = plaintext[8].toInt() and 0xff
                    val payload = plaintext.copyOfRange(9, plaintext.size)
                    when (type) {
                        AUDIO_FRAME -> audioTrack?.write(payload, 0, payload.size)
                        VIDEO_FRAME -> decodeRemoteFrame(payload)
                        else -> break
                    }
                } catch (e: Exception) {
                    if (running.get()) Log.d(TAG, "Media read ended: ${e.message}")
                    break
                }
            }
            if (running.get()) {
                // Remote hung up
                scope.launch { finishActive(CallOutcome.COMPLETED) }
            }
        }
    }

    private fun sendFrame(type: Int, payload: ByteArray, length: Int) {
        val out = mediaOut ?: return
        val key = callMediaKey ?: return
        if (length < 0 || length > MAX_VIDEO_FRAME_BYTES || length > payload.size) return
        try {
            val currentCallId = _session.value?.callId ?: return
            val nonce = ByteArray(12).apply { secureRandom.nextBytes(this) }
            val sequence = sendFrameSequence.incrementAndGet()
            val plain = ByteBuffer.allocate(9 + length).putLong(sequence).put(type.toByte()).put(payload, 0, length).array()
            val aad = currentCallId.toByteArray(Charsets.UTF_8)
            val cipherText = CryptoEngine.encryptChaCha20Poly1305(key, nonce, plain, aad)
            val packet = nonce + cipherText
            synchronized(writeLock) {
                out.writeInt(packet.size)
                out.write(packet)
                out.flush()
            }
        } catch (e: Exception) {
            Log.d(TAG, "Encrypted sendFrame failed: ${e.message}")
        }
    }

    /** Called from the video-call UI with a JPEG-encoded camera frame. */
    fun sendLocalVideoFrame(jpeg: ByteArray) {
        if (!running.get() || jpeg.isEmpty() || jpeg.size > MAX_VIDEO_FRAME_BYTES) return
        if (_session.value?.videoEnabled != true) return
        sendFrame(VIDEO_FRAME, jpeg, jpeg.size)
    }

    private fun decodeRemoteFrame(bytes: ByteArray) {
        try {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
            _remoteFrame.value = bmp
        } catch (_: Exception) {}
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive && running.get()) {
                val s = _session.value ?: break
                if (s.connectedAtMs > 0) {
                    _durationSeconds.value = (System.currentTimeMillis() - s.connectedAtMs) / 1000
                }
                delay(1000)
            }
        }
    }

    // ------------------------------------------------------------------
    // Controls
    // ------------------------------------------------------------------

    fun toggleMute() {
        val s = _session.value ?: return
        _session.value = s.copy(muted = !s.muted)
    }

    fun toggleSpeaker() {
        val s = _session.value ?: return
        val now = !s.speakerOn
        _session.value = s.copy(speakerOn = now)
        configureAudioRoute(now)
    }

    fun setVideoEnabled(enabled: Boolean) {
        val s = _session.value ?: return
        _session.value = s.copy(videoEnabled = enabled)
        if (!enabled) _remoteFrame.value = null
    }

    private fun configureAudioRoute(speakerOn: Boolean) {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = am.availableCommunicationDevices
                val target = devices.firstOrNull {
                    if (speakerOn) it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    else it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                }
                if (target != null) am.setCommunicationDevice(target)
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = speakerOn
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audio route change failed: ${e.message}")
        }
    }

    fun endCall() {
        val current = _session.value ?: return
        if (current.state == CallState.INCOMING_RINGING) {
            rejectIncoming()
            return
        }
        sendSignal(current.peerPubKeyHex, current.callId, CallSignalType.END, current.type)
        finishActive(if (current.connectedAtMs > 0) CallOutcome.COMPLETED else CallOutcome.CANCELED)
    }

    private fun finishActive(outcome: CallOutcome) {
        val current = _session.value ?: return
        dismissIncomingCallNotification()
        logCall(current, outcome)
        teardown()
        _session.value = current.copy(state = CallState.ENDED, error = _statusMessage.value)
        scope.launch {
            delay(1200)
            if (_session.value?.state == CallState.ENDED) {
                _session.value = null
                _durationSeconds.value = 0
                _statusMessage.value = null
            }
        }
    }

    private fun finishCall(
        outcome: CallOutcome,
        peerHex: String,
        peerName: String,
        type: CallType,
        outgoing: Boolean,
        reason: String? = null
    ) {
        val current = _session.value
        val entry = current ?: CallSession(
            callId = UUID.randomUUID().toString(),
            peerPubKeyHex = peerHex,
            peerName = peerName,
            type = type,
            isOutgoing = outgoing,
            state = CallState.ENDED
        )
        logCall(entry, outcome)
        if (reason != null) _statusMessage.value = reason
        teardown()
        _session.value = entry.copy(state = CallState.ENDED, error = reason ?: _statusMessage.value)
        scope.launch {
            delay(1400)
            if (_session.value?.state == CallState.ENDED) {
                _session.value = null
                _statusMessage.value = null
                _durationSeconds.value = 0
            }
        }
    }

    private fun logCall(session: CallSession, outcome: CallOutcome) {
        vault.addCallLog(
            CallLogEntry(
                id = UUID.randomUUID().toString(),
                peerPubKeyHex = session.peerPubKeyHex,
                peerName = session.peerName,
                type = session.type,
                outcome = outcome,
                timestampMs = System.currentTimeMillis(),
                durationSeconds = if (session.connectedAtMs > 0) (System.currentTimeMillis() - session.connectedAtMs) / 1000 else 0,
                isOutgoing = session.isOutgoing
            )
        )
    }

    private fun scheduleRingTimeout() {
        ringTimeoutJob?.cancel()
        ringTimeoutJob = scope.launch {
            delay(RING_TIMEOUT_MS)
            val current = _session.value
            if (current != null && current.state == CallState.OUTGOING_RINGING) {
                _statusMessage.value = "No answer"
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = true, reason = "No answer")
            }
        }
    }

    private fun scheduleConnectTimeout() {
        scope.launch {
            delay(20_000)
            val current = _session.value
            if (current != null && current.state == CallState.CONNECTING) {
                finishCall(CallOutcome.FAILED, current.peerPubKeyHex, current.peerName, current.type, outgoing = current.isOutgoing, reason = "Connection timed out")
            }
        }
    }

    private fun sendSignal(
        peerHex: String,
        callId: String,
        signal: CallSignalType,
        type: CallType,
        host: String? = null
    ) {
        scope.launch {
            val json = JSONObject().apply {
                put("type", "CALL_SIGNAL")
                put("callId", callId)
                put("signal", signal.name)
                put("callType", type.name)
                put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                put("senderDisplayName", vault.getDisplayName())
                put("timestamp", System.currentTimeMillis())
                if (host != null) {
                    put("host", host)
                    put("port", CALL_PORT.toString())
                }
            }
            signalSender(peerHex, json)
        }
    }

    private fun localIpAddress(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isAnyLocalAddress &&
                        (addr.isSiteLocalAddress || addr.isLinkLocalAddress)) {
                        return addr.hostAddress
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    private fun teardown() {
        try { SecureChatForegroundService.updateCallForeground(context, active = false) } catch (_: Exception) {}
        running.set(false)
        ringTimeoutJob?.cancel()
        captureJob?.cancel()
        playbackJob?.cancel()
        tickerJob?.cancel()
        captureJob = null; playbackJob = null; tickerJob = null; ringTimeoutJob = null
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        try { mediaIn?.close() } catch (_: Exception) {}
        try { mediaOut?.close() } catch (_: Exception) {}
        try { mediaSocket?.close() } catch (_: Exception) {}
        mediaIn = null; mediaOut = null; mediaSocket = null
        // Erase active media-key bytes during teardown rather than only dropping the reference.
        callMediaKey?.fill(0)
        callMediaKey = null
        mediaConnectionPending.set(false)
        try {
            val am = audioManager
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.clearCommunicationDevice()
                else { @Suppress("DEPRECATION") am.isSpeakerphoneOn = false }
            }
        } catch (_: Exception) {}
    }

    fun currentPeerHex(): String? = _session.value?.peerPubKeyHex
}
