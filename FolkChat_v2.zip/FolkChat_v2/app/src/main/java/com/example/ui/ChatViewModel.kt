package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SecureChatApp
import com.example.crypto.CryptoEngine
import com.example.crypto.KeyPairBytes
import com.example.data.ChatMessage
import com.example.data.Contact
import com.example.data.DisappearTimer
import com.example.data.DiscoveredPeer
import com.example.data.MediaAttachment
import com.example.data.MessageStatus
import com.example.data.RoutingPolicy
import com.example.service.SecureChatForegroundService
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as SecureChatApp
    private val vault = app.vault
    private val transportCoordinator = app.transportCoordinator

    private val _identity = MutableStateFlow(vault.getIdentityKeyPair())
    val identity: StateFlow<KeyPairBytes> = _identity.asStateFlow()

    private val _displayName = MutableStateFlow(vault.getDisplayName())
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    private val _contacts = MutableStateFlow(vault.getContacts())
    val contacts: StateFlow<List<Contact>> = _contacts.asStateFlow()

    private val _allMessages = MutableStateFlow(vault.getAllMessages())
    val allMessages: StateFlow<List<ChatMessage>> = _allMessages.asStateFlow()

    private val _messageRequests = MutableStateFlow(vault.getMessageRequests())
    val messageRequests: StateFlow<List<com.example.data.MessageRequest>> = _messageRequests.asStateFlow()

    private val _activeContact = MutableStateFlow<Contact?>(null)
    val activeContact: StateFlow<Contact?> = _activeContact.asStateFlow()

    private val _settings = MutableStateFlow(vault.getSettings())
    val settings: StateFlow<com.example.data.AppSettings> = _settings.asStateFlow()

    private val _callLogs = MutableStateFlow(vault.getCallLogs())
    val callLogs: StateFlow<List<com.example.data.CallLogEntry>> = _callLogs.asStateFlow()

    // ------------------------------------------------------------------
    // v2 state: typing indicators, unread badges, blocked peers, my avatar
    // ------------------------------------------------------------------

    /** pubKeys of peers currently typing (auto-expire after ~5s of silence). */
    private val _typingPeers = MutableStateFlow<Set<String>>(emptySet())
    val typingPeers: StateFlow<Set<String>> = _typingPeers.asStateFlow()

    /** conversation pubKey -> unread count, refreshed whenever data changes. */
    private val _unreadCounts = MutableStateFlow<Map<String, Int>>(emptyMap())
    val unreadCounts: StateFlow<Map<String, Int>> = _unreadCounts.asStateFlow()

    val totalUnread: Int get() = _unreadCounts.value.values.sum()

    private val _blockedPeers = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val blockedPeers: StateFlow<List<Pair<String, String>>> = _blockedPeers.asStateFlow()

    private val _myAvatarPath = MutableStateFlow<String?>(vault.getMyAvatarPath())
    val myAvatarPath: StateFlow<String?> = _myAvatarPath.asStateFlow()

    private val _torProbeResult = MutableStateFlow<String?>(null)
    val torProbeResult: StateFlow<String?> = _torProbeResult.asStateFlow()

    val callManager = app.callManager
    val appLock = app.appLockManager
    val mediaTransfer = transportCoordinator.mediaTransferManager
    val onlineRelay = transportCoordinator.onlineRelayManager

    private val _selectedTab = MutableStateFlow(BottomTab.CHATS)
    val selectedTab: StateFlow<BottomTab> = _selectedTab.asStateFlow()

    fun setSelectedTab(tab: BottomTab) { _selectedTab.value = tab }

    fun refreshSettings() { _settings.value = vault.getSettings() }
    fun refreshCallLogs() { _callLogs.value = vault.getCallLogs() }

    fun updateSettings(transform: (com.example.data.AppSettings) -> com.example.data.AppSettings) {
        vault.updateSettings(transform)
        _settings.value = vault.getSettings()
    }

    val discoveredPeers: StateFlow<List<DiscoveredPeer>> = transportCoordinator.allDiscoveredPeers

    private val _themeMode = MutableStateFlow(
        try {
            com.example.ui.theme.AppThemeMode.valueOf(vault.getThemeMode())
        } catch (e: Exception) {
            com.example.ui.theme.AppThemeMode.CLASSIC_LIGHT
        }
    )
    val themeMode: StateFlow<com.example.ui.theme.AppThemeMode> = _themeMode.asStateFlow()

    private val _isOnboardingCompleted = MutableStateFlow(vault.isOnboardingCompleted())
    val isOnboardingCompleted: StateFlow<Boolean> = _isOnboardingCompleted.asStateFlow()

    val routingEngine = transportCoordinator.routingEngine
    val routingPolicy: StateFlow<RoutingPolicy> = routingEngine.routingPolicy
    val isInternetAvailable: StateFlow<Boolean> = routingEngine.isInternetAvailable
    val networkTypeName: StateFlow<String> = routingEngine.networkTypeName

    fun setRoutingPolicy(policy: RoutingPolicy) {
        routingEngine.setRoutingPolicy(policy)
        vault.setRoutingPolicyName(policy.name)
        triggerOutboxFlush()
    }

    fun toggleSimulatedOffline() {
        routingEngine.toggleSimulatedOffline()
        triggerOutboxFlush()
    }

    // ------------------------------------------------------------------
    // Tor routing (OFF by default) & relay URL
    // ------------------------------------------------------------------

    fun setTorRoutingEnabled(enabled: Boolean) {
        updateSettings { it.copy(torRoutingEnabled = enabled) }
        viewModelScope.launch {
            if (enabled) {
                // Discover Orbot's actual SOCKS listener on IO before constructing the relay client.
                withContext(Dispatchers.IO) { transportCoordinator.onlineRelayManager.isTorProxyReachable() }
            }
            // restartPrivacyTransports rebuilds the relay from the updated settings; do not
            // immediately restart it a second time and create duplicate sockets.
            transportCoordinator.restartPrivacyTransports()
            probeTor()
        }
    }

    fun setRelayUrl(url: String) {
        updateSettings { it.copy(relayUrl = url.trim()) }
        viewModelScope.launch {
            transportCoordinator.onlineRelayManager.restart()
        }
    }

    /** Check whether the Orbot SOCKS proxy is reachable and expose the result. */
    fun probeTor() {
        viewModelScope.launch {
            val reachable = withContext(Dispatchers.IO) {
                transportCoordinator.onlineRelayManager.isTorProxyReachable()
            }
            _torProbeResult.value = if (reachable) "Orbot SOCKS proxy detected" else "Orbot proxy not detected — install or start Orbot before enabling Tor routing"
        }
    }

    fun completeOnboardingWithName(name: String) {
        val trimmed = name.trim()
        if (trimmed.isNotEmpty()) {
            vault.setDisplayName(trimmed)
            _displayName.value = trimmed
        }
        vault.setOnboardingCompleted(true)
        _isOnboardingCompleted.value = true
    }

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    val activeConversationMessages: StateFlow<List<ChatMessage>> = combine(
        _allMessages,
        _activeContact
    ) { messages, active ->
        if (active == null) emptyList()
        else messages.filter {
            it.conversationPeerPubKeyHex.equals(active.x25519PublicKeyHex, ignoreCase = true)
        }.sortedBy { it.timestampMs }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var typingExpiryJob: Job? = null
    private var housekeepingJob: Job? = null

    init {
        // MainActivity starts relay-only or the foreground local-link service after checking
        // runtime permissions. Starting a connected-device FGS here can race the permission prompt.
        refreshUnread()
        refreshBlocked()

        // Listen for new incoming messages from coordinator
        viewModelScope.launch {
            transportCoordinator.onNewMessageReceived.collect {
                refreshData()
                maybeSendReadReceipt()
            }
        }

        viewModelScope.launch {
            transportCoordinator.onConversationUpdated.collect {
                refreshData()
                _settings.value = vault.getSettings()
                _callLogs.value = vault.getCallLogs()
            }
        }

        // Live typing indicators with 5-second auto-expiry.
        viewModelScope.launch {
            transportCoordinator.onTypingUpdate.collect { (peer, isTyping) ->
                if (isTyping) {
                    _typingPeers.value = _typingPeers.value + peer.lowercase()
                    typingExpiryJob?.cancel()
                    typingExpiryJob = viewModelScope.launch {
                        delay(5000)
                        _typingPeers.value = emptySet()
                    }
                } else {
                    _typingPeers.value = _typingPeers.value - peer.lowercase()
                }
            }
        }

        // Presence traffic refreshes contact list (last-seen timestamps).
        viewModelScope.launch {
            transportCoordinator.onPresenceSeen.collect {
                _contacts.value = vault.getContacts()
            }
        }

        // Periodic housekeeping: purge expired disappearing messages.
        housekeepingJob = viewModelScope.launch {
            while (true) {
                delay(15_000)
                val had = vault.getAllMessages().size
                vault.purgeExpiredDisappearingMessages()
                if (vault.getAllMessages().size != had) {
                    refreshData()
                } else {
                    refreshUnread()
                }
            }
        }
    }

    fun refreshData() {
        _contacts.value = vault.getContacts()
        _allMessages.value = vault.getAllMessages()
        _messageRequests.value = vault.getMessageRequests()
        _displayName.value = vault.getDisplayName()
        refreshUnread()
        refreshBlocked()
    }

    private fun refreshUnread() {
        val map = mutableMapOf<String, Int>()
        for (c in _contacts.value) {
            val n = vault.getUnreadCount(c.x25519PublicKeyHex)
            if (n > 0) map[c.x25519PublicKeyHex.lowercase()] = n
        }
        _unreadCounts.value = map
    }

    private fun refreshBlocked() {
        _blockedPeers.value = vault.getBlockedPeers()
    }

    fun getUnreadFor(contact: Contact): Int =
        _unreadCounts.value[contact.x25519PublicKeyHex.lowercase()] ?: 0

    // ------------------------------------------------------------------
    // Conversation open + read receipts
    // ------------------------------------------------------------------

    fun selectContact(contact: Contact?) {
        _activeContact.value = contact
        if (contact != null) {
            val key = contact.x25519PublicKeyHex
            // Do not mark messages read or send a read receipt until a protected chat is unlocked.
            if (!appLock.isChatLocked(key) || appLock.isChatUnlocked(key)) {
                vault.markConversationRead(key)
                refreshUnread()
                maybeSendReadReceipt()
            }
        }
    }

    /** Call only after the PIN gate has successfully opened the currently active chat. */
    fun onActiveChatUnlocked() {
        val active = _activeContact.value ?: return
        vault.markConversationRead(active.x25519PublicKeyHex)
        refreshUnread()
        maybeSendReadReceipt()
    }

    /** Sends an encrypted read-receipt cursor to the active peer (if enabled). */
    private fun maybeSendReadReceipt() {
        val active = _activeContact.value ?: return
        val s = vault.getSettings()
        if (!s.readReceipts) return
        val isSelfChat = active.x25519PublicKeyHex.equals(vault.getIdentityKeyPair().publicKeyHex, ignoreCase = true)
        if (isSelfChat) return
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                active.x25519PublicKeyHex,
                JSONObject().apply {
                    put("type", "CHAT_READ")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("lastReadMs", System.currentTimeMillis())
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // Typing indicator send side
    // ------------------------------------------------------------------

    private var lastTypingSentAt = 0L

    fun sendTypingSignal() {
        val active = _activeContact.value ?: return
        val s = vault.getSettings()
        if (!s.typingIndicators) return
        val isSelfChat = active.x25519PublicKeyHex.equals(vault.getIdentityKeyPair().publicKeyHex, ignoreCase = true)
        if (isSelfChat) return
        val now = System.currentTimeMillis()
        if (now - lastTypingSentAt < 2500) return // throttle
        lastTypingSentAt = now
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                active.x25519PublicKeyHex,
                JSONObject().apply {
                    put("type", "CHAT_TYPING")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("typing", true)
                    put("timestamp", System.currentTimeMillis())
                }
            )
        }
    }

    fun isPeerTyping(contact: Contact?): Boolean =
        contact != null && _typingPeers.value.contains(contact.x25519PublicKeyHex.lowercase())

    // ------------------------------------------------------------------
    // Contacts
    // ------------------------------------------------------------------

    fun addContact(codeOrPubKey: String, name: String): Boolean {
        val trimmed = codeOrPubKey.trim()
        val parsed = CryptoEngine.parseContactCode(trimmed)

        val (pubKeyHex, finalName) = if (parsed != null) {
            Pair(parsed.first.lowercase(), if (name.isNotBlank()) name.trim() else parsed.second)
        } else if (trimmed.length == 64 && trimmed.matches(Regex("^[0-9a-fA-F]+$"))) {
            Pair(trimmed.lowercase(), if (name.isNotBlank()) name.trim() else "Peer " + trimmed.take(6))
        } else {
            return false
        }

        if (vault.isBlocked(pubKeyHex)) vault.unblockPeer(pubKeyHex)

        val contact = Contact(
            id = UUID.randomUUID().toString(),
            displayName = finalName,
            x25519PublicKeyHex = pubKeyHex,
            isVerified = false
        )
        vault.addOrUpdateContact(contact)
        refreshData()
        return true
    }

    fun confirmAddContact(pubKeyHex: String, displayName: String): Contact {
        val cleanKey = pubKeyHex.lowercase().trim()
        if (vault.isBlocked(cleanKey)) vault.unblockPeer(cleanKey)
        val finalName = displayName.trim().ifBlank { "Peer " + cleanKey.take(6) }
        val contact = Contact(
            id = UUID.randomUUID().toString(),
            displayName = finalName,
            x25519PublicKeyHex = cleanKey,
            isVerified = false
        )
        vault.addOrUpdateContact(contact)
        refreshData()
        _activeContact.value = contact
        return contact
    }

    /** Mark a peer verified only after comparing the displayed fingerprint out of band. */
    fun markContactVerified(pubKeyHex: String) {
        val key = pubKeyHex.lowercase().trim()
        val contact = vault.getContactByPubKey(key) ?: return
        vault.addOrUpdateContact(contact.copy(isVerified = true))
        refreshData()
    }

    fun acceptMessageRequest(senderPubKeyHex: String, displayName: String) {
        val contact = vault.acceptMessageRequest(senderPubKeyHex, displayName)
        refreshData()
        _activeContact.value = contact
    }

    fun declineMessageRequest(senderPubKeyHex: String) {
        vault.declineMessageRequest(senderPubKeyHex)
        refreshData()
    }

    /** Block a peer permanently: drop their request / contact and all traffic. */
    fun blockPeer(pubKeyHex: String, displayName: String) {
        val key = pubKeyHex.lowercase().trim()
        vault.blockPeer(key, displayName)
        vault.deleteContact(key)
        if (_activeContact.value?.x25519PublicKeyHex?.equals(key, ignoreCase = true) == true) {
            _activeContact.value = null
        }
        refreshData()
    }

    fun unblockPeer(pubKeyHex: String) {
        vault.unblockPeer(pubKeyHex)
        refreshBlocked()
    }

    fun isPeerBlocked(pubKeyHex: String): Boolean = vault.isBlocked(pubKeyHex)

    fun deleteContact(pubKeyHex: String) {
        vault.deleteContact(pubKeyHex)
        if (_activeContact.value?.x25519PublicKeyHex.equals(pubKeyHex, ignoreCase = true)) {
            _activeContact.value = null
        }
        refreshData()
    }

    fun clearChatHistory(contactPubKey: String) {
        vault.clearAllMessagesForContact(contactPubKey)
        refreshData()
    }

    fun updateDisplayName(name: String) {
        vault.setDisplayName(name)
        _displayName.value = name
        broadcastProfileUpdate()
    }

    // ------------------------------------------------------------------
    // Profile image flow
    // ------------------------------------------------------------------

    /** Saves a new personal avatar (compressed) and announces it to all contacts. */
    fun setMyAvatar(imageBytes: ByteArray) {
        viewModelScope.launch(Dispatchers.IO) {
            val compressed = compressAvatar(imageBytes)
            if (compressed != null) {
                val path = vault.saveAvatarImage(compressed)
                _myAvatarPath.value = path
                broadcastProfileUpdate()
            }
        }
    }

    private fun compressAvatar(imageBytes: ByteArray, maxDim: Int = 320, quality: Int = 62): ByteArray? {
        return try {
            val src = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size) ?: return null
            val scale = minOf(1f, maxDim.toFloat() / maxOf(src.width, src.height))
            val w = (src.width * scale).toInt().coerceAtLeast(1)
            val h = (src.height * scale).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val bos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
            bos.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    /** Announce display name + avatar to every contact (E2E encrypted). */
    private fun broadcastProfileUpdate() {
        viewModelScope.launch(Dispatchers.IO) {
            val avatarBytes: ByteArray? = _myAvatarPath.value?.let { path ->
                try {
                    val file = File(path)
                    if (file.isFile && file.length() <= 512L * 1024L) file.readBytes() else null
                } catch (_: Exception) { null }
            }
            for (contact in _contacts.value) {
                val isSelf = contact.x25519PublicKeyHex.equals(
                    vault.getIdentityKeyPair().publicKeyHex, ignoreCase = true
                )
                if (isSelf) continue
                val json = JSONObject().apply {
                    put("type", "PROFILE_UPDATE")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("displayName", vault.getDisplayName())
                    put("timestamp", System.currentTimeMillis())
                    avatarBytes?.let {
                        put("avatarBase64", Base64.encodeToString(it, Base64.NO_WRAP))
                    }
                }
                transportCoordinator.dispatchEncryptedJson(contact.x25519PublicKeyHex, json)
            }
        }
    }

    // ------------------------------------------------------------------
    // Messaging tools: reply / edit / delete / pin / reaction / star / forward
    // ------------------------------------------------------------------

    fun sendMessage(
        text: String,
        replyToId: String? = null,
        replyToPreview: String? = null,
        replyToSender: String? = null
    ) {
        val active = _activeContact.value ?: return
        if (text.isBlank()) return

        val myIdentity = vault.getIdentityKeyPair()
        val msg = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = active.x25519PublicKeyHex,
            senderPubKeyHex = myIdentity.publicKeyHex,
            recipientPubKeyHex = active.x25519PublicKeyHex.lowercase().trim(),
            content = text.trim(),
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.QUEUED,
            isOutgoing = true,
            routeUsed = "AUTO",
            replyToId = replyToId,
            replyToPreview = replyToPreview,
            replyToSender = replyToSender
        )
        vault.saveMessage(msg)
        viewModelScope.launch {
            transportCoordinator.flushOutbox()
            refreshData()
        }
        refreshData()
    }

    /** Forward a message (text or media) to another contact. */
    fun forwardMessage(messageId: String, toContactPubKeyHex: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val target = vault.getContactByPubKey(toContactPubKeyHex) ?: return
        val myIdentity = vault.getIdentityKeyPair()

        if (msg.attachment != null) {
            val source = File(msg.attachment.localPath ?: return)
            if (!source.exists()) return
            val attachment = msg.attachment.copy(
                id = UUID.randomUUID().toString(),
                transferState = com.example.data.TransferState.PENDING,
                progress = 0f,
                error = null,
                viewsUsed = 0
            )
            val forwarded = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationPeerPubKeyHex = target.x25519PublicKeyHex,
                senderPubKeyHex = myIdentity.publicKeyHex,
                recipientPubKeyHex = target.x25519PublicKeyHex.lowercase(),
                content = msg.content,
                timestampMs = System.currentTimeMillis(),
                status = MessageStatus.SENDING,
                isOutgoing = true,
                routeUsed = "AUTO",
                attachment = attachment
            )
            vault.saveMessage(forwarded)
            // MediaTransferManager streams straight from attachment.localPath.
            mediaTransfer.startTransfer(forwarded)
        } else {
            val forwarded = ChatMessage(
                id = UUID.randomUUID().toString(),
                conversationPeerPubKeyHex = target.x25519PublicKeyHex,
                senderPubKeyHex = myIdentity.publicKeyHex,
                recipientPubKeyHex = target.x25519PublicKeyHex.lowercase(),
                content = msg.content,
                timestampMs = System.currentTimeMillis(),
                status = MessageStatus.QUEUED,
                isOutgoing = true,
                routeUsed = "AUTO"
            )
            vault.saveMessage(forwarded)
            viewModelScope.launch {
                transportCoordinator.flushOutbox()
                refreshData()
            }
        }
        refreshData()
    }

    fun editMessage(messageId: String, newText: String) {
        val trimmed = newText.trim()
        if (trimmed.isBlank()) return
        val updated = vault.updateMessage(messageId) {
            it.copy(content = trimmed, isEdited = true, editedAtMs = System.currentTimeMillis())
        } ?: return
        viewModelScope.launch {
            if (updated.isOutgoing) {
                transportCoordinator.dispatchEncryptedJson(
                    updated.recipientPubKeyHex,
                    JSONObject().apply {
                        put("type", "CHAT_EDIT")
                        put("msgId", messageId)
                        put("text", trimmed)
                        put("timestamp", updated.editedAtMs)
                    }
                )
            }
            refreshData()
        }
        refreshData()
    }

    fun deleteMessageLocally(messageId: String) {
        vault.updateMessage(messageId) {
            it.copy(deletedAtMs = System.currentTimeMillis(), content = "")
        }
        refreshData()
    }

    /** Soft-delete for me + notify the peer to soft-delete on their side. */
    fun deleteMessageForEveryone(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val deletedAt = System.currentTimeMillis()
        vault.updateMessage(messageId) { it.copy(deletedAtMs = deletedAt, content = "") }
        refreshData()
        viewModelScope.launch {
            if (msg.isOutgoing) {
                transportCoordinator.dispatchEncryptedJson(
                    msg.recipientPubKeyHex,
                    JSONObject().apply {
                        put("type", "CHAT_DELETE")
                        put("msgId", messageId)
                        put("timestamp", deletedAt)
                    }
                )
            }
            refreshData()
        }
    }

    fun togglePin(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val nowPinned = !msg.isPinned
        val updatedAt = System.currentTimeMillis()
        vault.updateMessage(messageId) { it.copy(isPinned = nowPinned, pinUpdatedAtMs = updatedAt) }
        refreshData()
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                msg.recipientPubKeyHex,
                JSONObject().apply {
                    put("type", "CHAT_PIN")
                    put("msgId", messageId)
                    put("pinned", nowPinned)
                    put("timestamp", updatedAt)
                }
            )
        }
    }

    fun toggleStar(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        vault.setStarred(messageId, !msg.isStarred)
        refreshData()
    }

    fun getStarredMessages(): List<ChatMessage> = vault.getStarredMessages()

    fun toggleReaction(messageId: String, emoji: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val me = vault.getIdentityKeyPair().publicKeyHex.lowercase()
        val map = msg.reactions.toMutableMap()
        val current = map[emoji]?.toMutableList() ?: mutableListOf()
        val add = !current.contains(me)
        if (add) current.add(me) else current.remove(me)
        if (current.isEmpty()) map.remove(emoji) else map[emoji] = current
        vault.updateMessage(messageId) { it.copy(reactions = map) }
        refreshData()
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                msg.recipientPubKeyHex,
                JSONObject().apply {
                    put("type", "CHAT_REACTION")
                    put("msgId", messageId)
                    put("emoji", emoji)
                    put("add", add)
                    put("timestamp", System.currentTimeMillis())
                    put("senderPubKey", me)
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // Archive / mute / disappearing
    // ------------------------------------------------------------------

    fun toggleArchive(contact: Contact) {
        vault.addOrUpdateContact(contact.copy(isArchived = !contact.isArchived))
        refreshData()
    }

    fun toggleMute(contact: Contact) {
        vault.addOrUpdateContact(contact.copy(isMuted = !contact.isMuted))
        refreshData()
    }

    fun setDisappearTimer(contact: Contact, timer: DisappearTimer) {
        val nowMs = System.currentTimeMillis()
        vault.addOrUpdateContact(contact.copy(
            disappearAfterSec = timer.seconds,
            disappearAfterSetAtMs = nowMs,
            disappearTimerUpdatedAtMs = nowMs
        ))
        val event = ChatMessage(
            id = UUID.randomUUID().toString(),
            conversationPeerPubKeyHex = contact.x25519PublicKeyHex,
            senderPubKeyHex = vault.getIdentityKeyPair().publicKeyHex,
            recipientPubKeyHex = contact.x25519PublicKeyHex,
            content = "",
            timestampMs = System.currentTimeMillis(),
            status = MessageStatus.DELIVERED,
            isOutgoing = true,
            routeUsed = "SYNC",
            systemEvent = "You set disappearing messages to ${timer.label.lowercase()}"
        )
        vault.saveMessage(event)
        refreshData()
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                contact.x25519PublicKeyHex,
                JSONObject().apply {
                    put("type", "DISAPPEAR_SYNC")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("seconds", timer.seconds)
                    put("timestamp", nowMs)
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // View-limited media (view once / view twice)
    // ------------------------------------------------------------------

    /**
     * Record that the recipient opened a view-limited attachment. Deletes the
     * local file once the view budget is spent and informs the sender.
     */
    fun consumeViewLimitedMedia(messageId: String) {
        val msg = vault.getMessageById(messageId) ?: return
        val att = msg.attachment ?: return
        if (att.viewLimit <= 0 || att.isViewExpired) return

        val newViews = att.viewsUsed + 1
        val spent = newViews >= att.viewLimit
        vault.updateMessage(messageId) { m ->
            m.copy(attachment = m.attachment?.copy(viewsUsed = newViews))
        }
        if (spent) {
            att.localPath?.let { path ->
                vault.deleteManagedMedia(path)
            }
            vault.updateMessage(messageId) { m ->
                m.copy(attachment = m.attachment?.copy(localPath = null))
            }
        }
        refreshData()
        if (msg.isOutgoing) return // local self-notes: no network notify needed
        viewModelScope.launch {
            transportCoordinator.dispatchEncryptedJson(
                msg.recipientPubKeyHex,
                JSONObject().apply {
                    put("type", "ATTACHMENT_VIEWED")
                    put("senderPubKey", vault.getIdentityKeyPair().publicKeyHex)
                    put("msgId", messageId)
                    put("viewsUsed", newViews)
                }
            )
        }
    }

    // ------------------------------------------------------------------
    // Media transfers
    // ------------------------------------------------------------------

    fun sendMediaAttachment(attachment: MediaAttachment, caption: String = "") {
        val active = _activeContact.value ?: return
        transportCoordinator.queueMediaMessage(
            active.x25519PublicKeyHex.lowercase().trim(),
            attachment,
            caption
        )
        refreshData()
    }

    fun cancelMediaTransfer(messageId: String) {
        mediaTransfer.cancel(messageId)
        refreshData()
    }

    fun retryMediaTransfer(messageId: String) {
        mediaTransfer.retry(messageId)
        refreshData()
    }

    fun resolveMediaFile(attachment: MediaAttachment?) =
        mediaTransfer.resolveLocalFile(attachment)

    // ------------------------------------------------------------------
    // Calls
    // ------------------------------------------------------------------

    fun startCall(contact: Contact, isVideo: Boolean) {
        callManager.startOutgoing(
            contact,
            if (isVideo) com.example.data.CallType.VIDEO else com.example.data.CallType.VOICE
        )
        refreshCallLogs()
    }

    fun endActiveCall() {
        callManager.endCall()
        refreshCallLogs()
    }

    fun clearCallHistory() {
        vault.clearCallLogs()
        refreshCallLogs()
    }

    // ------------------------------------------------------------------
    // Service & misc
    // ------------------------------------------------------------------

    fun startBackgroundService() {
        SecureChatForegroundService.start(getApplication())
        _isServiceRunning.value = true
    }

    /** Relay-only fallback: internet messages/media can work without camera, microphone,
     * or nearby-device permissions while FolkChat is open. Background reliability requires
     * the foreground link service (and its platform-required permissions). */
    fun startInternetMessagingOnly() {
        transportCoordinator.startOnlineRelayOnly()
        _isServiceRunning.value = false
    }

    fun stopBackgroundService() {
        SecureChatForegroundService.stop(getApplication())
        _isServiceRunning.value = false
    }

    fun triggerOutboxFlush() {
        viewModelScope.launch {
            transportCoordinator.flushOutbox()
            refreshData()
        }
    }

    fun registerManualPeer(ipAddress: String) {
        transportCoordinator.socketManager.registerPeerManually(ipAddress)
        triggerOutboxFlush()
    }

    fun setThemeMode(mode: com.example.ui.theme.AppThemeMode) {
        _themeMode.value = mode
        vault.setThemeMode(mode.name)
    }

    fun openSavedNotes() {
        val myPubKey = identity.value.publicKeyHex.lowercase()
        val existing = contacts.value.firstOrNull { it.x25519PublicKeyHex.equals(myPubKey, ignoreCase = true) }
        if (existing != null) {
            _activeContact.value = existing
        } else {
            val self = Contact(
                id = "self_notes",
                displayName = "Saved Notes",
                x25519PublicKeyHex = myPubKey,
                isVerified = true
            )
            vault.addOrUpdateContact(self)
            refreshData()
            _activeContact.value = self
        }
    }

    /** Handle notification deep link: jump straight into a conversation. */
    fun openConversationByPubKey(pubKeyHex: String) {
        val contact = _contacts.value.firstOrNull {
            it.x25519PublicKeyHex.equals(pubKeyHex, ignoreCase = true)
        }
        if (contact != null) {
            selectContact(contact)
            _selectedTab.value = BottomTab.CHATS
        }
    }

    override fun onCleared() {
        housekeepingJob?.cancel()
        typingExpiryJob?.cancel()
        super.onCleared()
    }
}

enum class BottomTab { CHATS, CALLS, PEOPLE, PROFILE, SETTINGS }
