package com.example

import com.example.net.framing.L1Framer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import kotlin.random.Random

class L1FramerTest {

    @Before
    fun setup() {
        L1Framer.clearSessions()
    }

    @Test
    fun testSliceAndReassembleLargePayload() {
        // 50 KB payload
        val original = ByteArray(50 * 1024) { (it % 256).toByte() }
        val frames = L1Framer.slicePayload(original, maxChunkPayloadSize = 180, messageId = 12345L)

        // Expected number of chunks: ceil(51200 / 180) = 285 chunks
        assertEquals(285, frames.size)

        // Shuffle frames to simulate out-of-order network arrival
        val shuffledFrames = frames.shuffled(Random(42))

        var reassembled: ByteArray? = null
        for (f in shuffledFrames) {
            val chunk = L1Framer.parseFrame(f)
            assertNotNull("Frame must parse cleanly", chunk)
            val full = L1Framer.ingestChunk(chunk!!)
            if (full != null) {
                reassembled = full
            }
        }

        assertNotNull("Payload must be fully reassembled", reassembled)
        assertEquals(original.size, reassembled!!.size)
        assertTrue(original.contentEquals(reassembled))
    }

    @Test
    fun testCorruptedFrameDetectedAndDropped() {
        val payload = "Important verified message".toByteArray(Charsets.UTF_8)
        val frames = L1Framer.slicePayload(payload, maxChunkPayloadSize = 100, messageId = 999L)
        val frame = frames[0]

        // Corrupt a byte in the payload area
        val corrupted = frame.copyOf()
        corrupted[corrupted.size - 1] = (corrupted[corrupted.size - 1] + 1).toByte()

        val parsed = L1Framer.parseFrame(corrupted)
        // CRC32 mismatch must reject the frame
        assertNull("Corrupted frame must fail CRC32 verification", parsed)
    }

    @Test
    fun testSmallPayloadSingleChunk() {
        val payload = "Hello SecureChat".toByteArray(Charsets.UTF_8)
        val frames = L1Framer.slicePayload(payload, maxChunkPayloadSize = 256, messageId = 777L)

        assertEquals(1, frames.size)
        val chunk = L1Framer.parseFrame(frames[0])
        assertNotNull(chunk)
        assertEquals(1, chunk!!.totalChunks)
        assertEquals(0, chunk.chunkIndex)

        val reassembled = L1Framer.ingestChunk(chunk)
        assertNotNull(reassembled)
        assertEquals("Hello SecureChat", String(reassembled!!, Charsets.UTF_8))
    }
    @Test
    fun testOversizedPayloadAndChunkSizeAreBounded() {
        val validFrame = L1Framer.slicePayload(ByteArray(4097) { 1 }, maxChunkPayloadSize = 9000, messageId = 2468L)
        assertTrue(validFrame.all { L1Framer.parseFrame(it) != null })

        var rejected = false
        try {
            L1Framer.slicePayload(ByteArray(4096 * 1024 + 1), maxChunkPayloadSize = 4096, messageId = 2469L)
        } catch (_: IllegalArgumentException) {
            rejected = true
        }
        assertTrue("Payloads requiring more than the bounded frame count are rejected", rejected)
    }

}
