'use strict';

const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocket, WebSocketServer } = require('ws');
const { createX25519KeyPair, verifyRelayProof } = require('./auth');

const PORT = Number(process.env.PORT || 8080);
const WS_PATH = process.env.WS_PATH || '/ws';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const QUEUE_FILE = process.env.QUEUE_FILE || path.join(DATA_DIR, 'mailboxes.json');
const MAX_FRAME_BYTES = 256 * 1024;
const MAX_QUEUE_MESSAGES_PER_KEY = 256;
const MAX_QUEUE_BYTES_PER_KEY = 8 * 1024 * 1024;
const MAX_QUEUE_BYTES_TOTAL = 128 * 1024 * 1024;
const MAX_CONNECTIONS = Number(process.env.MAX_CONNECTIONS || 5000);
const MAX_MESSAGES_PER_SECOND = 300;
const CHALLENGE_TTL_MS = 10_000;

const mailboxes = new Map(); // public key -> Array<{id, from, payload, createdAtMs, bytes}>
const clientsByKey = new Map(); // public key -> Set<WebSocket>
const challenges = new WeakMap();
let queuedBytesTotal = 0;
let persistChain = Promise.resolve();

function sendJson(ws, payload) {
  if (ws.readyState !== WebSocket.OPEN || ws.bufferedAmount > 2 * 1024 * 1024) return false;
  try { ws.send(JSON.stringify(payload)); return true; } catch { return false; }
}

function replyError(ws, requestId, message) {
  sendJson(ws, { type: 'error', ...(requestId ? { requestId } : {}), message });
}

function mailboxBytes(items) {
  return items.reduce((n, item) => n + (item.bytes || Buffer.byteLength(item.payload || '', 'utf8')), 0);
}

async function loadMailboxes() {
  try {
    const raw = await fs.readFile(QUEUE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    for (const [key, items] of Object.entries(parsed)) {
      if (!/^[0-9a-f]{64}$/.test(key) || !Array.isArray(items)) continue;
      const valid = items.filter(item => item && typeof item.id === 'string' &&
        typeof item.from === 'string' && /^[0-9a-f]{64}$/.test(item.from) &&
        typeof item.payload === 'string' && Buffer.byteLength(item.payload, 'utf8') <= MAX_FRAME_BYTES &&
        Number.isFinite(item.createdAtMs))
        .slice(-MAX_QUEUE_MESSAGES_PER_KEY)
        .map(item => ({ ...item, bytes: Buffer.byteLength(item.payload, 'utf8') }));
      if (valid.length) mailboxes.set(key, valid);
    }
    // Trim oldest queues if a restored file is larger than current policy.
    for (const [key, items] of mailboxes) {
      while (items.length > 0 && mailboxBytes(items) > MAX_QUEUE_BYTES_PER_KEY) items.shift();
      if (!items.length) mailboxes.delete(key);
    }
    for (const [key, items] of mailboxes) if (!items.length) mailboxes.delete(key);
    queuedBytesTotal = [...mailboxes.values()].reduce((sum, items) => sum + mailboxBytes(items), 0);
    // A restored mailbox file can have been created under a looser policy. Trim the
    // globally oldest queue entries until the current process-wide cap is respected.
    while (queuedBytesTotal > MAX_QUEUE_BYTES_TOTAL) {
      let oldestKey = null;
      let oldestCreatedAt = Number.POSITIVE_INFINITY;
      for (const [key, items] of mailboxes) {
        const oldest = items[0];
        if (oldest && oldest.createdAtMs < oldestCreatedAt) {
          oldestCreatedAt = oldest.createdAtMs;
          oldestKey = key;
        }
      }
      if (!oldestKey) break;
      const items = mailboxes.get(oldestKey);
      const removed = items?.shift();
      if (removed) queuedBytesTotal = Math.max(0, queuedBytesTotal - removed.bytes);
      if (!items?.length) mailboxes.delete(oldestKey);
    }
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Could not load mailbox store:', error.message);
  }
}

function persistMailboxes() {
  const snapshot = JSON.stringify(Object.fromEntries(mailboxes));
  const current = persistChain.then(async () => {
    await fs.mkdir(DATA_DIR, { recursive: true });
    const temporaryPath = `${QUEUE_FILE}.tmp`;
    await fs.writeFile(temporaryPath, snapshot, { mode: 0o600 });
    await fs.rename(temporaryPath, QUEUE_FILE);
  });
  persistChain = current.catch(error => {
    console.error('Mailbox persistence failed:', error.message);
  });
  return current;
}

function addClient(key, ws) {
  let clients = clientsByKey.get(key);
  if (!clients) {
    clients = new Set();
    clientsByKey.set(key, clients);
  }
  clients.add(ws);
}

function removeClient(ws) {
  const key = ws.userKey;
  if (!key) return;
  const clients = clientsByKey.get(key);
  if (!clients) return;
  clients.delete(ws);
  if (!clients.size) clientsByKey.delete(key);
}

function deliverQueued(key, ws) {
  const queue = mailboxes.get(key) || [];
  for (const item of queue) {
    if (!sendJson(ws, {
      type: 'envelope',
      from: item.from,
      payload: item.payload,
      deliveryId: item.id
    })) break;
  }
}

async function handleEnvelope(ws, message) {
  const requestId = typeof message.requestId === 'string' && message.requestId.length <= 80 ? message.requestId : '';
  const recipientKey = typeof message.to === 'string' ? message.to.toLowerCase() : '';
  const payload = typeof message.payload === 'string' ? message.payload : '';
  const payloadBytes = Buffer.byteLength(payload, 'utf8');
  if (!/^[0-9a-f]{64}$/.test(recipientKey)) return replyError(ws, requestId, 'Invalid recipient key');
  if (!payload || payloadBytes > MAX_FRAME_BYTES || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(payload)) {
    return replyError(ws, requestId, 'Invalid or oversized encrypted packet');
  }

  const recipients = clientsByKey.get(recipientKey) || new Set();
  const openRecipients = [...recipients].filter(client => client.readyState === WebSocket.OPEN && client.userKey === recipientKey);
  const queueIfOffline = message.queueIfOffline !== false;

  if (!openRecipients.length && !queueIfOffline) {
    return replyError(ws, requestId, 'Recipient is offline; this packet type is not queued');
  }

  let queueItem = null;
  if (queueIfOffline) {
    const oldQueue = mailboxes.get(recipientKey) || [];
    const itemBytes = payloadBytes;
    if (oldQueue.length >= MAX_QUEUE_MESSAGES_PER_KEY || mailboxBytes(oldQueue) + itemBytes > MAX_QUEUE_BYTES_PER_KEY || queuedBytesTotal + itemBytes > MAX_QUEUE_BYTES_TOTAL) {
      return replyError(ws, requestId, 'Recipient offline mailbox is full; ask them to connect and retry');
    }
    queueItem = {
      id: crypto.randomUUID(),
      from: ws.userKey,
      payload,
      createdAtMs: Date.now(),
      bytes: itemBytes
    };
    oldQueue.push(queueItem);
    mailboxes.set(recipientKey, oldQueue);
    queuedBytesTotal += itemBytes;
    try {
      await persistMailboxes();
    } catch (error) {
      oldQueue.splice(oldQueue.findIndex(item => item.id === queueItem.id), 1);
      if (!oldQueue.length) mailboxes.delete(recipientKey);
      queuedBytesTotal = Math.max(0, queuedBytesTotal - itemBytes);
      return replyError(ws, requestId, 'Could not persist encrypted packet');
    }
  }

  if (openRecipients.length) {
    for (const recipient of openRecipients) {
      const ok = sendJson(recipient, {
        type: 'envelope',
        from: ws.userKey,
        payload,
        ...(queueItem ? { deliveryId: queueItem.id } : {})
      });
      if (!ok && queueItem) {
        // The persistent queue entry remains available for reconnect/redelivery.
      }
    }
  }
  sendJson(ws, { type: 'accepted', requestId });
}

async function handleReceived(ws, message) {
  const deliveryId = typeof message.deliveryId === 'string' ? message.deliveryId : '';
  if (!deliveryId || !ws.userKey) return;
  for (const [recipientKey, items] of mailboxes) {
    if (recipientKey !== ws.userKey) continue;
    const index = items.findIndex(item => item.id === deliveryId);
    if (index < 0) return;
    const [removed] = items.splice(index, 1);
    queuedBytesTotal = Math.max(0, queuedBytesTotal - removed.bytes);
    if (!items.length) mailboxes.delete(recipientKey);
    try { await persistMailboxes(); }
    catch (error) { console.error('Could not persist mailbox acknowledgement:', error.message); }
    return;
  }
}

function createRelayServer({ port = PORT, host = '0.0.0.0' } = {}) {
  const server = http.createServer((req, res) => {
    if (req.url === '/healthz') {
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify({ ok: true, service: 'folkchat-relay', protocol: 1 }));
      return;
    }
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('FolkChat relay. WebSocket endpoint: /ws\n');
  });

  const wss = new WebSocketServer({ server, path: WS_PATH, maxPayload: MAX_FRAME_BYTES });
  wss.on('connection', (ws) => {
    if (wss.clients.size > MAX_CONNECTIONS) {
      ws.close(1013, 'server at capacity');
      return;
    }
    ws.rateStartedMs = Date.now();
    ws.rateCount = 0;
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    ws.on('message', async (raw) => {
      try {
        const now = Date.now();
        if (now - ws.rateStartedMs >= 1000) {
          ws.rateStartedMs = now;
          ws.rateCount = 0;
        }
        ws.rateCount += 1;
        if (ws.rateCount > MAX_MESSAGES_PER_SECOND) {
          ws.close(1008, 'rate limit exceeded');
          return;
        }

        const message = JSON.parse(raw.toString('utf8'));
        if (!message || typeof message.type !== 'string') throw new Error('invalid message');

        if (!ws.userKey) {
          if (message.type === 'subscribe') {
            if (challenges.has(ws)) return replyError(ws, '', 'Challenge already issued');
            const key = typeof message.key === 'string' ? message.key.toLowerCase() : '';
            if (!/^[0-9a-f]{64}$/.test(key)) {
              ws.close(1008, 'invalid identity key');
              return;
            }
            const ephemeral = createX25519KeyPair();
            const nonce = crypto.randomBytes(32).toString('hex');
            challenges.set(ws, { key, nonce, privateKey: ephemeral.privateKey, expiresAt: Date.now() + CHALLENGE_TTL_MS });
            sendJson(ws, { type: 'challenge', nonce, serverPubKey: ephemeral.publicKeyHex });
            return;
          }
          if (message.type === 'authenticate') {
            const challenge = challenges.get(ws);
            if (!challenge || Date.now() > challenge.expiresAt || message.key?.toLowerCase() !== challenge.key || message.nonce !== challenge.nonce) {
              ws.close(1008, 'authentication challenge expired or mismatched');
              return;
            }
            const verified = verifyRelayProof({
              serverPrivateKey: challenge.privateKey,
              clientPublicKeyHex: challenge.key,
              nonce: challenge.nonce,
              suppliedProofHex: message.proof
            });
            challenges.delete(ws);
            if (!verified) {
              ws.close(1008, 'identity proof failed');
              return;
            }
            ws.userKey = challenge.key;
            addClient(ws.userKey, ws);
            sendJson(ws, { type: 'subscribed' });
            deliverQueued(ws.userKey, ws);
            return;
          }
          ws.close(1008, 'authenticate before sending');
          return;
        }

        if (message.type === 'envelope') await handleEnvelope(ws, message);
        else if (message.type === 'received') await handleReceived(ws, message);
        else if (message.type === 'pong') ws.isAlive = true;
        else replyError(ws, '', 'Unknown relay command');
      } catch (error) {
        replyError(ws, '', `Malformed relay frame: ${error.message}`);
      }
    });

    ws.on('close', () => removeClient(ws));
    ws.on('error', (error) => console.warn('WebSocket error:', error.message));
  });

  const heartbeat = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) {
        ws.terminate();
        continue;
      }
      ws.isAlive = false;
      try { ws.ping(); } catch { ws.terminate(); }
    }
  }, 25_000);

  server.on('close', () => clearInterval(heartbeat));
  return {
    server,
    wss,
    listen: () => new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(port, host, () => {
        server.off('error', reject);
        resolve(server.address());
      });
    }),
    close: () => new Promise(resolve => {
      clearInterval(heartbeat);
      for (const ws of wss.clients) ws.close(1001, 'server shutdown');
      wss.close(() => server.close(() => resolve()));
    })
  };
}

async function main() {
  await loadMailboxes();
  const relay = createRelayServer();
  const address = await relay.listen();
  console.log(`FolkChat relay listening on ${address.address}:${address.port}${WS_PATH}`);
  console.log(`Health endpoint: http://127.0.0.1:${address.port}/healthz`);
  console.log('Expose this service through TLS and configure the app with wss://your-host/ws.');
}

if (require.main === module) {
  main().catch(error => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = { createRelayServer, loadMailboxes, mailboxes, clientsByKey, verifyRelayProof };
