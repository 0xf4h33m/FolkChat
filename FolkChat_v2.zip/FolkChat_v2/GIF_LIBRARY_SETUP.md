# FolkChat GIF library setup

FolkChat's worldwide GIF picker uses the official Tenor API v2. Tenor requires an API key for the Search and Featured endpoints. See the official docs: https://developers.google.com/tenor/guides/endpoints

## Configure the API key

1. Create a Tenor API key in Google's developer console and review the provider's terms.
2. On your build machine (Linux/Kali), edit `~/.gradle/gradle.properties` and add:

   ```properties
   TENOR_API_KEY=YOUR_TENOR_API_KEY
   ```

   Or build with the `TENOR_API_KEY` environment variable. Do not commit the key in this repository. API keys embedded in Android apps can be extracted, so restrict the key to your Android package/signing certificate where supported and configure usage quotas.
3. Regenerate the Gradle wrapper if needed using `scripts/restore-gradle-wrapper.sh`, install the required Android SDK in Android Studio, then build with `./gradlew :app:assembleDebug`.
4. Install the build. In a chat, tap the attachment icon → **GIF library**. Trending GIFs load automatically; enter a query to search; tap a GIF to download and send it through FolkChat's normal media-transfer flow.

## Privacy and limits

- The picker applies Tenor's `contentfilter=high` setting.
- GIF downloads are HTTPS-only, validate Tenor's host, and are capped at 15 MB.
- The selected GIF is stored under the app's private `files/media` directory before the existing attachment transport sends it.
- Online GIF discovery is blocked while the app reports no internet, Tor routing is enabled, or the routing policy is offline-only. This avoids bypassing those privacy settings with a direct Tenor request.
- A configured API key and network access are required for live GIF results. Local GIF files can still be attached without the key.
