# FolkChat: mobile data, voice notes, and media setup

## 1. Enable internet messaging between different networks

FolkChat cannot connect directly through most carrier NATs from one phone to another. The included `relay-server/` service is required for cross-network messaging; it is intentionally not pointed at an unknown public server by default.

1. Deploy `relay-server/` on a public server with Node.js 20+ or Docker and persistent writable storage. A server reachable on a private LAN is not enough for different countries.
2. Point a DNS name at the server and expose it over TLS (`wss://`). `relay-server/Caddyfile.example` shows a simple Caddy reverse-proxy configuration. The Docker Compose service intentionally binds its internal port to `127.0.0.1:8080`; do not expose plain `ws://` to the public internet.
3. Check `https://YOUR_HOST/healthz` and confirm it returns `{"ok":true,...}`.
4. On **each phone**, open FolkChat → Settings → Relay server and save the same `wss://YOUR_HOST/ws` URL. Wait for Settings to show **Connected · mobile-data messaging ready**. Runtime Settings override the build-time default.
5. For a preconfigured app distribution, set `FOLKCHAT_RELAY_URL=wss://YOUR_HOST/ws` in the build environment or `~/.gradle/gradle.properties` before building. The app will use that URL unless a phone has saved a different one in Settings.
6. Test with Wi-Fi disabled on both devices, then test Wi-Fi-to-cellular and cellular-to-cellular. After a network handoff, FolkChat now closes the stale WebSocket and reconnects/authenticates on the new default network. Messages queued while the recipient is offline should arrive when the recipient reconnects.

If Settings says **Not configured**, **Connecting**, or displays an error, internet messaging is not ready yet. The app will still attempt reachable local Wi-Fi/Bluetooth routes; mobile data being enabled by itself is not a substitute for a relay.

## 2. Send a voice message

Open a chat and tap the microphone icon beside the composer while the text box is empty. Grant microphone permission if prompted. Tap Stop to finish and send the recording; tap Cancel on the recording strip to discard it. If recording fails, the composer displays an error. Voice notes use AAC audio in an M4A container.

## 3. Send photos, videos, and documents

Tap the attachment/paperclip action, select Photo, GIF, Video, or Document, then wait for the recipient to accept/download according to their privacy settings. The receiver can tap **Download** when auto-download is off or limited to Wi-Fi/LAN. Keep the recipient online while chunks transfer; if a transfer fails, use **Retry**. Transfers are bounded to 2 GB and are not yet resumable after an app/process restart.

## 4. What this package does not include

- A deployed relay hostname or server credentials. You must deploy the included service and configure both phones (or preconfigure the URL at build time). The archive cannot contain a live public server because no hosting account/domain was supplied.
- An installable APK. Build the Android app from this project in Android Studio after Gradle sync.
- Internet voice/video calling. Calls in this version require a reachable local LAN; the relay currently carries message/control envelopes and file chunks, but is not a WebRTC/TURN call-media relay.

## 5. Pre-release validation checklist

- Build and install on two real Android devices; test first install and upgrade/migration on test data.
- Confirm both app instances show the relay as Connected over Wi-Fi and cellular.
- Send text in both directions while both phones are cellular, with Wi-Fi disabled.
- Send a 0-byte file, small photo, large photo/video, document, and voice note. Test accepted and declined downloads, Wi-Fi-only and Never policies, disconnect/reconnect, and retry.
- Verify recipient delivery receipts, offline queue redelivery after force-stop/reopen, app lock, calls on LAN, and Tor mode separately.

## App lock and per-chat lock

In Settings, create a 6-digit PIN. Enable **App lock** to gate FolkChat at startup/background/inactivity. To protect only some conversations, open **Settings → Security center → Chat lock** and switch on the desired contacts, or open a chat’s overflow menu and choose **Lock this chat**. Locked conversations require the PIN, are re-locked when the app backgrounds, and hide their latest message text and system notification previews. The chat lock is an app-level UI gate over the encrypted vault, not a separate at-rest encryption key for each conversation.


## Worldwide GIF search

1. Create a Tenor API key using the [Tenor API documentation](https://developers.google.com/tenor/guides/endpoints).
2. Add `TENOR_API_KEY=your_key` to `~/.gradle/gradle.properties`, or set the environment variable when building. Do not commit the key.
3. Rebuild and install on the devices. Open a chat, tap the attachment icon, then **GIF library**. Trending GIFs load first; type a phrase to search. Tap a GIF to download it and send through the app's attachment flow.

The GIF library is intentionally disabled if the app has no internet connection, Tor routing is enabled, or offline-only routing is selected. This avoids creating a direct third-party connection that bypasses those privacy settings.
