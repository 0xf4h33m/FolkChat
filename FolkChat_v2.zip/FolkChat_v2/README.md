# FolkChat v2 — Private. Simple. Yours.

FolkChat is an Android peer-to-peer messenger with a local X25519 identity, encrypted vault storage, authenticated message envelopes, and ChaCha20-Poly1305 protected message contents. It supports local Wi-Fi, Bluetooth LE, and the bundled authenticated WebSocket relay (`relay-server/`). Local/mesh and relay transports still expose network metadata appropriate to the selected route; a relay can observe public-key routing identifiers and traffic timing. FolkChat is **not** described as a zero-knowledge relay system.

> **Important for mobile data/WAN:** cellular-to-cellular or Wi-Fi-to-cellular chat between different countries requires a publicly reachable relay. No public relay is hard-coded because this project has no supplied domain or hosting account. Deploy `relay-server/` behind TLS, then set the same `wss://YOUR_HOST/ws` URL under **Settings → Relay server on both phones**, or build with `FOLKCHAT_RELAY_URL=wss://YOUR_HOST/ws` to preconfigure the app. Until Settings says **Connected**, cross-network messaging is not ready. This source now watches Android's default network and reconnects/authenticates after Wi-Fi ↔ cellular handoffs; it also starts relay-only foreground-app messaging when camera/microphone permissions are denied. Background reliability still needs platform permissions and real-device testing.

> **Protocol compatibility:** the hardened packet format requires the authenticated envelope protocol on both devices. Older versions that send unsigned envelopes are rejected rather than silently accepted as authenticated messages. Back up the app's exportable information before testing a development build, and do not delete the old installation until you have confirmed migration on a test device.

## Cross-country/mobile-data setup

Follow [`WAN_RELAY_SETUP.md`](WAN_RELAY_SETUP.md) to deploy the included relay behind TLS, configure the same `wss://` URL on both phones (or at build time), and test cellular-to-cellular messaging and media. A public relay/domain must be supplied by the app owner; the repository cannot make a private server globally reachable on its own.

## Run locally

**Prerequisite:** [Android Studio](https://developer.android.com/studio) with the Android SDK and a compatible JDK.

1. Open this directory in Android Studio and sync the Gradle project. The supplied archive did not contain the standard Gradle wrapper script/JAR; on Linux/macOS, run `bash scripts/restore-gradle-wrapper.sh` once (this downloads the configured Gradle distribution and regenerates the standard wrapper files), then reopen/sync the project.
2. Install Android SDK Platform 36 (and the requested build tools) through Android Studio's SDK Manager. The app cannot compile with only a JDK.
3. For the optional AI Studio release-signing path, create `.env` from `.env.example` and configure signing as described in `app/build.gradle.kts`. The included root `debug.keystore` is for local debug builds only; do not use it to sign a release. Never commit release signing secrets.
4. Run on an emulator or physical Android device. Local LAN calls require devices on a reachable private IPv4 network; calls are intentionally disabled in Tor privacy mode.

## Features

### Messaging
- Text chat with replies, reactions, edit/delete, pin, star, copy, and forwarding.
- Typing indicators and read receipts with privacy controls.
- Per-chat disappearing-message settings. The selected policy applies to messages created after the policy change, not older messages.
- Archived/muted chats, unread counters, request inbox for unknown senders, and block list.
- Authenticated control messages with replay/staleness checks for edits, deletes, pins, reactions, typing, timer updates, profiles, and call signals.

### Media
- Photo, video, voice-note, and document transfer through bounded chunks, with an enforced 2 GB limit and per-transfer size/index validation.
- Auto-download preferences are applied before writing incoming chunks; incomplete transfers are closed and removed after timeout.
- The media directory is restricted to app-private files and the FileProvider exposes only that directory.
- **Current limitation:** completed media is still stored as plaintext inside the app-private media directory. App-private storage limits access by other ordinary apps, but this is not file-level encryption at rest. Do not treat media-at-rest encryption as implemented.

### Calls
- LAN voice/video using authenticated call setup and ChaCha20-Poly1305 authenticated media frames.
- Per-call ephemeral X25519 key agreement mixed with the long-term identity agreement; ephemeral key material is cleared after setup. Sequence numbers protect against replayed media frames within an active call.
- The media listener accepts only a known contact during the expected call state from a private/link-local IPv4 address. Calls are disabled while Tor privacy mode is enabled.
- Calls require reachable devices on the same private LAN/subnet. There is no TURN server or internet media relay. Validate audio/video behavior on real devices before release.

### Privacy and security
- **Vault:** random 256-bit data key wrapped by an Android Keystore AES-GCM key; the vault itself is authenticated-encrypted. Legacy vault migration occurs only after successful authenticated decryption and parsing. Vault replacement uses a synced temporary file and atomic rename; a failed load refuses to overwrite the original file or generate a replacement identity.
- **App lock:** salted PBKDF2-HMAC-SHA-256 PIN verifier (210,000 iterations), escalating persisted retry delays, cold-start gating, background/inactivity re-checks, optional system biometric, and screenshot protection enabled by default.
- **Chat lock:** lock individual conversations from the chat menu or **Settings → Security center → Chat lock**. Each locked chat asks for the app PIN, never marks messages read until unlock, hides message previews/timestamps/status from the chat list, and suppresses sender/content in message notifications. Per-chat unlock grants are memory-only and clear on app background/process restart/app lock. This is an in-app access gate over the globally encrypted vault, not a separate per-chat encryption key.
- **Identity:** incoming envelopes prove possession of the claimed sender's X25519 private key through a key-agreement-derived HMAC. Old contacts are marked unverified after migration; users must compare fingerprints out of band before marking a contact verified.
- **Safety numbers:** longer fingerprint display than the previous release. A fingerprint is only meaningful when compared with the peer through a trusted separate channel.
- **Backups:** Android cloud backup/device transfer are explicitly excluded.
- **Tor:** off by default, with a SOCKS5 availability probe and fail-closed routing when Tor mode is enabled. Relay URLs should use `wss://`; plain `ws://` is only allowed for `.onion` services with the explicit Tor route. Calls and local broadcast discovery are disabled in Tor privacy mode.

### Networking
- Routing policy: auto, forced offline mesh, or forced relay. In Auto mode the relay is used only when a relay URL is configured and authenticated; otherwise FolkChat falls back to reachable local routes.
- Internet relay service is included under `relay-server/`. It requires a Node.js 20+ public host (or Docker), persistent storage, public DNS, and TLS termination. Read `relay-server/README.md` and set the resulting `wss://HOST/ws` URL on every device or set `FOLKCHAT_RELAY_URL` at build time. Mobile data alone cannot bypass carrier NAT/firewalls or create a public relay automatically. After changing default networks, the client reconnects and re-authenticates over the newly selected network.
- Wi-Fi socket transport uses read timeouts, a connection cap, bounded length-prefixed frames, and multiple-frame reads per connection.
- Bluetooth GATT writes await connection/write completion rather than reporting success before a write finishes. Authenticated packet acceptance is still a separate step from a local transport write.
- Delivery state becomes delivered only after an authenticated recipient receipt. A local TCP/Bluetooth transport acknowledgement alone is not treated as delivery.
- Manual Wi-Fi peer entries are not used for contact-directed delivery until the endpoint can be explicitly bound to a verified contact; this prevents one manually configured peer from matching every contact.

### Design
- **Warm Sage Light is the new-install default**: warm ivory canvases, sage surfaces, forest-green actions, rounded conversation tiles, a privacy highlight card, and refined profile/settings panels. Deep Forest Dark and System modes remain available.

## Important known limitations before production

- There is no full Room database migration yet. The encrypted JSON vault remains a single snapshot file; frequently changing state can still cause noticeable work on large histories, although media checkpoints and retry loops have been reduced.
- Media files are not encrypted individually at rest (see above).
- Text message encryption still uses the current long-term identity-based envelope scheme; there is no Double Ratchet for text, so text forward secrecy and post-compromise recovery are not provided.
- The relay is not metadata-blind: it can see routing public keys/identifiers, timing, and traffic volumes, though message payloads are encrypted.
- Bluetooth bonding is not required by a dedicated pairing workflow yet. Packet authentication does not make the radio link confidential by itself.
- Full Android Gradle build, device-level migration, Tor/Orbot integration, background-call, media transfer on multiple routes, relay deployment, and multi-device interoperability tests are required before a release. A source review is not a substitute for those tests.
- Global text/media networking requires a deployed public relay. Internet voice/video call media remains LAN-only; secure global calls need a WebRTC/TURN media transport, not just a WebSocket message relay.

## Technology

Kotlin · Jetpack Compose · Material 3 · BouncyCastle (X25519, ChaCha20-Poly1305, HKDF, HMAC, Ed25519 primitives) · CameraX · Coil · OkHttp · AndroidX Biometric · minSdk 24 / targetSdk 36.

## UI redesign

The primary screens now share a premium Folk Forest visual system: warm ivory backgrounds, pale sage panels, deep forest actions, consistent rounded shapes, clearer spacing, a custom brand header, a privacy overview card, rounded chat-list tiles, a pill-style bottom bar, a softer message composer, and outlined profile/settings cards. Existing screen callbacks and ViewModel actions remain connected rather than using static mockup content.

## Worldwide GIF library and app logo

FolkChat now uses the uploaded transparent emblem for the welcome screen, home header, adaptive launcher icon, and legacy launcher icons. The conversation attachment sheet has an animated GIF picker with trending results, debounced search, preview tiles, bounded downloads (15 MB maximum), and sends selected GIFs through FolkChat's existing attachment-transfer pipeline. The chat uses the existing Coil animated-image decoder to play completed GIF attachments.

GIF discovery is powered by the [official Tenor API v2](https://developers.google.com/tenor/guides/endpoints). A Tenor API key is required for worldwide search; no private key is included in the source. Set it in `~/.gradle/gradle.properties` (not this repository):

```properties
TENOR_API_KEY=YOUR_TENOR_API_KEY
```

Alternatively, pass it to the build as an environment variable: `TENOR_API_KEY=YOUR_TENOR_API_KEY ./gradlew :app:assembleDebug`. Google/Android API keys embedded in apps can be extracted, so restrict the key to this package/signing certificate and configure quotas. The picker uses the high content-safety filter by default. Online GIF lookup is disabled while internet is unavailable, Tor routing is enabled, or offline-only routing is selected, so GIF requests do not bypass the app's privacy route. GIFs are downloaded over HTTPS from Tenor, then transferred as normal FolkChat attachments.
