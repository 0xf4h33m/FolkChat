# FolkChat cross-country / mobile-data setup

FolkChat can send encrypted messages and media between phones on different carriers or in different countries **after both phones connect to the same public relay**. This archive includes the relay server; it does not include a running public server, DNS name, TLS certificate, or hosting account.

## 1. Deploy one public relay

You need a public VPS/server, a domain or subdomain, Docker, and a TLS reverse proxy. Example hostname: `relay.your-domain.example` (replace it with a domain you control).

1. Point an `A`/`AAAA` DNS record for that host at the server.
2. On the server, install Docker + the Docker Compose plugin and copy the `relay-server/` folder.
3. Run:

   ```bash
   cd relay-server
   docker compose up --build -d
   docker compose logs -f
   ```

4. Install Caddy on the host and configure it with the included `relay-server/Caddyfile.example`, replacing the sample host with your real DNS name:

   ```caddy
   relay.your-domain.example {
       reverse_proxy 127.0.0.1:8080
   }
   ```

   Caddy must be able to receive inbound ports 80 and 443 and obtain a valid TLS certificate. Keep the relay's port 8080 bound to loopback; do not expose plain WebSocket traffic publicly.

5. Verify the server responds over HTTPS:

   ```bash
   curl -fsS https://relay.your-domain.example/healthz
   ```

   Expect JSON containing `"ok":true`. The client WebSocket endpoint is `wss://relay.your-domain.example/ws`.

The Docker Compose file mounts `/data` as a persistent volume for the relay's queued encrypted messages. Keep this volume when updating the service.

## 2. Configure both phones

On **each** phone, open **FolkChat → Settings → Network & routing → Relay server** and save the same full address, for example `wss://relay.your-domain.example/ws`. The exact hostname and path must match. Wait until the relay status says **Connected · mobile-data messaging ready** on both devices.

To embed the relay address into a build instead of typing it on each phone, set a Gradle property or environment variable before compiling:

```properties
FOLKCHAT_RELAY_URL=wss://relay.your-domain.example/ws
```

For the environment-variable route:

```bash
FOLKCHAT_RELAY_URL=wss://relay.your-domain.example/ws ./gradlew :app:assembleDebug
```

A nonblank URL saved in each phone's Settings overrides the build-time URL. If the URL is empty in both places, the app cannot message across the public internet.

## 3. Verify real WAN transfer

1. Add each other's FolkChat identity using the in-app QR/contact flow and compare the identity fingerprint through a trusted separate channel.
2. Send a text while phone A is on cellular and phone B is on Wi-Fi.
3. Reply in the opposite direction, then turn Wi-Fi off on both phones and send phone-to-phone over cellular.
4. Switch one active phone from Wi-Fi to cellular. The client is coded to reconnect and authenticate after Android reports a default-network change; verify it shows Connected again.
5. Send a small photo, a larger file, and a voice note. The recipient must be online and accept/download media according to their settings. If the network drops during a file, use Retry; transfer resume from the exact byte offset after process restart is not implemented yet.
6. Close the recipient app, send a text, then reopen it and confirm queued delivery. Keep the relay's persistent `/data` volume.

## What is and is not global

- **Text messages:** routed through the relay and can be queued while the recipient is offline, within configured mailbox limits.
- **Photo/video/document/voice-note bytes:** sent as encrypted chunks through the relay while the transfer is accepted and the recipient is reachable. If interrupted, retry is available; durable partial-file resume is not yet implemented.
- **Voice/video calls:** the current media transport is LAN/private-network oriented. The WebSocket relay is not a TURN/WebRTC media server. Cross-country calls need a separate WebRTC + STUN/TURN implementation/deployment.

Never assume WAN works just because Android says “Mobile data on”; use the authenticated relay status and the two-phone tests above. The relay can see destination public-key routing identifiers, packet sizes and timing, but message payloads are encrypted. The server must be maintained and monitored like any internet-facing service.
