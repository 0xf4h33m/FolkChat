# FolkChat security hardening notes

This note describes changes present in this source snapshot and items that remain open. A static review is not a substitute for a signed Android build and end-to-end device testing.

## Changes in this snapshot

- Replaced deterministic new-install vault encryption key derivation with a random 256-bit data key wrapped by a device Android Keystore AES-GCM key. Removed the deterministic fallback for new installs.
- Added legacy vault migration after authenticated decryption and full JSON parsing. Vault/key files are written to same-directory temporary files, synced, and atomically replaced. An unreadable vault is preserved and never overwritten by a newly generated identity.
- Upgraded PIN verification to salted PBKDF2-HMAC-SHA-256 (210,000 iterations), persisted escalating retry lockouts, moved PIN verification to IO, and re-checks idle lock state on app resume. Fixed cold-start enforcement so an early resume cannot clear the lock before authentication. Screenshot protection defaults on.
- Added persistent per-chat lock controls in Security Settings and the chat overflow menu. Locked conversations use the rate-limited PIN verifier without unlocking the whole app, avoid marking messages read before unlock, hide list previews/timestamps/outgoing status, and suppress both sender and body in system notifications. Per-chat unlock grants are memory-only and clear on background, process start, or app-lock activation. The lock list is persisted in the encrypted vault by public-key rather than contact name.
- Added authenticated packet envelopes derived from X25519 shared-secret possession proofs, reject old unsigned envelope packets, constrain ownership of edit/delete/pin commands, limit stale/replayed control updates, and wait for authenticated recipient receipts before marking a text message delivered.
- Reset legacy contact-verification flags to unverified because earlier versions marked contacts verified without a fingerprint comparison. Fingerprints now display six four-digit groups, and marking verified is an explicit user action.
- Bounded TCP connections/timeouts, socket frame sizes/counts and L1 reassembly sessions; TCP receive handles multiple frames on one connection. Bluetooth sends wait for connection, service discovery and write callbacks.
- Bound media transfer IDs to safe characters, validate sender/contact/message ownership and chunk metadata, cap attachment size and chunk counts, scope in-progress transfers to the sender, ignore duplicate chunk overwrites, respect Never/Wi-Fi-only download settings, and expire incomplete streams. Full encrypted-vault checkpoints occur every 32 chunks instead of on every chunk.
- Added authenticated call setup, ephemeral X25519 media key agreement mixed with static identity DH, ChaCha20-Poly1305 frame protection and sequence/replay checks. Call socket acceptance is gated by call state, known contact, and private IPv4 source; calls and radio discovery are disabled in Tor privacy mode.
- Detects a local SOCKS5 listener on IO rather than assuming port 9050; restricts relay URLs and cleartext; removes a boot permission with no corresponding receiver; avoids duplicate service collectors; scopes camera/microphone foreground service types to active calls.
- Uses the warm sage/ivory theme as the new-install default, enables screenshot protection by default, narrows FileProvider paths to the private media directory, and makes release minification enabled.
- Adds the bundled authenticated WebSocket relay under `relay-server/`, with bounded encrypted offline mailboxes, durable writes, identity challenge authentication, and delivery acknowledgements. The Android client retains queued relay packets until the transport consumer finishes processing the envelope.
- Adds explicit in-chat voice recording errors and cleans up MediaRecorder/file resources if permission or recorder startup fails. The composer visibly toggles between microphone, send, stop, and save-edit actions.
- Fixes the attachment picker lifecycle so selecting a file does not cancel its IO copy, and adds explicit download/retry controls for incoming media that was not auto-downloaded.
- Updates documentation and settings copy so the relay is not falsely described as zero-knowledge and explains that cellular messaging needs a reachable deployed relay configured on both devices.

## UI polish in this snapshot

- Redesigned the home header, navigation bar, privacy highlight, request row, conversation tiles, chat composer, profile identity panel, and settings cards in the sage/ivory + forest-green visual system. Existing ViewModel-backed click handlers and controls are retained.

## Known limitations / release blockers

- The app lock and chat lock are UI access gates. The Android Keystore wrapping key is **not** bound to per-use biometric/PIN authentication; a running/compromised app process can still use the vault key. Chat lock does not add a separate cryptographic key per conversation. A full cryptographic unlock flow requires restructuring startup so encrypted vault data is not loaded until an authentication gate succeeds.
- Completed media is still plaintext at rest under the app-private `files/media` directory. Private storage is not the same as file-level encryption.
- Text messages do not have a Double Ratchet or independent per-message forward secrecy. Call media uses ephemeral DH, but the protocol still depends on successful, authenticated long-term identity agreement at setup.
- The relay still learns subscription/routing public keys, timing, volume and online state. Challenge authentication proves the connecting device controls the claimed identity key; it does not hide routing metadata or make the relay zero-knowledge.
- Discovery tags are rotating but derived from public identity material; someone who already knows a public key can correlate its predictable time-slot tags. No dedicated Bluetooth bonding/pairing flow is enforced.
- Storage remains a single encrypted JSON snapshot instead of Room/SQLite. The main-thread startup vault load and snapshot serialization can still cause latency with large histories. Checkpointing reduces transfer churn but is not a database migration.
- The media protocol is chunked and bounded but does not implement resumable partial transfers across app/process restarts.
- A corrupt/unreadable vault is preserved and writes fail closed, but a polished recovery/import screen is not yet implemented.
- Device-specific Android behavior remains unverified here: calls in background, permission transitions, Tor/Orbot routing, migration of legacy installs, Bluetooth GATT interoperability, and Android 15/16 foreground service restrictions must be tested on real devices.

## Protocol and compatibility

The authenticated envelope requires both sender and recipient to run the hardened protocol version. Unsigned messages from older builds are rejected. Test migration and two-device compatibility on non-production installs before replacing a daily-use build.

## Validation performed for this snapshot

- XML resources and manifest are parsed for well-formedness.
- The pure Kotlin L1 framing implementation is compiled and its bounded framing/reassembly behavior is exercised separately where possible.
- Relay JavaScript syntax checks and the X25519/HMAC challenge unit test were run successfully (`node --check` and `npm test`; 1 test passed). Installing the `ws` dependency timed out in this environment, so the live WebSocket server was not integration-tested here.
- XML resources/manifest are well-formed and Kotlin sources were passed through the local compiler parser check (no syntax/parse errors; full compilation is not possible without Android/Compose/OkHttp/Gradle dependencies). The new chat-lock persistence, PIN-gate, list-preview masking and notification-masking paths were checked by source review; full UI behavior still requires an Android build/device test.
- A full Android Gradle build and emulator/device tests were **not** run in this environment because the project has no `gradlew` wrapper script/JAR, no system Gradle executable, and no Android SDK was available.


## GIF library and updated FolkChat emblem

- Replaced the old logo asset with the user-provided transparent FolkChat emblem. It is used by the welcome screen, main header, adaptive launcher icon, and density-specific legacy launcher icons.
- Added the Tenor v2 animated GIF picker to the chat attachment sheet. It supports trending results, debounced search, animated previews, high content filtering, tap-to-download, and sends the resulting local file through the existing attachment transfer pipeline. Downloads are HTTPS-only, host-validated against Tenor, and capped at 15 MB.
- Added build-time `TENOR_API_KEY` configuration. The key is deliberately not included in this source archive; see `GIF_LIBRARY_SETUP.md`.
- Online GIF discovery is disabled while internet is unavailable, Tor routing is enabled, or offline-only routing is selected.
- Added Compose size/visibility transitions to the picker and retained the welcome screen's animated halo.

Validation for this change is static only: resource XML and archive integrity can be checked in this environment, but the complete Android/Compose build and device-side GIF send/receive flow still require Android Studio/SDK and a configured API key.


## WAN/mobile-data reliability update

- Added `FOLKCHAT_RELAY_URL` as an optional build-time default, with a saved per-device relay URL taking precedence. No invented public endpoint is embedded; deploy the included relay first.
- Added an Android default-network callback to the relay client. On Wi-Fi/cellular default-network changes it debounces callbacks, clears stale pending sends, closes the old WebSocket, and reconnects/authenticates over the current network.
- Fixed startup behavior so the background transport service is started again when permissions are already granted on app launch. Camera/microphone grants no longer block internet messaging: when Bluetooth/local-link permissions are missing, the app uses relay-only while the UI is foreground.
- Bumped app version to 2.0 / versionCode 2.
- Mobile/WAN limitations remain: a public relay hostname and TLS deployment are required, and internet voice/video call media still needs WebRTC/TURN infrastructure. Cross-country text and file transfer should be verified on two real devices after relay deployment.
